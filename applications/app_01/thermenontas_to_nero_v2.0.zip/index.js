(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FFFFFF","rgba(255,255,255,0)"],[0,1],0,0,0,0,0,120.9).s().p("AsUNPQlHlegBnxQABnwFHlfQECkVFXg7QBagPBhAAQHOAAFHFfQFHFfABHwQgBHwlHFfQiWCiixBXQjTBnj7AAQnNAAlHlgg");
	this.shape.setTransform(48.2,4.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-63.5,-115.5,223.3,239.8);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FFFFFF","rgba(255,255,255,0)"],[0,1],0,0,0,0,0,61.9).s().p("AmvGWQiyioAAjuQgBiCA3huQAshZBQhMQCzioD8AAQD9AACzCoQCGB+AhCmQALA3AAA6QAADuiyCoQizCoj9AAQj8AAiziog");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-61,-57.4,122.1,114.8);


(lib.Tween3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D5FFFF").ss(0.5,1,1).p("AxVgBQAAiMFFhkQFFhiHLAAQHLAAFFBjQFFBkABCMQAACMlGBkQlEBknMAAQnLAAlFhlQlFhkAAiMg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-111.9,-35,224,70);


(lib.text9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AASAvIAAgrIgkAAIAAArIgQAAIAAhdIAQAAIAAAlIAkAAIAAglIARAAIAABdg");
	this.shape.setTransform(61,5.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AghAvIAAgGIAhgrIgegmIAAgGIBAAAIAAAPIgjAAIAUAbIgZAkIAnAAIAAAPg");
	this.shape_1.setTransform(52.7,5.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAbAvIgsg6IAAA5IgQAAIAAhcIAIAAIArA3IAAg3IAQAAIAABdg");
	this.shape_2.setTransform(44.7,5.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAXAvIgHgTIgfAAIgHATIgSAAIAlhdIAGAAIAmBdgAgKAQIAVAAIgLgig");
	this.shape_3.setTransform(36.2,5.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgCAvIgTgyIgKAxIgPAAIAShcIAJAAIATA9IAUg9IAJAAIASBcIgQAAIgJgxIgTAyg");
	this.shape_4.setTransform(27.3,5.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgeAvIAAhcIAUgBQAUAAALAHQAKAHAAAOQAAAfglAAIgHAAIAAAigAgNgfIAAAeIAGAAQALAAAFgDQAFgEAAgJQAAgOgWAAIgFAAg");
	this.shape_5.setTransform(18.8,5.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgdAvIAAhdIA7AAIAAAPIgqAAIAAAWIAeAAIAAANIgeAAIAAAcIApAAIAAAPg");
	this.shape_6.setTransform(11.3,5.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgeAiQgLgNAAgVQAAgTAMgOQALgOATAAQATAAALANQALAMAAAWQAAAUgLAOQgLAOgUAAQgUAAgKgOgAgSgXQgGAJAAAOQAAAQAGAJQAHAIALAAQAMABAHgKQAGgJAAgPQAAghgZAAQgLAAgHAKgAgRAGIAAgNIAiAAIAAANg");
	this.shape_7.setTransform(2.7,5.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4,-4.1,87.8,34.2);


(lib.Symbol33copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(22.2,0,1).p("AAAAAIC0izAizizICzCzAizC0ICzi0IC0C0");
	this.shape.setTransform(1.9,0.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").ss(6,0,1).p("AIuAAQAADnikCjQijCkjnAAQjmAAijikQikijAAjnQAAjmCkijQCjikDmAAQDnAACjCkQCkCjAADmg");

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#549FAC").s().p("AmJGKQijijAAjnQAAjmCjijQCjijDmAAQDnAACjCjQCjCjAADmQAADnijCjQijCjjnAAQjmAAijijg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-58.7,-58.7,117.5,117.5);


(lib.Symbol7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#61757E").s().p("ADgHOMhSLAAAIAAubMBSLAAAMBLMAAAIAAObg");
	this.shape.setTransform(612.4,-46.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol7, new cjs.Rectangle(108.8,-92.3,1007.2,92.3), null);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.749)").s().p("ABEAeQgtgPgxgMQhBgPgcABQgcACgOgGQgPgHAcgLQAYgKBCAFIBlAHIBHAAQAfABAMAIQAMAIgZACIgzAEQghAGBhAhQAaAJgpAAIgEAAQgnAAgfgKg");
	this.shape.setTransform(-32,-57.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AiHArQgGgJAPgJQARgKAegCQAqgDBKgmQA/ggAQAKQAnAYgiASQgXANh3AhQg1AQgdAAQgYAAgIgLg");
	this.shape_1.setTransform(-2.5,61);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Layer_4
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#54ADE2").s().p("AhzBQQABgOA7gHQA1gIA4hIIAjgyQAPgVAFgBQADABAAAFQAOBXgkApQgfAlhQALQgcAFgSAAQgwAAAAgOg");
	this.shape_2.setTransform(44.5,39.4);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	// Layer_5
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#54ADE2").s().p("AglA/QAXgoAPhGQANg2AIAAQAEAAAEAEQAXAVABAVQABAXgYAuQgPAegcAeQgaAcgLAAQgLAAAXgng");
	this.shape_3.setTransform(49.1,-31.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

	// Layer_6
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(121,197,235,0.686)").s().p("AivBrQAAgaAVgkQAfg1AogiQAjgeAlgMQAPgEAMAAQANAAALAHIAWARIAHACQAIAAAMgKIAXgYQAQgRAKgHQAOgLALAAIAEABQAZADgwA4QgkArgoAfQgLAJgGAAQgHAAgJgOQgJgPgLAAQgPAAgWAVIhKBVQgmAqgXAAQgSAAAAgYg");
	this.shape_4.setTransform(11.5,-31.4);

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(1));

	// Layer_7
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(121,197,235,0.71)").s().p("ABCBIQgdgSgWgKQgwgSgVgQQgmgagThCIAAgBQAngOBWgCQAQBIAxArQgSAXAfAgQAOAPAFAOIgtgcg");
	this.shape_5.setTransform(-46.5,44.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(1));

	// Layer_8
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(121,197,235,0.71)").s().p("AB8IgIgcgQQgGgOgNgPQgfghASgXIAQANQAcAVASAjQARAigOAAIgFgCgAiBCuQAMh6gHgrQgJgzAFiZQAGibgFggQgJg8ADguQAEg0ARgFIAFAAQAEAAAYAQQAaAQAvAEQAFAEgMAMQgYAXgHAJQguA6APBOQANBAArCfQAiCKgHA2IgNBsQgHBLAMA2QhXACgnAOQgPg3AMhyg");
	this.shape_6.setTransform(-45,1.8);

	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(1));

	// Layer_9
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(121,197,235,0.71)").s().p("AghglQAcACAiAAIADAAIACA/QgiAEgeAGQgDgmAAglg");
	this.shape_7.setTransform(-27.8,38.9);

	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(1));

	// Layer_10
	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(121,197,235,0.71)").s().p("ABNBwQg4glhNggIgBAAIAAgBIgBAAQhAgbgYhYQAAgNAagKIAAABQATBCAlAbQAWAPAwASQAWAKAdASIAtAcQAKAageAAgAAFhwIATAAQA3AAAzAFIAOABQgBAlAEAnQg9AOgQATQgxgrgQhIg");
	this.shape_8.setTransform(-45.6,45.8);

	this.timeline.addTween(cjs.Tween.get(this.shape_8).wait(1));

	// Layer_11
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(121,197,235,0.71)").s().p("AjDgSQBJgBBggLIBsgNIAZgBQA3AAAYAKQAXALgfAKQgZAIhOAKQhPAMgiAKQgQAFgwAEIhbAJg");
	this.shape_9.setTransform(-5,37.2);

	this.timeline.addTween(cjs.Tween.get(this.shape_9).wait(1));

	// Layer_12
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(255,255,255,0.749)").s().p("ACoAlQhIgFgaAAQglAAgJgKQgJgJAQgNQAMgKg/ADQhVAGgkABQhUADApgMQAlgMBTgMQBDgKBFAQQA8AOAyAdQAmAVgxAAIgDAAg");
	this.shape_10.setTransform(20.7,-61.2);

	this.timeline.addTween(cjs.Tween.get(this.shape_10).wait(1));

	// Layer_13
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(255,255,255,0.808)").s().p("AiKEjQgPgCADgRQAEgSAZgcQAngsgJg2IgIgsQgBgaAMgZQAphZAxhSQBIh1AzgeQAvgcgnB+QgmB6g3BMQgiAwgKA/QgLA9gjAtQgvA/gkAAIgFAAg");
	this.shape_11.setTransform(37.1,7.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_11).wait(1));

	// Layer_14
	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(255,255,255,0.749)").s().p("AAUDZQgMgGgHhwQgGhkAChCQACgrgZgqQgXgnABgEQAKgjAvAYQAwAYgKAjQgJAkgFCvQgFCZgIAAIAAAAg");
	this.shape_12.setTransform(-39.1,-26.9);

	this.timeline.addTween(cjs.Tween.get(this.shape_12).wait(1));

	// Layer_15
	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(121,197,235,0.71)").s().p("AkMJhQgfgJgYhAQgWg8gIhSQAfgFAhgFIAEA4QAFAwAbBMQARAvgSAAQgFAAgJgCgAkmFAQgjAAgbgCQAAgVACgYQAJhSgKiVQgDgsgVjeQgKhrAPhLQAUhEADgkQACgRhTgRQhfgTgOgLQgWgQAkAAQAgAAAmAKQBoAcAbAGQBIAQA9AAQAaAAAWgCIEIgZQC/gUBDgYQAYgJAaAAQA4AAAtAqIANAkIABAGQAEAKAEAcQgLgCgOgMQgOgNgKgUQgOgcgpAAQgZAAgoAKQgZAGg4ARQg+AUg8ADQhaADhSAFQiBAIgYAIQggAKg2A2QgyAygMBRQgIA4AHB7QAEA7AACNIACDlg");
	this.shape_13.setTransform(4.5,3.3);

	this.timeline.addTween(cjs.Tween.get(this.shape_13).wait(1));

	// Layer_16
	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(121,197,235,0.569)").s().p("AkJHyQhZgMgVgYQgJgJAIgHQAIgHAWAAIAVACQAaADAtAAQBJAAB0gHQBbgGBAgGQBHgIAfghQAngogXhMQgriPgHgyQgSh/AuhsQAlhXgKiVQgEg+ADgSQAFgfAYAAQAJAAAQgCQANAAANAMQARAPAXApQAfA5gBBYQgBA0gNByIgMC1QgBBvAeBcQAgBkgfA4QgaAshNAcQgmAOhVAIQhNAGhhAAQiKAAhdgMgAE/EwIgjAxQg4BKg2AHQg7AHAAAOQgBAOAxAAQASAAAcgEQBQgMAgglQAjgqgNhXQgBgFgDAAQgEAAgQAWgAEWl+QgQBGgYApQgXAnAMAAQAKAAAbgcQAcgeAQgfQAYgugCgYQgBgUgXgWQgEgEgEAAQgIAAgMA3g");
	this.shape_14.setTransform(21.4,1.9);

	this.timeline.addTween(cjs.Tween.get(this.shape_14).wait(1));

	// Layer_17
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(176,224,245,0.678)").s().p("AigKnQhdgGgkgfQg2gvgZgRQg9grhTgiQhUghgPiKQgGgwAChIIAEhxQABgrgHj7QgGjbAGhWQAHhgBsgZQAsgLCQAAQA6AABcgOQCCgTBXgIQB5gLBWATQAhAHCPAzQBkAjAUAQQAOAMARA1QAQAtAEChQAECJgFCiQgCBfAQDDQAGCggyA1QguAyi8AZIiaAVQhVAOgyATQhaAkhdAAIgegBg");

	this.timeline.addTween(cjs.Tween.get(this.shape_15).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol2, new cjs.Rectangle(-62.1,-68,124.2,136.1), null);


(lib.sprite78 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.sprite62copy5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2C7096").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape.setTransform(33.5,95.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2E769B").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_1.setTransform(33.5,95.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#317CA1").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_2.setTransform(33.5,95.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#3382A6").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_3.setTransform(33.5,95.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#3588AC").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_4.setTransform(33.5,95.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#378EB1").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_5.setTransform(33.5,95.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#3A94B7").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_6.setTransform(33.5,95.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#3C9BBC").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_7.setTransform(33.5,95.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#3EA1C1").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_8.setTransform(33.5,95.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#41A7C7").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_9.setTransform(33.5,95.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#43ADCC").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_10.setTransform(33.5,95.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#45B3D2").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_11.setTransform(33.5,95.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#47B9D7").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_12.setTransform(33.5,95.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#4ABFDD").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_13.setTransform(33.5,95.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#4CC5E2").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_14.setTransform(33.5,95.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#48BAD8").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_15.setTransform(33.5,95.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#46B4D3").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_16.setTransform(33.5,95.7);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#43AECE").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_17.setTransform(33.5,95.7);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#41A9C9").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_18.setTransform(33.5,95.7);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#3FA3C4").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_19.setTransform(33.5,95.7);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#3D9DBF").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_20.setTransform(33.5,95.7);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#3B98B9").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_21.setTransform(33.5,95.7);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#3992B4").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_22.setTransform(33.5,95.7);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#378CAF").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_23.setTransform(33.5,95.7);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#3587AA").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_24.setTransform(33.5,95.7);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#3281A5").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_25.setTransform(33.5,95.7);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#307BA0").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_26.setTransform(33.5,95.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).wait(1));

	// Layer 1
	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(0,0,0,0.6)").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_27.setTransform(33.5,95.7);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.lf(["rgba(132,121,123,0.8)","rgba(255,255,255,0.8)","#808080"],[0,0.506,1],-93,0,93.1,0).s().p("AuhEyIEOpjIUnAAIEPJjgAt9EbIb8AAIkEo1Iz0AAg");
	this.shape_28.setTransform(33.5,95.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27}]}).wait(30));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-59.6,65.2,186.1,61.1);


(lib.sprite62copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(132,121,123,0.8)","rgba(255,255,255,0.8)","#808080"],[0,0.506,1],-93,0,93.1,0).s().p("AuiEyIEPpjIUnAAIEPJjgAt+EbIb9AAIkEo1Iz1AAg");
	this.shape.setTransform(-0.9,-3.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(0,0,0,0.6)").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_1.setTransform(-0.9,-3.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.sprite62copy3, new cjs.Rectangle(-93.9,-33.8,186.1,61.2), null);


(lib.sprite62copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#965656").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape.setTransform(33.5,95.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#9A5858").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_1.setTransform(33.5,95.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#9E5A5A").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_2.setTransform(33.5,95.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#A15D5D").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_3.setTransform(33.5,95.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#A55F5F").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_4.setTransform(33.5,95.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#A96161").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_5.setTransform(33.5,95.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#AD6363").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_6.setTransform(33.5,95.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#B16666").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_7.setTransform(33.5,95.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#B46868").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_8.setTransform(33.5,95.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#B86A6A").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_9.setTransform(33.5,95.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#BC6C6C").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_10.setTransform(33.5,95.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#C06E6E").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_11.setTransform(33.5,95.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#C37171").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_12.setTransform(33.5,95.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#C77373").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_13.setTransform(33.5,95.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#CB7575").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_14.setTransform(33.5,95.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#C47171").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_15.setTransform(33.5,95.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#C06F6F").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_16.setTransform(33.5,95.7);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#BD6D6D").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_17.setTransform(33.5,95.7);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#B96B6B").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_18.setTransform(33.5,95.7);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#B66969").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_19.setTransform(33.5,95.7);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#B26767").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_20.setTransform(33.5,95.7);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#AF6464").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_21.setTransform(33.5,95.7);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#AB6262").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_22.setTransform(33.5,95.7);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#A86060").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_23.setTransform(33.5,95.7);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#A45E5E").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_24.setTransform(33.5,95.7);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#A15C5C").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_25.setTransform(33.5,95.7);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#9D5A5A").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_26.setTransform(33.5,95.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).wait(1));

	// Layer 1
	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(0,0,0,0.6)").s().p("At+EbIEEo1IT1AAIEEI1g");
	this.shape_27.setTransform(33.5,95.7);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.lf(["rgba(132,121,123,0.8)","rgba(255,255,255,0.8)","#808080"],[0,0.506,1],-93,0,93.1,0).s().p("AuhEyIEOpjIUnAAIEPJjgAt9EbIb8AAIkEo1Iz0AAg");
	this.shape_28.setTransform(33.5,95.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27}]}).wait(30));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-59.6,65.2,186.1,61.1);


(lib.shape134 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D3ECFE").ss(1,0,0,3).p("AAAh/IAAAIIAAD3");
	this.shape.setTransform(-100,-6.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#D3ECFE").ss(0.2,0,0,3).p("ARMh4QgBA4gzAyQhPBLi/A9QlDBnnHAAQnFAAlEhnQjBg+hNhLQgzgygBg4ARMh4IAAgIQgDiOk/hmQlBhmnJAAQnHAAlCBmQk+BmgECOAxLB+QACCPE/BmQFDBoHHAAQHIAAFBhnQFBhmACiPIAAj3");
	this.shape_1.setTransform(10,-6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(189,233,253,0.902)").s().p("AsKFzQk/hmgCiPIAAj3IAAgHQAFiOE9hmQFChmHHAAQHIAAFCBmQE/BmADCOIAAAIQgBA4gzAyQhQBLi+A9QlDBnnHAAQnFAAlEhnQjBg+hNhLQgzgygBg4QABA4AzAyQBNBLDBA+QFEBnHFAAQHHAAFDhnQC+g9BQhLQAzgyABg4IAAD3QgCCPlBBmQlBBnnIAAQnHAAlDhog");
	this.shape_2.setTransform(10,-6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-101,-54.5,222,97.1);


(lib.shape126 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ah2OIIgcgdIgDgLQgIgYAHgZIAFgEIADgDIAAgIIACgDQAHgNADgOIAFgEIADgDIAAgIQgBgHADgIIAHgCIAFAAIAAABIAIABIAEAEIABAMQAJAoAGAqIAEAEIABADIABAMQABAVgEAUQgNAIgPAAQgGAAgHgCgAhsMHIgCAFIgFAIIAAAHIgKAMIAAAHIgKATIAAATIAFAHIAAAIIASASIARAAIACgCQgBg3gMg2IAAAAIgCABgAnCthIgBgEIAAgHIABgEIAEgEIBagOIDPgHIG2ALIBTgJIAmABIACAAIAMgBIgCACIAWAEIAHAIIABADIgBAHIgDAEIgEAEQgiAMgkACQk1ARk0gVIgIAAIhZAJQgTAEgSAAQgnAAgigRgAFItlIApgBQAggBAegNIgegDIhrAGQiiABiggDIh1gJQhSgJhQANIhzAQIBQAFIA+gGQEtAKEzgGg");
	this.shape.setTransform(45.2,90.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,90.4,181.2);


(lib.shape125 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AiCKIIgTgWIAAgWIAGgIIAAgDQACgUAHgSIAAgEIAAgHIAUgiIAAgLIAGgIIgBgDQgEgSAHgQIAHgDIAAABIAIAGIABADIADAeQAOATACAXIACADIAHAIIAAAEIABALIAEAEIABA4QgRAggiAAQgKAAgNgDgAhhH+QgMAdgHAeIgFAHIAAAMIgFAHIAAAIQgFAFAAAGQAEAJAJAGIAjgEIACgGIAIgIIAAgHQgBgRACgRIgCgDQgFgJACgKIgKgMIgBgDIgGgXIgBgBIgCABgAnBpaIgFgBIgFgGIgDgEIAAgLIABgEIAGgBQCPgFCPADQA6ABA7gEIGDgQIBPAGIAKgBIAcAGIAIADIABACIACAIIgDADIgGADIgBAAIgJgCIgDABIgMALIgLAHIhwACQgvACgxgKIhDgFQiPALiSgCIgnABIgGAGIgwAEQgmAFgoAAQhCAAhCgNgAjCpnIAFgEIj+AAQB9AZB8gVgAGipsIADgEIgBgCIgGgCIgjgGQi1gQiyAaIB5AAQCKAGCLgCg");
	this.shape.setTransform(46.3,65.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,92.6,130.3);


(lib.shape124 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AD+MiQgEgqAhgdIAAgEQAFgWABgXIgFgHIAAgMIAEgDIACAAIAHACIAAAEIABAHIAEAEIAAABQAuAogHA/QgDAdgQANQgEAKgMAFQgfgLgVgZgAEqLhQgMALgEAPQgJAGgFAJIAAAEIABAPQAMAQAUAEIAFgCQABgGAGgEIADAAQAJgZgEgdQgFgigOgbQABAYgFAXgAh2h+QgrgWAJg1IAFgIIAAgHQAbgcAAgoIAEgDIAAgEIABgaIAEgEIADABIAIAAIACADIACALIAJAPIAEAhQgHgVgLgFIgCADQgEAJAEAIQAPAOAKAPIgDgrIACABIAHADIABAFQALA2gBA6IgDADQgEARgJASIgHABQgTAAgPgIgAhpj3QgIAJgCAMIgNAPIgCAEQgGARABAVIAFAHIAAAEIACALIAGALIAggDQAFgKAHgJIAAgEQAAgugZgogAhnsXIkxAOIgXgHIgFgDIgEgDIgLgIIAAgLIABgFIAJgHIDBgQQDEAIDHADQCMgGCQAJIAKgIIAGAFIADADIACADQAAAHgEAGQgKALgOACIiCALIh2AFIhEABQhrAAhogOgAg6siQBCARBGgJIAmgCQCXAFCYgNIAHgCIiqgHQgogDgoABQhmAEhmgEQhugGhuABIgCAAIi1AQIAIAEIARAFIEZgNIAQgBQAZAAAaAHg");
	this.shape.setTransform(45.2,83.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,90.4,167.6);


(lib.shape123 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AEaH+QgGgJgKgDIgCgDQgehAAwg4IAThAIAGgDIAAABIAJAGIAAADIABAMIAEADIABAEIALAmIADADIAAAEQACAOAFAMIACAEIAGAIQAGA5gvAZQgIAKgKAAQgEAAgGgCgAEyFyIgPAWIAAAIQgMAQgIARIAAAEQgBATACATIATANQAMgBALgGQAGgNAIgKIAAgHIAGgIQAAgQgKgOIAAgHIgGgIIAAgDQgCgSgGgQIgCAAQgDADABAGgAhNjQIgEgCIgKgFIgHgGIgNgPIAAgHIgEgIIAAgWIgDgEIgCgEIABgDIALgXIAMgTIAAgDIAAgEIACgEIAHgLIAAgIIgBgSIgDgIIAAgaIgGgIIAAgLIgBgHIgEgIIgFgEQgIgGgJgCIjugHIgmADQgeADgcgLIgCgGIgHgEIgCgDIgBgEIAAgEIABgEQAMgNAUAAIDXANQCKAJCLgJICcgKID7gKIAAABIAFABIACACIACAIIgDADIgGADIgHACIAAAKIgBAEIgBAEIgDAEIgEADQh7AIh7gBIh2gHQhRgJg8AbQgBAKABAJIABADIAAAIIAAAEIAEAHIABAEIABADIAEAEQAAAOAIALQAUAVACAdIABAIQAFAMgBAOIAAAiIgDAEIgCADIAAAMIgFAHQgMAVgYAAQgIAAgKgCgAhEl4IABAmIgfA0IAAAIQgBAUAIARIAPANQAZAHAPgSIABgEQARhCgpgyIgBgEIgGgTIAAAAQgCAAAAAGgAhKmwIgBgKIACgTIAEgDQAHgGAKgCIg2ABIAEACIADACIABAEIALAEIAKALIABALIACAFgABWncIBqACIDzgKQAGAAgBgHgAlXngIg3gGIgBAAIglABIgIADIBlACg");
	this.shape.setTransform(47.1,51.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,94.2,102.4);


(lib.shape122 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AEbECQg0gbAJg3IAFgEQAkgrAEg2IAHgDIAAABIAGACIACAEQACAGAFAFIAAADQgFAYAQASIAAAHIAKALIABAEQAFANABANIAEAIQAJAmgbAZQgIAJgLAAQgJAAgKgFgAEdCdQgLAQgNAJIgBACQgEAGABAGIAFAHQABAOAJAKIAGAEQAyAVgDg4IgGgIIAAgDIgGgbIgHgLIAAgHIgEgEIgCgIIgEAAQgHAOgEAPgAhygfIAAgCIgKgUQgOghAMghIABgEIALg4IgDgIIAAgEIgcgIIgvgBQhRAFhRgHIgPAAQg3AFgpgVIAAgTIABgEIAJgHIANgBIAjAEQCzAECzgLICegJIACABQAKACAJgCIAKAAIACABIAcACIBlgDIACgCQBdgBBbATIAHAHIABAIIgDADIgGACIgEABIgCABIgDADIgWAXIhfABIlIgQQglgCgSAZIABADIADAEIABAIIABAHQAEALAHAJIAMAWIAAAtIgPAaIgDADIgKAHQgRAOgYAEIgDAAQgKAAgIgGgAhhjMIAAAHIAFAIIAAALIgBAHQgFARgDARIgBAEIgGALIABAIIAAALIgEAEIgBADIAAAEIgCALIAAAEIACAIIADAEIABADIAEAIIACADIAEAEIAGABIANgBQARgNAOgRQAGgGAAgIIABgLIgCgOQgJgWgNgUIgBgEIAAgLIgFgIQgBgLAGgJQAZggArAEIGkARIAGgGIAEgEIACgEIgCgCIgHgBIjhgRIoyAYQBAAQBCgOQAZgFAXAAQAvAAAoAVgAm/jkQAQAMATgLIgZgDIgFgCIgEAAQgBABAAAAQgBAAAAABQAAAAAAABQABAAAAABg");
	this.shape.setTransform(46.6,26.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,93.1,52.6);


(lib.shape121 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AEIBoIgDgEIgCgDIAAgbQgCgKAEgIIADgIIABgEIAJgEIAEgGIACgDIAGgLIAFgPIACgDIAAgFIAAgDIgIgLIgGgMIgJgCIgXgFIgHgGIhKADIjIgNIgBAEIAAADIAEAMQADAFgBAGIAAADIACAIIADAEIAAADIAAAEIgDAEIgCACIAAAMIgFAHIAAAEIgBALIgEAIIgCADIgHADIgnAEIgFAAQgLgGgHgJIgQgVIAAgpIABgDIAEgIIgEgCIgWgIQgwgQgyAOQgtAMgegcIgfgCIgFADQgSAIgTABIhAACIgLgMIgCgDIgBgHIAAgEIACgIQARgJATgDIA6gFQDogFDoAJIDLgKIAHACICZgCIAEACIADACIADAIIAHAFIADACIgDACIgKABIgKgCIgEAFIgKACIgCABIgIAHIglADIgUAFIgBAAIgHAGIgSAEIgMALIgCAEIAAATIADAEIADAHIAEAEIAAAOIADAEIACAEIAAALIgDADIgBAFIAAADIADAHIABAEIAAAHIgFAIIgBAIIgBADIgCAEIAAAEIgDAEIgDAHIgNAGIgRAFIgDABIgaABgAESA+IAAAdQAVAEASgKIAHgHIAAgIIAFgHIAAgIIAEgIIgCgDQgDgMAFgLIgEgDIAAgQIgDgCIgDgIIgCAAQgJAsgiAagAh+g8IAPAGIAHAOQABAMgEAKQgEALACALIAAAHIADAEIAUAUIATgCIAKgEIADgCIACgFIABgDIAAgEIAFgHIAAgeIAAgDIAAgEIgFgHIABgIQACgLgCgMIABgHICRAGQA+AFA+gDQA5gDAmAjIAAgDQAAgHAEgFIADgHIAGgFIAGgHIAVgDIACAAIAIgFIATgGIgCgBIhYgEIjPAIQkBgKkAAKQgTAAgBAKICGgLIAJAGQAxAJA0gMgAGMhXIAaAAIAAAAg");
	this.shape.setTransform(47.2,10.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,94.4,21.5);


(lib.shape120 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AEZBNIgQgDIgRgQIgCgDIgBgDIgDgFIgBgDIgBgFIgDgDIgBgEIACgLIAEgPIAEgGIABgIQgzgOg7AGQg+AEg+gQIgNAGIgTAGIgLAGIgBACIADAEIACAEQABAIgDAJIgGALIgLAIIgHADIgUAGIgegMIgYgFIgBgCIgDgHIgDgFIAAgHIgOgKIgGgDIgTgDIgDgCIgDgCQg2AFg4gEIg7AFQhHAOgxgpIACgEIAFgHIAGgFIDGAKQBoAFBogIIFbgkIAAAAIAFABIBGAAQAgACAhgBIAHAAIAFABIACADIAAADIALAIIADAEIABAEQgEAHgJAEQgzATg4ADQgLACABAGIAAA+IgFAIIAAAEIgBADIgCAEIgMADIgIAIIgXABgAECgVIgBAZIgEAFIgBADIAAAEIgEAEIgBADIAGAIIAAAEIACAHIACAEIADAIQAXAMAYgCIANgJIADgIIADgWIAAgeIgEgDIgCgEIAAgEIACgHIAHgIIB3gWIgGgCIgFgDIgjAAIgHAGIgIgDIAIgMIhiAEIkQAZQA0ANA1gFIAjgBQAxAAAsAKgAirgXIAWAFQAZAKAIAWIA2APIARgKQAGgFAAgHIgBgEIgDgDIAAgWIAEgDIASgEIAagJIgJAAQhVAAhSAPgAnEgmQANALARACQBUAJBNgOIhagJgAjngXIAOABIAZgCg");
	this.shape.setTransform(46.8,8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,93.6,15.9);


(lib.shape119 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AEJA0QgGgBgGgEIgCgEIAAgLIgDgDIgBgEIgBgEIgDgDIgzgDQghAFgfgLQhAgXhAAXIghAKQhRAWhNgWIgBgEIgBgEIgDgEIgCgEIg8ADQg2AKg3gQIgYgBQgiAFgSgWIAAgLIACgIIAMgDQBrAFBtAAQCQAACPgGIENgNIAAABIAZACQAogBAeAVIABADIgCAEIgEACQhwglh4AYIgeACQhhgBhhAGIj9AHQg6AAg3gMQgcgGgJAQIBSAKQBMANBLgJIAHAGIADADIACAEIABADQALAHANAAIBygEQATgEAOgKQA5gHA7AEICXASIABAEIABAEIAEADIAAAQIAEADIA9gCIgBgBIgCgIIAAgIQgFgEgCgGIgCgJIAAgGIABgDIACgEIAFgEIAmAAIAfgDQAXgHAVAKIAGAGIgNADIhlAIIAFAKIAEAFIAAAHIAEAPIAAALIgCAEg");
	this.shape.setTransform(44.4,5.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,88.8,11);


(lib.shape117 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AILMEIgcgeIAAgLIgCgEIgDgEIAAgeIADgEIACgSIAAgIIADgEIACgPQATgcAAgjQAAgEADAAIANAKIACALQAVAcAOAgIADAEIABAHIAAAIIAFAHIAAAXIAFAHIgBAXIgJAHIAAAIQgHANgOAGIgDACgAIQJvIgIAPIAAAIIgFAHIAAAIIgFAHIAAAXIgFAHIAAATIAFAHIAAAMQATAeAcgUIABgEIAAgEIAKgLQgEghgNgeIgDgFIAAgHIgPgXIgCgFIgBgBgAEsrDQgPgCgNgFIgQgGIgDADIgBABIjegEQh2AIh6gMIgxgEQg6gFg8ACIgOgEQh0AQhygUIgKgEIgHABIgEABIgCgGIAAgEIAAgEIANgPQBqALBngMIAAgBQCIAbCLgLQBxgIBxAIQCFAKCCgHQCQgHCRAGQASABgEARQh4AgiAAAgAEbrcQCHAcCGgiIAygFIABgBIggAAIgDABIiNAGIgFABIgSgCIgHgCIgKAEIg7AEIgFgBgADtrcIAIgBIg3gBgAhrrmIgsAEIDuADIi5gJgApvrxIALAHIA8gCIgxgHIgGADIgRgCgAm/rxIgFABIgYAEIBKAAQgKgCgJgFQgGgDgFAAQgHAAgIAFgAodrsIAsAAIgpgBg");
	this.shape.setTransform(64.5,77.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,129.1,154.7);


(lib.shape116 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ah4LsQgrgxAug5IAAgmIABgDQADgcAVgQIABABIAIAFIAEAIQANAWgCAaIARAXIACAHQAOAzgUAvIgbAKQgIACgHAAQgOAAgJgLgAhcJbIgFAIIgBAtQgHAEgCAHIAAAHIgPAXIAAAEQgCAQAHAOQARANATgGQANgIAIgMIAAgxIgEgHIAAgIIgUgeIAAgDIgHgiIgBgBQgCAJACAIgAooDpQgLgJgJgMIAAgIIgEgHQgPgoAYgjIAAgIIACgDIAghXIAGgCIAFACQAGAEADAGIAAAIQACALAEAKIAEAEIACAEIAAADQADAPAJAMQgCAGACAGQAQA1gMA3QgSASgWAAQgNAAgOgGgAoPBJIgFAIIAAADIgGAbQgHAEgCAHIAAALIgKATIAAAHIgFAIIACALIAIAPIACALQASAYAbgPIAKgPIAAgxIgEgHIgCgXIgLgGIgNgtIgBAAgAkqrDIgYgEQiVAGiRgMQgYgCgNgTIAAgMIAEgDIBlgDIEPAIQCIANCHgLID9gKIEggCIB1AFIACAEIAAADIAAAEIgEACIgYAAIgEACIgDAEIgBADIgHAIIg2ABIj9AGIhhAFIhBgKIgQAJIk/AQIgYABQgpAAgogMgAkprSIAaADQCOAPCQgQIBtgHIACgDIAEgFIA0ACQCMAKCNgLQBGgFBFACIhugIQiIADiLgFIjYANQheAHhfgEIjigMIgGgEIjWAHIAHAIQA5ANA4gFQAygEAyAAQA7AAA6AGg");
	this.shape.setTransform(65.4,76.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0.4,130.8,151.9);


(lib.shape115 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhdHqIAAgIIgEgEQgIgOABgQIgEgIIgBgDQgJgvAbgoIAAgHIAFgHIAAgIIAFgHIAAg1IACgDQAFgJAIgBIAEACIAQANIACAIQAFALAAAMIACADQAFAOAHAMIABAFQAEARALANIAABHIgFAHQADAngaAcIgdACQgSgHgJgPgAg9EkQABArgRAoQgWAaAHAlIADAEQgBARALANIAAALIANALIAVgBQATgfACgkIgBgFQgMhCgXhAIAAgCIgBADgAoMAfIAAgIIgGgIIAAgHIgEgIIAAgKQgChBAWg7IAAgWIAEgIIAAgHIABgIIADgDQAGgIAJABIAAABIAJAGIAAAIIAFAHIAAAIIABAHIAEAEIAAAHQAEAlAJAjIAQAWQgDAUAEASQAEATgNAOQgVAYgTAAQgRAAgQgRgAnxh/IgFAHIAAAIIgFAIIAAADQgBAXgEAWIgFAIQgIAtAcAhIAPABIASgKIAAgIQAIgHADgHIgBgDQgIgUADgWIgCgDQgdgwgFg2IAAgBQgDAMABANgApynMIgCgDIgBgEIgDgEIgEgDIgDgFIAGgKIABgIIADgEQCQgJCPADQBoACBmgGICfAMIADgCQAqACAogCIADACIAugCIAVgFIATACIACAAQCKgJCNAKQBMAHBJgJIAGAEIAGAEIAAADIgCAEIgFABIgFALIgDAFIgDACQgFgEgIgBIgcAFIhVAAIAHAJIgUACQgOgLgTgBIksgSIgUABIhuALIAGAEIgCABIgLgDIgDAAIgPAEIgEgDIgEgDIgOgBIgBACIgDADQjIAIjKgCIg/AMQgYABgZAAQgoAAgogFgAprniIADADIByAKIAHgCQAhgNAkgEgAIAnmIAxAGQAhAGAagLIABgEIABgDgAkonsQCBASCCgNIhbgJIgcAAQhGAAhGAEgAHdnoIgEgBIgMAAIAKABIACgBIAAABIAEAAgAlmnqIAWABIgGgCgAlMnpIAeAAIAEgCIABAAg");
	this.shape.setTransform(64,51.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,127.9,102.4);


(lib.shape114 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AH3MMIgRgeIAAgIQgBgNACgNIAEgEQADgcARgYIgBgEIAAgIIAFgHIAAgEIAAgEIAFgHIAAgEQACgQAIgOIgCgEIgCgHIABgEIAEgEIAGABIABABIACACIAUA1IAAALIACAEQAOAiAAAlIgKATIAAALIgYAeIgiAGgAIaJwIgBAJIgDAEIgCAEIAAAHIgDAEIgCAEIgBAEIABAHQgMATgJATIAAALIgFAHIAAAXIAJAPQANAFAMgIIAQgWIAAgIIACgDIAEgIIAAgLIAFgLIgBgEQgLgdgEgfIgEgEIgBgEIgCgBIgBACgAhckRIgBgDIgBgDIgHgDIgIgSQgTg2AkgrQALgMAOgIIAGgPIgBgHQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAIALgGIAFACIAIAFIAFAaIAEAEIAFAEIABAEIAFAHIAAAIIABADIAEAEIAAATIAKALIAAAIIABADIADAEIAFAeIgDAEIgCAEIAAAHIgKATQgVANgVAAQgVAAgUgNgAhMl7IAAABIgNARIgDAMIgDAEIgBADIAEAEIAAAEQgFAkAhARIAegBQAcgPgHgiIgFgHIAAgIIgJgLIgBgEIAAgLIgDgEIgCgDIAAgIIgDgEQgDgJgIgGIgBAAQgLAPgRAMgAoMoDQgHgOABgRIAAgHQgBgKAFgJIACgEIANgmQAGgOALgLIAAgMIACgDIAHgPIABgEIAAgaIgPgTIhwgFIgHgBQgKgCgFgKIgBgDIAAgPIACgMIAbgFIAVgBQE9AFE7gGQBjAGBlgDIFIgLIAHABIApgBQAJgBACAJIAAAEIAAADIgCAMIgBADIgKAMIgcACIhSgIIjBgHQhYgFhYAQQgngBgnADIjIAKQidgQiYAWIgCACIgBAEIAAAPIAAAEIABALIAEAEIAAATIABAHIAEAMIAAADIAAALIgDAFIgBADIACAEIACAHIAAAEIABALIAEAEIAAApIgFAIIAAAWIgDAEIgTAeQgLADgJAAQgdAAgQgegAnrpjQgCAPgJAMIAAAHIgKATIAAAEIABAWQAMAbAagCIAJgHQADgKAHgJIAAgEQAEgYABgZIgFgHIgKhiIgBAAQAAArgaAlgAnrriIAHACIABADQABAGAFAGIACADIACAEIAFABIAEAAIAAgPIABgEIABgEIARgGIAOgDIADgBIgEgBIiggGIgTACIgFAEIAAADIAHADIArgBQAlAAAmAEgAGrr7IBRADQAcACAZAIQAlAMAWgVIg/gFIgCgBgAlVrtIDBADIAbgDIgygDIgHgBg");
	this.shape.setTransform(63.5,78.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,127.1,156.4);


(lib.shape113 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AIUHeIgGgHQgSghAUgfIAAgLQAAgGADgGIAFgFQAQgnAEguIAGgBIAKgBIAEAEIARAXIABAMIAAADIAEAEIAAAIIABADIAEAEIgCBEQgGA6g2AAIgJgBgAI2FVIAAAhIgUAbIgBADQgIAYAAAZIAbgHIATgTIAAgEQACgwgMguIgBAAgAhNjNQgigCADghQAFgsATgpQAKgVgIgWIABgEIADgEIgJgLIgEgIIgCgLQgpgMgqABIg+AEQhnALhngGIAJAXQAKAdgIAeIgKATIAAAHIgEAEIgBAEIAAALQggAog0gKIgCgCQgIgGgEgJIAAgIQAAgPADgOQAHghASgcIABgHIAEgIIgCgEIgIgLQgOABgLgGIgCgCIgDgIQgqAEgqgDIgEgEQgMgRAKgUIANgGIAAgEQBPgMBTAMQBdAOBfgKIACgBIDOgTIAHABQBbAEBbgGIBFAKIAcgBIBGAJIAhgGIAFACQCbAGCaAAIAKANIABADIAFAEIABADIgBAEIgGAIIgYABQhYgQhYADIgjgBQiUgPiSAdIiHAaIAAALQgGAFgBAGIgEAMIgBAHIADAEIAHAPIADAEIAAAEIABAHIAIAIIAFAWIABAaIgDAEIgCAEIAAALIgFAIIAAAHQgUAagiAAIgGAAgAg6lbIABAaIgKATIAAAHIgKAMIAAAHIgKATIAAAHIgFAIQAAAGAFAFQAaAAAVgJIACgDQAIgWAEgXQgPgXgLgaIgBgEIgCgHIgCgCQAAAAAAAAQAAABAAAAQAAAAAAABQgBAAAAABgApmnBIABADIgDAEIgKAHIBUADIAKALQAOADAMAHIAOAZIAAAPIgFAIIAAAHIgPAXIAAAHIgQAeIgBAIIACALIADAEIADADIAkgDIACgBIARgSIAAgIIAFgHIAAgIIAEgHIALgtIgDgHQgHgSgCgRIgUgCIgDgEIgBgDIABgEIAJgFIAZgFIAFAAICbAGIBagHIBzAGIAKAKIAAAEIABAHIADAEIABAEIAGAHIAEAEIAAATIAAADIABABIADgCIACgEIAAgDIAAgEIADgIIAEgEIADgDIAAgPIADgIIBhgUQA9gSA/gFQhRgPhUANIm4AYIgBgBIgDgDQghACghgDIh6gJgAJCm7IAHACQAWAHAAgHIAAgDg");
	this.shape.setTransform(64.9,47.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,129.7,95.8);


(lib.shape112 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.shape111 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.shape110 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AItBMIgFgMIgHgLIgBgaIANghIgFgDIgbgSIgUgCIn5AOIAAABQggAOgXAXIgMAAIgEgEIgDgDQgIgDgFgEQgQgLgCgUQg9gHg/AIQgtAFgogMQieAHibgGIgBgEIgCgEIgTgLIAAgEIACgHIAFgIIAXgGIABABIABABIAIgCIAKAFIAFACIAPACIANgGQB8gOB7ARQCPATCPgLIEKgMQCVAACUgHIAAABIAvAFIAfAIQAJACAHAIIABACIgFADIgHgDIgGgDIhIgHIk5AKQhPgDhPAFQisAMiugOIhEgEQhrgEhrAAIgIAGIgbAAIgEgBIgRgJIgJAMQAHAMANABIBDACQCdgECXACQBDgDBDAEIAHAIIACAOQABAJAGAGIAPABIADACIAEADIAHAAIAEgDIAZgTIAMgEIAIgGIFbgOQBegMBeAKQAZALARASIAAAEIgBAKIgDAEQAAAIgEAHQgJAMABAOIAFAEIABAHIADAEIABAEIAcgCIAFgPIACgSIgFgIIAAgPIAJgKIABgEIABgHQAOgOASgJIgIgCIgEgCIABgCIANgJIAEAEIAGAHIAAAMIgHAEIgSAJIgKAKIgBAHIgJALIABAEIAEAHIAAAeIgFAIIAAAHIgDAEIgFAEg");
	this.shape.setTransform(65,7.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,130,15.4);


(lib.shape108 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.shape107 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAbANIg5gCIgGgCIgCgBIgngHIgDgBIgCAAIAAABIgDABIgEgCIgCgBIAAgGIAEgFIACgBIADgBIADAAIACAAIAAgBIChAFIAEACQAEADgBAFIgLAIQgQAIgRAAQgKAAgKgDgAAogCIgDABIgCABIAkABIAEgCIADgBIgkgBgAghgBIACABIAagCIgfAAg");
	this.shape.setTransform(9.2,1.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,18.3,3.2);


(lib.shape106 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag5AVIgLgCQgIgBgHgFIAAgBIAAgDIgBgBIgBgBIAAgJQATgVAfACIAzABIAOgDIAwAGIABAAQAMABgIAKIgDACQgOAKgSAGIgwALgAAJAPIgFABIAHAAIADgBIgCAAgAhFgGIgBABIAAAFIABADIAAACIAAACIAAABIBFADIAvgLIATgFIg2gHIgIABIgbAAgAhNADIABABIABAAIAAAAIgBgBIAAgDIgBAAQAAAAgBAAQAAAAAAABQAAAAAAABQABAAAAABg");
	this.shape.setTransform(8.6,2.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,17.2,4.7);


(lib.shape105 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgqIaIAAgHIgBgCIgCgCQgCgVAEgUIABgGIACgDIAAgEIAAgCQAPgZATgUIABgFIAAgCQAFgHAAgIIAAgEIAFgDIAAgBIAEACIABAGIAAACQAKAXAGAbIAAACQAbAngQArIgDAEIAAAEIgBADQgTANgPAAQgXAAgSgagAADGyQgSARgMAWIgBACIAAAFIgBACIgCACQgDAOAAAOIAAALIADAEQAEAYAbACIARgEQAFgEABgFIACgCIABgFIAAgCQAHgKgBgOIgCgIIgEgEIgBgDIgFgPIgBgGIgDgEIgCgDIgCgLIgCgGIgFgGIAAgFIgBgCgAhZoaIgDgEIgBgDIABgPIABgBIAEgCICwAGIAEAAIABAFIAAAKIgDAFIgJAGIgCACQhAgFg/AGIgGAAQgTAAgRgKgAghocIAXgDIBXAEIAGgHIingEQAVARAegHg");
	this.shape.setTransform(9.4,56.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,18.8,112.8);


(lib.shape104 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgcE0IgGgEIgOgQQgOgkAQgjIACgJQAHgPANgIIAAgDIADgGIgBgCIgBgHIABgCIABgCQAFgRAIgPIACgDIADgBIAAAAIAFAAIAEABQADAPgBAQIAAAGIADAEQgBAHACAHIACAGIAJAIQATAggFAmIgCAGIgHALQgKAdgXAAQgKAAgNgFgAgQC7IAAADIgKAGQgfAqAXAuIACAGIANALQAeAFAGgaIAIgLIAAgmIgDgFQgFgTgPgPIAAgFIgCgEIgDggIgBAAgAhLkSIgFgEQgEgIgIgFIgBgEQADgIAJABQAnACAkgMQAsADAtgDIADABIACACIAEAFIACAGIgBAGQgCAOgMAHIgFADgAhNkhIAEAGIACACICMACIAHgFIAEgCIABgFIACgEIgCgFIAAgBQgsACgtgCg");
	this.shape.setTransform(9.4,31.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,18.8,62.6);


(lib.shape103 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgsCHIAAgEIgBgCIgCgDQgHgcAGgcIACgTIACgCIABgJIADgEQAIgrgDgtQgBgPABgPIAAgEIgFgHQgBgHADgGIABgCIgxgLQgFgHABgIIAAgCQAFgKAJgBIChgIIAGAJIAAAVQglAQghAYIgIAYIgNANIAAAEIgCAEQgBARADAQIAAAGQAHAMABAPIAKANQAXA0gVAzQgFALgMACIgKABQgXAAgOgVgAhMiLIgDAHIgBACIACACIACACIADABIAJACIABABIAYABIAEABIAFAEIABAEIAAAFIgBAGIgCAEIABACIAEAFIABAGIAAAUIgDAEIACAuQADAWgFAWIgDAEIAAAHIgBACIgCACIAAAEIgCAFIAAAKIgDAFIAAAGIgBACIgCAHQgBADADADIAAACIABASIADAEIAAAEIABACIABADIACAIIAGAHIACABIAOAIIAOgCIAGgCIAEgFIACgCIADgGQAAgHABgHQACgMgBgNQgEgXgHgWIgEgFIgBgCIgFgIIAAgHIgEgPIgEgHIAAgLIgBgCIgCgDIAAgeIACgCIABgEIAAgDIAHgIIACgFIAAgBIADgBIABgDIAAgCIADgEIACgFIABgGIACgCIACgEIACgDIACgBIADgBIAHgBIAEgHIACgCIAagPIABgBIALAAIAHgBIACgCIABgCIAAgHIABgCIgCgFg");
	this.shape.setTransform(9.1,15.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,18.3,31.2);


(lib.shape102 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgVBeIgHgGIgCgCIgGgEIgBgCIgIgNIgCgCIgBgCIAAgEQgEgIABgKIACgKIAKgrQADgQgMgJIACgLIAAgGIAAgCIgCgHIgkgMIgBgCIgBgEIgEgDIgDgEIAAgCIAHgHIACgBIAAgBICnAHIAHAEIAEAHIgBACIgFAGIgLACIgJAKIgBADIgLAIIgDAAIgSACIgBACIgBABIgGADQgDAFAAAFIAAAiIADAEIAAAHIAEAEIAAALIACAEIAAATQgDAdgXASIgIACQgKAAgKgGgAgphGIACABIADAPIgBAPQAIARgFATQgDAJAAAKQgHAKABAMQABAKAEAJIALARIAOAKIACACIAOAAIAHgHIADgCIACgLIABgEIADgEIAAgEIADgFIgCgOQgDgHACgHIgDgEIAAgHIgDgEIAAguIADgFIAAgEIALgJIAEgCQAPABANgJIAHgKIAGgFQhNADhIgGg");
	this.shape.setTransform(9.4,10);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,18.7,19.9);


(lib.shape101 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AghA4IgCgCIgJgHIgFgGIgDgWIgBgCIgBgCIAAgFIgBgCIgCgCIABgMIAEgJQgHgTgUgIIgEgDIAAgJIAXgBIACACQA+AGA8gNQAGgBAAAVIgDgEIAAgCIgBgCIgBAAIhXAIIgnAAIAJAEIAGAGIACAFIABAIIgBAHIgFAIIABACIABACIABACIACAIIABAHIAAAJIABACIADAGIAGAEIAHAHQAKAHANgHIAGgHIAAgCIAAgHIADgCIABgJIgEgRIAAgKIAMgLIAkgBIAKgIIAJgFIADgDIgBgCIAIgRIAEAPIAAALIgJAKIgRAJIgDACQgLAFgIgHIgOABIgEADIgDAEQAGASgFAUIgCALQgNANgOAAQgKAAgKgFg");
	this.shape.setTransform(8.4,6.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,16.9,12.1);


(lib.shape100 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgsAZIgTgfIgNgBIgKgDIgFgEIAAgDIAAgEIgBgCIgCgCIgBgCIACgEIADgCIADgBQBAANA+gNQAfgGAYAPIACACIAAAJIgDAHIgGAFIgrAIQgHABgFAFIgGAJIgTAKQgQAGgMAAQgRAAgGgMgAg6gRIgDABQARAGALAQQAKAQATgEIAWgGQACgVAUgHIAggDIgTgDg");
	this.shape.setTransform(9.6,3.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,19.3,7.4);


(lib.shape76 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.902)").s().p("AhKBKQgegfAAgrQAAgqAegfQAggfAqAAQArAAAfAfQAfAfAAAqQAAArgfAfQgfAfgrAAQgqAAgggfgAhDhCQgbAcAAAmQAAAnAbAcQAcAcAnAAQAnAAAcgcQAcgcAAgnQAAgmgcgcQgcgcgnAAQgnAAgcAcg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["rgba(255,255,255,0.902)","rgba(27,134,187,0.902)"],[0,1],2.4,-3,0,2.4,-3,10.1).s().p("AhDBDQgbgcAAgnQAAgmAbgcQAcgcAnAAQAnAAAcAcQAcAcAAAmQAAAngcAcQgcAcgnAAQgnAAgcgcg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.5,-10.5,21,21);


(lib.shape73 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FFFFFF","rgba(255,255,255,0)"],[0,1],-1.7,-1.2,0,-1.7,-1.2,9.8).s().p("AgoFAIgCgDIgEgXIACgZQABgTAIgZQAVhHAFgjQAHg5gQgxQgkhwgHg1QgLhiArhEIADgCIADAAIADACIAAADQgQBmAnBYQArBgAGAWQAWBDgRA8IgGAVIAAAAIhDB2IAAAAIgHAMIgGARIgDAdIgCADIgDABg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-6.4,-32.1,12.9,64.3);


(lib.shape66 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 6
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(247,247,247,0.749)").ss(0.1,0,0,3).p("AAAgJIABABIAAAGIgBAO");
	this.shape.setTransform(43.5,46);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#F7F7F7").ss(1,0,0,3).p("AnHnYQAYAyBpAlQCIAwC+AAQC/AACHgwQBkgjAbguIgTBGIAELtIgCARIAAAKIgCAHQgOA2h5AjQh7AkiyABQi0AAh7glQh7gmgHg8IAAgHIAAgIIAFrmgAHFnSIAJgjIAAAAQAAASgJARgAnNn1IACARIAEAM");
	this.shape_1.setTransform(0,7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(128,128,128,0.051)").s().p("AE0gUQh/gui1AAQizAAiBAuQh3AqgIA6IAAgGIAAgIQAIg8B3gpQCBgtCzgBQC1ABB/AtQCAAsAABBIAAAHQgIg7h4gqg");
	this.shape_2.setTransform(0,36.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 5
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#8D581D").s().p("AgtC3IgEgLIAEgLQAEgEAHAAQAGAAAEAEQAEAFAAAGQAAAGgEAFQgEAEgGAAQgHAAgEgEgAjoCjIgDgGIADgFIAFgCIAFACIADAFIgDAGIgFACgABeCdQgEgEAAgGQAAgFAEgFQAFgEAFAAQAGAAAEAEIAFAKQAAAGgFAEQgEAFgGAAQgFAAgFgFgADcCdIgDgGIADgFQACgCADAAIAFACIADAFIgDAGIgFACQgDAAgCgCgAhxCAQgGgGAAgIQAAgIAGgGQAHgGAJAAQAIAAAHAGQAGAGAAAIQAAAIgGAGQgHAGgIAAQgJAAgHgGgADwByQgIgGAAgIQAAgIAIgGQAJgGAMAAQAMAAAIAGQAJAGAAAIQAAAIgJAGQgIAGgMAAQgMAAgJgGgAjvBwQgFgFAAgIQAAgIAFgFQAGgGAIAAQAHAAAGAGQAFAFAAAIQAAAIgFAFQgGAGgHAAQgIAAgGgGgAk5ByIgGgFIAGgGIAQgCIAPACIAGAGQAAADgGACIgPACgAA6BrQgEgDAAgFQAAgGAEgEIAKgDIALADIAEAKQAAAFgEADIgLADgAljBmQgDgDAAgGIADgJQAEgEAGAAQAFAAAEAEQAEAEAAAFQAAAGgEADQgEAEgFAAQgGAAgEgEgAFtBfQgEgEAAgFQAAgFAEgEQAEgFAGAAIAJAFIAEAIIAAACIgEAIQgEAEgFAAQgGAAgEgEgAFABSQgFgEAAgHQAAgHAFgFQAFgEAHAAQAGAAAFAEQAFAFAAAHQAAAHgFAEQgFAFgGAAQgHAAgFgFgAi/BLIgCgHIACgHIAIgDIAGADQADADAAAEQAAAEgDADQgCADgEAAgACGBIQgDgDAAgFQAAgFADgDQAEgEAFAAQAFAAADAEIADAIQAAAFgDADQgDAEgFAAQgFAAgEgEgAksBIQgEgDAAgGQAAgFAEgEQAEgDAFAAIAJADQAEAEAAAFQAAAGgEADQgEAEgFAAQgFAAgEgEgAl4AoIgDgIIADgIQADgEAFAAQAFAAADAEQAEADAAAFQAAAFgEADQgDAEgFAAQgFAAgDgEgAiPgDQgGgDAAgEQAAgFAGgCIAOgDIAOADQAFACAAAFQAAAEgFADIgOADgAClgSIgIgFIAIgFIAqAAIAIAFQAAADgIACgAAIgYIgFgCIAFgDIAXAAIAFADIgFACgAh7g3QgNgGAAgGQABgGANgEIBCAFQAOAGAAAGQgBAGgOAEgAj1hWQgHgDAAgFIAHgIIATgEIATAEQAIAEAAAEQAAAFgIADIgTAEgAl9hVQgGgCAAgDIAGgHIAcAAIAGAHQAAADgGACIgOADgAFQhiQgHgDAAgFQAAgEAHgEIASgDIASADIAIAIQAAAFgIADIgSAEgAARhiIgDgDIgCgGIAFgJIAOgEIAOAEQAFADAAAGIgCAGIgDADIgOADgAiqiCQgJgEAAgEQAAgFAJgDIAVgEIAVAEQAJADAAAFQAAAEgJAEIgVADgACWiFQgMgEAAgFQAAgHAMgEIAfgEIAeAEQANAEAAAHQAAAFgNAEIgeAFgAgTirQgHgDAAgEQAAgFAHgDIAgAAQAHADAAAFQAAAEgHADg");
	this.shape_3.setTransform(-0.7,-42);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

	// Layer 4
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#DE9642").s().p("AkyBqQh8gpgDg4IAAiaQACAhAsAdQAfATAyAQQCAAoCzAAQCzAAB/goQAwgQAegRIAEgCQAmgYAGgbIABCXQgGAdgrAbQgdARgxAQQh/AoizAAQizAAiAgog");
	this.shape_4.setTransform(-0.2,-36.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CC6600").s().p("AkyBiQgygQgfgTQgsgcgCgiIAAgBQAAg5B/gpQCAgoCzABQCzgBB/AoQBxAkANAzIABABIAAATIgBADQgGAbgmAYIgEADQgeARgwAPQh/ApizAAQizAAiAgpg");
	this.shape_5.setTransform(-0.2,-51);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4}]}).wait(1));

	// Layer 3
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#F7F7F7").ss(1.4,0,0,3).p("AnNBVQgBhECIgvQCIgwC+AAQC/AACHAwQCIAvAABE");
	this.shape_6.setTransform(0,-51.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(1));

	// Layer 2
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(247,247,247,0.302)").s().p("AgkGrIAArEQgIhbAYgkIAEgHIA3gRIgDAOIgHAMQgCAJgGAEQgYAUAGBZIAALFIgmAHg");
	this.shape_7.setTransform(23.4,13.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(1));

	// Layer 1
	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(1,1,1,0)").s().p("AkzImQiAguAAhAIAFrtIgZhcIgEgNIgCgQQgBhECIgwQCIgxC+ABQC/gBCHAxQCIAwAABDIgcBqIAELtIgCAQQAABAiAAuQiAAti0AAQizAAiAgtg");

	this.timeline.addTween(cjs.Tween.get(this.shape_8).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-47.2,-64.9,94.5,124.4);


(lib.shape63 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(255,255,255,0.702)").ss(0.2,0,0,3).p("AMQjsQFGBkABCIQAACJlHBiQlFBinLAAQnLAAlGhjQlFhhAAiJQAAiJFFhjQFFhgHMAAQHLAAFFBgg");
	this.shape.setTransform(10.3,5.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-101.8,-28.6,224.2,68.7);


(lib.ClipGroupcopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_5
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D4D8DC").s().p("AhlBlQgpgqAAg7QAAg6ApgqQAqgqA7AAQA7AAAqAqQAqAqAAA6QAAA7gqAqQgqAqg7AAQg7AAgqgqgAhSgwQgKAGgGAMQgFAMAAAQIAAAEQAAAQAFAMQAGALAKAHQALAGANAAQAOAAAKgGQAKgHAGgMQAFgLAAgQIAAgEQAAgQgFgMQgGgMgKgGQgLgGgNAAQgNAAgLAGgABDA1IAWAAIAAhqIgWAAIAABFIgrhFIgWAAIAABqIAWAAIAAhFgAhLAbQgGgJAAgQIAAgEQAAgRAGgJQAGgIALAAQALAAAGAJQAGAIAAARIAAAEQAAARgGAJQgGAIgLAAQgLAAgGgJg");
	this.shape.setTransform(-0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_6
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(167,170,173,0.659)").s().p("AhZB3QgqgqABg7QgBg6AqgqQAqgqA7AAQA7AAAqAqQAWAVgEA5QgEA5gaAOIAAhmIgWAAIAABFIgrhFIgWAAIAABqIAWAAIAAhGIArBGIAPAAQgWALgdAMQhMAfgiAAQgPAAgHgGgAhGgeQgKAGgGAMQgFAMAAAPIAAAFQAAAQAFAMQAGALAKAHQAKAGAOAAQAOAAAKgGQAKgHAGgMQAFgLAAgQIAAgFQAAgPgFgMQgGgMgKgGQgLgGgNAAQgNAAgLAGgAg/AtQgGgJAAgQIAAgFQAAgQAGgJQAGgIALAAQALAAAGAJQAGAIAAAQIAAAFQAAARgGAJQgGAIgLAAQgMAAgFgJg");
	this.shape_1.setTransform(-0.8,-1.2);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Layer_7
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF3E31").s().p("Ah/B/Qg0g1AAhKQAAhKA0g0QA1g1BKAAQBLAAA1A1QA0A0AABKQAABKg0A1Qg1A1hLAAQhKAAg1g1g");
	this.shape_2.setTransform(-0.1,0.1,0.794,0.794);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	// Layer_8
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#D4D8DC").s().p("Ah/B/Qg0g1AAhKQAAhKA0g0QA1g1BKAAQBLAAA1A1QA0A0AABKQAABKg0A1Qg1A1hLAAQhKAAg1g1g");
	this.shape_3.setTransform(-0.2,0.2,0.794,0.794);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

	// Layer_9
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F5FAFF").s().p("Ah/B/Qg0g1AAhKQAAhKA0g0QA1g1BKAAQBLAAA1A1QA0A0AABKQAABKg0A1Qg1A1hLAAQhKAAg1g1g");
	this.shape_4.setTransform(-0.3,-0.3,0.794,0.794);

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(1));

	// Layer_10
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#DADDE0","#C7CBD0","#A9AFB6","#C8D1D4","#829093"],[0,0.169,0.388,0.576,1],-17.9,0,18,0).s().p("Ah/B/Qg0g1AAhKQAAhKA0g0QA1g1BKAAQBLAAA1A1QA0A0AABKQAABKg0A1Qg1A1hLAAQhKAAg1g1g");
	this.shape_5.setTransform(-0.4,0.1,1,1,61.2);

	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroupcopy, new cjs.Rectangle(-18.5,-18,36.1,36.2), null);


(lib.ClipGroup = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_5
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D4D8DC").s().p("AhlBlQgpgqAAg7QAAg6ApgqQAqgqA7AAQA7AAAqAqQAqAqAAA6QAAA7gqAqQgqAqg7AAQg7AAgqgqgAhSgwQgKAGgGAMQgFAMAAAQIAAAEQAAAQAFAMQAGALAKAHQALAGANAAQAOAAAKgGQAKgHAGgMQAFgLAAgQIAAgEQAAgQgFgMQgGgMgKgGQgLgGgNAAQgNAAgLAGgABDA1IAWAAIAAhqIgWAAIAABFIgrhFIgWAAIAABqIAWAAIAAhFgAhLAbQgGgJAAgQIAAgEQAAgRAGgJQAGgIALAAQALAAAGAJQAGAIAAARIAAAEQAAARgGAJQgGAIgLAAQgLAAgGgJg");
	this.shape.setTransform(-0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_6
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(167,170,173,0.659)").s().p("AhZB3QgqgqABg7QgBg6AqgqQAqgqA7AAQA7AAAqAqQAWAVgEA5QgEA5gaAOIAAhmIgWAAIAABFIgrhFIgWAAIAABqIAWAAIAAhGIArBGIAPAAQgWALgdAMQhMAfgiAAQgPAAgHgGgAhGgeQgKAGgGAMQgFAMAAAPIAAAFQAAAQAFAMQAGALAKAHQAKAGAOAAQAOAAAKgGQAKgHAGgMQAFgLAAgQIAAgFQAAgPgFgMQgGgMgKgGQgLgGgNAAQgNAAgLAGgAg/AtQgGgJAAgQIAAgFQAAgQAGgJQAGgIALAAQALAAAGAJQAGAIAAAQIAAAFQAAARgGAJQgGAIgLAAQgMAAgFgJg");
	this.shape_1.setTransform(-0.8,-1.2);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Layer_7
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#B82D24").s().p("Ah/B/Qg0g1AAhKQAAhKA0g0QA1g1BKAAQBLAAA1A1QA0A0AABKQAABKg0A1Qg1A1hLAAQhKAAg1g1g");
	this.shape_2.setTransform(-0.1,0.1,0.794,0.794);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	// Layer_8
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#D4D8DC").s().p("Ah/B/Qg0g1AAhKQAAhKA0g0QA1g1BKAAQBLAAA1A1QA0A0AABKQAABKg0A1Qg1A1hLAAQhKAAg1g1g");
	this.shape_3.setTransform(-0.2,0.2,0.794,0.794);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

	// Layer_9
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F5FAFF").s().p("Ah/B/Qg0g1AAhKQAAhKA0g0QA1g1BKAAQBLAAA1A1QA0A0AABKQAABKg0A1Qg1A1hLAAQhKAAg1g1g");
	this.shape_4.setTransform(-0.3,-0.3,0.794,0.794);

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(1));

	// Layer_10
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#DADDE0","#C7CBD0","#A9AFB6","#C8D1D4","#829093"],[0,0.169,0.388,0.576,1],-17.9,0,18,0).s().p("Ah/B/Qg0g1AAhKQAAhKA0g0QA1g1BKAAQBLAAA1A1QA0A0AABKQAABKg0A1Qg1A1hLAAQhKAAg1g1g");
	this.shape_5.setTransform(-0.4,0.1,1,1,61.2);

	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup, new cjs.Rectangle(-18.5,-18,36.1,36.2), null);


(lib.fasa = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FFC447","#FFC447","#DE4F00"],[0,0.016,1],-240.2,-106.9,272.2,163.4).s().p("Ehj/ADlIAAnJMDH/AAAIAAHJg");
	this.shape.setTransform(640,22.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.fasa, new cjs.Rectangle(0,0,1280,45.7), null);


(lib.text16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AASAvIAAgrIgjAAIAAArIgRAAIAAhdIARAAIAAAlIAjAAIAAglIARAAIAABdg");
	this.shape.setTransform(29.2,5.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgiAvIAAgPIAbAAIAAgcIgTAAIAAgNIATAAIAAgWIgaAAIAAgPIBDAAIAAAPIgaAAIAAAWIATAAIAAANIgTAAIAAAcIAbAAIAAAPg");
	this.shape_1.setTransform(20.7,5.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgHAvIAAgnIggg2IASAAIAVAoIAWgoIASAAIggA2IAAAng");
	this.shape_2.setTransform(12.6,5.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgHAvIAAgVQgSgCgKgJQgJgKAAgPIAAgkIAQAAIAAAjQAAAKAGAFQAFAHAKABIAAg6IAPAAIAAA6QAKgBAGgHQAFgFAAgJIAAgkIAQAAIAAAjQAAAPgKAKQgKAKgRACIAAAVg");
	this.shape_3.setTransform(3.3,5.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4,-4.1,52.8,34.2);


(lib.ClipGroupcopy_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_5
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#D4D8DC").s().p("AhlBlQgpgqAAg7QAAg6ApgqQAqgqA7AAQA7AAAqAqQAqAqAAA6QAAA7gqAqQgqAqg7AAQg7AAgqgqgAhSgwQgKAGgGAMQgFAMAAAQIAAAEQAAAQAFAMQAGALAKAHQALAGANAAQAOAAAKgGQAKgHAGgMQAFgLAAgQIAAgEQAAgQgFgMQgGgMgKgGQgLgGgNAAQgNAAgLAGgABDA1IAWAAIAAhqIgWAAIAABFIgrhFIgWAAIAABqIAWAAIAAhFgAhLAbQgGgJAAgQIAAgEQAAgRAGgJQAGgIALAAQALAAAGAJQAGAIAAARIAAAEQAAARgGAJQgGAIgLAAQgLAAgGgJg");
	this.shape_6.setTransform(-0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(1));

	// Layer_6
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(167,170,173,0.659)").s().p("AhZB3QgqgqABg7QgBg6AqgqQAqgqA7AAQA7AAAqAqQAWAVgEA5QgEA5gaAOIAAhmIgWAAIAABFIgrhFIgWAAIAABqIAWAAIAAhGIArBGIAPAAQgWALgdAMQhMAfgiAAQgPAAgHgGgAhGgeQgKAGgGAMQgFAMAAAPIAAAFQAAAQAFAMQAGALAKAHQAKAGAOAAQAOAAAKgGQAKgHAGgMQAFgLAAgQIAAgFQAAgPgFgMQgGgMgKgGQgLgGgNAAQgNAAgLAGgAg/AtQgGgJAAgQIAAgFQAAgQAGgJQAGgIALAAQALAAAGAJQAGAIAAAQIAAAFQAAARgGAJQgGAIgLAAQgMAAgFgJg");
	this.shape_7.setTransform(-0.8,-1.2);

	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(1));

	// Layer_7
	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#7AE6FF").s().p("Ah/B/Qg0g1AAhKQAAhKA0g0QA1g1BKAAQBLAAA1A1QA0A0AABKQAABKg0A1Qg1A1hLAAQhKAAg1g1g");
	this.shape_8.setTransform(-0.1,0.1,0.794,0.794);

	this.timeline.addTween(cjs.Tween.get(this.shape_8).wait(1));

	// Layer_8
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#D4D8DC").s().p("Ah/B/Qg0g1AAhKQAAhKA0g0QA1g1BKAAQBLAAA1A1QA0A0AABKQAABKg0A1Qg1A1hLAAQhKAAg1g1g");
	this.shape_9.setTransform(-0.2,0.2,0.794,0.794);

	this.timeline.addTween(cjs.Tween.get(this.shape_9).wait(1));

	// Layer_9
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#F5FAFF").s().p("Ah/B/Qg0g1AAhKQAAhKA0g0QA1g1BKAAQBLAAA1A1QA0A0AABKQAABKg0A1Qg1A1hLAAQhKAAg1g1g");
	this.shape_10.setTransform(-0.3,-0.3,0.794,0.794);

	this.timeline.addTween(cjs.Tween.get(this.shape_10).wait(1));

	// Layer_10
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["#DADDE0","#C7CBD0","#A9AFB6","#C8D1D4","#829093"],[0,0.169,0.388,0.576,1],-17.9,0,18,0).s().p("Ah/B/Qg0g1AAhKQAAhKA0g0QA1g1BKAAQBLAAA1A1QA0A0AABKQAABKg0A1Qg1A1hLAAQhKAAg1g1g");
	this.shape_11.setTransform(-0.4,0.1,1,1,61.2);

	this.timeline.addTween(cjs.Tween.get(this.shape_11).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroupcopy_1, new cjs.Rectangle(-18.5,-18,36.1,36.2), null);


(lib.ClipGroup_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_5
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#D4D8DC").s().p("AhlBlQgpgqAAg7QAAg6ApgqQAqgqA7AAQA7AAAqAqQAqAqAAA6QAAA7gqAqQgqAqg7AAQg7AAgqgqgAhSgwQgKAGgGAMQgFAMAAAQIAAAEQAAAQAFAMQAGALAKAHQALAGANAAQAOAAAKgGQAKgHAGgMQAFgLAAgQIAAgEQAAgQgFgMQgGgMgKgGQgLgGgNAAQgNAAgLAGgABDA1IAWAAIAAhqIgWAAIAABFIgrhFIgWAAIAABqIAWAAIAAhFgAhLAbQgGgJAAgQIAAgEQAAgRAGgJQAGgIALAAQALAAAGAJQAGAIAAARIAAAEQAAARgGAJQgGAIgLAAQgLAAgGgJg");
	this.shape_6.setTransform(-0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(1));

	// Layer_6
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(167,170,173,0.659)").s().p("AhZB3QgqgqABg7QgBg6AqgqQAqgqA7AAQA7AAAqAqQAWAVgEA5QgEA5gaAOIAAhmIgWAAIAABFIgrhFIgWAAIAABqIAWAAIAAhGIArBGIAPAAQgWALgdAMQhMAfgiAAQgPAAgHgGgAhGgeQgKAGgGAMQgFAMAAAPIAAAFQAAAQAFAMQAGALAKAHQAKAGAOAAQAOAAAKgGQAKgHAGgMQAFgLAAgQIAAgFQAAgPgFgMQgGgMgKgGQgLgGgNAAQgNAAgLAGgAg/AtQgGgJAAgQIAAgFQAAgQAGgJQAGgIALAAQALAAAGAJQAGAIAAAQIAAAFQAAARgGAJQgGAIgLAAQgMAAgFgJg");
	this.shape_7.setTransform(-0.8,-1.2);

	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(1));

	// Layer_7
	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#65BED2").s().p("Ah/B/Qg0g1AAhKQAAhKA0g0QA1g1BKAAQBLAAA1A1QA0A0AABKQAABKg0A1Qg1A1hLAAQhKAAg1g1g");
	this.shape_8.setTransform(-0.1,0.1,0.794,0.794);

	this.timeline.addTween(cjs.Tween.get(this.shape_8).wait(1));

	// Layer_8
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#D4D8DC").s().p("Ah/B/Qg0g1AAhKQAAhKA0g0QA1g1BKAAQBLAAA1A1QA0A0AABKQAABKg0A1Qg1A1hLAAQhKAAg1g1g");
	this.shape_9.setTransform(-0.2,0.2,0.794,0.794);

	this.timeline.addTween(cjs.Tween.get(this.shape_9).wait(1));

	// Layer_9
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#F5FAFF").s().p("Ah/B/Qg0g1AAhKQAAhKA0g0QA1g1BKAAQBLAAA1A1QA0A0AABKQAABKg0A1Qg1A1hLAAQhKAAg1g1g");
	this.shape_10.setTransform(-0.3,-0.3,0.794,0.794);

	this.timeline.addTween(cjs.Tween.get(this.shape_10).wait(1));

	// Layer_10
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["#DADDE0","#C7CBD0","#A9AFB6","#C8D1D4","#829093"],[0,0.169,0.388,0.576,1],-17.9,0,18,0).s().p("Ah/B/Qg0g1AAhKQAAhKA0g0QA1g1BKAAQBLAAA1A1QA0A0AABKQAABKg0A1Qg1A1hLAAQhKAAg1g1g");
	this.shape_11.setTransform(-0.4,0.1,1,1,61.2);

	this.timeline.addTween(cjs.Tween.get(this.shape_11).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1, new cjs.Rectangle(-18.5,-18,36.1,36.2), null);


(lib.dertg36copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AisCvIAAldIFZAAIAAFdg");
	this.shape.setTransform(0,0.6);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

	// Layer 1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhsBuQgvguABhAQgBhAAvgsQAsgvBAABQBAgBAuAvQAuAsgBBAQABBAguAuQguAuhAgBQhAABgsgugAhYhYQgmAkAAA0QAAA0AmAmQAkAkA0AAQA0AAAmgkQAkgmAAg0QAAg0gkgkQgmgmg0AAQg0AAgkAmgAgSBiQgFgIgBgLQABgLAFgHQAIgHAKAAQALAAAGAHQAHAHAAALQAAAFgDAEIgEAJIgIAGQgEACgFAAQgLgBgHgGgAgMApIgDgCIgCgDIAAgDQABgSAHgNIAAAAQAHgMAOgNIAAgBIAJgGIAAAAQARgOAAgMQgBgXglAAQgLABgNADIAAASQAAAAAAAAQAAABAAAAQgBABAAAAQAAABgBAAIgCABIgTAAIgEgBIgBgDIAAglIABgDQAAAAABAAQAAAAAAgBQAAAAABAAQAAAAABAAQAagIAaAAQAhAAARALQAUAMgBAXQABAXgbAVIAAAAIgMALQgKAHgFAHQgDAIAAAKIAAAJIgBADQgBABAAAAQgBAAAAABQgBAAAAAAQAAAAgBAAg");
	this.shape_1.setTransform(0.1,0.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.161)").s().p("AhYBaQgmgmAAg0QAAg0AmgkQAkgmA0AAQA0AAAmAmQAkAkAAA0QAAA0gkAmQgmAkg0AAQg0AAgkgkgAgSA9QgFAHgBALQABALAFAIQAHAGALABQAFAAAEgCIAIgGIAEgJQADgEAAgFQAAgLgHgHQgGgHgLAAQgKAAgIAHgAgRAhIAAADIACADIADACIAYAAQABAAAAAAQAAAAABAAQAAgBABAAQAAAAABgBIABgDIAAgJQAAgKADgIQAFgHAKgHIAMgLIAAAAQAbgVgBgXQABgXgUgMQgRgLghAAQgaAAgaAIQgBAAAAAAQgBAAAAAAQAAABAAAAQgBAAAAAAIgBADIAAAlIABADIAEABIATAAIACgBQABAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAAAIAAgSQANgDALgBQAlAAABAXQAAAMgRAOIAAAAIgJAGIAAABQgOANgHAMIAAAAQgHANgBASg");
	this.shape_2.setTransform(0.1,0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1}]}).wait(4));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-15.5,-15.5,31.1,31.1);


(lib.dertg36 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgDCcQhBgCgsguQgtgvAChAQAChBAvgrQAugtBAABQBBADAsAuQAsAugBBBQgDBAgtAtQgtAqg+AAIgEAAgAhWhaQgnAjgBA1QgBA0AlAmQAjAlA0ACQA0ABAngkQAlgkABg0QABg1gjglQgkgmg1gBIgDAAQgyAAgkAjgAglBMIAcgCIABgyIAAglIghgBIABgeIA+ACIgBAxIAABBIAhACIACAcIheAEgAgDg2QgNAAgIgIQgGgIABgNQAAgMAHgJQAHgHAMABQAMAAAIAHQAGAJAAAMQAAAFgDAGQgBAFgEAFIgIAGIgHABIgDAAg");
	this.shape.setTransform(0.2,0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.161)").s().p("AgCB/Qg1gCgjglQglgmACg0QABg1AmgkQAmgkAzACQA2ABAkAmQAjAlgBA0QgBA1gmAkQglAjgzAAIgCAAgAgogOIAgAAIAAAmIAAAyIgcABIgBAeIBegDIgCgcIghgCIgBhCIABgwIg+gCgAgWhoQgHAIAAAMQgBANAHAJQAHAHANAAQAFABAFgCIAIgFQAEgFACgFQACgGABgGQAAgMgHgIQgIgHgLgBIgCAAQgLAAgHAHg");
	this.shape_1.setTransform(0.1,0.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#3F3F3F").s().p("AgDCcQhBgCgsguQgtgvAChAQAChBAvgrQAugtBAABQBBADAsAuQAsAugBBBQgDBAgtAtQgtAqg+AAIgEAAgAhWhaQgnAjgBA1QgBA0AlAmQAjAlA0ACQA0ABAngkQAlgkABg0QABg1gjglQgkgmg1gBIgDAAQgyAAgkAjgAglBMIAcgCIABgyIAAglIghgBIABgeIA+ACIgBAxIAABBIAhACIACAcIheAEgAgDg2QgNAAgIgIQgGgIABgNQAAgMAHgJQAHgHAMABQAMAAAIAHQAGAJAAAMQAAAFgDAGQgBAFgEAFIgIAGIgHABIgDAAg");
	this.shape_2.setTransform(0.2,0.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgDCcQhBgCgsguQgtgvAChAQAChBAvgrQAugtBAABQBBADAsAuQAsAugBBBQgDBAgtAtQgtAqg+AAIgEAAg");
	this.shape_3.setTransform(0.2,0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_1},{t:this.shape_2}]},1).to({state:[{t:this.shape_1},{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-15.4,-15.5,31.2,31.2);


(lib.shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#000000","rgba(0,0,0,0)"],[0,1],-4.1,0,3.8,0).s().p("EgAnA2RMAAAhshIBPAAMAAABshg");
	this.shape.setTransform(4,-347.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-694.5,8,694.5);


(lib.grid = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").p("EA09gxfIAADGIAANsIu/AAIu/AAIAANsIAANsIu+AAIAANrIAANsIAANtIu+AAIu/AAIu/AAIu/AAIu/AAIhHAAEBD8gxfIAADGIu/AAIu/AAIAANsIAANsIu/AAIu+AAIu+AAIu/AAIAANsIu/AAIu/AAIAANrIAANsIAANtIAANsIu/AAIhHAAEAW/gxfIAADGIAANsIu+AAIAANsIAANsIu+AAIu/AAIAANrIAANsIAANtIAANsIu/AAIu/AAEAl+gxfIAADGIu/AAIu+AAIAANsIu+AAIu/AAIAANsIu/AAIu/AAIu/AAIhHAAEBD8gTBIu/AAIu/AAIAANsIu/AAIAANrIAANsIAANtIAANsIu+AAIu+AAIu/AAEBD8ggtIu/AAIAANsIAANsIAANrIAANsIAANtIu/AAIu/AAIu+AAIAANsEBD8ggtIAANsIAANsIu/AAIu/AAIAANrIu/AAIu+AAIu+AAIu/AAIu/AAIu/AAIu/AAIhHAAEBD8guZIAANsEBD8AIWIu/AAIu/AAIAANsIu/AAIu+AAIu+AAIu/AAIu/AAIu/AAIu/AAIhHAAEBD8gFVIAANrIAANsIu/AAIu/AAIAANtIAANsIu/AAEBD8AjvIu/AAIAANsIu/AAEBD8AWCIAANtIAANsIu/AAEAIBgxfIAADGIu+AAIAANsIAANsIAANsIAANrIAANsIAANtIAANsEgV8gxfIAADGIAANsIu/AAIu/AAIAANsIAANsIu/AAIhHAAEgG9gxfIAADGIu/AAIu/AAIAANsIAANsIAANsIAANrIAANsIAANtIAANsEgz6gxfIAADGIAANsIu/AAIhHAAEgk7gxfIAADGIu/AAIu/AAIhHAAEhC5gxfIAADGIAANsIAANsIAANsIAANrIAANsIAANtIAANs");
	this.shape.setTransform(524,-316.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.grid, new cjs.Rectangle(87.8,-634,872.1,635), null);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// objects
	this.instance = new lib.Symbol2();
	this.instance.parent = this;
	this.instance.setTransform(5.3,-15.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56.8,-83.5,124.2,136.1);


(lib.sprite135 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.shape134("synched",0);
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.sprite135, new cjs.Rectangle(-101,-54.5,222,97.1), null);


(lib.sprite127 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.shape119("synched",0);
	this.instance.parent = this;

	this.instance_1 = new lib.shape120("synched",0);
	this.instance_1.parent = this;

	this.instance_2 = new lib.shape121("synched",0);
	this.instance_2.parent = this;

	this.instance_3 = new lib.shape122("synched",0);
	this.instance_3.parent = this;

	this.instance_4 = new lib.shape123("synched",0);
	this.instance_4.parent = this;

	this.instance_5 = new lib.shape124("synched",0);
	this.instance_5.parent = this;

	this.instance_6 = new lib.shape125("synched",0);
	this.instance_6.parent = this;

	this.instance_7 = new lib.shape126("synched",0);
	this.instance_7.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},2).to({state:[{t:this.instance_2}]},2).to({state:[{t:this.instance_3}]},2).to({state:[{t:this.instance_4}]},2).to({state:[{t:this.instance_5}]},2).to({state:[{t:this.instance_6}]},2).to({state:[{t:this.instance_7}]},2).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,88.8,11);


(lib.sprite118 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.shape110("synched",0);
	this.instance.parent = this;

	this.instance_1 = new lib.shape111("synched",0);
	this.instance_1.parent = this;

	this.instance_2 = new lib.shape112("synched",0);
	this.instance_2.parent = this;

	this.instance_3 = new lib.shape113("synched",0);
	this.instance_3.parent = this;

	this.instance_4 = new lib.shape114("synched",0);
	this.instance_4.parent = this;

	this.instance_5 = new lib.shape115("synched",0);
	this.instance_5.parent = this;

	this.instance_6 = new lib.shape116("synched",0);
	this.instance_6.parent = this;

	this.instance_7 = new lib.shape117("synched",0);
	this.instance_7.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},2).to({state:[{t:this.instance_2}]},2).to({state:[{t:this.instance_3}]},2).to({state:[{t:this.instance_4}]},2).to({state:[{t:this.instance_5}]},2).to({state:[{t:this.instance_6}]},2).to({state:[{t:this.instance_7}]},2).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,130,15.4);


(lib.sprite109 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.shape100("synched",0);
	this.instance.parent = this;

	this.instance_1 = new lib.shape101("synched",0);
	this.instance_1.parent = this;

	this.instance_2 = new lib.shape102("synched",0);
	this.instance_2.parent = this;

	this.instance_3 = new lib.shape103("synched",0);
	this.instance_3.parent = this;

	this.instance_4 = new lib.shape104("synched",0);
	this.instance_4.parent = this;

	this.instance_5 = new lib.shape105("synched",0);
	this.instance_5.parent = this;

	this.instance_6 = new lib.shape106("synched",0);
	this.instance_6.parent = this;

	this.instance_7 = new lib.shape107("synched",0);
	this.instance_7.parent = this;

	this.instance_8 = new lib.shape108("synched",0);
	this.instance_8.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,19.3,7.4);


(lib.sprite94 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Mask Layer 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AsQV6QlGh0AAijIAL94Ig+jsIgMgfIgFgqQgBiuFbh6QFZh8HnABQHmgBFaB8QFZB6ACCsIhJENIALd4IgFAqQAACjlGB0QlGB0nLAAQnMAAlFh0g");
	mask.setTransform(117.9,-151.8);

	// Layer_4
	this.instance = new lib.Tween7("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(195.6,-180.4);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:22.6,y:-89},16,cjs.Ease.get(1)).to({x:90.2,y:-196},16,cjs.Ease.get(-1)).to({x:97.5,y:-204.7},16,cjs.Ease.get(1)).to({x:195.6,y:-180.4},16,cjs.Ease.get(-1)).wait(1));

	// Layer_3
	this.instance_1 = new lib.Tween8("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-20.9,-97.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:167.8,y:-179.4},16,cjs.Ease.get(1)).to({x:154.7,y:-63.1},16,cjs.Ease.get(-1)).to({x:87.1,y:-58.3},16,cjs.Ease.get(1)).to({x:-20.9,y:-97.2},16,cjs.Ease.get(-1)).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.498)").s().p("A9IZOMAAAgybMA6RAAAMAAAAybg");
	this.shape.setTransform(101.2,-147.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(65));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-303.5,235.8,303.6);


(lib.sprite77 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 4
	this.instance = new lib.shape76("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-11,17,0.28,0.28);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(7).to({_off:false},0).to({x:-12.3,y:13.8,alpha:0.93},1).to({x:-11.2,y:10.7,alpha:0.852},1).to({x:-9.4,y:8.1,alpha:0.77},1).to({x:-14.3,y:3.7,alpha:0.621},2).to({x:-14.2,y:0.3,alpha:0.539},1).to({x:-12.5,y:-2.5,alpha:0.469},1).to({x:-9.3,y:-3.1,alpha:0.391},1).to({x:-7.9,y:-6.4,alpha:0.32},1).to({x:-7,y:-20.5,alpha:0.012},4).wait(1));

	// Layer 3
	this.instance_1 = new lib.shape76("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-28.2,-4.7,0.28,0.28);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(3).to({_off:false},0).to({x:-28.5,y:-12.4,alpha:0.77},3).to({x:-29.5,y:-14.6,alpha:0.699},1).to({x:-31.2,y:-16.4,alpha:0.621},1).to({x:-32.5,y:-18.5,alpha:0.539},1).to({x:-32.6,y:-21.1,alpha:0.469},1).to({x:-24.7,y:-33.5,alpha:0.012},6).to({_off:true},1).wait(4));

	// Layer 2
	this.instance_2 = new lib.shape76("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(45.8,5.5,0.28,0.28);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(5).to({_off:false},0).to({x:44.6,y:3.3,alpha:0.93},1).to({x:43.1,y:1.6,alpha:0.852},1).to({x:41,y:1.5,alpha:0.77},1).to({x:39.1,y:-3.1,alpha:0.621},2).to({x:38.8,y:-5.4,alpha:0.539},1).to({x:39,y:-7.8,alpha:0.469},1).to({x:40.5,y:-12.3,alpha:0.32},2).to({x:40.9,y:-14.6,alpha:0.238},1).to({x:40.1,y:-16.7,alpha:0.16},1).to({x:41.4,y:-18.9,alpha:0.09},1).to({x:43,y:-20.7,alpha:0.012},1).to({_off:true},1).wait(2));

	// Layer 1
	this.instance_3 = new lib.shape76("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(22,1,0.28,0.28);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({x:20.8,y:-3.7,alpha:0.852},2).to({x:20.9,y:-6,alpha:0.77},1).to({x:25.4,y:-17,alpha:0.391},5).to({x:25.2,y:-21.6,alpha:0.238},2).to({x:23.9,y:-23.5,alpha:0.16},1).to({x:19.3,y:-25.2,alpha:0.012},2).to({_off:true},1).wait(7));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(19.1,-1.9,5.9,5.9);


(lib.sprite74 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.shape73("synched",0);
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1,skewY:20},1).to({scaleX:1,skewY:160.2},7).to({scaleX:1,skewY:180},1).to({scaleX:1,skewY:144.1},2).to({scaleX:1,skewY:18},7).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-6.4,-32.1,12.9,64.3);


(lib.button12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 9
	this.instance = new lib.text9("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-34.6,46.8);
	this.instance.shadow = new cjs.Shadow("#FFFFFF",1,1,0);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},3).wait(1));

	// Layer 7
	this.instance_1 = new lib.ClipGroup();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-2.8,11,1.639,1.639,0,0,0,1,0.8);

	this.instance_2 = new lib.ClipGroupcopy();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-2.8,11,1.639,1.639,0,0,0,1,0.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2}]},1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-40.6,-19.8,95,102.5);


(lib.Symbol27 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.xi = new lib.Symbol33copy();
	this.xi.name = "xi";
	this.xi.parent = this;
	this.xi.setTransform(-1237.8,-24,1,1,-90);
	new cjs.ButtonHelper(this.xi, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.xi).wait(1));

	// Symbol 19
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ABUEDIAAl5QABgugTgVQgSgVgsAAQgfAAgWAPQgWAOgMAbIAAELIhAAAIAAlxIA5AAIAFAvQApg1BDAAQBAAAAfAhQAdAiABBGIAAF8g");
	this.shape.setTransform(-2145.2,-136.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAuEiIATgVQARgVABgVQgBgNgNgIQgNgIgngJQgmgJgdgKQgdgMgVgSQgUgSgLgaQgLgaAAgmQAAgxAcgiQAcgjA0gQQgpgOgWgaQgXgaAAghQAAg3AsgfQAtgfBNgBQAxAAAmAOIgJAzQgtgNghAAQgwAAgbASQgbARAAAdQAABMBwAAIAuAAIAAAzIgzAAQg9ABgiAbQgiAbAAA2QgBAnAZAbQAZAaAtALQAuALAVAHQAWAGALAHQAbARAAAjQAAAWgSAdQgSAdgYAUg");
	this.shape_1.setTransform(-2181.5,-143.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhxDqQgigmgBhKIAAjiIBAAAIAADdQAABoBEAAQArAAAegrQAdgrAAg+QgChOgohjIBCAAQAnBTAABeQAABagsA3QgsA2hKAAQhCAAgigmgAgjicIAShzIA7AAIgoBzg");
	this.shape_2.setTransform(-2217.6,-151.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AglEKIAAidQhXgJgtg0Qgsg0AAheIAAinIA/AAIAACrQABBCAdAmQAcAnA3AIIAAlCIA/AAIAAFDQA6gIAhgnQAhgnABg9QgChPgphhIBBAAQApBRAABfQAABZgxAzQgwA0hbAHIAACcg");
	this.shape_3.setTransform(-2261.7,-135.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("ABVEDIAAl5QgBgugSgVQgSgVgsAAQgfAAgWAPQgWAOgMAbIAAELIg/AAIAAlxIA4AAIAFAvQAog1BEAAQBAAAAeAhQAeAiABBGIAAF8g");
	this.shape_4.setTransform(-2323.6,-136.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("ABVFYIAAl5QAAgvgTgVQgTgVgsAAQgeAAgWAPQgWAPgMAaIAAEMIhAAAIAAlxIA6AAIADAuQApg1BEAAQBAAAAeAiQAeAhAABGIAAF9gAgWjkIAShzIA7AAIgoBzg");
	this.shape_5.setTransform(-2380.6,-145.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("ABUEDIAAl5QAAgugSgVQgTgVgsAAQgeAAgWAPQgWAOgMAbIAAELIhAAAIAAlxIA6AAIADAvQAqg1BDAAQBAAAAfAhQAdAiAABGIAAF8g");
	this.shape_6.setTransform(-2437.5,-136.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AiFCIQgugzAAhWIAAgFQABg0ATgpQAVgqAlgWQAlgYAvAAIDFAAIAAA0IhiAAQBFAyAABdIAAAFQAAAxgVAoQgVAoglAXQgnAXgvABQhKAAgtg1gAhYhkQgbAjAABCQAAA+AbAlQAbAkAvAAQAwAAAbgkQAbglAAhFQAAg7gbgjQgdgjguAAQgvAAgbAjg");
	this.shape_7.setTransform(-2475.6,-143.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgWC5IiGlxIBAAAIBdEbIBckbIBAAAIiEFxg");
	this.shape_8.setTransform(-2513.9,-143.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("ABJCIQgkA4hHAAQhBAAgngwQgngxAAhTIAAgFQAAhaAng2QAmg2BDAAQBFAAAkA3IAGgwIA2AAIAAEPQAAAwAbAAQAGAAAGgCIAHAvQgQAMgZAAQgzAAgNg4gAhYhkQgaAnAABLQAAA8AZAhQAZAhAuAAQA6AAAcg/IAAiYQgdhAg4AAQguAAgZAng");
	this.shape_9.setTransform(-2549.1,-143.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AiREAIAAn/IBAAAIAADYQAAA3ASAbQARAbAoAAQBDAAAVg0IAAkRIBAAAIAAFxIg5AAIgEgoQgfAvg5AAQgzAAgbgZIAACgg");
	this.shape_10.setTransform(-2590.1,-136.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AibEDIAAlTQABg2ATgoQATgpAkgWQAigVAsAAQBGAAAqAwQAqAwAEBXIAAAWQgBBRglAwQgnAwhBAAQhCAAgngqIAACxgAhDiqQgYAlAAA6IAABhQAcAyA7AAQAtAAAZghQAbghAAhCQgBhGgYgmQgZgmgtAAQgoAAgZAkg");
	this.shape_11.setTransform(-2629,-136.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AhwD2QgqgfAAgyQAAg/BGgXQgegMgRgVQgQgVAAgZQAAgyAogcQAngcBEAAQBAAAAqAeQAqAfAAAwIg/AAQAAgXgYgSQgZgRgkAAQglAAgYAPQgXAQAAAZQAAA2BUAAIBCAAIAAAyIhMAAQhQACABA6QAAAaAYARQAZARAoAAQAmAAAbgTQAagSAAgdIBAAAQgBA1grAhQgsAfhDAAQhFAAgrgegAgXigIAShzIA7AAIgoBzg");
	this.shape_12.setTransform(-2668.4,-152);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AhyDHQgpg5gBhpIAAhFQAAhtAog5QApg5BLAAQBMAAAoA4QAoA3ABBpIAABFQAABugoA6QgoA6hMAAQhKAAgpg5gAhdAoQAABPAZAqQAZArAsAAQAsAAAYgpQAYgpABhOIAAgRIi7AAgAhFihQgYApAABNIAAATIC7AAIAAgTQAAhNgYgpQgYgqguAAQgtAAgYAqg");
	this.shape_13.setTransform(-2707.2,-150);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("ABVEDIAAl5QgBgugSgVQgSgVgsAAQgfAAgWAPQgWAOgMAbIAAELIg/AAIAAlxIA4AAIAFAvQApg1BDAAQBAAAAeAhQAeAiABBGIAAF8g");
	this.shape_14.setTransform(-1415.1,-220.8);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AhCBWIAAkQIA/AAIAAEUQAAAWAJAKQAJAMAWAAQARAAANgFIAAA0QgYAGgYAAQhVAAAAhlg");
	this.shape_15.setTransform(-1461.4,-227.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AhwCiQgqgfAAgyQAAhABGgVQgdgNgRgUQgRgVAAgZQAAgzAngcQAogdBEAAQBAAAAqAfQArAfgBAwIg+AAQAAgYgZgRQgYgRglAAQgmAAgWAPQgYAQAAAZQABA3BTAAIBCAAIAAAxIhMAAQhQACAAA6QAAAaAZARQAZARAoAAQAmAAAbgTQAbgTAAgcIA/AAQAAA1grAgQgsAghEAAQhFAAgrgeg");
	this.shape_16.setTransform(-1493.6,-227.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AiFCJQgug0AAhXIAAgEQABg0ATgpQAUgpAmgYQAlgXAvAAIDEAAIAAA0IhhAAQBFAzAABcIAAAFQAAAxgVAoQgVAogmAXQgmAXgvAAQhKABgtg0gAhYhkQgbAiAABDQAAA+AbAlQAcAlAuAAQAwAAAbglQAbgmAAhEQAAg7gbgjQgdgjguAAQgvAAgbAjg");
	this.shape_17.setTransform(-1530.8,-227.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("ABUFYIAAl5QAAgvgSgVQgSgVgtAAQgeAAgWAPQgWAPgMAaIAAEMIhAAAIAAlxIA6AAIADAuQApg1BEAAQBBAAAeAiQAdAhAABGIAAF9gAgWjkIAShzIA7AAIgnBzg");
	this.shape_18.setTransform(-1572,-229.3);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgWC5IiGlxIBAAAIBdEbIBckbIBAAAIiEFxg");
	this.shape_19.setTransform(-1608.7,-227.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AhCBWIAAkQIA/AAIAAEUQAAAWAJAKQAJAMAWAAQAQAAAOgFIAAA0QgYAGgYAAQhVAAAAhlg");
	this.shape_20.setTransform(-1634.8,-227.4);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("ABQC5IiKidIglAAIAACdIhAAAIAAlxIBAAAIAACcIAgAAICGicIBMAAIiaCzICnC+g");
	this.shape_21.setTransform(-1665.9,-227.6);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AhwCiQgqgfAAgyQAAhABGgVQgdgNgRgUQgRgVAAgZQAAgzAngcQAogdBEAAQBAAAAqAfQArAfAAAwIhAAAQABgYgZgRQgYgRglAAQgmAAgWAPQgYAQAAAZQABA3BTAAIBCAAIAAAxIhMAAQhQACAAA6QAAAaAZARQAaARAnAAQAnAAAagTQAbgTAAgcIA/AAQAAA1grAgQgsAghEAAQhFAAgrgeg");
	this.shape_22.setTransform(-1706,-227.6);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AAuEjIATgXQASgUgBgVQAAgNgMgIQgOgIgngIQgmgKgdgLQgdgLgUgSQgVgSgKgaQgMgaAAgmQAAgwAcgjQAcgjAzgQQgogOgWgaQgXgaAAghQAAg2AtgfQArghBNAAQAyAAAmAOIgJAzQgtgMgiAAQguAAgcARQgbASAAAcQAABMBwgBIAuAAIAAA0IgzAAQg9ABgiAbQgjAbAAA2QAAAnAZAbQAZAaAtAMQAuALAVAGQAWAGALAHQAbAQAAAkQAAAXgSAcQgSAdgZAUg");
	this.shape_23.setTransform(-1741.4,-227.6);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("ABJCIQgkA4hHAAQhBAAgngwQgngxAAhTIAAgFQAAhaAng2QAmg2BDAAQBFAAAkA3IAGgwIA2AAIAAEPQAAAwAbAAQAGAAAGgCIAHAvQgQAMgZAAQgzAAgNg4gAhYhkQgaAnAABLQAAA8AZAhQAZAhAuAAQA6AAAcg/IAAiYQgdhAg4AAQguAAgZAng");
	this.shape_24.setTransform(-1794.9,-227.6);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgWC5IiGlxIBAAAIBdEbIBckbIBAAAIiEFxg");
	this.shape_25.setTransform(-1833.1,-227.6);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("ABJCIQgkA4hHAAQhBAAgngwQgngxAAhTIAAgFQAAhaAng2QAmg2BDAAQBFAAAkA3IAGgwIA2AAIAAEPQAAAwAbAAQAGAAAGgCIAHAvQgQAMgZAAQgzAAgNg4gAhYhkQgaAnAABLQAAA8AZAhQAZAhAuAAQA6AAAcg/IAAiYQgdhAg4AAQguAAgZAng");
	this.shape_26.setTransform(-1885.7,-227.6);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AhCBWIAAkQIBAAAIAAEUQgBAWAJAKQAJAMAWAAQARAAANgFIAAA0QgYAGgZAAQhUAAAAhlg");
	this.shape_27.setTransform(-1916.1,-227.4);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgfEAIAAikIiClbIBBAAIBhETIBgkTIBBAAIiCFdIAACig");
	this.shape_28.setTransform(-1946.8,-220.5);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AAhDfIARgSQAQgVABgYQgBgPgLgHQgMgHgegHQhQgSgqgrQgrgsAAhHIAAgPQAAg0AVgrQAUgrAlgXQAkgXAvAAQBBAAAnAkQAnAkAAA+Ig7AAQAAgmgYgWQgWgWgmAAQgsAAgbAlQgaAlAAA+IAAALQAABXBsAiIAuANQAhAKAOARQAOAQAAAbQgBAWgQAdQgSAcgZAVg");
	this.shape_29.setTransform(-2000.8,-221.5);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AhwCiQgqgfAAgyQAAhABGgVQgegNgRgUQgQgVAAgZQAAgzAogcQAngdBEAAQBAAAAqAfQAqAfAAAwIg/AAQABgYgZgRQgYgRglAAQgmAAgWAPQgYAQAAAZQAAA3BUAAIBCAAIAAAxIhMAAQhPACAAA6QAAAaAYARQAZARAoAAQAmAAAbgTQAagTABgcIA/AAQgBA1grAgQgsAghDAAQhFAAgrgeg");
	this.shape_30.setTransform(-2038.4,-227.6);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgOCkQgVgaAAgyIAAjgIh2AAIAAgzIEzAAIAAAzIh+AAIAADhQAAAtAkAAQAPABAQgJIAOAsQgZATglgBQgrABgSgZg");
	this.shape_31.setTransform(-2075.5,-227.2);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AA+BWIAAjbIiIAAIAAE8Ig/AAIAAk8Ig6AAIAAg1IF1AAIAAA1Ig0AAIAADfQAAAVAJALQAJAMAWAAQAQAAANgFIABA0QgYAGgZAAQhVAAAAhlg");
	this.shape_32.setTransform(-2114.4,-227.4);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("Ah5DgQgug1AAhWIAAgEQgBg2AWgrQAVgrAmgYQAngXAwAAQBLAAAvA0QAuA0AABWIAAAEQAAA2gUAsQgVAqgnAYQgmAYgyAAQhKAAgvg0gAhLgRQgdAkAABFQAAA+AdAlQAdAlAuAAQAxAAAbglQAdgmAAhEQAAg9gdglQgdglgvAAQgvAAgcAlgAgZigIAShzIA6AAIgnBzg");
	this.shape_33.setTransform(-2155.4,-236);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("ABQC5IiKidIglAAIAACdIhAAAIAAlxIBAAAIAACcIAgAAICGicIBMAAIiaCzICnC+g");
	this.shape_34.setTransform(-2193.1,-227.6);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("ABJCIQgkA4hHAAQhBAAgngwQgngxAAhTIAAgFQAAhaAng2QAmg2BDAAQBFAAAkA3IAGgwIA2AAIAAEPQAAAwAbAAQAGAAAGgCIAHAvQgQAMgZAAQgzAAgNg4gAhYhkQgaAnAABLQAAA8AZAhQAZAhAuAAQA6AAAcg/IAAiYQgdhAg4AAQguAAgZAng");
	this.shape_35.setTransform(-2232.6,-227.6);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AhCBWIAAkQIBAAAIAAEUQAAAWAIAKQAJAMAWAAQAQAAAOgFIAAA0QgYAGgZAAQhUAAAAhlg");
	this.shape_36.setTransform(-2263.1,-227.4);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("Ah3DcQgtgyAAhTIAAgEQAAg5AggsQAggtAxgMIAAgCQgigNgSgYQgTgYAAgfQAAguAjgbQAjgcA6AAQAwAAAuATIgBA3QgzgUgrAAQgcAAgRAMQgSAMAAAWQAAAlBLAaQBMAaAjAuQAjAtACBDIAAANQAAA0gUAqQgUApgmAXQglAXgyAAQhLAAgsgzgAhIgLQgdAiAABDQAAA8AcAjQAcAiAtAAQAvAAAbgiQAcgiAAhEQAAgvgdgkQgdglgrgJQgtAAgcAjg");
	this.shape_37.setTransform(-2296.2,-235.5);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AAiDfIAPgSQASgVgBgYQAAgPgMgHQgMgHgdgHQhQgSgqgrQgrgsAAhHIAAgPQAAg0AVgrQAUgrAlgXQAkgXAvAAQBAAAAoAkQAnAkAAA+Ig8AAQAAgmgWgWQgXgWgmAAQgtAAgaAlQgaAlAAA+IAAALQAABXBsAiIAuANQAhAKAOARQAOAQAAAbQgBAWgRAdQgRAcgZAVg");
	this.shape_38.setTransform(-2352.3,-221.5);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AhxCWQgigmgBhJIAAjiIBAAAIAADcQAABoBEAAQArAAAegrQAdgqAAg+QgChPgohiIBCAAQAnBSAABfQAABagsA2QgsA2hKAAQhCABgigng");
	this.shape_39.setTransform(-2389.4,-227.2);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("Ah5CLQgug0AAhWIAAgEQgBg2AWgrQAVgsAmgXQAngYAwAAQBLAAAvA0QAuA1AABWIAAAEQAAA2gUArQgVArgnAYQgmAYgyAAQhKAAgvg1gAhLhmQgdAmAABEQAAA9AdAmQAdAlAuAAQAxAAAbgmQAdgmAAhDQAAg8gdgmQgdgmgvAAQgvAAgcAlg");
	this.shape_40.setTransform(-2429.1,-227.6);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AgOCkQgUgaAAgyIAAjgIh4AAIAAgzIE1AAIAAAzIh/AAIAADhQAAAtAkAAQAOABARgJIAPAsQgaATglgBQgqABgTgZg");
	this.shape_41.setTransform(-2467.3,-227.2);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AhwCiQgqgfAAgyQAAhABGgVQgegNgRgUQgQgVAAgZQAAgzAogcQAngdBEAAQBAAAAqAfQAqAfAAAwIg/AAQABgYgZgRQgZgRgkAAQgmAAgWAPQgYAQAAAZQABA3BTAAIBCAAIAAAxIhMAAQhQACAAA6QABAaAYARQAZARAoAAQAmAAAbgTQAagTABgcIA/AAQgBA1grAgQgsAghDAAQhFAAgrgeg");
	this.shape_42.setTransform(-2521.8,-227.6);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AgOCkQgVgaAAgyIAAjgIh2AAIAAgzIEzAAIAAAzIh+AAIAADhQAAAtAkAAQAPABAQgJIAOAsQgZATglgBQgrABgSgZg");
	this.shape_43.setTransform(-2558.9,-227.2);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AiFCJQgtg0AAhXIAAgEQgBg0AUgpQAUgpAmgYQAlgXAvAAIDFAAIAAA0IhhAAQBEAzAABcIAAAFQAAAxgVAoQgVAoglAXQgmAXgwAAQhKABgtg0gAhYhkQgbAiAABDQAAA+AbAlQAcAlAuAAQAvAAAbglQAcgmgBhEQABg7gcgjQgcgjguAAQgvAAgbAjg");
	this.shape_44.setTransform(-2595.5,-227.2);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AhwD2QgqgeAAgzQAAhABGgWQgegNgRgUQgQgVAAgZQAAgyAogcQAngdBEAAQBAAAAqAgQAqAeAAAwIg/AAQABgYgZgRQgZgRgkAAQgmAAgWAQQgYAPAAAYQAAA3BUAAIBCAAIAAAyIhMAAQhPADAAA5QgBAbAZAQQAZARAoAAQAmAAAbgTQAagTAAgcIBAAAQgBA2grAfQgrAghEAAQhFAAgrgegAgXigIAShzIA7AAIgoBzg");
	this.shape_45.setTransform(-2635.6,-236);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AhCBWIAAkQIA/AAIAAEUQAAAWAJAKQAJAMAWAAQAQAAAOgFIAAA0QgYAGgYAAQhVAAAAhlg");
	this.shape_46.setTransform(-2663.7,-227.4);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AB6D5IAAm7Ij0AAIAAG7IhCAAIAAnxIF4AAIAAHxg");
	this.shape_47.setTransform(-2702.1,-234);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#FFFFFF").ss(6,1,1).p("Ak9BJIJ8k2InRHb");
	this.shape_48.setTransform(-1159,-363.4);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#FEFBF1").ss(6,1,1).p("EB9igdwQDdEIAAFkMAAAAoJQAAGWkfEfQkfEemVAAMjjXAAAQlUAAkCjKQgwgmguguQkfkfAAmWIAAjQIAAkSIAAkuIAA28IAAk9QAAiNAjiAQAShDAfhDQBHieCEiDQEfkfGVAAMDjXAAAQFOAAD9DC");
	this.shape_49.setTransform(-1977.2,-149.1);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#549FAC").s().p("EhzlAkTQlVAAkBjKQgxgmguguQkekfAAmWIAAjRIAAkSIAAkuIAA28IAAk9QAAiNAjiAQAShCAehDQBIieCDiEQEfkfGWAAMDjWAAAQFOAAD9DDIJ9k4InRHdQDcEIAAFjMAAAAoKQAAGWkfEfQkeEemWAAg");
	this.shape_50.setTransform(-1964.9,-155);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2805.6,-390.2,1681.5,470.6);


(lib.button12copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 9
	this.instance = new lib.text16("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-20.2,47.1);
	this.instance.shadow = new cjs.Shadow("#FFFFFF",1,1,0);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},3).wait(1));

	// Layer 7
	this.instance_1 = new lib.ClipGroup_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-2.8,11,1.639,1.639,0,0,0,1,0.8);

	this.instance_2 = new lib.ClipGroupcopy_1();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-2.8,11,1.639,1.639,0,0,0,1,0.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2}]},1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,-19.8,68.6,103.7);


(lib.gridandgrey = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// grid
	this.instance = new lib.grid();
	this.instance.parent = this;
	this.instance.setTransform(551.8,-453.2,1.16,1.146,0,0,0,479.4,-394.1);
	this.instance.alpha = 0.301;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#444444").s().p("EhO8ADKIAAmTMCd5AAAIAAGTg");
	this.shape.setTransform(603.9,-21.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// grey
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.137)").s().p("EhO6A4HMAAAhwNMCd1AAAMAAABwNg");
	this.shape_1.setTransform(603.6,-363.2);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// skia
	this.instance_1 = new lib.shadow("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(1110.7,-360.7,0.928,1.039,0,0,0,2.2,-347.3);
	this.instance_1.alpha = 0.43;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(97.9,-727.6,1018.2,727.6);


(lib.sprite143 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{standby:0,icecube_to_water:1,water_to_steam:161,water_boiling:208,steam_to_water:298,ice_to_water:459,water_to_ice:619});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_160 = function() {
		this.stop();
		//_root.matterChanged(2);
	}
	this.frame_297 = function() {
		this.stop();
		//_root.matterChanged(3);
	}
	this.frame_458 = function() {
		this.stop();
		//_root.matterChanged(2);
	}
	this.frame_618 = function() {
		this.stop();
		//_root.matterChanged(2);
	}
	this.frame_688 = function() {
		this.stop();
		//_root.matterChanged(1);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(160).call(this.frame_160).wait(137).call(this.frame_297).wait(161).call(this.frame_458).wait(160).call(this.frame_618).wait(70).call(this.frame_688).wait(1));

	// Layer 64
	this.instance = new lib.shape66("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(10.7,-109.8,2.55,2.55);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(689));

	// Layer 57
	this.instance_1 = new lib.sprite109("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,-166.8);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(298).to({_off:false},0).to({_off:true},160).wait(231));

	// Layer 55
	this.instance_2 = new lib.sprite109("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(95,-185.3);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(298).to({_off:false},0).to({_off:true},160).wait(231));

	// Layer 53
	this.instance_3 = new lib.sprite127();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-55.3,-185.3);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(298).to({_off:false},0).to({_off:true},160).wait(231));

	// Layer 51
	this.instance_4 = new lib.sprite118();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-55.3,-193.8);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(298).to({_off:false},0).to({_off:true},160).wait(231));

	// Layer 49
	this.instance_5 = new lib.sprite94();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-107.1,41);

	this.instance_6 = new lib.sprite109("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(-97.3,-182.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_5}]},297).to({state:[{t:this.instance_6}]},1).to({state:[]},160).wait(231));

	// Layer 40
	this.instance_7 = new lib.sprite94();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-107.1,41);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(208).to({_off:false},0).wait(1).to({alpha:1},87).wait(1).to({alpha:0.012},160).wait(1).to({alpha:0},0).wait(231));

	// Layer 38
	this.instance_8 = new lib.sprite78();
	this.instance_8.parent = this;
	this.instance_8.setTransform(7.5,-13.3);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(208).to({_off:false},0).wait(63).to({alpha:0},25).to({_off:true},1).wait(392));

	// Layer 33
	this.instance_9 = new lib.sprite77("synched",0);
	this.instance_9.parent = this;
	this.instance_9.setTransform(-52.2,-8.2,0.63,0.63);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(235).to({_off:false},0).wait(36).to({startPosition:12},0).to({alpha:0,startPosition:19},25).to({_off:true},1).wait(392));

	// Layer 28
	this.instance_10 = new lib.sprite77("synched",0);
	this.instance_10.parent = this;
	this.instance_10.setTransform(18.2,-13.9,0.69,0.69);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(226).to({_off:false},0).wait(45).to({startPosition:0},0).to({alpha:0,startPosition:7},25).to({_off:true},1).wait(392));

	// Layer 23
	this.instance_11 = new lib.sprite77("synched",0);
	this.instance_11.parent = this;
	this.instance_11.setTransform(51.8,5.3,0.69,0.69);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(218).to({_off:false},0).wait(53).to({startPosition:8},0).to({alpha:0,startPosition:15},25).to({_off:true},1).wait(392));

	// Layer 18
	this.instance_12 = new lib.sprite77("synched",0);
	this.instance_12.parent = this;
	this.instance_12.setTransform(-41.9,7.7,0.87,0.87);
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(208).to({_off:false},0).wait(63).to({startPosition:18},0).to({alpha:0,startPosition:4},25).to({_off:true},1).wait(392));

	// Layer 16
	this.instance_13 = new lib.sprite74();
	this.instance_13.parent = this;
	this.instance_13.setTransform(25.9,-18.4);
	this.instance_13.alpha = 0.809;
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(221).to({_off:false},0).to({y:-71.2,alpha:0.34},16).to({y:-81.4,alpha:0.289},2).to({y:-148,alpha:0},13).to({_off:true},1).wait(436));

	// Layer 14
	this.instance_14 = new lib.sprite74();
	this.instance_14.parent = this;
	this.instance_14.setTransform(25.9,-18.4);
	this.instance_14.alpha = 0.809;
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(174).to({_off:false},0).to({y:-71.2,alpha:0.34},16).to({y:-81.4,alpha:0.289},2).to({y:-148,alpha:0},13).to({_off:true},1).wait(22).to({_off:false,x:66.2,y:-41.5,alpha:0.828},0).to({y:-54.5,alpha:0.711},5).to({y:-109.9,alpha:0.281},14).to({y:-147.1,alpha:0},7).to({_off:true},1).wait(434));

	// Layer 12
	this.instance_15 = new lib.sprite74();
	this.instance_15.parent = this;
	this.instance_15.setTransform(66.2,-41.5);
	this.instance_15.alpha = 0.828;
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(181).to({_off:false},0).to({y:-54.5,alpha:0.711},5).to({y:-109.9,alpha:0.281},14).to({y:-147.1,alpha:0},7).to({_off:true},1).wait(16).to({_off:false,x:-60.9,y:-43,alpha:0.82},0).to({y:-160.6,alpha:0},30).to({_off:true},1).wait(434));

	// Layer 10
	this.instance_16 = new lib.sprite74();
	this.instance_16.parent = this;
	this.instance_16.setTransform(-60.9,-43);
	this.instance_16.alpha = 0.82;
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(174).to({_off:false},0).to({y:-160.6,alpha:0},30).to({_off:true},1).wait(3).to({_off:false,x:1.9,y:-18.4,alpha:0.809},0).to({y:-71.2,alpha:0.34},16).to({y:-81.4,alpha:0.289},2).to({y:-148,alpha:0},13).to({_off:true},1).wait(449));

	// Layer 8
	this.instance_17 = new lib.sprite74();
	this.instance_17.parent = this;
	this.instance_17.setTransform(1.9,-18.4);
	this.instance_17.alpha = 0.809;
	this.instance_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(166).to({_off:false},0).to({y:-71.2,alpha:0.34},16).to({y:-81.4,alpha:0.289},2).to({y:-148,alpha:0},13).to({_off:true},1).wait(17).to({_off:false,x:54.2,y:-41.5,alpha:0.828},0).to({y:-54.5,alpha:0.711},5).to({y:-109.9,alpha:0.281},14).to({y:-147.1,alpha:0},7).to({_off:true},1).wait(447));

	// Layer 6
	this.instance_18 = new lib.sprite74();
	this.instance_18.parent = this;
	this.instance_18.setTransform(54.2,-41.5);
	this.instance_18.alpha = 0.828;
	this.instance_18._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(168).to({_off:false},0).to({y:-54.5,alpha:0.711},5).to({y:-109.9,alpha:0.281},14).to({y:-147.1,alpha:0},7).to({_off:true},1).wait(13).to({_off:false,x:-48.9,y:-43,alpha:0.82},0).to({y:-160.6,alpha:0},30).to({y:-43,alpha:0.82},1).to({y:-156.5,alpha:0.039},29).wait(1).to({y:-160.6,alpha:0},0).wait(420));

	// Layer 4
	this.instance_19 = new lib.Tween1("synched",0);
	this.instance_19.parent = this;
	this.instance_19.setTransform(9.3,-28.8);

	this.instance_20 = new lib.sprite74();
	this.instance_20.parent = this;
	this.instance_20.setTransform(-48.9,-43);
	this.instance_20.alpha = 0.82;
	this.instance_20._off = true;

	this.instance_21 = new lib.sprite135();
	this.instance_21.parent = this;
	this.instance_21.setTransform(1.1,-1.6);
	this.instance_21._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_19).to({scaleX:0.02,scaleY:0.02,x:11.2,y:-11.3},159,cjs.Ease.get(-1)).to({_off:true},1).wait(529));
	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(161).to({_off:false},0).to({y:-160.6,alpha:0},30).to({_off:true},1).wait(497));
	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(459).to({_off:false},0).to({scaleX:0.05,scaleY:0.05,x:10.4,y:-3.8},158).to({_off:true},1).wait(71));

	// Layer_11
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFgIhMgZQj2hYgBh0IAAj1QABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAAD1QgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape.setTransform(10.6,-6.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFfIhMgZQj2hYgBh1IAAjyQABiFFChfQFHhiHLABQHMgBFHBiQFCBfABCFIAADyQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_1.setTransform(10.6,-6.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFeIhMgZQj2hYgBh1IAAjvQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAADvQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_2.setTransform(10.6,-6.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFcIhMgZQj2hXgBh1IAAjtQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAADtQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_3.setTransform(10.6,-6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFbIhMgZQj2hYgBh0IAAjrQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAADrQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_4.setTransform(10.6,-5.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFaIhMgZQj2hYgBh1IAAjnQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAADnQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_5.setTransform(10.6,-5.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFYIhMgZQj2hXgBh1IAAjlQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAADlQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_6.setTransform(10.6,-5.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFXIhMgZQj2hYgBh0IAAjjQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAADjQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_7.setTransform(10.6,-5.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFWIhMgZQj2hYgBh1IAAjgQABiFFChfQFHhiHLABQHMgBFHBiQFCBfABCFIAADgQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_8.setTransform(10.6,-5.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFVIhMgZQj2hYgBh1IAAjdQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAADdQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_9.setTransform(10.6,-5.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFTIhMgZQj2hXgBh1IAAjbQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAADbQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_10.setTransform(10.6,-5.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFSIhMgZQj2hYgBh0IAAjZQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAADZQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_11.setTransform(10.6,-5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFRIhMgZQj2hYgBh1IAAjWQABiFFChfQFHhiHLABQHMgBFHBiQFCBfABCFIAADWQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_12.setTransform(10.6,-4.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFPIhMgZQj2hXgBh1IAAjTQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAADTQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_13.setTransform(10.6,-4.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFOIhMgZQj2hYgBh0IAAjRQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAADRQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_14.setTransform(10.6,-4.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFNIhMgZQj2hYgBh1IAAjOQABiFFChfQFHhiHLABQHMgBFHBiQFCBfABCFIAADOQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_15.setTransform(10.6,-4.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFMIhMgZQj2hYgBh1IAAjLQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAADLQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_16.setTransform(10.6,-4.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFKIhMgZQj2hXgBh1IAAjJQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAADJQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_17.setTransform(10.6,-4.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFJIhMgZQj2hYgBh0IAAjHQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAADHQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_18.setTransform(10.6,-4.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFIIhMgZQj2hYgBh1IAAjEQABiFFChfQFHhiHLABQHMgBFHBiQFCBfABCFIAADEQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_19.setTransform(10.6,-4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFHIhMgZQj2hYgBh1IAAjBQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAADBQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_20.setTransform(10.6,-3.9);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFFIhMgZQj2hYgBh0IAAi/QABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAAC/QgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_21.setTransform(10.6,-3.7);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFEIhMgZQj2hYgBh1IAAi8QABiFFChfQFHhiHLABQHMgBFHBiQFCBfABCFIAAC8QgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_22.setTransform(10.6,-3.6);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFDIhMgZQj2hYgBh1IAAi5QABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAAC5QgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_23.setTransform(10.6,-3.5);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFBIhMgZQj2hXgBh1IAAi3QABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAAC3QgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_24.setTransform(10.6,-3.3);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFAIhMgZQj2hYgBh0IAAi1QABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAAC1QgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_25.setTransform(10.6,-3.2);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(160,252,250,0.188)").s().p("AsSE/IhMgZQj2hYgBh1IAAiyQABiFFChfQFHhiHLABQHMgBFHBiQFCBfABCFIAACyQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_26.setTransform(10.6,-3.1);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(160,252,250,0.188)").s().p("AsSE+IhMgZQj2hYgBh1IAAivQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAACvQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_27.setTransform(10.6,-3);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(160,252,250,0.188)").s().p("AsSE8IhMgZQj2hXgBh1IAAitQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAACtQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_28.setTransform(10.6,-2.8);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(160,252,250,0.188)").s().p("AsSE7IhMgZQj2hYgBh1IAAiqQABiFFChfQFHhiHLABQHMgBFHBiQFCBfABCFIAACqQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_29.setTransform(10.6,-2.7);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(160,252,250,0.188)").s().p("AsSE6IhMgZQj2hYgBh1IAAinQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAACnQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_30.setTransform(10.6,-2.6);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(160,252,250,0.188)").s().p("AsSE4IhMgZQj2hXgBh1IAAilQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAAClQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_31.setTransform(10.6,-2.4);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("rgba(160,252,250,0.188)").s().p("AsSE3IhMgZQj2hYgBh0IAAijQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAACjQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_32.setTransform(10.6,-2.3);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("rgba(160,252,250,0.188)").s().p("AsSE2IhMgZQj2hYgBh1IAAigQABiFFChfQFHhiHLABQHMgBFHBiQFCBfABCFIAACgQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_33.setTransform(10.6,-2.2);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(160,252,250,0.188)").s().p("AsSE1IhMgZQj2hYgBh1IAAidQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAACdQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_34.setTransform(10.6,-2.1);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEzIhMgZQj2hXgBh1IAAibQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAACbQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_35.setTransform(10.6,-1.9);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEyIhMgZQj2hYgBh0IAAiZQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAACZQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_36.setTransform(10.6,-1.8);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(160,252,250,0.188)").s().p("AsSExIhMgZQj2hYgBh1IAAiVQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAACVQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_37.setTransform(10.6,-1.7);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEvIhMgZQj2hXgBh1IAAiTQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAACTQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_38.setTransform(10.6,-1.5);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEuIhMgZQj2hYgBh0IAAiRQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAACRQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_39.setTransform(10.6,-1.4);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEtIhMgZQj2hYgBh1IAAiOQABiFFChfQFHhiHLABQHMgBFHBiQFCBfABCFIAACOQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_40.setTransform(10.6,-1.3);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEsIhMgZQj2hYgBh1IAAiLQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAACLQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_41.setTransform(10.6,-1.2);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEqIhMgZQj2hXgBh1IAAiJQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAACJQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_42.setTransform(10.6,-1);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEpIhMgZQj2hYgBh0IAAiHQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAACHQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_43.setTransform(10.6,-0.9);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEoIhMgZQj2hYgBh1IAAiEQABiFFChfQFHhhHLgBQHMABFHBhQFCBfABCFIAACEQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_44.setTransform(10.6,-0.8);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEmIhMgZQj2hXgBh1IAAiBQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAACBQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_45.setTransform(10.6,-0.6);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("rgba(160,252,250,0.188)").s().p("AsSElIhMgZQj2hYgBh0IAAh/QABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAAB/QgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_46.setTransform(10.6,-0.5);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEkIhMgZQj2hYgBh1IAAh8QABiFFChfQFHhiHLABQHMgBFHBiQFCBfABCFIAAB8QgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_47.setTransform(10.6,-0.4);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEjIhMgZQj2hYgBh1IAAh5QABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAAB5QgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_48.setTransform(10.6,-0.3);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEhIhMgZQj2hXgBh1IAAh3QABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAAB3QgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_49.setTransform(10.6,-0.1);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEgIhMgZQj2hYgBh0IAAh1QABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAAB1QgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_50.setTransform(10.6,0);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEfIhMgZQj2hYgBh1IAAhyQABiFFChfQFHhhHLgBQHMABFHBhQFCBfABCFIAAByQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_51.setTransform(10.6,0.1);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEeIhMgZQj2hYgBh1IAAhvQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAABvQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_52.setTransform(10.6,0.2);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEcIhMgZQj2hYgBh0IAAhtQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAABtQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_53.setTransform(10.6,0.4);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEbIhMgZQj2hYgBh1IAAhqQABiFFChfQFHhiHLABQHMgBFHBiQFCBfABCFIAABqQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_54.setTransform(10.6,0.5);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEaIhMgZQj2hYgBh1IAAhnQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAABnQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_55.setTransform(10.6,0.6);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEYIhMgZQj2hXgBh1IAAhlQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAABlQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_56.setTransform(10.6,0.8);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEXIhMgZQj2hYgBh0IAAhjQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAABjQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_57.setTransform(10.6,0.9);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEWIhMgZQj2hYgBh1IAAhgQABiFFChfQFHhhHLgBQHMABFHBhQFCBfABCFIAABgQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_58.setTransform(10.6,1);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEVIhMgZQj2hYgBh1IAAhdQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAABdQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_59.setTransform(10.6,1.1);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("rgba(160,252,250,0.188)").s().p("AsSETIhMgZQj2hXgBh1IAAhbQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAABbQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_60.setTransform(10.6,1.3);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("rgba(160,252,250,0.188)").s().p("AsSESIhMgZQj2hYgBh1IAAhYQABiFFChfQFHhiHLABQHMgBFHBiQFCBfABCFIAABYQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_61.setTransform(10.6,1.4);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("rgba(160,252,250,0.188)").s().p("AsSERIhMgZQj2hYgBh1IAAhVQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAABVQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_62.setTransform(10.6,1.5);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEPIhMgZQj2hXgBh1IAAhTQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAABTQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_63.setTransform(10.6,1.7);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEOIhMgZQj2hYgBh0IAAhRQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAABRQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_64.setTransform(10.6,1.8);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("rgba(160,252,250,0.188)").s().p("AsSENIhMgZQj2hYgBh1IAAhOQABiFFChfQFHhhHLgBQHMABFHBhQFCBfABCFIAABOQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_65.setTransform(10.6,1.9);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEMIhMgZQj2hYgBh1IAAhLQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAABLQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_66.setTransform(10.6,2);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEKIhMgZQj2hXgBh1IAAhJQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAABJQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_67.setTransform(10.6,2.2);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEJIhMgZQj2hYgBh0IAAhHQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAABHQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_68.setTransform(10.6,2.3);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEIIhMgZQj2hYgBh1IAAhDQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAABDQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_69.setTransform(10.6,2.4);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEGIhMgZQj2hXgBh1IAAhBQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAABBQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_70.setTransform(10.6,2.6);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEFIhMgZQj2hYgBh0IAAg/QABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAAA/QgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_71.setTransform(10.6,2.7);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEEIhMgZQj2hYgBh1IAAg8QABiFFChfQFHhhHLgBQHMABFHBhQFCBfABCFIAAA8QgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_72.setTransform(10.6,2.8);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEDIhMgZQj2hYgBh1IAAg5QABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAAA5QgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_73.setTransform(10.6,2.9);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEBIhMgZQj2hXgBh1IAAg3QABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAAA3QgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_74.setTransform(10.6,3.1);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEAIhMgZQj2hYgBh0IAAg1QABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAAA1QgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_75.setTransform(10.6,3.2);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("rgba(160,252,250,0.188)").s().p("AsSD/IhMgZQj2hYgBh1IAAgyQABiFFChfQFHhhHLgBQHMABFHBhQFCBfABCFIAAAyQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_76.setTransform(10.6,3.3);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("rgba(160,252,250,0.188)").s().p("AsSD9IhMgZQj2hXgBh1IAAgvQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAAAvQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_77.setTransform(10.6,3.5);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("rgba(160,252,250,0.188)").s().p("AsSD8IhMgZQj2hYgBh0IAAgtQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAAAtQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_78.setTransform(10.6,3.6);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("rgba(160,252,250,0.188)").s().p("AsSD7IhMgZQj2hYgBh1IAAgqQABiFFChfQFHhhHLgBQHMABFHBhQFCBfABCFIAAAqQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_79.setTransform(10.6,3.7);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("rgba(160,252,250,0.188)").s().p("AsSD6IhMgZQj2hYgBh1IAAgnQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAAAnQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_80.setTransform(10.6,3.8);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("rgba(160,252,250,0.188)").s().p("AsSD4IhMgZQj2hXgBh1IAAglQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAAAlQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_81.setTransform(10.6,4);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("rgba(160,252,250,0.188)").s().p("AsSD3IhMgZQj2hYgBh0IAAgjQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAAAjQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_82.setTransform(10.6,4.1);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("rgba(160,252,250,0.188)").s().p("AsSD2IhMgZQj2hYgBh1IAAggQABiFFChfQFHhhHLgBQHMABFHBhQFCBfABCFIAAAgQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_83.setTransform(10.6,4.2);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("rgba(160,252,250,0.188)").s().p("AsSD1IhMgZQj2hYgBh1IAAgdQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAAAdQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_84.setTransform(10.6,4.3);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("rgba(160,252,250,0.188)").s().p("AsSDzIhMgZQj2hYgBh0IAAgbQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAAAbQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_85.setTransform(10.6,4.5);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("rgba(160,252,250,0.188)").s().p("AsSDyIhMgZQj2hYgBh1IAAgYQABiFFChfQFHhhHLgBQHMABFHBhQFCBfABCFIAAAYQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_86.setTransform(10.6,4.6);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("rgba(160,252,250,0.188)").s().p("AsSDxIhMgZQj2hYgBh1IAAgVQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAAAVQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_87.setTransform(10.6,4.7);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("rgba(160,252,250,0.188)").s().p("AsSDvIhMgZQj2hXgBh1IAAgTQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAAATQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_88.setTransform(10.6,4.9);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("rgba(160,252,250,0.188)").s().p("AsSDuIhMgZQj2hYgBh0IAAgRQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAAARQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_89.setTransform(10.6,5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},208).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[]},1).wait(391));

	// Layer_13
	this.instance_22 = new lib.Tween3("synched",0);
	this.instance_22.parent = this;
	this.instance_22.setTransform(10.9,-16.7);
	this.instance_22._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(208).to({_off:false},0).to({y:6.1},89).to({_off:true},1).wait(391));

	// Layer 3
	this.instance_23 = new lib.Tween3("synched",0);
	this.instance_23.parent = this;
	this.instance_23.setTransform(10.9,-16.7);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFgIhMgZQj2hYgBh0IAAj1QABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAAD1QgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_90.setTransform(10.6,-6.4);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("rgba(160,252,250,0.188)").s().p("AsSDuIhMgZQj2hYgBh0IAAgRQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAAARQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_91.setTransform(10.6,5);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("rgba(160,252,250,0.188)").s().p("AsSDwIhMgZQj2hYgBh1IAAgTQABiGFChgQFHhhHLAAQHMAAFHBhQFCBgABCGIAAATQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_92.setTransform(10.6,4.8);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("rgba(160,252,250,0.188)").s().p("AsSDyIhMgZQj2hYgBh1IAAgYQABiFFChfQFHhhHLgBQHMABFHBhQFCBfABCFIAAAYQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_93.setTransform(10.6,4.6);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("rgba(160,252,250,0.188)").s().p("AsSD0IhMgZQj2hYgBh1IAAgbQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAAAbQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_94.setTransform(10.6,4.4);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("rgba(160,252,250,0.188)").s().p("AsSD1IhMgZQj2hXgBh1IAAgfQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAAAfQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_95.setTransform(10.6,4.3);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("rgba(160,252,250,0.188)").s().p("AsSD3IhMgZQj2hXgBh1IAAgjQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAAAjQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_96.setTransform(10.6,4.1);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("rgba(160,252,250,0.188)").s().p("AsSD5IhMgZQj2hYgBh0IAAgnQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAAAnQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_97.setTransform(10.6,3.9);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("rgba(160,252,250,0.188)").s().p("AsSD7IhMgZQj2hYgBh1IAAgqQABiFFChfQFHhhHLgBQHMABFHBhQFCBfABCFIAAAqQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_98.setTransform(10.6,3.7);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("rgba(160,252,250,0.188)").s().p("AsSD9IhMgZQj2hYgBh1IAAgtQABiGFChgQFHhgHLAAQHMAAFHBgQFCBgABCGIAAAtQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_99.setTransform(10.6,3.5);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("rgba(160,252,250,0.188)").s().p("AsSD/IhMgZQj2hYgBh1IAAgxQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAAAxQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_100.setTransform(10.6,3.3);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEBIhMgZQj2hYgBh1IAAg1QABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAAA1QgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_101.setTransform(10.6,3.1);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("rgba(160,252,250,0.188)").s().p("AsSECIhMgZQj2hXgBh1IAAg5QABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAAA5QgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_102.setTransform(10.6,3);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEEIhMgZQj2hYgBh0IAAg9QABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAAA9QgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_103.setTransform(10.6,2.8);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEGIhMgZQj2hYgBh0IAAhBQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAABBQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_104.setTransform(10.6,2.6);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEIIhMgZQj2hYgBh1IAAhEQABiFFChfQFHhhHLgBQHMABFHBhQFCBfABCFIAABEQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_105.setTransform(10.6,2.4);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEKIhMgZQj2hYgBh1IAAhHQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAABHQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_106.setTransform(10.6,2.2);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEMIhMgZQj2hYgBh1IAAhLQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAABLQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_107.setTransform(10.6,2);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("rgba(160,252,250,0.188)").s().p("AsSENIhMgZQj2hXgBh1IAAhPQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAABPQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_108.setTransform(10.6,1.9);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEPIhMgZQj2hYgBh0IAAhTQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAABTQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_109.setTransform(10.6,1.7);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("rgba(160,252,250,0.188)").s().p("AsSERIhMgZQj2hYgBh0IAAhXQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAABXQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_110.setTransform(10.6,1.5);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("rgba(160,252,250,0.188)").s().p("AsSETIhMgZQj2hYgBh1IAAhZQABiGFChgQFHhgHLAAQHMAAFHBgQFCBgABCGIAABZQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_111.setTransform(10.6,1.3);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEVIhMgZQj2hYgBh1IAAhdQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAABdQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_112.setTransform(10.6,1.1);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEXIhMgZQj2hYgBh1IAAhhQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAABhQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_113.setTransform(10.6,0.9);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEYIhMgZQj2hXgBh1IAAhlQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAABlQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_114.setTransform(10.6,0.8);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEaIhMgZQj2hXgBh1IAAhpQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAABpQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_115.setTransform(10.6,0.6);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEcIhMgZQj2hYgBh0IAAhtQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAABtQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_116.setTransform(10.6,0.4);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEeIhMgZQj2hYgBh1IAAhwQABiFFChgQFHhgHLgBQHMABFHBgQFCBgABCFIAABwQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_117.setTransform(10.6,0.2);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEgIhMgZQj2hYgBh1IAAh0QABiFFChfQFHhiHLABQHMgBFHBiQFCBfABCFIAAB0QgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_118.setTransform(10.6,0);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEiIhMgZQj2hYgBh1IAAh3QABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAAB3QgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_119.setTransform(10.6,-0.2);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEjIhMgZQj2hXgBh1IAAh7QABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAAB7QgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_120.setTransform(10.6,-0.3);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("rgba(160,252,250,0.188)").s().p("AsSElIhMgZQj2hXgBh1IAAh/QABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAAB/QgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_121.setTransform(10.6,-0.5);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEnIhMgZQj2hYgBh0IAAiDQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAACDQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_122.setTransform(10.6,-0.7);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEpIhMgZQj2hYgBh1IAAiGQABiFFChfQFHhiHLABQHMgBFHBiQFCBfABCFIAACGQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_123.setTransform(10.6,-0.9);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("rgba(160,252,250,0.188)").s().p("AsSErIhMgZQj2hYgBh1IAAiJQABiGFChgQFHhhHLAAQHMAAFHBhQFCBgABCGIAACJQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_124.setTransform(10.6,-1.1);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEtIhMgZQj2hYgBh1IAAiNQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAACNQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_125.setTransform(10.6,-1.3);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEuIhMgZQj2hXgBh1IAAiRQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAACRQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_126.setTransform(10.6,-1.4);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEwIhMgZQj2hXgBh1IAAiVQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAACVQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_127.setTransform(10.6,-1.6);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEyIhMgZQj2hYgBh0IAAiZQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAACZQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_128.setTransform(10.6,-1.8);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("rgba(160,252,250,0.188)").s().p("AsSE0IhMgZQj2hYgBh1IAAibQABiGFChgQFHhhHLAAQHMAAFHBhQFCBgABCGIAACbQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_129.setTransform(10.6,-2);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("rgba(160,252,250,0.188)").s().p("AsSE2IhMgZQj2hYgBh1IAAigQABiFFChfQFHhiHLABQHMgBFHBiQFCBfABCFIAACgQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_130.setTransform(10.6,-2.2);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("rgba(160,252,250,0.188)").s().p("AsSE4IhMgZQj2hYgBh1IAAijQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAACjQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_131.setTransform(10.6,-2.4);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("rgba(160,252,250,0.188)").s().p("AsSE6IhMgZQj2hYgBh1IAAinQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAACnQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_132.setTransform(10.6,-2.6);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("rgba(160,252,250,0.188)").s().p("AsSE7IhMgZQj2hXgBh1IAAirQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAACrQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_133.setTransform(10.6,-2.7);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("rgba(160,252,250,0.188)").s().p("AsSE9IhMgZQj2hYgBh0IAAivQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAACvQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_134.setTransform(10.6,-2.9);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("rgba(160,252,250,0.188)").s().p("AsSE/IhMgZQj2hYgBh0IAAizQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAACzQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_135.setTransform(10.6,-3.1);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFBIhMgZQj2hYgBh1IAAi1QABiGFChgQFHhhHLAAQHMAAFHBhQFCBgABCGIAAC1QgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_136.setTransform(10.6,-3.3);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFDIhMgZQj2hYgBh1IAAi5QABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAAC5QgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_137.setTransform(10.6,-3.5);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFFIhMgZQj2hYgBh1IAAi9QABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAAC9QgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_138.setTransform(10.6,-3.7);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFGIhMgZQj2hXgBh1IAAjBQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAADBQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_139.setTransform(10.6,-3.8);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFIIhMgZQj2hYgBh0IAAjFQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAADFQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_140.setTransform(10.6,-4);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFKIhMgZQj2hYgBh0IAAjJQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAADJQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_141.setTransform(10.6,-4.2);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFMIhMgZQj2hYgBh1IAAjMQABiFFChfQFHhhHLgBQHMABFHBhQFCBfABCFIAADMQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_142.setTransform(10.6,-4.4);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFOIhMgZQj2hYgBh1IAAjPQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAADPQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_143.setTransform(10.6,-4.6);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFQIhMgZQj2hYgBh1IAAjTQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAADTQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_144.setTransform(10.6,-4.8);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFRIhMgZQj2hXgBh1IAAjXQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAADXQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_145.setTransform(10.6,-4.9);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFTIhMgZQj2hXgBh1IAAjbQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAADbQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_146.setTransform(10.6,-5.1);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFVIhMgZQj2hYgBh0IAAjfQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAADfQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_147.setTransform(10.6,-5.3);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFXIhMgZQj2hYgBh1IAAjhQABiGFChgQFHhgHLAAQHMAAFHBgQFCBgABCGIAADhQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_148.setTransform(10.6,-5.5);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFZIhMgZQj2hYgBh1IAAjmQABiFFChfQFHhhHLgBQHMABFHBhQFCBfABCFIAADmQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_149.setTransform(10.6,-5.7);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFbIhMgZQj2hYgBh1IAAjpQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAADpQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_150.setTransform(10.6,-5.9);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFcIhMgZQj2hXgBh1IAAjtQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAADtQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_151.setTransform(10.6,-6);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFeIhMgZQj2hXgBh1IAAjxQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAADxQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_152.setTransform(10.6,-6.2);

	this.instance_24 = new lib.sprite135();
	this.instance_24.parent = this;
	this.instance_24.setTransform(1.1,-1.6);
	this.instance_24.alpha = 0;
	this.instance_24._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_90},{t:this.instance_23}]},160).to({state:[{t:this.shape_90},{t:this.instance_23}]},1).to({state:[]},47).to({state:[{t:this.shape_91}]},188).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_104}]},1).to({state:[{t:this.shape_105}]},1).to({state:[{t:this.shape_106}]},1).to({state:[{t:this.shape_107}]},1).to({state:[{t:this.shape_108}]},1).to({state:[{t:this.shape_109}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_111}]},1).to({state:[{t:this.shape_112}]},1).to({state:[{t:this.shape_113}]},1).to({state:[{t:this.shape_114}]},1).to({state:[{t:this.shape_115}]},1).to({state:[{t:this.shape_116}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_118}]},1).to({state:[{t:this.shape_119}]},1).to({state:[{t:this.shape_120}]},1).to({state:[{t:this.shape_121}]},1).to({state:[{t:this.shape_122}]},1).to({state:[{t:this.shape_123}]},1).to({state:[{t:this.shape_124}]},1).to({state:[{t:this.shape_125}]},1).to({state:[{t:this.shape_126}]},1).to({state:[{t:this.shape_127}]},1).to({state:[{t:this.shape_128}]},1).to({state:[{t:this.shape_129}]},1).to({state:[{t:this.shape_130}]},1).to({state:[{t:this.shape_131}]},1).to({state:[{t:this.shape_132}]},1).to({state:[{t:this.shape_133}]},1).to({state:[{t:this.shape_134}]},1).to({state:[{t:this.shape_135}]},1).to({state:[{t:this.shape_136}]},1).to({state:[{t:this.shape_137}]},1).to({state:[{t:this.shape_138}]},1).to({state:[{t:this.shape_139}]},1).to({state:[{t:this.shape_140}]},1).to({state:[{t:this.shape_141}]},1).to({state:[{t:this.shape_142}]},1).to({state:[{t:this.shape_143}]},1).to({state:[{t:this.shape_144}]},1).to({state:[{t:this.shape_145}]},1).to({state:[{t:this.shape_146}]},1).to({state:[{t:this.shape_147}]},1).to({state:[{t:this.shape_148}]},1).to({state:[{t:this.shape_149}]},1).to({state:[{t:this.shape_150}]},1).to({state:[{t:this.shape_151}]},1).to({state:[{t:this.shape_152}]},1).to({state:[{t:this.shape_90}]},1).to({state:[]},1).to({state:[{t:this.instance_24}]},160).to({state:[{t:this.instance_24}]},69).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_24).wait(619).to({_off:false},0).to({alpha:1},69).wait(1));

	// Layer_9
	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("rgba(213,255,255,0.718)").s().p("AsSDuIhMgZQj2hYgBh0IAAgRQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAAARQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_153.setTransform(10.6,5);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("rgba(212,255,255,0.71)").s().p("AsSDwIhMgZQj2hYgBh0IAAgVQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAAAVQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_154.setTransform(10.6,4.8);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("rgba(211,255,255,0.698)").s().p("AsSDyIhMgZQj2hYgBh1IAAgYQABiFFChfQFHhhHLgBQHMABFHBhQFCBfABCFIAAAYQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_155.setTransform(10.6,4.6);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("rgba(210,255,255,0.69)").s().p("AsSD0IhMgZQj2hYgBh1IAAgbQABiGFChgQFHhgHLAAQHMAAFHBgQFCBgABCGIAAAbQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_156.setTransform(10.6,4.4);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("rgba(209,255,255,0.682)").s().p("AsSD2IhMgZQj2hYgBh1IAAgfQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAAAfQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_157.setTransform(10.6,4.2);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("rgba(209,255,255,0.675)").s().p("AsSD4IhMgZQj2hYgBh1IAAgjQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAAAjQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_158.setTransform(10.6,4);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("rgba(208,255,254,0.663)").s().p("AsSD6IhMgZQj2hYgBh1IAAgnQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAAAnQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_159.setTransform(10.6,3.8);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("rgba(207,255,254,0.655)").s().p("AsSD7IhMgZQj2hXgBh1IAAgrQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAAArQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_160.setTransform(10.6,3.7);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("rgba(206,255,254,0.647)").s().p("AsSD9IhMgZQj2hXgBh1IAAgvQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAAAvQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_161.setTransform(10.6,3.5);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("rgba(205,255,254,0.639)").s().p("AsSD/IhMgZQj2hYgBh0IAAgzQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAAAzQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_162.setTransform(10.6,3.3);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("rgba(204,254,254,0.627)").s().p("AsSEBIhMgZQj2hYgBh0IAAg3QABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAAA3QgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_163.setTransform(10.6,3.1);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("rgba(203,254,254,0.62)").s().p("AsSEDIhMgZQj2hYgBh0IAAg7QABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAAA7QgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_164.setTransform(10.6,2.9);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("rgba(202,254,254,0.612)").s().p("AsSEFIhMgZQj2hYgBh1IAAg+QABiFFChfQFHhiHLABQHMgBFHBiQFCBfABCFIAAA+QgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_165.setTransform(10.6,2.7);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("rgba(202,254,254,0.604)").s().p("AsSEHIhMgZQj2hYgBh1IAAhBQABiGFChgQFHhhHLAAQHMAAFHBhQFCBgABCGIAABBQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_166.setTransform(10.6,2.5);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("rgba(201,254,254,0.592)").s().p("AsSEJIhMgZQj2hYgBh1IAAhFQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAABFQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_167.setTransform(10.6,2.3);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f("rgba(200,254,254,0.584)").s().p("AsSELIhMgZQj2hYgBh1IAAhJQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAABJQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_168.setTransform(10.6,2.1);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("rgba(199,254,254,0.576)").s().p("AsSENIhMgZQj2hYgBh1IAAhNQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAABNQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_169.setTransform(10.6,1.9);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f("rgba(198,254,254,0.569)").s().p("AsSEOIhMgZQj2hXgBh1IAAhRQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAABRQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_170.setTransform(10.6,1.8);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("rgba(197,254,253,0.557)").s().p("AsSEQIhMgZQj2hXgBh1IAAhVQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAABVQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_171.setTransform(10.6,1.6);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f("rgba(196,254,253,0.549)").s().p("AsSESIhMgZQj2hYgBh0IAAhZQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAABZQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_172.setTransform(10.6,1.4);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("rgba(195,254,253,0.541)").s().p("AsSEUIhMgZQj2hYgBh0IAAhdQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAABdQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_173.setTransform(10.6,1.2);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f("rgba(194,254,253,0.533)").s().p("AsSEWIhMgZQj2hYgBh0IAAhhQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAABhQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_174.setTransform(10.6,1);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f("rgba(194,254,253,0.522)").s().p("AsSEYIhMgZQj2hYgBh1IAAhjQABiGFChgQFHhgHLAAQHMAAFHBgQFCBgABCGIAABjQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_175.setTransform(10.6,0.8);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f("rgba(193,254,253,0.514)").s().p("AsSEaIhMgZQj2hYgBh1IAAhoQABiFFChfQFHhhHLgBQHMABFHBhQFCBfABCFIAABoQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_176.setTransform(10.6,0.6);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f("rgba(192,254,253,0.506)").s().p("AsSEcIhMgZQj2hYgBh1IAAhrQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAABrQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_177.setTransform(10.6,0.4);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f("rgba(191,254,253,0.498)").s().p("AsSEeIhMgZQj2hYgBh1IAAhvQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAABvQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_178.setTransform(10.6,0.2);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f("rgba(190,254,253,0.486)").s().p("AsSEgIhMgZQj2hYgBh1IAAhzQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAABzQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_179.setTransform(10.6,0);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f("rgba(189,254,253,0.478)").s().p("AsSEhIhMgZQj2hXgBh1IAAh3QABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAAB3QgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_180.setTransform(10.6,-0.1);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f("rgba(188,254,253,0.471)").s().p("AsSEjIhMgZQj2hXgBh1IAAh7QABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAAB7QgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_181.setTransform(10.6,-0.3);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f("rgba(187,254,253,0.463)").s().p("AsSElIhMgZQj2hYgBh0IAAh/QABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAAB/QgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_182.setTransform(10.6,-0.5);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f("rgba(187,254,253,0.455)").s().p("AsSEnIhMgZQj2hYgBh0IAAiDQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAACDQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_183.setTransform(10.6,-0.7);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f("rgba(186,253,252,0.443)").s().p("AsSEpIhMgZQj2hYgBh0IAAiHQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAACHQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_184.setTransform(10.6,-0.9);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f("rgba(185,253,252,0.435)").s().p("AsSErIhMgZQj2hYgBh1IAAiJQABiGFChgQFHhhHLAAQHMAAFHBhQFCBgABCGIAACJQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_185.setTransform(10.6,-1.1);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f("rgba(184,253,252,0.427)").s().p("AsSEtIhMgZQj2hYgBh1IAAiOQABiFFChfQFHhiHLABQHMgBFHBiQFCBfABCFIAACOQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_186.setTransform(10.6,-1.3);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f("rgba(183,253,252,0.42)").s().p("AsSEvIhMgZQj2hYgBh1IAAiRQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAACRQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_187.setTransform(10.6,-1.5);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f("rgba(182,253,252,0.408)").s().p("AsSExIhMgZQj2hYgBh1IAAiVQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAACVQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_188.setTransform(10.6,-1.7);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f("rgba(181,253,252,0.4)").s().p("AsSEzIhMgZQj2hYgBh1IAAiZQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAACZQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_189.setTransform(10.6,-1.9);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f("rgba(180,253,252,0.392)").s().p("AsSE0IhMgZQj2hXgBh1IAAidQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAACdQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_190.setTransform(10.6,-2);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f("rgba(179,253,252,0.384)").s().p("AsSE2IhMgZQj2hXgBh1IAAihQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAAChQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_191.setTransform(10.6,-2.2);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f("rgba(179,253,252,0.373)").s().p("AsSE4IhMgZQj2hYgBh0IAAilQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAAClQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_192.setTransform(10.6,-2.4);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f("rgba(178,253,252,0.365)").s().p("AsSE6IhMgZQj2hYgBh0IAAipQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAACpQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_193.setTransform(10.6,-2.6);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f("rgba(177,253,252,0.357)").s().p("AsSE8IhMgZQj2hYgBh0IAAitQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAACtQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_194.setTransform(10.6,-2.8);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f("rgba(176,253,252,0.349)").s().p("AsSE+IhMgZQj2hYgBh1IAAiwQABiFFChfQFHhhHLgBQHMABFHBhQFCBfABCFIAACwQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_195.setTransform(10.6,-3);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f("rgba(175,253,251,0.337)").s().p("AsSFAIhMgZQj2hYgBh1IAAizQABiGFChgQFHhgHLAAQHMAAFHBgQFCBgABCGIAACzQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_196.setTransform(10.6,-3.2);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f("rgba(174,253,251,0.329)").s().p("AsSFCIhMgZQj2hYgBh1IAAi3QABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAAC3QgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_197.setTransform(10.6,-3.4);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f("rgba(173,253,251,0.322)").s().p("AsSFEIhMgZQj2hYgBh1IAAi7QABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAAC7QgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_198.setTransform(10.6,-3.6);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f("rgba(172,253,251,0.314)").s().p("AsSFGIhMgZQj2hYgBh1IAAi/QABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAAC/QgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_199.setTransform(10.6,-3.8);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.f("rgba(171,253,251,0.302)").s().p("AsSFHIhMgZQj2hXgBh1IAAjDQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAADDQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_200.setTransform(10.6,-3.9);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.f("rgba(171,253,251,0.294)").s().p("AsSFJIhMgZQj2hXgBh1IAAjHQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAADHQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_201.setTransform(10.6,-4.1);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.f("rgba(170,253,251,0.286)").s().p("AsSFLIhMgZQj2hYgBh0IAAjLQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAADLQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_202.setTransform(10.6,-4.3);

	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.f("rgba(169,253,251,0.278)").s().p("AsSFNIhMgZQj2hYgBh0IAAjPQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAADPQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_203.setTransform(10.6,-4.5);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.f("rgba(168,252,251,0.267)").s().p("AsSFPIhMgZQj2hYgBh0IAAjTQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAADTQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_204.setTransform(10.6,-4.7);

	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.f("rgba(167,252,251,0.259)").s().p("AsSFRIhMgZQj2hYgBh1IAAjWQABiFFChfQFHhiHLABQHMgBFHBiQFCBfABCFIAADWQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_205.setTransform(10.6,-4.9);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.f("rgba(166,252,251,0.251)").s().p("AsSFTIhMgZQj2hYgBh1IAAjZQABiGFChgQFHhhHLAAQHMAAFHBhQFCBgABCGIAADZQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_206.setTransform(10.6,-5.1);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.f("rgba(165,252,251,0.243)").s().p("AsSFVIhMgZQj2hYgBh1IAAjdQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAADdQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_207.setTransform(10.6,-5.3);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.f("rgba(164,252,250,0.231)").s().p("AsSFXIhMgZQj2hYgBh1IAAjhQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAADhQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_208.setTransform(10.6,-5.5);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.f("rgba(164,252,250,0.224)").s().p("AsSFZIhMgZQj2hYgBh1IAAjlQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAADlQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_209.setTransform(10.6,-5.7);

	this.shape_210 = new cjs.Shape();
	this.shape_210.graphics.f("rgba(163,252,250,0.216)").s().p("AsSFaIhMgZQj2hXgBh1IAAjpQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAADpQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_210.setTransform(10.6,-5.8);

	this.shape_211 = new cjs.Shape();
	this.shape_211.graphics.f("rgba(162,252,250,0.208)").s().p("AsSFcIhMgZQj2hXgBh1IAAjtQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAADtQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_211.setTransform(10.6,-6);

	this.shape_212 = new cjs.Shape();
	this.shape_212.graphics.f("rgba(161,252,250,0.196)").s().p("AsSFeIhMgZQj2hYgBh0IAAjxQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAADxQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_212.setTransform(10.6,-6.2);

	this.shape_213 = new cjs.Shape();
	this.shape_213.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFgIhMgZQj2hYgBh0IAAj1QABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAAD1QgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_213.setTransform(10.6,-6.4);

	this.instance_25 = new lib.Tween3("synched",0);
	this.instance_25.parent = this;
	this.instance_25.setTransform(10.9,6.1);
	this.instance_25._off = true;

	this.shape_214 = new cjs.Shape();
	this.shape_214.graphics.f("rgba(160,252,250,0.188)").s().p("AsSDuIhMgZQj2hYgBh0IAAgRQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAAARQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_214.setTransform(10.6,5);

	this.shape_215 = new cjs.Shape();
	this.shape_215.graphics.f("rgba(160,252,250,0.188)").s().p("AsSDwIhMgZQj2hYgBh1IAAgTQABiGFChgQFHhhHLAAQHMAAFHBhQFCBgABCGIAAATQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_215.setTransform(10.6,4.8);

	this.shape_216 = new cjs.Shape();
	this.shape_216.graphics.f("rgba(160,252,250,0.188)").s().p("AsSDyIhMgZQj2hYgBh1IAAgYQABiFFChfQFHhhHLgBQHMABFHBhQFCBfABCFIAAAYQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_216.setTransform(10.6,4.6);

	this.shape_217 = new cjs.Shape();
	this.shape_217.graphics.f("rgba(160,252,250,0.188)").s().p("AsSD0IhMgZQj2hYgBh1IAAgbQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAAAbQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_217.setTransform(10.6,4.4);

	this.shape_218 = new cjs.Shape();
	this.shape_218.graphics.f("rgba(160,252,250,0.188)").s().p("AsSD2IhMgZQj2hYgBh1IAAgfQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAAAfQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_218.setTransform(10.6,4.2);

	this.shape_219 = new cjs.Shape();
	this.shape_219.graphics.f("rgba(160,252,250,0.188)").s().p("AsSD3IhMgZQj2hXgBh1IAAgjQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAAAjQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_219.setTransform(10.6,4.1);

	this.shape_220 = new cjs.Shape();
	this.shape_220.graphics.f("rgba(160,252,250,0.188)").s().p("AsSD5IhMgZQj2hXgBh1IAAgnQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAAAnQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_220.setTransform(10.6,3.9);

	this.shape_221 = new cjs.Shape();
	this.shape_221.graphics.f("rgba(160,252,250,0.188)").s().p("AsSD7IhMgZQj2hYgBh0IAAgrQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAAArQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_221.setTransform(10.6,3.7);

	this.shape_222 = new cjs.Shape();
	this.shape_222.graphics.f("rgba(160,252,250,0.188)").s().p("AsSD9IhMgZQj2hYgBh0IAAgvQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAAAvQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_222.setTransform(10.6,3.5);

	this.shape_223 = new cjs.Shape();
	this.shape_223.graphics.f("rgba(160,252,250,0.188)").s().p("AsSD/IhMgZQj2hYgBh1IAAgyQABiFFChfQFHhhHLgBQHMABFHBhQFCBfABCFIAAAyQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_223.setTransform(10.6,3.3);

	this.shape_224 = new cjs.Shape();
	this.shape_224.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEBIhMgZQj2hYgBh1IAAg1QABiGFChgQFHhgHLAAQHMAAFHBgQFCBgABCGIAAA1QgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_224.setTransform(10.6,3.1);

	this.shape_225 = new cjs.Shape();
	this.shape_225.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEDIhMgZQj2hYgBh1IAAg5QABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAAA5QgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_225.setTransform(10.6,2.9);

	this.shape_226 = new cjs.Shape();
	this.shape_226.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEFIhMgZQj2hYgBh1IAAg9QABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAAA9QgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_226.setTransform(10.6,2.7);

	this.shape_227 = new cjs.Shape();
	this.shape_227.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEGIhMgZQj2hXgBh1IAAhBQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAABBQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_227.setTransform(10.6,2.6);

	this.shape_228 = new cjs.Shape();
	this.shape_228.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEIIhMgZQj2hXgBh1IAAhFQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAABFQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_228.setTransform(10.6,2.4);

	this.shape_229 = new cjs.Shape();
	this.shape_229.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEKIhMgZQj2hYgBh0IAAhJQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAABJQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_229.setTransform(10.6,2.2);

	this.shape_230 = new cjs.Shape();
	this.shape_230.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEMIhMgZQj2hYgBh0IAAhNQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAABNQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_230.setTransform(10.6,2);

	this.shape_231 = new cjs.Shape();
	this.shape_231.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEOIhMgZQj2hYgBh1IAAhQQABiFFChfQFHhiHLABQHMgBFHBiQFCBfABCFIAABQQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_231.setTransform(10.6,1.8);

	this.shape_232 = new cjs.Shape();
	this.shape_232.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEQIhMgZQj2hYgBh1IAAhTQABiGFChgQFHhhHLAAQHMAAFHBhQFCBgABCGIAABTQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_232.setTransform(10.6,1.6);

	this.shape_233 = new cjs.Shape();
	this.shape_233.graphics.f("rgba(160,252,250,0.188)").s().p("AsSESIhMgZQj2hYgBh1IAAhXQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAABXQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_233.setTransform(10.6,1.4);

	this.shape_234 = new cjs.Shape();
	this.shape_234.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEUIhMgZQj2hYgBh1IAAhbQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAABbQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_234.setTransform(10.6,1.2);

	this.shape_235 = new cjs.Shape();
	this.shape_235.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEVIhMgZQj2hXgBh1IAAhfQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAABfQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_235.setTransform(10.6,1.1);

	this.shape_236 = new cjs.Shape();
	this.shape_236.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEXIhMgZQj2hYgBh0IAAhjQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAABjQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_236.setTransform(10.6,0.9);

	this.shape_237 = new cjs.Shape();
	this.shape_237.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEZIhMgZQj2hYgBh0IAAhnQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAABnQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_237.setTransform(10.6,0.7);

	this.shape_238 = new cjs.Shape();
	this.shape_238.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEbIhMgZQj2hYgBh1IAAhqQABiFFChfQFHhiHLABQHMgBFHBiQFCBfABCFIAABqQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_238.setTransform(10.6,0.5);

	this.shape_239 = new cjs.Shape();
	this.shape_239.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEdIhMgZQj2hYgBh1IAAhtQABiGFChgQFHhhHLAAQHMAAFHBhQFCBgABCGIAABtQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_239.setTransform(10.6,0.3);

	this.shape_240 = new cjs.Shape();
	this.shape_240.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEfIhMgZQj2hYgBh1IAAhxQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAABxQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_240.setTransform(10.6,0.1);

	this.shape_241 = new cjs.Shape();
	this.shape_241.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEhIhMgZQj2hYgBh1IAAh1QABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAAB1QgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_241.setTransform(10.6,-0.1);

	this.shape_242 = new cjs.Shape();
	this.shape_242.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEiIhMgZQj2hXgBh1IAAh5QABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAAB5QgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_242.setTransform(10.6,-0.2);

	this.shape_243 = new cjs.Shape();
	this.shape_243.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEkIhMgZQj2hXgBh1IAAh9QABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAAB9QgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_243.setTransform(10.6,-0.4);

	this.shape_244 = new cjs.Shape();
	this.shape_244.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEmIhMgZQj2hYgBh0IAAiBQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAACBQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_244.setTransform(10.6,-0.6);

	this.shape_245 = new cjs.Shape();
	this.shape_245.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEoIhMgZQj2hYgBh0IAAiFQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAACFQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_245.setTransform(10.6,-0.8);

	this.shape_246 = new cjs.Shape();
	this.shape_246.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEqIhMgZQj2hYgBh1IAAiHQABiGFChgQFHhgHLAAQHMAAFHBgQFCBgABCGIAACHQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_246.setTransform(10.6,-1);

	this.shape_247 = new cjs.Shape();
	this.shape_247.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEsIhMgZQj2hYgBh1IAAiMQABiFFChfQFHhhHLgBQHMABFHBhQFCBfABCFIAACMQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_247.setTransform(10.6,-1.2);

	this.shape_248 = new cjs.Shape();
	this.shape_248.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEuIhMgZQj2hYgBh1IAAiPQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAACPQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_248.setTransform(10.6,-1.4);

	this.shape_249 = new cjs.Shape();
	this.shape_249.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEwIhMgZQj2hYgBh1IAAiTQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAACTQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_249.setTransform(10.6,-1.6);

	this.shape_250 = new cjs.Shape();
	this.shape_250.graphics.f("rgba(160,252,250,0.188)").s().p("AsSExIhMgZQj2hXgBh1IAAiXQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAACXQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_250.setTransform(10.6,-1.7);

	this.shape_251 = new cjs.Shape();
	this.shape_251.graphics.f("rgba(160,252,250,0.188)").s().p("AsSEzIhMgZQj2hXgBh1IAAibQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAACbQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_251.setTransform(10.6,-1.9);

	this.shape_252 = new cjs.Shape();
	this.shape_252.graphics.f("rgba(160,252,250,0.188)").s().p("AsSE1IhMgZQj2hYgBh0IAAifQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAACfQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_252.setTransform(10.6,-2.1);

	this.shape_253 = new cjs.Shape();
	this.shape_253.graphics.f("rgba(160,252,250,0.188)").s().p("AsSE3IhMgZQj2hYgBh0IAAijQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAACjQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_253.setTransform(10.6,-2.3);

	this.shape_254 = new cjs.Shape();
	this.shape_254.graphics.f("rgba(160,252,250,0.188)").s().p("AsSE5IhMgZQj2hYgBh1IAAimQABiFFChgQFHhgHLgBQHMABFHBgQFCBgABCFIAACmQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_254.setTransform(10.6,-2.5);

	this.shape_255 = new cjs.Shape();
	this.shape_255.graphics.f("rgba(160,252,250,0.188)").s().p("AsSE7IhMgZQj2hYgBh1IAAipQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAACpQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_255.setTransform(10.6,-2.7);

	this.shape_256 = new cjs.Shape();
	this.shape_256.graphics.f("rgba(160,252,250,0.188)").s().p("AsSE9IhMgZQj2hYgBh1IAAitQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAACtQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_256.setTransform(10.6,-2.9);

	this.shape_257 = new cjs.Shape();
	this.shape_257.graphics.f("rgba(160,252,250,0.188)").s().p("AsSE+IhMgZQj2hXgBh1IAAixQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAACxQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_257.setTransform(10.6,-3);

	this.shape_258 = new cjs.Shape();
	this.shape_258.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFAIhMgZQj2hXgBh1IAAi1QABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAAC1QgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_258.setTransform(10.6,-3.2);

	this.shape_259 = new cjs.Shape();
	this.shape_259.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFCIhMgZQj2hYgBh0IAAi5QABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAAC5QgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_259.setTransform(10.6,-3.4);

	this.shape_260 = new cjs.Shape();
	this.shape_260.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFEIhMgZQj2hYgBh0IAAi9QABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAAC9QgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_260.setTransform(10.6,-3.6);

	this.shape_261 = new cjs.Shape();
	this.shape_261.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFGIhMgZQj2hYgBh1IAAi/QABiGFChgQFHhhHLAAQHMAAFHBhQFCBgABCGIAAC/QgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_261.setTransform(10.6,-3.8);

	this.shape_262 = new cjs.Shape();
	this.shape_262.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFIIhMgZQj2hYgBh1IAAjEQABiFFChfQFHhiHLABQHMgBFHBiQFCBfABCFIAADEQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_262.setTransform(10.6,-4);

	this.shape_263 = new cjs.Shape();
	this.shape_263.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFKIhMgZQj2hYgBh1IAAjHQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAADHQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_263.setTransform(10.6,-4.2);

	this.shape_264 = new cjs.Shape();
	this.shape_264.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFMIhMgZQj2hYgBh1IAAjLQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAADLQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_264.setTransform(10.6,-4.4);

	this.shape_265 = new cjs.Shape();
	this.shape_265.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFNIhMgZQj2hXgBh1IAAjPQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAADPQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_265.setTransform(10.6,-4.5);

	this.shape_266 = new cjs.Shape();
	this.shape_266.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFPIhMgZQj2hXgBh1IAAjTQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAADTQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_266.setTransform(10.6,-4.7);

	this.shape_267 = new cjs.Shape();
	this.shape_267.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFRIhMgZQj2hYgBh0IAAjXQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAADXQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_267.setTransform(10.6,-4.9);

	this.shape_268 = new cjs.Shape();
	this.shape_268.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFTIhMgZQj2hYgBh0IAAjbQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAADbQgBCFlCBgQlGBhnNAAQnMAAlGhhg");
	this.shape_268.setTransform(10.6,-5.1);

	this.shape_269 = new cjs.Shape();
	this.shape_269.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFVIhMgZQj2hYgBh1IAAjeQABiFFChfQFHhhHLgBQHMABFHBhQFCBfABCFIAADeQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_269.setTransform(10.6,-5.3);

	this.shape_270 = new cjs.Shape();
	this.shape_270.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFXIhMgZQj2hYgBh1IAAjhQABiGFChgQFHhgHLAAQHMAAFHBgQFCBgABCGIAADhQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_270.setTransform(10.6,-5.5);

	this.shape_271 = new cjs.Shape();
	this.shape_271.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFZIhMgZQj2hYgBh1IAAjlQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAADlQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_271.setTransform(10.6,-5.7);

	this.shape_272 = new cjs.Shape();
	this.shape_272.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFbIhMgZQj2hYgBh1IAAjpQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAADpQgBCGlCBgQlGBgnNAAQnMAAlGhgg");
	this.shape_272.setTransform(10.6,-5.9);

	this.shape_273 = new cjs.Shape();
	this.shape_273.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFcIhMgZQj2hXgBh1IAAjtQABiFFChgQFHhhHLAAQHMAAFHBhQFCBgABCFIAADtQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_273.setTransform(10.6,-6);

	this.shape_274 = new cjs.Shape();
	this.shape_274.graphics.f("rgba(160,252,250,0.188)").s().p("AsSFeIhMgZQj2hXgBh1IAAjxQABiGFChfQFHhhHLAAQHMAAFHBhQFCBfABCGIAADxQgBCGlCBfQlGBhnNAAQnMAAlGhhg");
	this.shape_274.setTransform(10.6,-6.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_153}]},99).to({state:[{t:this.shape_154}]},1).to({state:[{t:this.shape_155}]},1).to({state:[{t:this.shape_156}]},1).to({state:[{t:this.shape_157}]},1).to({state:[{t:this.shape_158}]},1).to({state:[{t:this.shape_159}]},1).to({state:[{t:this.shape_160}]},1).to({state:[{t:this.shape_161}]},1).to({state:[{t:this.shape_162}]},1).to({state:[{t:this.shape_163}]},1).to({state:[{t:this.shape_164}]},1).to({state:[{t:this.shape_165}]},1).to({state:[{t:this.shape_166}]},1).to({state:[{t:this.shape_167}]},1).to({state:[{t:this.shape_168}]},1).to({state:[{t:this.shape_169}]},1).to({state:[{t:this.shape_170}]},1).to({state:[{t:this.shape_171}]},1).to({state:[{t:this.shape_172}]},1).to({state:[{t:this.shape_173}]},1).to({state:[{t:this.shape_174}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_176}]},1).to({state:[{t:this.shape_177}]},1).to({state:[{t:this.shape_178}]},1).to({state:[{t:this.shape_179}]},1).to({state:[{t:this.shape_180}]},1).to({state:[{t:this.shape_181}]},1).to({state:[{t:this.shape_182}]},1).to({state:[{t:this.shape_183}]},1).to({state:[{t:this.shape_184}]},1).to({state:[{t:this.shape_185}]},1).to({state:[{t:this.shape_186}]},1).to({state:[{t:this.shape_187}]},1).to({state:[{t:this.shape_188}]},1).to({state:[{t:this.shape_189}]},1).to({state:[{t:this.shape_190}]},1).to({state:[{t:this.shape_191}]},1).to({state:[{t:this.shape_192}]},1).to({state:[{t:this.shape_193}]},1).to({state:[{t:this.shape_194}]},1).to({state:[{t:this.shape_195}]},1).to({state:[{t:this.shape_196}]},1).to({state:[{t:this.shape_197}]},1).to({state:[{t:this.shape_198}]},1).to({state:[{t:this.shape_199}]},1).to({state:[{t:this.shape_200}]},1).to({state:[{t:this.shape_201}]},1).to({state:[{t:this.shape_202}]},1).to({state:[{t:this.shape_203}]},1).to({state:[{t:this.shape_204}]},1).to({state:[{t:this.shape_205}]},1).to({state:[{t:this.shape_206}]},1).to({state:[{t:this.shape_207}]},1).to({state:[{t:this.shape_208}]},1).to({state:[{t:this.shape_209}]},1).to({state:[{t:this.shape_210}]},1).to({state:[{t:this.shape_211}]},1).to({state:[{t:this.shape_212}]},1).to({state:[{t:this.shape_213}]},1).to({state:[]},1).to({state:[{t:this.instance_25}]},236).to({state:[{t:this.instance_25}]},62).to({state:[]},1).to({state:[{t:this.shape_214}]},98).to({state:[{t:this.shape_215}]},1).to({state:[{t:this.shape_216}]},1).to({state:[{t:this.shape_217}]},1).to({state:[{t:this.shape_218}]},1).to({state:[{t:this.shape_219}]},1).to({state:[{t:this.shape_220}]},1).to({state:[{t:this.shape_221}]},1).to({state:[{t:this.shape_222}]},1).to({state:[{t:this.shape_223}]},1).to({state:[{t:this.shape_224}]},1).to({state:[{t:this.shape_225}]},1).to({state:[{t:this.shape_226}]},1).to({state:[{t:this.shape_227}]},1).to({state:[{t:this.shape_228}]},1).to({state:[{t:this.shape_229}]},1).to({state:[{t:this.shape_230}]},1).to({state:[{t:this.shape_231}]},1).to({state:[{t:this.shape_232}]},1).to({state:[{t:this.shape_233}]},1).to({state:[{t:this.shape_234}]},1).to({state:[{t:this.shape_235}]},1).to({state:[{t:this.shape_236}]},1).to({state:[{t:this.shape_237}]},1).to({state:[{t:this.shape_238}]},1).to({state:[{t:this.shape_239}]},1).to({state:[{t:this.shape_240}]},1).to({state:[{t:this.shape_241}]},1).to({state:[{t:this.shape_242}]},1).to({state:[{t:this.shape_243}]},1).to({state:[{t:this.shape_244}]},1).to({state:[{t:this.shape_245}]},1).to({state:[{t:this.shape_246}]},1).to({state:[{t:this.shape_247}]},1).to({state:[{t:this.shape_248}]},1).to({state:[{t:this.shape_249}]},1).to({state:[{t:this.shape_250}]},1).to({state:[{t:this.shape_251}]},1).to({state:[{t:this.shape_252}]},1).to({state:[{t:this.shape_253}]},1).to({state:[{t:this.shape_254}]},1).to({state:[{t:this.shape_255}]},1).to({state:[{t:this.shape_256}]},1).to({state:[{t:this.shape_257}]},1).to({state:[{t:this.shape_258}]},1).to({state:[{t:this.shape_259}]},1).to({state:[{t:this.shape_260}]},1).to({state:[{t:this.shape_261}]},1).to({state:[{t:this.shape_262}]},1).to({state:[{t:this.shape_263}]},1).to({state:[{t:this.shape_264}]},1).to({state:[{t:this.shape_265}]},1).to({state:[{t:this.shape_266}]},1).to({state:[{t:this.shape_267}]},1).to({state:[{t:this.shape_268}]},1).to({state:[{t:this.shape_269}]},1).to({state:[{t:this.shape_270}]},1).to({state:[{t:this.shape_271}]},1).to({state:[{t:this.shape_272}]},1).to({state:[{t:this.shape_273}]},1).to({state:[{t:this.shape_274}]},1).to({state:[{t:this.shape_213}]},1).to({state:[]},1).wait(70));
	this.timeline.addTween(cjs.Tween.get(this.instance_25).wait(396).to({_off:false},0).to({y:-16.7},62).to({_off:true},1).wait(230));

	// Layer_7
	this.shape_275 = new cjs.Shape();
	this.shape_275.graphics.f("#D5FFFF").s().p("AieCLQgZgCgSgHQgQgFgcgQQgagMgcgGQgUgDgdgBIgwgBQgjgChSgNQgLgCgDgEQgEgFACgKQAFgRAVgKQAMgFAagEQgtgGgYgHQgmgLgXgUQgMgNAFgIQADgFAKgBQAVgDAdgBIAzAAQBhgCBegVQgGAAgDgGQgDgGABgGQADgJANgIQAbgPAuADIAmADQAWACAPgCIAegFQATgDALgBQAOgBAIAGQAFADABAGQACAGgDAFQBtgWBEgEQBjgGBPAZQAQAFAAAJQABALgRADIgLAEQgHACgCAFQCIgMCEAgIAlAKQANADAEAEQADADABAFQABAFgCADQgEAFgLABIhuALQhLAIgoAOQACAFAHAFIALAJQAGAFACAGQACAIgFAEQgDAEgKABQhFAJhGgDIgWAAQgNABgJAFQADADAQAGQANAEACAKQACANgVAGQgdAJgxAAQhAABgQACIgmAGQgYAFgOACQgOABgcAAIgsABIgtgBg");
	this.shape_275.setTransform(10.4,0.9);

	this.shape_276 = new cjs.Shape();
	this.shape_276.graphics.f("#D5FFFF").s().p("AhuCOIgugBIgHgBQgRgCgNgEIgHgCIgVgJIgXgMQgMgGgNgEQgPgFgPgDIgBAAIgTgDIgLgBIgOgBIgDAAIgugCIgHgBIgmgEIglgFIgggEIgEgBQgKgBgEgEQgEgFACgJQACgKAHgGQAGgGAJgFQAIgDAPgDIANgDQgtgGgZgIQgYgGgSgLQgLgGgIgIIgCgCQgLgLAFgHQADgGAKgBIAKgBIAegDIALAAIATAAIAFAAIAFAAIATgBIABAAIASgBIAPgBIATgCIAigCIAlgEIAZgEIARgDIAIgDIAJgCIAKgCQgFAAgDgFIgBgBQgDgGACgGQADgJAOgIQATgKAfgCIAYAAIAmADIAgAAIAGAAIAegFIABAAQARgEAMAAIACAAQANgBAHAFQAFAEACAGQABAEgBAEIgBACIAIgCIALgCIASgDIA6gJIAdgEIAWgCIAWgCIALgBIAJgBIAQAAIAXgBQBJACA8ATIABAAQAPAEABAJQAAAIgJAEIgGACIgLAEQgEABgCADIgDADQAmgDAmAAQArAAAqAFIAOACIAMACIALACIAKACQAcAEAbAHIAEABIAjAKQALADAEADIABABQADADABAEQABAFgDAEQgCADgGABIgFACIgBAAIgFABIggADIgzAFIgRACIgNACQgeADgYAFIgeAJIgNAFQABAFAHAFIACACIAIAGQAGAFACAHQABAHgEAEQgEAEgJABQgYAEgXABQgvADgvgBIgXAAQgNABgJAFQADADAPAGQAKADADAGIABAEQABAIgIAGIgIAFIgEABIgEABIgHACIgQADIgUACIgbABIgFAAIgMAAIgNAAQgrABgNABIgcAFIgLACIgcAFIgKABQgOACgcAAIgpABIgEAAg");
	this.shape_276.setTransform(10.1,0.9);

	this.shape_277 = new cjs.Shape();
	this.shape_277.graphics.f("#D5FFFF").s().p("AhrCPIgvgBIgHgBQgRgBgOgEIgGgDQgJgCgNgHIgXgLIgZgKIgegJIgCAAIgTgCIgKgBIgOgCIgCgBIgtgCIgGgBIgngEIgmgFIgfgDIgEgBQgLgCgDgDQgFgEACgKQACgJAGgHQAGgGAJgEQAHgDAOgDIAMgDQgtgGgZgIQgZgGgSgLQgLgGgJgIIgCgCQgKgLAEgIIAAgBQADgEAKgCIAKgCIAfgCIAKAAIATgBIAFAAIAFAAIATgBIABAAIAQgBIAQgDIATgBIAigCIAlgEIAagEIARgDIAIgDIAIgCIALgCQgFgBgDgFIAAgBQgDgFACgGQADgJAOgIQAUgLAfgBQALgBANABIAnACIAgAAIAGAAIAfgFIABAAQARgEAMAAIACAAQANgBAIAFQAFAEACAFQABAFgBAEIgBACIAIgCIALgCIATgCIA6gKIAegEIAWgCIAWgCIAMgBIAJAAIAPgBIAYAAQBLABA8ATIABAAQAPAFABAHQABAJgJAEIgGACIgKADQgEACgCADIgCACQAlgCAoABQAsAAApAEIAPADIALACIALACIAKACQAbAFAZAHIADABIAiAJQAKADAEADIABABQADADABAFQAAAFgCADQgDAEgGABIgFABIgBAAIgEABIgfAEIgwAFIgQACIgMACQgdADgXAGQgPADgOAGIgNAFQACAFAFAFIADACIAHAGQAGAFABAHQACAHgFAFQgDADgKABIgwAGQgvACgwgBQgQAAgHABQgMABgKAFQACADAPAGQAKACACAHIABAEQABAHgIAHIgIAFIgEABIgEABIgHADIgRACIgUACIgaACIgGAAIgMgBIgOAAIg4ACIgcAEIgLACIgcAEIgLACQgPABgcAAIgpACIgEAAg");
	this.shape_277.setTransform(9.8,1);

	this.shape_278 = new cjs.Shape();
	this.shape_278.graphics.f("#D5FFFF").s().p("AhoCQIgvgBIgHAAQgRgCgPgEIgGgCQgJgCgNgHIgYgLIgZgKQgPgFgQgDIgBAAIgTgEIgKgCIgNgCIgDAAQgNgCgdgBIgGAAIgngGIgmgDIgggEIgFAAQgKgCgEgDQgEgFABgJQACgIAGgHQAFgFAIgFQAHgDANgDIAMgDQgtgHgbgHQgYgHgTgKQgLgHgJgHIgCgDQgLgLAFgHIAAgBQADgFAJgCIALgCIAegDIALAAIAUAAIAFgBIAEAAIASgBIABAAIAQgCIAPgCIATgCIAjgDIAlgDIAagDIARgEIAIgCIAJgDIAKgDQgEAAgDgEIgBgCQgCgFACgGQAEgJAOgHQAUgLAfgCIAZAAIAnACQATABAOgBIAGgBIAfgEIABAAQARgEANgBIACAAQANAAAIAFQAFADACAGQACAFgBADIgBACIAIgBIALgCIATgDIA7gKIAegDIAXgCIAWgDIAMgBIAJAAIAQgBIAYAAQBMACA9ASIABAAQAPAFABAIQABAIgJAEIgFACIgKAEQgDABgCACIgCADQAlgCApABQAtABAqAFIAOACIAMACIAKADIAJACQAaAFAXAGIAEABIAfAKQAKADADADIABABQADADABAEQAAAFgCAEQgDADgGABIgFACIgBABIgEABIgdADIguAFIgPACIgLABQgcAEgVAGIgcAKIgNAFQABAFAGAFIACACIAHAHQAFAEACAHQABAHgFAFQgDADgKABQgYAEgYACQgwADgwgBIgYAAQgNACgJAFQACACAOAHQAJADACAFIABAEQAAAIgHAGIgIAFIgEACIgEACIgHACIgRACIgVACIgbABIgFAAIgMAAIgOAAQgrAAgOACQgLAAgSADIgLACIgdAFIgKACQgPABgdAAIgqABIgEAAg");
	this.shape_278.setTransform(9.4,1.1);

	this.shape_279 = new cjs.Shape();
	this.shape_279.graphics.f("#D5FFFF").s().p("AiVCSIgHgBQgRgCgPgEIgGgBQgJgDgNgGIgZgMIgagKQgPgFgPgDIgCAAIgTgEIgKgCIgMgCIgDAAQgMgDgbgCIgHAAIgngFIgngEIgggDIgEAAQgLgCgDgDQgFgEABgJQABgIAGgHQAFgFAIgFQAGgDAMgDIAMgDQgugGgbgIQgZgHgTgKQgMgHgJgHIgCgCQgKgMAEgIIAAAAQADgGAJgCIALgCQANgCASgBIALAAIAUAAIAFgBIAEAAIARgBIAAAAIAPgDIAPgDIAUgCQARgCASAAQAUgBASgCIAagDIARgEIAIgDIAIgDIALgDQgEAAgCgEIgBgCQgCgFACgGQAEgJAOgHQAVgKAggDIAYAAIAoACQATABAOgBIAGgBIAggFIABAAQARgDANgBIACAAQANAAAIAEQAGAEACAFIABAJIgBACIAIgCIALgBIAUgDIA8gKIAegEIAXgCIAWgCIAMgBIAKAAIAQAAIAYgBQBOACA9ARIABAAQAPAFABAIQACAIgJAEIgFACQgIADgBABQgDABgCADIgCADQAmgDApABQAuABAqAGIAPACIALADIAKADIAJADQAYAEAWAHIADABIAeAJQAJADADADIABABQADADAAAEQABAFgDAEQgDADgGACIgFABIgBAAIgEACIgbADIgrAFIgOACIgLABQgaAEgUAHIgbAKIgNAGQABAFAGAFIACACIAGAGQAFAFACAGQABAIgFAEQgEAEgKABQgXADgZACQgxAEgxgBIgYABQgNABgJAFQABADAOAFQAIADACAGIABAEQAAAIgHAGIgIAGIgEABIgEACIgHACIgRADIgVACIgcABIgFAAIgMAAIgOgBIg6ABQgLABgSADIgLACIgeAFIgKABQgQACgcAAIgrABIgEAAIgcAAIgUAAg");
	this.shape_279.setTransform(9.1,1.1);

	this.shape_280 = new cjs.Shape();
	this.shape_280.graphics.f("#D5FFFF").s().p("AiSCTIgIgBQgRgBgPgEIgGgBIgXgJIgZgMIgagKIgfgJIgBAAIgTgEIgKgCIgMgCIgCAAQgMgDgagCIgGgBIgogFIgngEIghgCIgEgBQgKgBgEgDQgFgEABgJQABgIAFgGQAFgFAHgFQAGgDALgDIALgDQgugHgcgIQgZgHgTgKQgMgGgJgIIgDgCQgKgLAEgIIAAgBQADgGAJgCIALgCIAfgDIALAAIAUgBIAFAAIAFgBIAPgBIABAAIAOgDIAPgDIATgDQASgCASAAQAUgBASgCIAbgDIASgDIAHgEIAIgDIALgDQgEAAgCgEIgBgCQgCgFADgFQAEgJAOgIQAWgKAggCQAMgBANAAIAoACQATAAAOgBIAGAAIAggFIABAAQARgEAOAAIACAAQAOgBAIAFQAFADADAGIABAIIgBACIAJgBIALgBIAUgDIA8gKIAfgEIAXgDIAXgCIAMgBIAKAAIAQAAIAYAAQBQABA9ASIABAAQAPAEACAIQACAIgJAEIgEACQgIACgBACQgDABgCADIgBACQAlgBArABQAuABArAFIAOADQAGABAGADIAJADIAJACQAXAFAUAGIADABIAbAKQAJADADADIABABQADADAAAEQAAAFgDAEQgCADgGABIgFACIgBAAIgEACIgZADIgpAFIgNACIgKABQgZAEgTAHIgZALIgOAGQACAFAFAFIABACIAHAHQAEAEABAHQABAHgFAEQgEAEgJABQgYAEgaACQgxADgxAAQgRAAgIABQgNABgKAFQACADANAFQAIADABAGIABAEQAAAIgHAGIgIAGIgEABIgEACIgHACIgSADIgVACIgbABIgGAAIgMAAIgPgBQgrAAgPABQgLAAgTAEIgLABIgfAFIgJABQgQACgdAAIgrABIgEAAIgcAAIgUAAg");
	this.shape_280.setTransform(8.8,1.1);

	this.shape_281 = new cjs.Shape();
	this.shape_281.graphics.f("#D5FFFF").s().p("AiQCVIgIgBQgRgBgPgEIgGgCQgLgCgNgGIgYgLIgbgLIgfgJIgCAAIgTgEIgKgDIgLgCIgCgBQgLgDgZgCIgFgBIgogFIgogEIghgBIgEgBQgLgBgEgDQgFgEABgIQAAgIAFgGQAFgFAGgFQAFgDALgDIAKgDQgugHgcgIQgagHgUgKQgMgGgJgIIgCgCQgLgLAEgJIAAgBQADgGAJgCIALgCQANgDATAAIALAAIAUgBIAFgBIAEAAIAPgCIAAAAIAOgDIAPgEIATgDQASgCASAAQAVAAASgCIAbgDIASgEIAHgDIAIgEIALgDQgEgBgCgEIAAgBQgCgFACgFQAFgJAPgIQAWgKAggCQAMgBANAAIApACIAigBIAGgBIAggFIABAAQARgDAOgBIACAAQAOAAAJAEQAFAEACAFQACAEAAAEIgBACIAJgBIALgBIAUgCIA+gLIAfgEIAXgCIAXgCIANgBIAJgBIAQABIAZAAQBSABA9ARIABAAQAPAFACAHQACAIgIAEIgEACQgIACAAACIgFADIgBADQAmgBArABQAwACAqAFIAPADIALAEIAKADIAIADQAWAFASAGIACABIAaAJQAJADACADIABABQADAEAAAEQAAAFgDADQgDADgGACIgFACIgBAAIgDACIgYADIgmAFIgMACIgJABQgYAEgRAIIgZALIgNAHQABAFAEAFIACACIAGAGQAEAFABAGQABAHgFAEQgEAEgKABIgyAGQgxAEgzAAIgYABQgNABgLAFQABACANAGQAIADABAGIABAEQgBAHgHAGIgIAHIgEABIgEACIgHADIgSACIgVACIgcACIgGgBIgMAAIgPgBIg7AAQgLABgTADIgLACIgfAEIgKACQgRABgcAAIgsACIgEAAIgcAAIgVAAg");
	this.shape_281.setTransform(8.5,1.2);

	this.shape_282 = new cjs.Shape();
	this.shape_282.graphics.f("#D5FFFF").s().p("AiOCWIgHAAQgSgBgPgEIgHgCQgKgCgNgGIgZgLIgbgKIgggKIgCAAIgTgEIgJgDIgLgDIgCgBQgKgDgXgDIgGgBIgogFIgogDQgPgCgTABIgEgBQgLgBgEgDQgEgDAAgJQAAgHAEgGQAEgFAGgFQAFgDAKgDIAKgDQgvgHgdgIQgZgHgVgKQgMgGgJgIIgDgCQgLgLAEgKIAAAAQADgGAJgCIALgDQAOgDASgBIAMAAIAUAAIAFgBIAEgBQAIAAAFgCIABAAIANgDIAOgFIAUgDQARgCAUAAQAUAAASgCIAbgDQAKgBAJgCIAHgEIAIgEIALgDQgEgBgBgEIgBgBQgBgFACgFQAFgJAPgHQAWgKAhgDIAZgBIAqABQATABAPgBIAGgBIAhgGIABAAQARgDAOAAIADAAQANgBAJAFQAGADACAFQACAFAAADIAAACIAIAAIAMgBIAUgDIA+gKIAggEIAXgDIAYgCIAMgBIAKAAIAQAAIAZAAQBUABA9ARIABAAQAPAFADAIQACAHgHAEIgFACQgHACAAACIgEADIgCADQAngBAsACQAwACArAFIAPADIALAEIAJAEIAHADQAWAFAQAGIACABIAYAJQAIADADADIAAABQACADABAFQgBAEgDAEQgDADgFACIgFACIgBAAIgEACIgWAEIgjAEIgMACIgIABQgWAEgQAIIgYANIgNAGQABAFAEAFIACACIAFAGQAFAFAAAGQABAHgFAEQgFAEgJABQgZAEgaACQgyAFgzAAIgZABQgNABgLAEQABADAMAGQAHADABAFIABAEQgBAIgHAGIgIAGIgDACIgEACIgIADIgSADIgVACIgdABIgFAAIgNgBIgPgBIg8AAQgMAAgSADIgMACIgfAFIgLABQgQACgdAAIgsABIgFAAIgcAAIgVAAg");
	this.shape_282.setTransform(8.2,1.2);

	this.shape_283 = new cjs.Shape();
	this.shape_283.graphics.f("#D5FFFF").s().p("AhZCYIgyAAIgIgBQgSgBgPgDIgGgCQgLgCgNgGIgagLIgbgKQgQgGgQgEIgCAAIgTgFIgJgDIgKgEIgCAAQgJgEgXgDIgEgBIgpgFIgpgDQgOgBgUAAIgEAAQgLgBgEgDQgFgDAAgIQAAgIAEgFIAJgKQAEgDAKgDIAIgDQgugHgegIQgagIgVgJQgMgHgKgHIgCgDQgLgLAEgJIAAgBQACgGAJgCIALgEQAOgCATgBIAMAAIAUgBIAFgBIAEgBIAMgBIABAAIAMgEIAOgFIAUgEQASgCATAAQAVAAASgBIAcgDQAKgBAIgDIAHgEIAIgEIALgDQgDgBgCgEIAAgBQgBgFACgFQAGgJAPgHQAXgKAggDIAagBIAqABIAjgBIAGgBIAhgFIABAAQARgDAPgBIACAAQAOAAAJAEQAGADACAGQADAEAAAEIgBACIAJgBIAMgBIAUgCIA/gLIAggEIAYgCIAXgCIANgBIAKgBIARABIAZAAQBVABA9ARIABAAQAQAEACAIQADAHgHAEIgEACQgHACAAACIgEADIgBADQAngBAtACQAxACArAGIAPADQAGACAFADIAJAEIAHADQAUAFAPAGIABABIAWAJQAIADACADIABABQACADAAAEQgBAFgDAEQgDADgGACIgFACIAAAAIgDACIgVAEIggAEIgLACIgIABQgVAEgOAJIgXANIgNAGQAAAFAFAFIABACIAFAHQAEAFAAAGQABAGgFAFQgFADgJACIg0AGQgzAEgzABIgZAAQgOACgKAEQAAADAMAGQAGADABAFIAAAEQgBAHgHAHIgHAGIgEACIgEACIgIADIgSADIgVACIgdABIgGAAIgMgBIgPgBQgsgBgRAAQgMABgTADIgMACIggAEIgLACQgQABgdAAIgtACIgEAAg");
	this.shape_283.setTransform(7.9,1.3);

	this.shape_284 = new cjs.Shape();
	this.shape_284.graphics.f("#D5FFFF").s().p("AhWCZIgzAAIgIAAQgSgBgQgEIgGgBQgLgCgNgGIgagLIgcgKQgQgGgQgEIgBAAIgUgFIgJgEIgJgEIgCAAQgIgFgVgDIgFgBIgpgGIgpgCQgPgBgTABIgFAAQgKgBgFgDQgFgDAAgIQgBgHAEgGQADgEAFgFQAEgDAJgDIAIgDQgvgHgfgJQgagHgVgKQgNgGgJgHIgDgDQgLgLAEgKIAAAAQACgHAJgCIALgEQAOgDATAAIAMAAIAVgBIAFgBIADgBIAMgCIAAAAIAMgEIAOgGIATgEQASgDAUABQAWABASgCIAcgDQAKgBAIgDIAHgEIAIgEIALgEQgDAAgBgEIgBgBQgBgFADgFQAGgJAPgHQAXgKAhgDIAbgBIAqABIAjgBIAGgBIAigGIABAAQAQgDAQAAIACAAQAPgBAJAFQAGADACAFQADAEAAAEIgBACIAJgBIAMAAIAVgDIBAgKIAggFIAYgCIAYgCIANgBIAKAAIAQAAIAaAAQBXACA9AQIABAAQAQAEADAIQADAHgHAEIgEACQgGACAAACIgDADIgBADQAmgBAvADQAyACArAGIAPADQAGACAFADIAIAFIAHADQASAFANAGIACABIAUAJQAHADACADIABABQABADAAAEQAAAFgDADQgDADgGACIgFADIgBAAIgDACIgTAEIgdAEIgKABIgHACQgUAEgNAJIgWAOIgNAHQABAFADAFIACACIAEAGQAEAFAAAGQAAAHgFAEQgEADgKACQgZAEgbACQgzAFg0AAIgaABQgOACgKAEQAAADALAFQAGADAAAGIABAEQgCAHgHAGIgHAHIgDACIgEACIgIADIgTADIgWACIgdABIgFAAIgNgBIgQgBQgrgBgSAAQgNAAgSADIgMACIghAEIgLACIgtACIguABIgEAAg");
	this.shape_284.setTransform(7.6,1.3);

	this.shape_285 = new cjs.Shape();
	this.shape_285.graphics.f("#D5FFFF").s().p("AiOCaQgTAAgQgEIgGgBQgLgCgNgGQgMgEgPgHIgcgKQgQgGgQgEIgCAAIgTgGIgJgEIgJgEIgCAAQgHgFgUgEIgEgBIgqgGIgqgCQgOgBgUACIgEgBQgLAAgEgDQgGgDAAgHQgBgHADgGIAIgIQADgEAIgDIAHgDQgvgHgfgJQgbgHgVgLQgNgFgKgIIgCgCQgMgLAEgKIAAgBQACgHAJgCQAFgDAGgBQAOgDAUgBIAMAAIAVgBIAFgBIADgBIAKgCIABAAIALgFIANgGQAKgDAKgBQASgDAUABQAWABASgBIAdgDQAKgBAIgDIAHgEQAEgDAEgCQAEgCAHgCQgDAAgBgEIAAgBQgBgFADgFQAGgIAPgIQAYgJAhgDQANgCAOABIArAAIAjgCIAGgBIAjgFIAAAAQARgDAQgBIADAAQAOAAAJAEQAGADADAFIADAIIAAACIAJAAIAMgBIAVgCIBAgLIAhgEIAYgDIAYgBIANgBIAKgBIARABIAaAAQBZABA9AQIABAAQAQAFADAHQADAHgGAEIgDACQgHACABABQgCACgBACIgBADQAngBAvADQAzADArAGIAPADQAGACAFADQAEAEAEABIAGAEQASAFALAGIABABIATAJQAGACACADIABABQABAEAAAEQgBAEgDAEQgDADgGACIgFADIAAAAIgDACIgRAEIgbAEIgJABIgHACQgSAEgMAKQgIAHgMAHIgOAHQABAFADAFIACACIAEAHQADAEAAAGQAAAHgFAEQgFAEgJABIg1AHQg0AEg1ABIgaABQgNABgLAFQgBADALAFQAGADAAAFIAAAEQgCAIgHAGIgHAHIgDACIgEACIgIAEIgTADIgWABIgeABIgFAAIgNgBIgQgBQgsgCgSABIggADIgMABIggAFIgMABQgRACgdAAIguABIgEAAIg0ABIgHgBg");
	this.shape_285.setTransform(7.3,1.4);

	this.shape_286 = new cjs.Shape();
	this.shape_286.graphics.f("#D5FFFF").s().p("AiMCcQgTgBgQgDIgGgBQgMgCgNgGQgMgEgPgHIgcgKQgQgGgRgEIgCgBIgTgFIgIgFIgJgEIgCAAQgGgGgTgDIgDgCQgTgDgYgDQgTgCgXAAQgOAAgVABIgEAAQgLgBgEgCQgGgDAAgHQgBgGACgGIAHgIQADgEAHgDIAGgDQgvgIgggIQgagIgWgKQgOgFgJgIIgDgCQgLgMADgKIAAgBQACgGAJgDIALgEQAOgDAUgBIAMAAQANAAAJgBIAFgCIACgBQAGAAAEgCIAAAAIAKgFIAOgGQAJgEALgBQASgDAUABQAWABATgBIAcgCQALgBAIgEQAEgBADgDIAHgFQAFgCAHgCQgDgBgBgDIAAgCQAAgEADgFQAGgIAQgHQAYgKAigDIAagBIAsgBIAjgBIAHgBIAigGIABAAQARgDARAAIACAAQAOgBAKAEQAGADADAGQACAEABADIAAACIAJAAIAMAAIAWgCIBBgLIAggFIAZgCIAZgCIANgBIAKAAQAIgBAJACIAbAAQBZABA+AQIABAAQAQAEAEAHQADAHgGAEIgDACQgGACABABIgDAEIAAADQAmgBAxADQAzADAsAGIAPAEQAGACAFAEQAEADAEACIAFADQARAGAJAGIABAAIAQAJQAHADABADIABABQABADAAAEQgBAFgEAEQgDADgFACIgFACIgBABIgCACIgQAEIgYAEIgJABIgFACQgRAEgLAKQgHAHgMAIIgNAIQAAAFADAEIABACIAEAHQADAFAAAFQAAAHgGAEQgEAEgKABQgZAEgcADQg1AFg1ABIgbABQgNABgLAFQgBADAKAFQAFADAAAFIAAAEQgCAHgHAHIgHAHIgDACIgEACQgEADgEABQgIACgLABIgXACIgeABIgFgBIgNAAIgQgCIg/gCIggADIgMACIghAEIgMACQgRABgdAAIgvACIgFAAIgzABIgIgBg");
	this.shape_286.setTransform(7,1.4);

	this.shape_287 = new cjs.Shape();
	this.shape_287.graphics.f("#D5FFFF").s().p("AiKCeQgTgBgQgDIgGgBQgMgCgNgGQgNgEgPgHIgdgKQgQgGgRgFIgBAAIgUgGIgIgFIgIgEIgCAAQgFgHgRgDIgEgCQgSgDgYgDQgUgCgXAAQgOAAgVACIgFAAQgKgBgFgCQgFgCgBgIQgCgGADgFQACgEADgEQACgEAHgDIAGgDQgwgIghgJQgagHgXgKQgNgGgKgHIgDgDQgLgLADgKIAAgBQACgHAJgDIALgEQAOgEAUAAIANAAIAWgBIAFgCIACgBIAJgCIAAgBIAJgFIANgHQAKgEAKgBQATgDAVABQAWACASgCIAdgCQALgBAIgDQAEgCADgDIAHgFQAFgCAHgCQgDgBAAgDIgBgCQAAgEAEgFQAGgIAQgHQAYgKAjgDIAbgBIArgBIAlgCIAGgBIAjgFIABAAQAQgDASgBIACAAQAPAAAJAEQAGADAEAFIADAIIAAACIAJAAIAMAAIAVgDIBDgLIAhgEIAZgDIAZgCIANgBIALAAQAHAAAKABIAbAAQBbABA+AQIABAAQAQAEAEAHQAEAHgGAEIgCACQgGACABABQAAAAgBABQAAAAAAABQgBAAAAABQAAABAAAAIgBADQAnAAAxADQA1ADArAGIAQAEQAGACAEAEIAIAGIAFADQAPAFAIAGIAAABQAGAFAJAEQAGADABADIABABQABADgBAEQgBAFgDADQgDADgGADIgFACIgBABIgCACIgNAEIgWADIgIACIgFACQgPAEgJALQgHAHgMAIIgNAIQAAAFADAFIABACIADAGQADAFAAAGQgBAGgFAEQgFAEgKABIg1AHQg2AFg1ACIgbABQgOABgLAFQgBADAJAFQAFADgBAFIAAAEQgCAHgHAGIgHAIIgDACIgEADIgIADQgIACgLABIgXACIgfABIgFAAIgNgBIgQgCQgsgCgUAAIggADIgMABIgiAFIgMABIgvACIgvABIgFAAIg0ABIgIAAg");
	this.shape_287.setTransform(6.7,1.5);

	this.shape_288 = new cjs.Shape();
	this.shape_288.graphics.f("#D5FFFF").s().p("AiICfQgTAAgRgDIgGgCQgMgBgNgGQgMgEgQgHIgdgKQgQgGgRgFIgCAAIgUgGIgHgFIgIgFIgCgBQgEgGgQgEIgDgBQgTgEgYgDQgUgCgXABQgOgBgWADIgEAAQgLgBgFgCQgFgCgBgHQgCgGACgFIAEgIQACgEAGgDIAFgDQgwgIghgJQgbgHgXgLQgOgFgKgHIgCgDQgMgLADgLIAAgBQACgHAJgDIALgEQAOgEAVAAIAMAAQANAAAJgCIAFgCIADgBQAEAAADgCIAJgGIANgIQAJgEALgBQASgEAWACQAWACATgBIAdgCQAMgBAHgEIAHgFIAHgFQAFgDAHgBQgDgBAAgEIAAgBQAAgEADgFQAHgIAQgHQAZgJAjgEQANgBAOAAIAsgBIAlgCIAGgBIAkgGIABAAQAQgDASAAIACAAQAPgBAKAEQAGADADAFQADAEABAEIAAACIAJAAIANAAIAVgCIBEgLIAhgFIAZgCIAZgCIAOgBIAKgBIASACIAbAAQBdABA+APIABAAQAQAEAEAHQAEAHgFAEIgCACQgCAAgBABQAAAAgBABQAAAAAAAAQAAABAAAAQAAABgBAAQAAABAAAAQgBABAAAAQAAABAAAAIAAADQAmAAAzADQA1AEAsAGQAJACAHACQAFACAFAFIAHAFQAEACABACQAOAFAGAGIAAABIANAJQAFADABADIABABQABADgBAEQgBAEgEAEQgDADgGACIgFADIAAABIgCACIgMAEIgTADIgHACIgEACQgPAEgHALQgGAIgLAIIgOAIQAAAFADAFIABACIADAHQACAEAAAGQgBAGgGAEQgFAEgJABQgaAFgdADQg1AFg3ABIgbACQgOABgLAFQgCADAJAFQAEACAAAGIAAADQgDAHgHAHIgGAIIgEACIgEADIgIADQgIACgLABIgYACIgeABIgGAAIgNgBIgQgCIhBgDIghADIgMACIgiAEIgMABIgvACIgwACIgFAAIg1ABIgIgBg");
	this.shape_288.setTransform(6.4,1.5);

	this.shape_289 = new cjs.Shape();
	this.shape_289.graphics.f("#D5FFFF").s().p("AiGChQgTgBgRgCIgGgCQgMgBgNgFQgNgEgQgHIgdgLQgRgGgRgFIgBAAIgUgHQgFgCgDgDIgHgFIgBgBQgEgHgPgEIgCgBQgTgEgZgDQgUgCgYABQgOAAgVACIgFAAQgLAAgEgCQgGgCgBgHQgDgFACgFIAEgIQABgEAFgDIAEgDQgwgIgigJQgbgHgXgLQgOgGgKgHIgDgCQgMgMADgKIAAgCQADgHAIgDIALgFQAOgDAVgBIANAAQANAAAJgBIAFgCIACgBIAHgDIAAAAIAIgGQAEgEAJgEQAJgEAKgCQATgEAWACQAXACATgBIAdgCQAMgBAIgDIAGgFIAHgGQAFgDAHgBQgCgBgBgEIAAgBQAAgEAEgFQAIgIAQgHQAZgJAjgEQANgBAOAAIAtgBIAlgDIAHgBIAkgFIAAAAQAQgDATgBIACAAQAPAAAKAEQAHADADAFQADADABAEIAAACIAKAAIAMABQALAAALgCIBEgLIAigFIAZgDIAagCIAOgBIAKAAIASABIAbABQBfABA+APIACAAQAPAEAFAGQAEAHgFAEIgCACQgBAAgBABQgBAAAAABQAAAAAAAAQAAABAAAAQAAABgBAAQAAABAAAAQAAAAgBABQAAABAAAAIAAADQAnAAAzAEQA3ADAsAHQAJACAGACQAGADAFAEQADAEAEACIAEAEQANAFAEAGIAAABIALAJQAFADAAADIABABQABADgBADQgCAFgDAEIgJAFIgFADIgBABIgBACIgLAEIgQADIgGACIgDACQgOAEgGAMQgFAIgLAIIgNAJQgBAFADAFIABACIACAGQACAFgBAFQAAAHgGAEQgFADgKACQgaAEgdADQg2AFg3ACIgcACQgOABgLAFQgCACAIAGQAEACgBAFIAAAEQgEAHgGAHIgGAIIgDACIgEADIgJAEQgIACgMABIgXACIgfAAIgFAAIgOgBIgQgCQgtgDgVAAQgOAAgTADIgMABIgjAEIgMACQgTABgdAAIgwACIgFAAIg2ABIgIAAg");
	this.shape_289.setTransform(6.1,1.6);

	this.shape_290 = new cjs.Shape();
	this.shape_290.graphics.f("#D5FFFF").s().p("AiDCiQgUAAgRgDIgGgBQgNgCgNgEQgNgEgQgHIgegLIghgLIgCAAIgUgHQgFgDgCgDIgHgFIgBgBQgDgHgNgFIgDgBQgTgFgZgCQgVgCgXABQgOAAgWADIgEAAQgLAAgFgCQgGgCgBgGQgDgGABgEIADgIQABgEAEgDIAEgDQgxgIgigJQgcgIgXgKQgPgGgKgHIgDgDQgMgLADgLIAAgBQADgIAIgDIALgFQAOgEAWAAIAMAAIAXgCIAFgCIACgBIAFgDIAHgHQAFgEAIgEQAJgEALgCQATgEAWACQAXACATAAIAegCQAMgBAIgEQADgCADgDQADgEAEgCQAEgDAIgCQgBAAAAAAQAAAAgBgBQAAAAAAgBQAAgBAAgBIAAgBQAAgEAEgFQAIgIAQgGQAagKAjgEQAOgBAOAAIAtgCIAlgCIAHgBIAkgGIABAAQAQgDATgBIADAAQAPAAAKAEQAGADAEAFQADAEABADIAAACIAKABIANAAQAKAAALgCIBGgLIAigFIAZgCIAagCIAOgBIALgBIASACIAbAAQBhABA+APIACAAQAPAEAFAGQAFAHgFADQAAAAAAABQAAAAgBAAQAAABAAAAQAAAAAAABQgBAAgBABQgBAAAAABQgBAAAAAAQAAABABAAQAAABgBAAQAAAAAAABQAAAAAAABQgBABAAAAIABADQAmAAA1AEQA3AEAsAHIAQAEQAGADAEAEIAHAHQADACAAACQANAFACAGIgBABQADAEAGAFQAFACAAADIAAABQABADAAAEQgCAFgEADQgDAEgGACIgFADIAAABIgCACIgIAEIgOADIgFACIgDACQgMAEgFAMQgEAJgLAIQgGAFgHAEQAAAFACAFIAAACIACAHQACAEgBAGQgBAGgGAEQgFADgJACIg4AIQg3AFg4ACQgRAAgLACQgOABgMAEQgCADAIAFQAEADgCAFIAAAEQgEAGgGAHIgGAJIgDACIgEADIgJAEQgIACgMABIgYACIgfAAIgFAAIgOgBIgRgCQgsgDgWAAQgOAAgTACIgNACIgjAEIgMABIgwACIgxACIgFAAIg2ABIgIgBg");
	this.shape_290.setTransform(5.8,1.6);

	this.shape_291 = new cjs.Shape();
	this.shape_291.graphics.f("#D5FFFF").s().p("AiBCkQgUAAgRgDIgGgBQgNgCgOgEQgNgEgQgHIgegLIgigLIgCAAQgMgEgIgEQgFgDgCgDIgGgFIgBgBQgCgIgMgFIgCgBQgTgFgagCQgVgCgXABQgOAAgXAEIgEAAQgLAAgFgCQgGgCgBgGQgEgFABgFIACgHQAAgEAEgDIADgDQgxgIgjgKQgcgHgYgKQgPgHgJgGIgDgDQgMgLADgLIgBgCQADgHAIgEQAFgDAGgCQAOgEAWAAIANAAQAOAAAJgCIAFgCIABgCQADAAACgCIAAgBIAGgHQAEgEAJgFQAJgEALgCQATgEAWACQAYADATgBIAegCQAMAAAIgEQADgCADgEQADgEADgCQAFgDAIgCQgBAAAAAAQAAgBgBAAQAAgBAAgBQAAAAAAgBIAAgBQABgEAEgFQAIgHAQgHQAagJAkgEIAcgCIAugCIAmgDIAGgBIAlgFIABAAQAQgDATgBIADAAQAPgBAKAFQAHACAEAFQADAEABAEIABACIAJAAIANABQALAAALgCIBGgLIAjgGIAagCIAagCIAOgBIAKAAIASABIAcABQBjABA+AOIACAAQAQAEAFAGQAEAHgEADIgBADQgBAAgBABQgBAAAAABQAAAAAAAAQAAABABAAIgBAEIAAADQAnAAA1AEQA4AFAtAHIAQAEQAFADAFAFIAGAGQADADAAACQALAFABAGIgBABQACAEAFAEQAEADAAADIAAABQABADgBAEQgCAEgDAEIgJAGIgFADIgBABIgBACIgHAEIgLADIgEACIgCACQgLAEgDANQgEAJgKAJIgOAJQAAAFABAEIABACIABAHQACAEgBAGQgBAGgGAEQgFADgKACQgaAFgeADQg4AFg4ADIgcACQgPABgMAEQgCADAHAFQADADgBAFIgBADQgEAHgGAHIgGAIIgDADIgEADQgEADgFABQgIACgMABIgYACIggABIgFgBIgOgBIgRgCQgsgDgXgBQgOAAgUADIgMABIgkAEIgMABIgxACIgxACIgFAAIg3ABIgIAAg");
	this.shape_291.setTransform(5.5,1.7);

	this.shape_292 = new cjs.Shape();
	this.shape_292.graphics.f("#D5FFFF").s().p("Ah/CmQgUgBgSgCIgGgBQgNgCgNgEIgdgLIgfgLIgjgLIgBgBQgNgDgIgEQgEgDgCgEIgGgGIgBAAQgBgJgLgFIgBgBQgUgFgZgCQgWgCgXABQgOAAgXAEIgFABQgLAAgFgCQgGgBgCgGQgDgFAAgFIABgHQAAgDADgEIACgEQgxgIgkgJQgcgHgYgLQgPgGgKgGIgDgDQgMgMADgLIgBgCQADgHAIgEQAFgDAGgCQAOgEAWAAIAOAAIAXgCIAFgDIABgBIADgDQABgDAFgFQAEgFAIgFQAJgEALgDQATgDAXACQAYADATAAIAfgCQAMgBAIgEQADgCADgEQADgEADgCQAFgDAIgCQAAAAgBgBQAAAAAAgBQAAAAAAgBQgBAAAAgBIAAgBQABgEAEgFQAJgHARgHQAagJAkgEIAcgCIAvgCIAmgDIAHgBIAlgGIAAAAQAQgDAUgBIADAAQAPAAALAEQAHADADAEIAFAIIABACIAJABIAOAAIAWgBIBHgMIAjgFIAagDIAagBIAOgBIALgBIASACIAdABQBkAAA+AOIACAAQAQAEAFAHQAFAGgEADIgBACQgBABAAAAQgBABAAABQAAAAAAAAQAAABABAAIgBAEIAAADQAoAAA2AFQA5AEAsAIQAKACAGACQAGADAEAFQAEAFADACQABABAAAAQABABAAAAQAAABAAAAQAAABAAAAQAKAGgBAGIgCABQABAEAFAEQADADAAADIAAABIAAAGQgCAFgEAEIgJAFIgFAEIAAABIgBACIgGAEIgIADIgDACIgCACQgJAEgCANQgCAJgLAKQgGAFgIAEQAAAFABAFIABACIABAGQABAFgBAFQgBAGgGAEQgGAEgJABQgbAFgeADQg5AGg4ADIgdABQgPACgMAEQgCADAGAFQADADgCAEIgBAEIgKAOIgGAIIgDADIgEADIgJAEQgIADgMABIgYABIghABIgFAAIgOgCIgRgCQgsgEgYAAQgOAAgUACIgNABIgkAEIgMACQgUABgdAAIgyACIgFAAIg4ACIgIAAg");
	this.shape_292.setTransform(5.2,1.7);

	this.shape_293 = new cjs.Shape();
	this.shape_293.graphics.f("#D5FFFF").s().p("Ah9CnQgUAAgSgCIgGgBQgOgCgNgEQgNgEgQgHIgggLIgigLIgCgBQgMgEgIgEQgFgDgCgEIgFgGIgBAAQAAgJgJgFIgCgCQgUgFgZgCQgWgCgYACQgNAAgYAEIgEAAQgLABgGgCQgGgBgCgGQgEgFAAgEIABgHQgBgDACgEIACgEQgygIgkgJQgdgIgYgKQgQgGgKgIIgDgBQgMgMADgMIAAgBQACgIAIgEQAFgDAGgCQAOgFAXAAIANAAQAOAAAJgCQAEgBABgBQABgBAAAAQABAAAAgBQAAAAAAAAQAAAAgBAAIADgDIAAAAQAAgDAFgFQAEgFAIgFQAJgFALgDQATgEAXADQAZADATAAIAfgBQAMgBAIgEIAGgGQADgFADgCQAFgDAIgCQAAgBgBAAQAAAAAAgBQAAAAAAgBQAAgBAAAAIAAgBQABgEAEgFQAJgHARgHQAbgJAkgEIAdgCIAvgDIAmgDIAHgBIAlgGIABAAQAQgCAVgBIACAAQAQgBALAEQAGADAEAFQAEADABAEIABACIAKABIANABQALAAALgCIBIgLIAjgGIAbgCIAagCIAPgBIAKAAQAIAAALACIAdAAQBlABA/AOIACAAQAQADAFAHQAFAGgDADIAAACQgBABgBAAQAAABAAAAQAAABAAAAQAAABABAAQAAAAgBABQAAAAAAABQAAAAAAABQAAAAAAABIABADQAnAAA3AFQA6AFAtAHQAKACAGADQAGADAEAGIAGAHQABAAAAABQAAAAABABQAAABAAAAQAAABAAAAQAJAGgDAGIgCAAQAAAEAEAFQADADgBADIAAABIAAAGQgDAFgEADQgDAEgGACIgFAEIAAAAIgBADQgEADABABIgGADIgCACIgBABQgIAFgBAOQgBAJgLAKIgNAJQgBAFABAFIABACIAAAHQABAEgBAFQgCAGgGAEQgFAEgKABQgbAFgeAEQg5AGg6ACIgdACQgPACgMAEQgDADAGAFQACACgCAFIAAADIgLAOIgGAJIgDADIgEADIgJAFQgHACgNABIgZACIghAAIgFAAIgOgCIgRgCQgtgEgYgBQgOAAgUACIgNACIglAEIgMABQgVACgdAAIgyACIgFAAIg5ACIgIgBg");
	this.shape_293.setTransform(4.9,1.8);

	this.shape_294 = new cjs.Shape();
	this.shape_294.graphics.f("#D5FFFF").s().p("Ah7CpQgUAAgSgCIgGgBQgOgCgNgEQgOgEgQgHIgggLIgjgMIgCAAQgMgEgIgEQgFgEgBgDIgFgHIgBAAQABgKgIgFIgBgCQgUgFgagCQgWgCgYACQgOAAgXAFIgFAAQgLABgFgCQgHgBgCgGQgEgEAAgEIgBgHQgBgDABgEIABgEQgygIglgKQgdgHgYgKQgQgGgKgIIgDgCQgNgLADgMIAAgCQACgIAIgEQAFgDAGgCQAOgFAXAAIAOAAQAOAAAJgCQAEgBABgCQABAAAAgBQAAAAAAAAQABAAgBAAQAAAAAAAAIABgEIAAAAQAAgDAFgFQADgFAIgGQAJgFALgDQAUgEAXADQAZAEATgBIAggBQAMgBAIgEQADgCADgEQACgFAEgCQAEgDAJgCQgBgBAAAAQAAAAAAgBQAAAAAAgBQAAgBAAAAIAAgBQABgEAFgFQAJgHARgGQAbgJAlgFIAdgCIAwgDIAmgDIAHgBIAmgGIABAAQAPgDAWgBIACAAQAQAAALAEQAHADAEAEQAEAEABADIABACIAKABIANACQALAAAMgCQAlgFAkgHIAjgFIAbgDIAbgCIAOgBIALAAQAIAAALACIAdABQBnAAA/AOIACAAQAQAEAGAGQAFAGgDADQAAAAAAABQAAAAAAAAQAAAAAAABQAAAAAAAAQgBABAAAAQgBABAAAAQAAABABAAQAAABABAAQAAAAgBABQAAAAAAABQAAAAAAABQABAAAAABIAAADQAoABA4AFQA7AFAsAHQAKACAHADQAFADAEAGIAGAHQACADAAACQAHAGgEAFIgCABQgCAEADAFQADACgBADIAAABQABADgCAEQgCAEgEAEIgJAGIgFAEIAAAAIgBADQgBABgBAAQAAABgBAAQAAABAAAAQABAAAAABIgDADIgBACIgBABQgGAFAAAOQAAAKgKAKQgGAFgIAFQgBAFABAFIAAACIAAAGQABAEgBAGQgCAFgGAEQgGAEgKABQgbAFgfAEQg5AGg6ADIgeACQgOACgNAEQgDADAFAFQACACgCAFIgBADIgLAOIgGAJIgDADIgEADQgEADgFACQgHACgNABIgZACIghAAIgFAAIgPgCIgRgCQgtgEgZgBQgPAAgUACIgMABIglAEIgNABIgyACIgzACIgFAAIg5ACIgJAAg");
	this.shape_294.setTransform(4.6,1.8);

	this.shape_295 = new cjs.Shape();
	this.shape_295.graphics.f("#D5FFFF").s().p("Ah7CqQgUAAgSgCIgGgBQgPgBgNgEQgOgEgQgHIgggLIgkgMIgBAAQgNgEgIgFQgFgDgBgEIgEgHIAAgBQABgJgHgGIAAgCQgVgFgagDQgWgBgYACQgOAAgYAFIgFABQgKAAgGgBQgHgBgCgFQgFgEAAgEIgCgHQgCgDABgEIAAgEQgygIgmgKQgcgHgagKQgQgHgKgHIgDgDQgMgLACgMIAAgBQACgJAIgEIALgGQAOgEAYAAIANAAQAPAAAJgDQAEgBABgBQAAgBAAAAQABAAAAAAQAAgBAAAAQgBAAAAAAIABgDIAAgBQgBgDAEgFQAEgGAIgGQAJgFALgDQAUgEAXADQAaAEATAAIAfgBQANgBAIgEQADgDADgEQACgFAEgCQAEgEAIgCQAAAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBIAAgBIAHgIQAJgHASgGQAbgJAlgFIAegCIAwgDIAngEIAGgBIAngGIABAAQAPgCAWgBIACAAQARgBALAEQAHADAEAEQAEAEABAEIABACIAKABIAOABQALAAAMgCQAlgFAkgGIAkgGIAbgCIAbgCIAPgBIALgBIATADIAdAAQBpABA/ANIACAAQAQAEAGAGQAGAGgDADIAAACQgBABAAAAQAAABAAAAQAAABAAAAQABABABAAIAAAEIABACQAnACA5AFQA8AFAtAIQAKACAHADQAFADAEAGIAGAIQAAABAAAAQABABAAABQAAAAAAABQAAAAAAABQAGAGgHAFIgCABQgCAEACAEQACADgBADIAAABIgBAHIgHAIQgDADgGADQgDABgCACIAAABIAAADQgBABgBAAQAAABAAAAQAAABAAAAQAAABABAAIAAADIgBABQAAABABAAQAAAAAAAAQAAABAAAAQAAAAAAAAQgFAFACAPQAAAKgKAKIgOAKIAAAKIAAACQgBADABADQAAAFgCAFQgCAGgGADQgFAEgKABQgcAGgfADQg6AHg7ADIgdACQgPACgNAEQgEADAFAEQACADgDAFIgBADIgLAOQgDADgCAGIgDADIgEADIgJAFQgIACgOABIgZACIghABIgFgBIgPgBIgRgDQgtgEgagBQgPgBgUACIgNACIglADIgNACIgzACIg0ACIgFAAIg5ACIgJgBg");
	this.shape_295.setTransform(4.5,1.9);

	this.shape_296 = new cjs.Shape();
	this.shape_296.graphics.f("#D5FFFF").s().p("Ah7CsQgUAAgTgCIgGgBQgPgBgNgEQgOgEgRgGIgggMIgkgMIgBAAQgNgEgIgFQgFgEgBgEIgDgHIgBgBQADgKgGgGIAAgCQgVgFgagDQgWgBgZACQgOABgYAFIgFABIgQAAQgHgCgCgFQgGgDgBgEIgCgHQgCgDAAgEIgBgEQgygIgngKQgdgIgZgKQgRgGgKgHIgDgDQgNgLACgMIAAgCQACgIAJgFQAEgDAHgDQAOgFAYAAIANAAQAPAAAJgCQAEgBABgCQABAAAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQAAgBAAAAQAAgBAAAAIAAgBQgBgDAEgGQADgFAIgGQAJgGALgDQAUgEAYADQAaAEATAAIAggBQANAAAHgFQAEgCACgFQADgEADgDQAEgEAJgCIAAgEIAAgBQACgDAFgFQAKgGASgHQAbgJAmgEIAdgDIAxgDIAngEIAHgBIAngGIABAAQAPgDAXgBIACAAQAQAAAMAEQAHACAEAFQAEADACAEIABACIAKABIAOACQALAAAMgCIBKgMIAkgGIAcgCIAbgCIAPgBIALAAIATACIAeABQBqABBAANIABAAQARADAGAGQAGAGgCADQAAAAAAABQAAAAAAAAQAAAAAAABQAAAAAAAAQAAABgBAAQAAABAAAAQAAABABAAQAAABABAAIABAEIABACQAnACA7AGQA8AFAtAIQALACAGADQAFADAEAHIAFAIQACADgBACQAFAGgIAFIgDABQgDAEACAEQABADgBADIAAABIgCAGIgHAJIgJAFIgFAEIAAABIAAADQgBABAAAAQAAABAAABQAAAAABABQAAAAABAAIACADIABABQAAAAAAABQABAAAAAAQAAAAAAABQAAAAAAAAQgEAFADAPQACALgKAKQgGAGgIAFQgBAFAAAEIAAACIgBAHQABAEgCAFQgCAGgHAEQgGADgJACQgcAFgfAEQg7AGg7AEIgfACQgPACgMAEQgEACAEAFQABADgDAEIgBADIgMAOQgDAEgCAGIgDADIgEAEQgEADgFABQgIADgNABIgaABIghABIgFgBIgPgBIgSgDQgtgFgagBQgQAAgUACIgNABIgmAEIgNABQgVACgfAAIgzACIgFAAIg6ACIgJAAg");
	this.shape_296.setTransform(4.4,1.9);

	this.shape_297 = new cjs.Shape();
	this.shape_297.graphics.f("#D5FFFF").s().p("Ah7CuQgVAAgTgCIgGgBQgPgBgNgEQgOgEgRgGIghgMIgkgMIgBAAQgOgFgHgEQgFgFgBgEIgCgHIgBgBQADgLgEgGIAAgCQgVgGgagCQgXgBgZACQgNABgZAGIgFAAIgRABQgGgBgDgFQgGgEgBgDIgDgHQgDgDgBgEIgBgEQgzgIgngKQgdgIgagKQgRgGgKgIIgDgDQgNgKACgNIAAgCQACgIAIgFQAFgEAGgCQAPgFAXAAIAOAAQAPAAAKgCQAEgCABgBQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBIAAAAQgBgEADgGQADgGAIgGQAJgGALgDQAUgEAZADQAaAFATAAIAggBQANgBAIgFQADgCADgEQACgFADgDQAFgEAIgCIABgEIAAgBQACgEAFgEQALgGARgHQAdgIAlgFIAegDIAxgEIAogDIAHgCIAngGIABAAQAPgCAXgBIADAAQAQgBAMAEQAHADAEAEIAHAHIABACIAKACIAOABQALABAMgCQAmgFAlgHIAlgGIAbgDIAcgBIAPgBIALgBIAUADIAdABQBtAAA/ANIACAAQAQADAHAGQAGAGgBADQgBAAAAABQAAAAAAAAQAAAAABABQAAAAAAAAQgBABAAAAQAAABAAAAQAAABABAAQABABABAAIAAAEIACACQAnACA8AGQA9AGAtAIQALACAGADQAGAEADAGIAFAJQABAAAAABQAAABAAAAQAAABAAAAQAAABgBABQAEAGgKAFIgDABQgEAEABAEQABADgBADIgBABIgCAGIgHAIIgJAGIgFAEIAAABIAAADQgCAEAFAAIAFADIABABQABAAAAABQAAAAABAAQAAAAAAABQAAAAAAAAQgCAFAEAQQACALgKAKQgFAGgIAFIgBAKIAAACIgCAGQABAEgDAGQgCAFgHAEQgGADgJACQgcAFggAEQg8AHg7AEIgfACQgPABgNAEQgEADADAFQABADgDAEIgCADIgMAOIgEAKIgDADIgEAEIgJAFQgIACgOABIgaACIgiAAIgFAAIgPgCIgSgDQgtgFgbgBQgPgBgUACIgOABIgmAEIgNABIg1ACIg0ACIgFAAIg7ADIgIAAg");
	this.shape_297.setTransform(4.4,2);

	this.shape_298 = new cjs.Shape();
	this.shape_298.graphics.f("#D5FFFF").s().p("Ah8CvQgVAAgTgBIgGgBQgPgBgNgEQgPgDgRgHIghgMIgkgMIgCgBQgOgEgHgFQgFgEAAgFIgCgHIgBgBQAEgLgDgHIABgBQgVgHgbgCQgXgBgZADQgNAAgaAGIgEABIgRABQgHgBgDgFQgGgDgCgEIgEgGQgDgDgCgEIgCgEQgzgJgngKQgegHgbgKQgQgGgLgIIgDgDQgNgLACgMIAAgCQACgJAIgFQAFgEAGgCQAPgFAYAAIAOAAQAPAAAJgDQAFgBAAgCQABAAAAgBQAAAAAAAAQAAAAAAgBQAAAAgBAAQAAAAgBgBQAAAAAAAAQgBgBAAgBQAAAAAAgBIgBAAQgBgEADgGQACgGAIgHQAJgGAMgDQAUgFAZAEQAaAFATAAIAhgBQAOAAAHgFQADgDADgEQACgFADgDQAEgEAJgCIABgEIABgBQACgEAFgEQALgGASgGQAcgJAmgFIAfgDIAxgEIAogEIAHgBIAogGIABAAQAPgDAXgBIADAAQARAAALAEQAIACAEAEIAHAHIABACIAKACQAIACAGAAQALAAANgCQAmgFAmgHIAlgGIAbgCIAcgCIAPgBIAMAAIATACIAfABQBuABA/AMIACAAQAQAEAHAFQAHAGgBADIAAACQAAABAAAAQAAABAAAAQAAABABAAQABABABAAQAAABAAAAQAAAAAAABQAAAAAAABQAAAAABABIABACQAoACA8AGQA+AGAuAJQALACAGADQAFAEAEAGIAEAJQACADgCACQADAHgMAFIgDABQgFADAAAFQAAACgBADIgBABIgCAHIgHAIQgEADgGADQgDACgCACIAAABQAAABAAAAQAAAAAAABQAAAAAAAAQABABAAAAQgCAEAGAAIAIADIACABQABAAAAABQABAAAAAAQAAAAAAABQAAAAAAAAQgBAFAGAQQADALgJALQgGAGgIAFIgCAKIAAACIgBAHQAAAEgDAFQgDAFgGAEQgGADgKACQgcAFggAFQg8AGg9AEIgfADQgPABgNAEQgFADADAFQABACgEAFIgBADIgNAOQgCAEgCAGIgDADIgEAEIgJAFQgIACgOABIgaACIgjAAIgFAAIgPgCIgSgDQgtgFgcgCQgPAAgVACIgNABIgnADIgNACIg1ACIg1ACIgFAAIg7ACIgJAAg");
	this.shape_298.setTransform(4.4,2);

	this.shape_299 = new cjs.Shape();
	this.shape_299.graphics.f("#D5FFFF").s().p("AilCwIgGgBQgQgBgNgEQgPgDgRgHIghgMIglgMIgCgBQgNgEgIgFQgEgFgBgEIgBgIIgBgBQAFgMgCgGIABgCQgVgHgbgCQgXgBgZADQgOABgZAGIgFABIgRABQgHgBgDgEQgHgDgCgEIgFgGQgEgDgCgEIgCgEQg0gJgogKQgegIgbgJQgRgHgKgHIgEgDQgNgLACgNIAAgCQACgJAIgFQAFgEAGgCQAPgGAYABIAOAAQAQgBAJgCQAEgCABgBQABgBAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBgBAAAAQgBgBAAAAIAAgBQgCgEACgGQADgHAIgGQAJgHAMgDQAUgFAZAEQAbAFATABIAhgBQAOAAAHgGQADgCACgFQADgFADgDQAEgEAJgCQAAgBAAAAQAAAAAAgBQABAAAAgBQAAgBABAAIAAgBIAIgHQALgHASgGQAdgJAmgFIAfgDIAygEIApgEIAHgCIAogGIAAAAQAQgCAYgBIACAAQARgBAMAEQAHACAFAFQAEADADAEIABACIAKABQAIACAHAAQALABANgCQAmgFAmgHIAlgGIAdgDIAcgBIAPgBIALgBIAUADIAfABQBvAABAANIACAAQARADAHAFQAGAGAAADQAAAAAAAAQAAABAAAAQAAAAAAAAQAAABABAAQgBABAAAAQAAABAAAAQABABAAAAQABABABAAIACAEIACACQAnACA+AHQA/AGAtAIQALADAGADQAGAEADAHIAFAJQABADgCACQACAHgOAFIgDAAQgHAEgBAFQABACgCADIgBABIgCAGIgIAJIgJAGIgFAEIAAABQAAABAAAAQAAAAAAABQAAAAAAAAQAAAAAAABQAAAEAHAAIAKADIADABQAAAAABABQABAAAAAAQABAAAAAAQAAABAAAAQAAAFAIARQADALgJAMQgFAGgIAFIgDAJIAAACIgCAHQAAAEgDAFQgDAFgHAEQgGADgJACQgdAGghAEQg8AHg9AEIgfADQgQABgNAEQgFADACAFQAAACgEAEIgBADIgNAOQgCAEgCAGIgDAEIgEAEQgEADgFACQgIADgOABIgbABIgiAAIgFAAIgQgCIgSgDQgtgGgdgBQgQgBgUACIgOABIgnAEIgNABIg2ACIg1ACIgFAAIg8ADIgJAAIgKAAIgegBg");
	this.shape_299.setTransform(4.4,2.1);

	this.shape_300 = new cjs.Shape();
	this.shape_300.graphics.f("#D5FFFF").s().p("Ah+CyQgVABgUgCIgGAAQgQgBgNgEQgPgDgSgHIghgMIglgNIgCAAQgOgFgHgFQgEgEgBgFIgBgIIAAgBQAGgMgBgHIABgCQgVgHgbgCQgYgCgZAEQgNABgaAHIgFAAIgRACQgIgBgDgEQgHgDgCgDIgGgGIgHgHIgDgEQg0gJgpgKQgegIgbgKQgSgGgKgIIgEgCQgNgLACgNIAAgDQABgJAIgFQAFgEAHgCQAOgGAZAAIAOAAQAQAAAKgDQAEgBABgCQAAAAAAgBQABAAgBAAQAAgBAAAAQAAAAgBAAQgDgBgCgDIAAgBQgDgDADgHQACgHAIgHQAJgHAMgDQAUgFAZAEQAcAGATAAIAhAAQAOgBAIgFQADgDACgFQACgFADgDQAEgEAKgDIACgDIAAgBQADgEAFgDQALgHATgGQAdgIAngGIAfgDIAzgEIAogFIAIgBIAogGIABAAQAPgDAYgBIADAAQARAAAMADQAHADAFAEIAHAHIACACIAKACIAOACQAMABANgCQAngFAmgIIAmgGIAcgCIAdgCIAPgBIAMAAIAUADIAeABQByAABAAMIABAAQARADAIAFQAHAGgBADQAAAAAAAAQAAAAABABQAAAAAAAAQAAABABAAQgBABAAAAQAAABABAAQAAABABAAQABABABAAIACAEIACACQAnADA/AGQBAAHAtAIQALADAHADQAFAEADAHIAFAKQABADgDACQABAHgPAEIgEABQgIAEgCAEQAAADgCADIAAABIgDAGIgIAIIgJAGQgEACgBADIAAABQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAAAABQAAAEAJAAIAMADIAEABIAEACQACAFAIARQAFAMgJAMQgFAGgJAFIgCAKIgBACIgCAGQgBAEgDAFQgDAGgHADQgGAEgKABQgcAGghAEQg9AHg+AFQgTABgNACQgPABgOAEQgFADACAEQgBADgEAEIgBADQgIAGgFAIIgEAKIgDAEIgEAEQgEADgGACQgHADgPABIgbABIgjABIgFgBIgPgCIgTgDQgtgGgdgCQgQAAgVACIgNABIgoADIgOABIg2ACIg1ADIgGAAIg8ADIgJgBg");
	this.shape_300.setTransform(4.4,2.1);

	this.shape_301 = new cjs.Shape();
	this.shape_301.graphics.f("#D5FFFF").s().p("Ah/C0IgpgBIgGAAQgQgBgOgEQgPgDgSgHIgigMIglgNIgBAAQgPgFgHgFQgEgFAAgFIgBgJIAAAAQAHgNABgHIABgCQgWgHgbgCQgYgCgZAEQgOABgaAHIgFABIgRACQgHgBgEgEQgHgCgDgDIgHgGQgFgDgDgEIgEgEQg0gJgqgKQgegIgcgKQgRgGgLgIIgEgDQgNgLACgNIAAgCQABgJAIgGQAFgEAHgDQAOgFAZAAIAPAAQAQAAAJgDQAFgCAAgBQABgBAAAAQAAgBAAAAQAAAAgBgBQAAAAgBAAQgDgBgCgDIgBAAQgDgEACgIQACgGAJgIQAIgHAMgDQAVgFAaAEQAbAGATAAIAiAAQAOAAAIgGQADgCACgFQACgGADgDQAEgEAKgDIACgDIAAgBQADgEAGgDQAMgHASgGQAegIAngGIAfgDIAzgFIAqgEIAHgCIApgGIAAAAQAPgCAZgBIADAAQARgBAMAEQAIACAFAEQAFADACAEIACACIAKACIAPADQALAAAOgCQAngFAngHIAmgHIAcgCIAdgCIAQgBIALAAIAVADIAfABQBzABBAALIABAAQARADAIAGQAHAFAAADQAAAAAAAAQAAAAABABQAAAAAAAAQABABAAAAQgBACAFACIACAEIACACQAoADA/AHQBBAGAuAJQALADAGADQAGAEADAIIAEAJQABADgDADQAAAHgSAEIgEABQgIAEgDAEQAAADgDADIAAABIgDAGIgJAIIgJAGQgEACgBADIAAABQAAAAAAABQAAAAAAAAQABABAAAAQAAAAAAABQABAEAJAAIAPADIAFABIAFACIANAXQAFAMgJAMQgFAGgIAGIgDAJIgBACIgDAHQgBAEgDAFQgDAFgHADQgGAEgKABQgdAGghAFQg+AHg+AFIggACQgQACgOAEQgFADABAEIgFAHIgCADQgIAGgFAIQgDAEgBAGIgDAEIgEAEQgEAEgFACQgIACgPABIgbACIgkAAIgEgBIgQgCIgTgDQgtgGgegCQgRgBgUACIgOABIgoAEIgOABIg2ACIg2ACIgGAAIg9ADIgJAAg");
	this.shape_301.setTransform(4.4,2.2);

	this.shape_302 = new cjs.Shape();
	this.shape_302.graphics.f("#D5FFFF").s().p("AEYC2IgFgBIgQgCIgTgDQgugHgegCQgRgBgUACIgOABIgpADIgOACIg3ACIg2ACIgGAAIg+ADIgJAAQgVABgVgCIgGAAQgQgBgNgDQgPgDgTgHIgigMIglgNIgCgBQgOgFgHgFQgFgFAAgFIAAgJIAAgBQAIgNACgHIACgDQgWgHgbgCQgZgBgZAEQgOABgaAIIgFABIgSABQgHAAgEgEQgIgCgDgDIgIgGIgJgHIgFgDQg0gKgqgKQgfgIgcgKQgSgGgLgHIgDgDQgNgMABgNIAAgCQABgKAIgFQAFgEAHgDQAOgGAaAAIAOAAQAQAAAKgDQAFgCAAgBQAAgBAAAAQAAgBAAAAQAAAAAAAAQgBgBAAAAQgEgBgDgDIAAgBQgEgEACgHQACgHAIgIQAJgHAMgDQAUgGAbAEQAcAHATAAIAiAAQAOAAAIgGQADgCACgGQACgGADgCQAEgFAKgDIACgDIABgBQADgDAGgEQAMgGASgGQAfgIAngGIAggEIAzgEIAqgFIAHgCIAqgGIAAAAQAPgCAagBIACAAQASgBAMAEQAIACAFAEQAFADACAEIACACIALACIAOADQAMABANgDQAogFAngHIAmgHIAdgCIAdgCIAQgBIAMAAIAUADIAgABQB0ABBBALIABAAQARADAIAFQAIAFAAADIACADQgBACAGACIACADIADADQAnACBBAIQBCAHAuAIQALADAGAEQAGAEADAHIADALQABADgDACQgCAHgTAFIgEAAQgKAEgDAEIgEAGIAAABIgEAGIgIAIIgKAGQgDACgCADIABABQAAABAAAAQAAABAAAAQAAAAAAABQAAAAABAAQABAEAKABIASACIAGABIAFACQAFAGALASQAGAMgJAMQgEAHgJAGIgEAJIAAACIgEAHQgBAEgDAEQgEAGgHADQgGADgKACIg/ALQg+AHg/AFIggADQgQACgOADQgGADABAEQgBADgFAEIgCADQgIAGgFAIQgDAEgBAHIgCAEIgEAEQgFADgFACQgIADgPABIgcABIgaABIgJAAg");
	this.shape_302.setTransform(4.4,2.3);

	this.shape_303 = new cjs.Shape();
	this.shape_303.graphics.f("#D5FFFF").s().p("AEaC3IgEAAIgQgCIgTgEQgugHgggCQgQAAgVABIgOACIgpADIgOABIg4ACIg3ADIgFAAIg/ADIgJAAQgWAAgUgBIgGAAQgRgBgNgEQgPgDgTgGIgjgMIglgOIgCAAQgPgFgGgGQgFgFABgGQgBgEABgFIAAAAIAMgVIACgDQgWgHgcgCQgYgBgaAEQgNABgbAIIgFABQgLACgHAAQgIAAgEgDQgHgCgEgDIgJgGQgFgDgFgEIgGgEQg1gJgqgLQgfgIgdgJQgSgGgLgIIgDgDQgOgMACgNIgBgCQACgJAIgHQAFgDAGgDQAPgHAaABIAPAAQAQgBAKgCQAEgCABgCQAAAAAAgBQAAAAAAgBQAAAAAAAAQgBAAgBAAQgFgCgCgDIgBgBQgEgEACgIQABgHAIgIQAJgIAMgDQAVgFAaAEQAdAHATABIAjAAQAOAAAHgHQAEgCABgGQACgFADgDQAEgGAKgCIADgEIABAAIAJgHQAMgGATgFQAfgJAogGIAggDIA0gGIAqgFIAHgBIAqgGIAAAAQAPgDAagBIADAAQASAAAMADQAIADAFADIAIAHIACACIALADIAOACQAMABAOgCQAogFAngIIAngGIAdgCIAdgDIAQgBIAMAAIAVAEQAMABAUAAQB2AABAALIACAAQARADAIAFQAIAFABADIACACQAAACAFACIADAEIADACQAoADBBAIQBDAHAuAJQALADAGAEQAGAEADAHIADALQABADgEADQgCAHgVAEIgFABQgKADgFAFIgEAGIgBABIgDAGIgJAHIgKAHQgDACgCADIABABQAAAAAAABQAAAAAAABQAAAAABAAQAAABAAAAQACAFALAAIAVACIAHABIAFACQAGAFANATQAHANgJANQgEAGgJAGIgEAJIgBADIgEAGIgFAIQgDAFgHAEQgHADgKACQgdAGgiAFQg/AIhAAEIggAEQgQACgOADQgHADAAAEIgGAHIgCACQgIAHgGAIIgDALIgDADIgEAFQgEADgGACQgIADgPABIgbABIgVABIgQgBg");
	this.shape_303.setTransform(4.5,2.4);

	this.shape_304 = new cjs.Shape();
	this.shape_304.graphics.f("#D5FFFF").s().p("AEdC5IgEAAIgQgCIgUgEQgugHgggCIgmAAIgOABIgpAEIgOABIg4ACIg4ACIgGAAIg/AEIgJAAIgqAAIgHgBQgRAAgNgEQgPgDgTgGIgjgNIgmgNIgCgBQgPgFgGgGQgFgFABgGQgBgEACgFIAAgBIAOgWIADgCQgXgHgcgCQgYgCgaAFQgOABgbAIIgFABIgSADQgIAAgEgDQgIgCgEgCIgKgGQgGgDgFgEIgHgEQg1gKgrgKQgfgIgdgKQgSgGgLgIIgEgDQgOgMACgNIgBgCQACgKAIgGQAEgEAHgDQAPgGAaAAIAPAAQARAAAJgDQAFgCAAgCQABgBAAAAQAAgBAAAAQAAAAgBAAQAAgBgBAAQgGgBgDgDIgBgBQgEgEABgIQACgIAIgIQAJgIAMgDQAUgGAbAFQAdAHATABIAjAAQAPAAAHgGQAEgDABgGQACgGADgCQAEgGAKgCIADgEIABgBIAKgGQAMgGAUgGQAfgIAogGIAggEIA1gGIAqgFIAHgBIAqgHIABAAQAPgCAagBIADAAQASAAANADQAHACAGAEIAIAHIACACIALACQAIADAHAAQALABAOgCQApgFAngIIAogGIAdgDIAegBIAQgBIAMgBQAIABANADQAMABAUAAQB4AABAALIACAAQARADAJAFQAIAFABADIADACQgBACAGACIADADIADADIBqALQBEAHAuAKQAMACAGAFQAFADADAJIADAKQABAEgEACQgEAHgWAFIgFABQgMADgFAFIgFAFIgBABIgEAGIgJAIIgJAGQgEADgBACIAAACQAAAAAAABQAAAAAAAAQABABAAAAQAAAAABABQACAEANAAIAXACIAHACQAFAAACACQAHAFAOATQAIANgIANQgFAHgJAGIgEAJIgBACIgFAHQgBAEgEAFQgEAEgHAEQgHADgJACQgeAGgiAFQhAAIhAAFIghADQgQACgOAEQgHACgBAFIgHAGIgCADQgJAGgFAIIgDALIgDAEIgEAEQgEAEgGACQgIADgPABIgcACIglgBg");
	this.shape_304.setTransform(4.5,2.4);

	this.shape_305 = new cjs.Shape();
	this.shape_305.graphics.f("#D5FFFF").s().p("AEhC7IgFAAIgQgDIgUgEQgugHghgCIgmAAIgOABIgqADIgOACIg5ACIg4ACIgGAAIg/AEIgKAAQgWABgVgBIgGgBQgRAAgNgDQgQgDgTgHIgjgMIgngOIgCAAQgOgGgHgGQgEgFABgGQgBgFACgEIAAgCIAQgWIADgCQgWgIgcgCQgZgBgaAEQgOACgcAJIgFABIgSACQgIABgEgDQgIgCgFgCIgLgFIgMgIIgHgEQg2gJgsgLQgfgIgdgKQgTgFgLgIIgEgDQgNgMABgOIgBgCQACgKAIgGQAEgFAHgDQAPgGAbAAIAPAAQAQAAAKgDQAFgCAAgCQAAgBAAAAQAAAAAAgBQAAAAgBAAQAAAAgBgBQgGgBgDgEIgCAAQgEgFABgIQABgIAIgIQAJgIAMgEQAVgGAbAGQAdAHAUABIAjAAQAPAAAHgGQAEgDABgGQACgGADgDQAEgGAKgCIAEgEIAAAAIALgHQAMgFAUgGQAfgIApgGIAggEIA2gGIAqgGIAIgBIAqgHIABAAQAOgCAcgBIACAAQASAAANADQAIACAGAEIAIAGIACACIALADQAIADAHAAQALACAQgDQAogFAogIIAngGIAegDIAegBIAQgBIAMgBQAJABAMADQANABAUAAQB5AABBALIACAAQARADAJAEQAIAFACADIADACQAAACAGACIAEAEIACACQApAEBDAIQBEAIAvAJQAMADAGAEQAFAEADAIIADAMQAAADgEADQgFAHgYAEIgGABQgMADgGAFIgGAFIgBABIgEAGIgJAIIgKAGQgEADgBADIAAABQAAABAAAAQAAABABAAQAAABAAAAQABAAAAAAQAEAFANAAIAaACIAIABQAFABACABQAJAGAPATQAJAOgIANQgFAHgJAGIgFAJIgBACIgEAHIgGAIQgEAFgHAEQgHADgKACQgeAGgjAFQhAAIhBAFIghAEQgQABgOAEQgIADgBAEIgIAGIgCADQgJAGgFAIQgCAEgBAHIgCAEIgEAFQgFAEgGACQgIADgPABIgcABIgWABIgPgBg");
	this.shape_305.setTransform(4.5,2.5);

	this.shape_306 = new cjs.Shape();
	this.shape_306.graphics.f("#D5FFFF").s().p("AEkC9IgFgBIgQgCIgUgEQgugIgigCQgRgBgVABIgPABIgqADIgOACIg5ACIg5ACIgGAAIhAAEIgJAAIgsAAIgGAAQgSAAgNgEQgQgCgTgHIgkgNIgmgNIgCgBQgPgFgHgHQgEgFABgGQAAgFACgFIABgBQAKgPAIgIIADgDQgXgIgcgCQgZgBgbAFQgNACgcAJIgFABIgTADQgHAAgFgCQgJgBgFgDIgLgFIgOgHIgIgEQg2gKgsgLQgggIgegJQgSgGgMgIIgEgDQgNgMABgOIgBgCQACgKAIgHQAEgEAHgEQAPgGAbABIAPAAQARgBAKgDQAFgCAAgCQAAgBAAAAQAAAAAAgBQgBAAAAAAQgBAAAAgBQgHgCgEgDIgBAAQgFgFABgJQABgIAIgIQAJgJAMgDQAVgGAcAFQAdAHATACIAkAAQAPAAAHgGQAEgDABgGQACgHACgCQAFgGAKgDIAEgDIABgBIAKgGQAOgGATgFQAggJApgGIAhgEIA1gGIArgGIAIgBIArgHIAAAAQAPgCAcgBIADAAQASAAANADQAIACAFAEQAGADADADIACACIALADQAJADAHAAQALACAQgDQAogFAogIIAogHIAegCIAegBIARgBIAMgBQAIABANADQANABAUAAQB7ABBBAKIACAAQARACAJAFQAJAFACADIADACQABACAGACIAEADIADADQAoADBEAJQBGAIAvAJQAMADAFAFQAGAEADAIIACAMQAAADgFADQgFAHgbAFIgFAAQgOAEgGAEIgHAGIgBABIgEAFIgKAIIgKAHQgEACgBADIABACQAAAAAAABQAAAAAAABQABAAAAAAQABABAAAAQAEAEAOAAIAdACIAJABQAGABACACQAKAFAQAUQAKAOgIANQgEAIgJAGIgGAJIgBACIgFAHQgCAEgFAEQgEAFgHADQgHADgJACQgeAHgkAFQhBAIhBAGIgiADQgQACgOADQgIADgCAEIgIAGIgDADQgJAGgFAIQgCAEgBAIIgCAEIgEAFQgFAEgFACQgJADgQABIgcABIgPABIgWgBg");
	this.shape_306.setTransform(4.5,2.6);

	this.shape_307 = new cjs.Shape();
	this.shape_307.graphics.f("#D5FFFF").s().p("AElC/IgEAAIgRgDIgUgEQgugIgigCQgSgBgVABIgOABIgrADIgPABIg5ACIg6ADIgFAAIhBAEIgKAAIgsAAIgGAAQgSAAgNgEQgQgCgTgHIglgNIgmgOIgCAAQgQgGgGgGQgEgGABgGQAAgFADgFIAAgBQAMgQAJgIIADgDQgXgIgcgCQgagBgaAFQgOACgcAJIgFACIgTADQgIABgFgDQgJgBgFgCIgNgFIgPgHIgIgEQg2gKgtgLQghgIgdgKQgTgFgMgIIgEgDQgNgNAAgNIAAgDQABgKAIgHQAFgEAHgEQAOgGAcAAIAPAAQARAAAKgDQAFgCAAgDQAAAAAAgBQAAAAAAAAQAAgBgBAAQgBAAAAAAQgIgCgEgEIgBAAQgGgFABgJQABgIAIgJQAJgJAMgDQAVgHAcAGQAeAIATABIAlABQAPgBAHgGQADgDACgGQABgHADgCQAEgGAKgDIAFgDIABgBIALgGQANgGAUgFQAggIAqgHIAggEIA3gGIArgGIAIgBIArgHIABAAQAOgDAcAAIADAAQASgBAOADIAOAGIAJAGIACACIALAEIAPADQAMABAQgCQAogFApgIIApgHIAegCIAegCIARgBIAMAAQAIAAAOAEQAMABAVAAQB9AABBAKIABAAQASADAJAEQAJAFACADIAEACQABACAHACIAEADIADADIBtAMQBHAIAvAKQAMADAGAFQAFAEADAJIACAMQAAADgFADQgHAHgcAEIgGABQgPADgHAFIgIAFIAAABIgFAGIgKAIIgKAGQgEADgBADIABABQAAABAAAAQAAABAAAAQABABAAAAQAAABABAAQAFAEAPAAIAfACIALABIAIACQALAGASAVQALAOgIANQgEAIgKAGIgFAKIgCACIgFAGIgHAIQgEAFgIADQgHAEgKABQgeAHgjAFQhCAIhCAGIgiAEQgQACgPADQgIADgCAEIgJAGIgDADQgKAFgEAJQgCAEgBAIIgCAEIgEAFQgFAEgGACQgIADgQABIgdABIgWAAIgQAAg");
	this.shape_307.setTransform(4.6,2.7);

	this.shape_308 = new cjs.Shape();
	this.shape_308.graphics.f("#D5FFFF").s().p("AEnDBIgEgBIgRgCIgUgFQgvgIgjgCQgSgBgVABIgOABIgsADIgOABIg6ACIg6ADIgGAAIhCAEIgJAAIgsAAIgHAAQgSAAgNgDQgQgDgUgGIgkgNIgogOIgBgBQgQgFgGgHQgEgGABgGQAAgGADgFIABgBQAMgQAKgIIAEgDQgXgIgdgCQgagCgaAGQgOACgcAKIgGABIgSADQgIABgFgCQgKAAgFgCIgOgFIgQgIIgJgEQg3gKgugLQgggIgegJQgTgGgMgIIgEgDQgOgMABgOIAAgDQABgKAIgHQAEgFAHgDQAPgHAcABIAPAAQASgBAKgDQAEgCABgDQAAAAAAgBQAAAAgBAAQAAgBgBAAQAAAAgBgBQgIgBgFgEIgBAAQgGgFAAgJQABgJAIgJQAJgJAMgEQAVgGAdAGQAeAIATABIAlABQAPAAAIgHQADgDABgGQABgHADgDQAEgGALgDIAFgDIAAgBIAMgFQAOgGAUgFQAhgIApgHIAhgEIA3gHIAsgGIAIgBIArgHIABAAQAOgDAdAAIADAAQASgBAOADQAIACAGAEQAGADADADIADACIALAEIAPADQAMACAQgDQApgFApgIIApgHIAfgCIAegCIARgBIAMAAQAJAAANAEQAMABAVAAQB/AABBAKIACAAQASACAJAFQAJAEADADIAEACQABACAHACIAEAEIAEACQAoAEBGAJQBIAJAvAJQAMAEAGAEQAFAEADAKIACAMQgBADgFADQgIAIgeAEIgGAAQgQAEgIAEIgIAGIgBABIgFAFIgKAIIgKAHQgEACgBADIABACQAAABAAAAQAAABAAAAQAAAAABABQAAAAABAAQAGAFAQAAIAiACIALABIAJACQANAGATAVQALAOgHAOQgEAIgKAGIgGAJIgBACIgHAHIgHAIQgEAFgIADQgHADgKACQgeAHgkAFQhCAIhDAHIgiADQgRACgPAEQgIACgDAEIgKAGIgCADQgKAFgFAJQgCAEgBAIIgCAEIgEAFQgEAFgGACQgIADgRABIgdABIgmAAg");
	this.shape_308.setTransform(4.8,2.8);

	this.shape_309 = new cjs.Shape();
	this.shape_309.graphics.f("#D5FFFF").s().p("AEoDDIgEgBIgRgDIgUgEQgvgIgkgDQgSgBgVABIgPABIgrACIgPACIg7ACIg6ADIgGAAIhCAEIgKAAIgtABIgGgBQgSAAgOgCQgQgDgUgHIglgMIgngOIgCgBQgQgGgGgHQgEgFACgIQAAgFADgFIABgBQANgQAMgKIAEgCQgYgIgcgCQgbgCgaAGQgOACgdAKIgFACIgTADQgIABgFgCQgKAAgGgCIgPgFIgRgHIgKgEQg3gKgugMQghgHgegKQgUgFgLgIIgFgDQgNgNAAgOIAAgDQABgKAIgIQAEgEAHgEQAPgHAcABIAQAAQARAAAKgEQAFgCAAgCQABgBAAgBQAAAAgBgBQAAAAgBAAQgBAAgBgBQgIgBgFgEIgCAAQgGgGAAgJQAAgJAJgJQAIgJANgEQAVgHAdAHQAeAHAUACIAlABQAQAAAHgHQADgDABgHQABgGADgDQAEgGALgDIAFgDIABgBIAMgFQAOgGAUgFQAhgIAqgHIAigEIA3gHIAsgHIAIgBIAsgHIABAAQAOgDAdAAIADAAQATgBANADQAJACAGAEIAJAGIADACIALADQAJADAHABQALACARgDQApgEAqgJIApgHIAfgCIAfgCIARgBIAMAAQAIAAAOAEQAMACAWgBQCAAABBAKIACAAQASADAKAEIAMAHIAEACQACACAHACIAFAEIADACQApAEBHAKQBIAIAvAKQANADAGAFQAFAEACAJIACANQAAAEgGACQgJAJggADIgGABQgRADgJAEIgJAGIgBABIgFAGIgLAIIgJAGQgFADAAADIAAABQAAABABABQAAAAAAABQABAAAAAAQABABAAAAQAGAEARAAIAlACIAMABIAKADQANAGAVAVQAMAOgHAPQgEAIgJAGIgHAKIgCACIgGAGIgIAIQgFAFgHADQgHADgKACQgfAGgkAGQhDAIhDAHIgjAEQgQACgQAEQgIACgEAEIgKAGIgDACQgKAFgFAJQgCAFAAAHIgDAFIgEAFQgEAEgGACQgIADgRACIgdABIgXAAIgQAAg");
	this.shape_309.setTransform(5,2.9);

	this.shape_310 = new cjs.Shape();
	this.shape_310.graphics.f("#D5FFFF").s().p("AEqDFIgFgBQgHAAgKgDIgUgEQgvgJgkgDQgSgBgWABIgPABIgsADIgPABIg7ACIg7ADIgGAAIhDAEIgJABIgtAAIgHAAQgSAAgOgCQgQgDgUgHIglgMIgogPIgCgBQgQgGgGgGQgEgHACgGQAAgGAEgFIABgCQAOgQANgKIAEgCQgYgJgdgCQgagBgbAGQgNACgeALIgFABIgTAEQgIABgGgCQgKAAgGgBIgQgFIgTgHIgKgEQg3gLgvgLQghgIgfgJQgUgGgLgIIgFgDQgOgMABgPIgBgDQABgLAIgGQAFgGAHgDQAPgHAcABIAQAAQASgBAKgDQAFgDAAgCQAAgBAAgBQAAAAAAAAQgBgBgBAAQAAAAgCAAQgJgCgFgEIgCAAQgGgGgBgJQAAgJAJgKQAIgJANgEQAVgHAeAGQAeAJAUABIAlABQAQAAAHgGQADgEABgGQABgIADgCQAEgHALgDIAGgDIABAAIAMgGIAjgKQAigIAqgHIAigFIA4gHIAsgGIAIgCIAsgHIABAAQAOgCAegBIADAAQATAAANADQAJACAGADQAGADAEADIADACIALAEIAQAEQALABARgCQApgFArgJIApgHIAfgCIAggCIARgBIAMAAQAJABANADQANACAVAAQCCAABCAJIABAAQASACALAFIANAGIAEADQACACAHACIAFADIAEADIBxANQBJAKAvAKQANADAGAFQAFAEACAKIACANQgBADgGADQgKAIghAEIgHABQgSADgKAEIgJAGIgBABIgGAFIgLAIIgJAHQgFACAAAEIAAABQAAABABAAQAAABAAAAQABABAAAAQABAAAAABQAHAFASAAIAnABIANABQAHABAEABQAPAGAWAWQANAPgHAPQgEAIgKAGIgHAKIgBACIgHAGIgJAIQgFAFgHADQgHADgKACQgfAHglAFQhDAJhEAHIgjAEQgRABgPAEQgJADgEADIgLAGIgDADQgLAFgEAJQgCAEgBAIIgCAFIgEAFQgFAEgGADQgIADgRABIgdABIgQAAIgXAAg");
	this.shape_310.setTransform(5.1,2.9);

	this.shape_311 = new cjs.Shape();
	this.shape_311.graphics.f("#D5FFFF").s().p("AEsDGIgFAAQgIgBgJgCIgVgFQgvgJgkgDQgTgBgWABIgPABIgsADIgPABIg7ACIg8ADIgGAAQgjABghADIgJABIguABIgHAAQgSAAgOgDQgQgCgVgHIglgNIgogPIgCAAQgQgGgGgHQgEgHACgHQABgGAEgFIAAgBQAQgSANgJIAFgDQgYgJgdgBQgbgCgbAGQgNADgeALIgFABIgTAFQgJABgGgCQgKABgHgCIgQgEIgUgIIgLgEQg3gKgwgMQgigIgfgJQgUgGgMgIIgEgDQgOgMAAgPIAAgDQABgLAHgHQAFgFAHgEQAPgHAdABIAQAAQASgBAKgDQAFgDAAgCQAAgBAAAAQAAgBAAAAQgBgBAAAAQgBAAgBAAQgKgCgGgEIgCgBQgHgFAAgKQgBgJAJgKQAIgKANgEQAVgHAeAHQAfAJAUABIAmABQAQAAAHgHQADgDABgHQABgHACgDQAEgGAMgDIAGgDIABgBIAMgFQAPgFAVgFQAigIAqgHIAigFIA5gIIAsgGIAJgCIAtgHQAOgCAfgBIADAAQASAAAOADQAJACAGADIALAGIACACIAMAEIAQAEQALACARgDQAqgFArgJIApgHIAggCIAfgCIASgBIAMAAQAJABAOADQAMACAWAAQCDAABCAJIACAAQASACAKAEIAOAHIAFACQACACAIACIAFAEIAEACIByAOQBKAKAvAKQANADAGAFQAFAFACAKIABANQAAAEgHADQgLAHgjAEIgHABQgTADgLAFIgKAFIgBABIgGAFIgLAIIgKAHQgEADgBADIABACQAAAAAAABQABAAAAABQAAAAABABQABAAAAAAQAIAFATAAIAqABIAOACQAHAAAEACQAQAGAXAWQAPAQgHAOQgEAJgKAGIgHAKIgCACIgIAGIgIAIQgFAEgIAEQgIADgJACQgfAGgmAGIiIAQIgkAEQgQACgQADQgJADgEAEIgNAFIgDADQgLAFgEAJIgCANIgCAEIgEAGQgFAEgGACQgIAEgRABIgeABIgQAAIgXgBg");
	this.shape_311.setTransform(5.3,3);

	this.shape_312 = new cjs.Shape();
	this.shape_312.graphics.f("#D5FFFF").s().p("AEtDIIgEAAIgSgDIgUgFQgvgJgmgDQgTgCgVABIgQABIgtACIgPACIg7ACIg9ADIgGAAQgjABghADIgKABIguABIgGAAQgTAAgOgCQgRgDgUgGIgmgNIgpgPIgBgBQgRgGgGgHQgEgHADgHQABgGAEgGIABgBQAQgSAPgJIAGgDQgZgJgdgCQgbgBgcAGQgNACgeAMIgGACIgTAEQgIACgGgCQgLABgHgCIgRgEIgWgHIgMgEIhogWQghgIgggKQgUgGgMgHIgEgEQgOgMAAgPIgBgDQABgLAIgHQAFgGAHgEQAPgHAdABIAQAAQASAAAKgEQAFgDAAgCQABgBgBAAQAAgBAAAAQgBgBAAAAQgBAAgBgBQgLgCgGgDIgCgBQgHgGgBgKQgBgJAJgLQAIgJANgEQAWgIAeAHQAfAJAUACIAmABQAQABAHgIQADgDABgHQABgHADgDQAEgHALgDIAGgDIABgBIANgFIAlgKQAigIArgHIAigFIA5gIIAtgGIAIgCIAugHIAAAAQAOgCAfgBIADAAQATAAAOADQAJABAGADIALAHIADACIALAEIARAEQALACARgDQAqgFAsgJIAqgHIAggCIAfgCIASgBIAMAAIAXAEQAMACAXAAQCFAABCAIIABAAQATADAKAEIAPAGIAFADIAKAEIAGADIAEACIBzAPQBLAKAwAKQANAEAFAFQAGAEACALIAAANQAAAEgHADQgNAIglAEIgHAAQgUADgLAFIgLAFIgBABIgHAFIgLAIIgKAHQgEADgBADIABACQAAADAEABQAIAFAUAAIAsABIAPABIAMACQASAGAYAXQAPAQgHAPQgDAIgKAHIgIAJIgCACIgIAHQgDAEgGAEQgFAEgIADQgIADgJACQggAHglAGQhFAJhFAHIgkAEQgRACgPAEQgKACgFAEIgNAGIgDACQgLAFgFAJQgBAFAAAIIgCAFIgEAFQgFAFgGACQgJADgRABIgeACIgQAAIgYgBg");
	this.shape_312.setTransform(5.4,3.1);

	this.shape_313 = new cjs.Shape();
	this.shape_313.graphics.f("#D5FFFF").s().p("AEvDKIgEAAQgIgBgKgCIgVgFQgvgKgmgDQgUgBgVABIgQAAIgtADIgPABIg8ACIg+ADIgGAAQgjACghADIgKAAIgvACIgGAAQgTAAgOgCQgRgCgVgHIgmgNIgpgQIgCAAQgQgGgGgIQgEgGADgIQABgGAFgGIABgBQARgSAQgKIAGgDQgZgJgdgCQgcgBgbAGQgOADgeAMIgGABIgTAFQgJACgGgBQgLABgHgCIgTgEIgWgHIgNgEQg3gLgygMQghgIgggJQgVgGgMgIIgEgDQgPgMAAgQIAAgDQABgLAHgHQAFgGAHgEQAPgHAeABIAQAAQASgBALgEQAFgCAAgDQAAgCgEgBQgMgCgGgEIgCgBQgIgGgBgKQgBgKAJgKQAIgKANgEQAWgIAeAHQAgAKAUACIAmABQARAAAHgHQADgDABgIQAAgHADgDQAEgHALgDIAHgDIABgBIAOgFIAkgJQAjgIArgHIAjgGIA6gIIAtgHIAIgBIAugHQAOgDAgAAIADAAQATgBAOADQAJACAHADIALAGIADACIALAEQAJADAIABQALACASgCQAqgFAsgJIAqgIIAggCIAggBIASgBIANgBIAWAFQANACAWAAQCHAABCAIIACAAQASACALAEIAPAGIAGADIALAEIAGADIAEACIB0AQQBMAKAwAKQANAEAFAFQAGAEACALIAAAOQgBAEgHADQgOAIgmADIgIABQgVADgMAFIgMAFIgBABIgHAFIgLAIIgKAHQgEADgBADIABACQAAADAEABQAIAFAWAAIAvABIAPABIANACQATAGAaAYQAQAQgHAPQgDAJgKAHQgEAFgFAEIgCACIgIAGIgKAIQgFAEgIADQgIADgJACQggAHgmAGIiLARIgkAEQgRACgQAEQgKACgFAEIgOAFIgDADQgMAFgEAJQgCAFAAAIIgCAFIgEAFQgFAFgGACQgIAEgSABIgeABIgRAAIgXgBg");
	this.shape_313.setTransform(5.6,3.2);

	this.shape_314 = new cjs.Shape();
	this.shape_314.graphics.f("#D5FFFF").s().p("AEwDMIgEgBQgIAAgKgDIgVgFQgwgJgmgEQgUgBgWABIgPAAIguADIgPABIg8ACIg/ADIgGAAQgjACgiADIgKAAIgvACIgGAAQgUABgNgDQgSgCgVgHIgmgNIgpgPIgCgBQgRgGgFgIQgFgHADgHQACgHAFgFIABgCQASgSARgKIAGgDQgZgKgdgCQgcgBgcAHQgNADgfAMIgFABIgUAGQgJABgGgBQgMACgHgBIgTgEIgYgIIgNgEQg4gLgygMIhCgRQgVgGgMgIIgFgDQgOgMgBgQIAAgDQABgLAHgIQAFgFAHgEQAPgIAeABIAQAAQATAAAKgFQAGgCgBgDQABgDgFAAQgMgCgGgEIgCgBQgJgGgBgLQgBgJAIgLQAJgLANgEQAWgIAeAIQAhAJATACQANACAaAAQARAAAHgHQADgEABgHQAAgIADgDQAEgHALgDIAIgDIABAAIAOgFIAlgKQAjgHAsgIIAjgFIA6gJIAtgHIAIgBIAvgHIAAAAQAOgDAgAAIADAAQAUgBAOADQAJACAHADQAGACAFAEIADACIAMAEIAQAFQAMACARgDQArgFAsgJIArgIIAggCIAhgCIARgBIANAAQAJABAOAEQANACAWAAQCJAABCAIIACAAQASACAMADIAPAHIAGACIAMAEIAGAEIAFACIB1AQQBMAKAwAKQANAEAGAFQAFAFACALQABAKgBAEQgBAEgHADQgPAIgoAEIgIAAQgWADgOAFIgMAFIgBABIgHAFIgMAIIgJAHQgFADAAAEIAAABQABADADABQAKAFAWAAIAyABIAQABIANACQAVAHAbAYQARAQgGAQQgEAIgKAHIgJAKIgCACIgJAGIgKAIIgOAHIgRAFQggAHgmAGIiMARIglAFIghAFQgKADgGADIgPAGIgDACQgMAFgEAJQgCAFAAAIIgCAFIgEAGQgEAFgHACQgIADgSABIgfACIgogBg");
	this.shape_314.setTransform(5.8,3.3);

	this.shape_315 = new cjs.Shape();
	this.shape_315.graphics.f("#D5FFFF").s().p("AEyDOIgFAAIgRgEIgWgFQgvgKgogDQgTgCgWABIgQABIguACIgQABIg8ACQgpACgWACIgGAAQgjABgjAEIgKAAIgwACIgGAAQgUABgNgDQgSgCgVgGQgSgGgVgIIgpgPIgCgBQgRgHgGgHQgEgHADgIQACgHAFgGIACgBQASgTATgKIAHgDQgagKgdgCQgcgBgcAHQgNADggAMIgFACIgUAGQgJACgHgBQgMABgIAAIgUgEQgLgDgOgFIgOgEQg4gLgygMQgjgIgggJQgVgGgNgIIgEgDQgPgNAAgQIAAgDQAAgLAIgIQAEgFAIgFQAPgHAeABIARAAQASgBALgEQAFgCAAgDQAAgDgFgBQgMgCgHgEIgCgBQgJgGgCgLQgBgKAIgLQAJgLANgEQAWgIAfAIQAhAKATACQANABAbABQARAAAGgIQADgDABgIQABgIACgDQAEgHAMgDIAHgDIACAAIAOgFIAmgJQAjgIAsgIIAjgFIA7gJIAugHIAIgCIAvgHQAOgCAhgBIADAAQATAAAPACIAQAFIALAGIADACIAMAEIARAFQAMACARgCQAsgFAsgKIArgHIAhgCIAggCIASgBIANAAQAJABAPAEQAMACAXAAQCKgBBDAIIABAAQATACALAEIARAGIAGACQADACAJACIAHADIAEADIB3AQQBNAKAwALQAOAEAFAFQAGAFABALQABALgBAEQgBAEgIADQgQAIgqAEIgIAAQgXADgOAFIgNAFIgBABIgIAFIgMAIIgKAHQgEADgBAEIABABQABADAEABQAKAFAXAAIA0ABIASABIANACQAWAHAdAYQASARgHAQQgDAJgKAHIgJAJIgDACIgJAHIgLAHQgFAEgIADIgSAFQggAHgnAHIiNARIglAEIghAGQgLACgHAEIgPAFIgDACQgNAFgEAKQgBAFAAAIIgCAFIgEAGQgFAFgGACQgIAEgTABIgeABIgRAAIgYgBg");
	this.shape_315.setTransform(5.9,3.3);

	this.shape_316 = new cjs.Shape();
	this.shape_316.graphics.f("#D5FFFF").s().p("AE0DQIgFgBQgIAAgKgDIgVgFQgwgKgogEQgUgCgWABIgQAAIgvADIgPABIg9ACIhAADIgGAAIhHAGIgKAAIgwACIgGAAQgUABgNgCQgSgCgVgHQgTgFgVgIIgqgQIgBgBQgSgGgFgIQgEgHADgIQACgHAGgGIABgCQAUgTAUgLIAHgDQgagKgegBQgcgCgcAIQgNADggANIgGACIgTAFQgJACgHAAQgNACgIgBQgIgBgNgDQgMgCgOgFIgPgFQg4gLg0gMIhDgRQgVgGgNgHIgEgEQgPgMAAgRIgBgDQABgLAHgIQAFgGAHgEQAPgIAfABIARAAQATAAAKgFQAFgCAAgDQAAgDgFgBQgNgCgHgEIgCgBQgKgGgBgLQgCgLAIgLQAJgLANgFQAWgIAgAIQAhALATACQANABAbABQARAAAHgIQADgDABgIQAAgIACgDQAEgIAMgDIAIgDIABAAIAPgFIAmgJQAkgHAtgIIAjgGIA7gJIAvgHIAIgCIAvgHIABAAQANgCAhgBIADAAQAUAAAPACQAJACAHADQAHACAFAEIADACIAMAEIARAFQAMACASgCQArgFAtgKIAsgHIAhgDIAggBIASgBIANAAQAJABAPAEQAMACAYAAQCMgBBCAIIACAAQATACALADIARAGIAHACIANAFIAHADIAEACIB4ARQBOALAwALQAOADAGAGQAFAFABALQABALgBAEQgBAEgIADQgSAJgrADIgJABQgYACgPAFIgOAFIgBABIgIAFIgMAIIgKAHQgEADgBAEIABACQABADAEABQALAFAYAAIA3ABIASABQAJAAAFACQAYAGAeAZQASARgGARQgDAIgKAIIgKAJIgCACIgKAGQgFAEgGAEQgGAEgIADQgIADgKACQggAHgoAGQhGAKhIAIIglAFQgSACgQADQgLADgHADIgQAGIgDABQgNAGgEAJQgCAFABAIIgCAGIgEAGQgFAFgHACQgIADgSABIgfACIgSAAIgXgBg");
	this.shape_316.setTransform(6.1,3.4);

	this.shape_317 = new cjs.Shape();
	this.shape_317.graphics.f("#D5FFFF").s().p("AE1DSIgEgBIgSgDIgWgGQgwgKgpgEQgUgCgWABIgQAAIgvADIgQABIg9ACIhAADIgHAAIhHAGIgKAAIgwADIgHAAQgUABgNgCQgSgCgWgHQgTgGgVgIIgqgQIgBAAQgSgHgFgIQgEgHADgJQADgHAFgGIACgBQAUgUAWgLIAHgDQgagKgegCQgcgBgdAIQgNADggANIgGACIgTAGQgKACgHAAQgNACgIgBQgIAAgOgDIgcgIIgPgEQg5gLg0gMQgigIgigKQgVgFgNgIIgEgEQgPgMgBgRIAAgEQABgLAHgIQAEgGAIgEQAPgIAfABIARAAQATAAAKgFQAGgCgBgDQABgDgGgBQgNgCgIgFIgCAAQgKgHgCgLQgCgLAJgLQAIgLANgFQAWgIAgAIQAiAKAUADQAMACAbAAQASAAAHgIQACgDABgIQAAgJADgDQAEgHAMgDIAIgDIABgBIAPgEIAngJIBRgPIAkgGIA8gJIAugIIAJgCIAwgHQANgCAigBIADAAQAUAAAPACQAJACAHADIAMAFIAEACIAMAFQAKAEAHABQAMADASgDQAsgFAtgJQAggHAMgBIAhgDIAhgBIATgBIANAAQAIABAPAEQANACAXAAQCOAABDAHIACAAQASACAMADIASAGIAHACQADACAKACIAHADIAFADIB5ARQBPALAxALQANAEAGAFQAFAGACALQAAALgBAEQgCAEgIAEQgSAIguADIgJABQgZADgQAEIgOAGIgBABIgIAEIgNAIIgKAHQgEAEgBADIABACQABADAEABQALAGAagBIA5ABIATABQAKABAGABQAYAHAfAZQAUASgGAQQgDAJgKAIQgFAFgGAEIgCACIgKAGIgMAIQgGAEgIADIgSAFQghAHgnAGQhIAKhIAJIgmAEQgRACgQAEQgMACgIAEIgQAFIgEACQgNAFgEAJQgBAFAAAJIgBAFIgEAGQgFAFgHADQgIADgTABIgfACIgqgBg");
	this.shape_317.setTransform(6.2,3.5);

	this.shape_318 = new cjs.Shape();
	this.shape_318.graphics.f("#D5FFFF").s().p("AE3DTIgEAAIgTgEIgWgFQgwgLgpgEQgVgCgWABIgQAAIgvADIgRABIg9ACIhBADIgGAAIhIAGIgKAAIgxADIgGAAQgVABgOgCQgSgCgVgGQgTgGgWgIIgqgQIgCgBQgRgHgFgIQgEgIADgIQADgHAGgGIACgCQAVgUAXgLIAHgEQgagKgegCQgdgBgdAIQgNADggAOIgGACIgUAGQgJADgHAAQgOACgJAAQgIgBgOgDQgNgCgQgFIgQgFIhugXIhEgRQgXgGgMgIIgFgEQgPgMAAgRIgBgEQABgLAHgIQAFgGAHgFQAPgIAgABIARAAQATAAALgFQAFgCAAgDQAAgDgGgBQgOgDgIgEIgCgBQgLgGgCgMQgCgLAJgMQAIgLANgFQAXgIAgAIQAiALAUADQAMACAcAAQARAAAHgIQADgDAAgIQABgJACgDQAEgIAMgDIAJgDIABAAIAQgEIAngJIBSgQIAkgGIA8gJIAvgIIAJgCIAwgHQANgCAjgBIADAAQAUgBAPADIARAEQAHADAFADIADACIANAFQAJAEAIABQAMADASgDQAsgFAugJQAggHAMgCIAigCIAhgBIATgBIANAAIAYAFQAMACAYAAQCPAABDAGIACAAQATACAMADIASAGIAIACIANAFIAIADIAFACIB6ASQBQALAxALQANAEAGAGQAFAFACAMQAAAMgBADQgCAFgJADQgTAJgwADIgJAAQgaADgRAFIgPAFIgBABIgIAEIgNAIIgKAIQgFADAAAEIABACQABACAEACQAMAFAbAAIA8ABIAUAAIAQADQAaAGAgAaQAUASgFARQgDAJgLAIQgEAFgGAEIgDACIgLAGIgMAIIgOAGQgIADgKACQghAIgoAGIiRATIgmAFIgiAFQgMACgIAEIgRAFIgEACQgOAFgDAJQgCAFABAJIgCAGIgEAGQgFAFgGADQgJADgTABIgfABIgqgBg");
	this.shape_318.setTransform(6.4,3.6);

	this.shape_319 = new cjs.Shape();
	this.shape_319.graphics.f("#D5FFFF").s().p("AE5DVIgFgBQgIAAgKgDIgWgGQgwgLgrgDQgUgDgXABIgQAAIgwADIgQABIg+ACIhCADIgGAAIhIAGIgLAAIgxADIgGAAQgVACgOgCQgSgCgWgHQgTgFgVgIIgrgRIgCAAQgSgIgFgIQgEgHAEgJQADgIAGgFIACgCQAWgVAYgMIAIgCQgagMgfgBQgdgBgcAIQgNAEghANIgGACIgUAHQgKADgHAAQgOACgJAAQgJAAgPgDIgegHIgQgFIhvgYIhFgRQgXgFgMgIIgFgEQgPgNgBgRIAAgEQABgLAHgIQAEgHAIgEQAPgJAgACIARAAQAUgBAKgFQAGgCgBgDQAAgEgGAAQgPgDgIgEIgCgBQgLgHgDgLQgCgMAJgMQAIgLANgFQAXgJAgAJQAjALAUADQAMACAcAAQASAAAHgHQACgFABgIQAAgIACgDQAEgJAMgCIAKgEIABAAIAQgDIAogJIBSgQIAlgGIA9gKIAvgIIAIgCIAxgHIAAAAQANgCAjgBIADAAQAVAAAPACQAKACAHADIAMAFIAEACIAMAFQAKAEAIACQAMACASgCQAtgGAugJQAhgHAMgCIAhgCIAigBIATgBIANAAIAYAFQANADAYAAQCRgBBDAGIACAAQASACANADIATAFIAHADIAPAEIAIAEIAFACIB7ASQBRALAxAMQAOADAFAGQAFAGACAMQAAAMgBADQgCAFgJADQgVAKgxACIgKABQgbACgRAFIgQAGIgCABIgIAEIgNAIIgKAHQgFAEAAAEIABABQABADAEACQANAFAbgBIA/ABIAVABIARADQAbAGAiAaQAVATgFAQQgEAKgKAHIgLAKIgDACIgLAGIgMAIIgPAGQgIADgKACQghAIgpAHIiSATIgmAEIgjAFQgMADgJAEIgRAEIgEACQgOAFgEAJQgBAFABAKIgCAFIgEAHQgFAFgHADQgIADgTABIggABIgqgBg");
	this.shape_319.setTransform(6.5,3.7);

	this.shape_320 = new cjs.Shape();
	this.shape_320.graphics.f("#D5FFFF").s().p("AE6DXIgFAAIgSgEIgXgGQgwgLgrgEQgUgCgXAAIgQABIgxACIgQABIg/ACQgrACgXACIgGAAIhJAFIgKABIgyADIgGAAQgWABgNgBQgTgCgWgHQgTgFgWgJIgqgQIgCgBQgTgHgEgJQgEgHAEgJQADgIAHgGIABgCQAXgVAagMIAIgDQgagLgfgBQgegBgdAIQgMADgiAPIgFACIgVAHQgJADgIAAQgOADgKAAQgJAAgPgDQgOgDgSgFIgRgEQg6gMg1gMIhHgRQgWgGgNgIIgEgEQgQgMgBgSIAAgEQABgLAHgJQAEgGAIgEQAPgJAgABIARAAQAUAAALgFQAGgDgBgDQAAgDgGgBQgQgCgIgFIgDgBQgLgHgDgMQgCgLAIgNQAIgLAOgFQAXgJAhAJQAiALAUADQANACAcAAQASABAHgIQACgEABgIQAAgJACgEQAEgIAMgDIAKgDIACAAIAQgEIAogIIBTgQIAlgGIA9gKIAwgJIAJgBIAxgIQANgCAjgBIAEAAQAUAAAQADIARADQAHADAGADIADACIANAFQAKAFAHABQAMACATgCQAtgFAvgKQAhgHAMgBIAhgCIAigCIATgBIAOAAIAYAFQANADAYAAQCTgBBDAGIACAAQASACANADIAUAFIAIADIAPAEIAIADIAGACIB7ATQBSAMAxAMQAPADAFAGQAFAGABAMQABAMgCAEQgCAFgKADQgVAJgzADIgKABQgcACgSAFQgKACgHADIgCABIgIAEIgNAIIgLAIQgEADgBAEIABACQACADAEABQANAGAdgBIBBABIAWABIARACQAdAHAjAbQAWASgFARQgDAKgLAIQgEAFgHAEIgDACIgLAHIgNAHIgQAGIgSAFQghAIgpAHIiTATIgnAFIgjAFIgWAGIgSAFIgEACQgOAEgEAKQgBAFABAKIgCAFIgEAHQgFAFgHADQgIADgTABIghABIgOAAQgTAAgJgBg");
	this.shape_320.setTransform(6.7,3.8);

	this.shape_321 = new cjs.Shape();
	this.shape_321.graphics.f("#D5FFFF").s().p("AE7DZIgEgBIgTgDIgWgGQgwgMgsgEQgVgCgXAAIgQABIgxACIgRABIg/ACQgsACgWACIgHAAQgjACgmAEIgLAAIgyADIgGABQgWABgNgCQgTgCgWgGQgUgGgWgIIgrgRIgBgBQgTgHgFgJQgDgIAEgJQADgHAHgHIACgBQAYgWAbgMIAIgDQgbgMgfgBQgdgBgdAJQgNADgiAPIgGACIgUAHQgKADgIABQgOADgKAAQgKAAgQgDIgggHIgSgFIhxgYIhGgRQgXgGgNgIIgFgDQgPgNgBgSIAAgEQAAgLAHgJQAFgGAHgFQAPgJAhACIARAAQAVgBAKgFQAGgDgBgDQAAgDgGgBQgQgDgJgEIgDgBQgMgHgDgMQgCgMAIgNQAIgMAOgFQAXgJAhAJQAjAMAUADQANACAcABQATAAAGgIQADgEAAgJQAAgJACgDQAEgIANgEIAKgCIABgBIARgDIApgIIBUgQIAlgHIA+gKIAwgJIAJgBIAxgIIAAAAQANgCAkgBIADAAQAVAAAQACIARAEIANAGIAEACIAMAFQALAFAHABQAMADATgDQAtgFAwgKQAhgHAMgBIAigCIAigCIATgBIAOAAIAYAGQANACAZAAQCUgBBDAGIACAAQATACANADIAUAFIAJACIAPAFIAJADIAGACIB8ATQBTAMAxAMQAPAEAFAGQAFAGABAMQABAMgCAEQgDAFgJADQgXAJg1ADIgKABQgdACgTAFIgSAFIgBABIgJAEIgOAIIgKAIQgFADAAAEIABACQACADAEACQAOAFAeAAIBEAAIAWABIASACQAeAHAlAcQAXASgFASQgDAKgLAIQgFAFgHAEIgDACIgMAGIgNAHIgQAHIgSAFQghAIgpAGIiVAUIgnAFIgjAFIgXAGIgTAFIgEACQgPAEgDAKQgCAFABAKIgBAGIgEAGQgFAGgHACQgIAEgUABIghABIgrgBg");
	this.shape_321.setTransform(6.9,3.9);

	this.shape_322 = new cjs.Shape();
	this.shape_322.graphics.f("#D5FFFF").s().p("AE9DbIgFgBQgIAAgLgDIgWgGQgxgMgsgFQgVgBgXAAIgQAAIgyACIgRABIg/ACIhDAEIgHAAIhKAGIgKABIgzADIgGABQgWABgOgCQgTgBgWgHQgUgFgWgJIgrgRIgCgBQgTgHgEgJQgEgIAFgJQADgIAHgHIACgBQAZgXAcgMIAJgDQgbgMgfgBQgegBgeAJQgMAEgjAPIgFACIgVAHQgKADgIABQgOAEgLAAQgKAAgQgCIgigIIgTgFIhxgYIhHgRQgYgGgMgIIgFgEQgQgMgBgSIAAgFQAAgLAHgJQAFgHAHgEQAPgJAhABIASAAQAUAAALgFQAGgDgBgEQAAgDgGgBQgRgCgKgFIgCgBQgNgHgDgNQgDgLAJgNQAIgNAOgFQAXgJAhAJQAjAMAVADQAMADAdAAQATABAGgJQADgEAAgIQAAgKACgDQAEgIANgEIAKgCIACgBIARgDIApgIIBVgQIAlgGIA/gLIAwgJIAJgCQAfgFATgCQANgCAkgBIAEAAQAUgBAQADIASAEQAHACAGADIAEACIANAGQAKAEAHACQANACATgCQAugFAvgKIAugJIAigCIAjgCIATgBIANAAQAJABAQAFQANADAZAAQCWgBBDAGIACAAQATABAOADIAUAFIAJACIAQAEIAJAEIAGACIB+ATQBTANAyAMQAOAEAGAGQAFAGABAMQAAANgCAEQgDAFgKADQgXAJg3ADIgLABQgeACgUAFIgSAFIgBABIgJAEIgOAIIgKAIQgFADAAAEIABACQABADAFACQAPAGAegBIBHAAIAXABIATACQAfAHAmAcQAYATgFASQgDAKgKAIQgGAFgHAEIgDACIgMAHIgOAHIgQAGIgTAFQghAIgqAHIiVAUIgoAFIgjAFIgYAGIgUAFIgEABQgPAFgDAKQgCAFABAKIgBAGIgEAGQgFAGgHADQgIADgUABIghABIgrgBg");
	this.shape_322.setTransform(7.1,3.9);

	this.shape_323 = new cjs.Shape();
	this.shape_323.graphics.f("#D5FFFF").s().p("AE+DdIgEgBIgTgEIgXgGQgxgMgtgEQgVgCgXAAIgQAAIgyACIgRABIhAACIhEAEIgGAAIhLAGIgLABIgzADIgGABQgWABgOgBQgTgCgXgGQgTgGgXgJIgrgRIgCAAQgTgIgEgJQgEgIAFgKQADgHAIgHIACgCQAZgXAegMIAJgEQgbgLgggCQgegBgdAKQgNADgjAQIgFACIgVAIQgKADgIABQgPAEgLAAQgLABgRgDIgigIIgUgEQg7gMg3gNIhIgRQgYgGgMgIIgFgDQgQgNgBgSIgBgFQABgLAHgKQAEgGAIgFQAPgJAhABIASAAQAVAAAKgFQAGgDgBgEQAAgDgGgBQgSgCgKgFIgCgBQgNgHgDgNQgEgMAJgOQAIgMAOgFQAXgKAiAKQAjAMAVADQAMADAeAAQASABAHgJQADgEAAgJQgBgJACgEQAEgIANgEIALgCIACAAIARgEIAqgHIBWgQIAlgHIA/gLIAxgJIAJgCQAfgFATgCIAAAAQANgCAlgBIADAAQAVgBAQADIASADIAOAGIAEACIANAGQAKAEAHACQANACATgCQAvgFAvgKQAigIAMgBIAjgCIAjgCIATgBIAOAAQAIABAQAFQANADAZAAQCYgBBEAFIACAAQATACAOACIAVAFIAJADIARAEIAJADIAGACQAqAIBVAMQBUANAyAMQAPAEAFAGQAFAGABANQAAANgCAEQgDAFgKAEQgZAJg5ACIgLABQgfACgUAFIgTAFIgCABIgJAEIgOAIIgKAIQgFADAAAFIABACQABADAFABQAPAGAggBIBJABIAZAAIATADQAhAHAnAcQAYAUgEASQgDAKgLAIQgFAFgIAEIgDACIgNAHIgOAGIgQAGIgTAFQghAJgqAHIiXAUIgoAGIgkAFIgZAFIgUAFIgEACQgQAEgDAKQgBAFABAKIgBAGIgEAHQgGAGgGACQgJAEgUABIghABIgsgBg");
	this.shape_323.setTransform(7.2,4);

	this.shape_324 = new cjs.Shape();
	this.shape_324.graphics.f("#D5FFFF").s().p("AFADfIgEgBQgJgBgLgDIgXgGQgwgNgugEQgWgCgXAAIgQAAIgzACIgRABIhAACIhEAEIgHAAIhMAGIgKABIgzAEIgHAAQgWACgOgCQgTgBgXgHQgUgFgWgJIgsgRIgCgBQgTgIgFgJQgDgIAFgKQADgIAIgHIADgCQAagXAfgMIAJgEQgbgMgggBQgegBgeAJQgNAEgjAQIgFADIgVAIIgTAEQgPAEgMABQgKAAgSgCIgkgIIgUgFIhzgZIhJgRQgYgGgMgHIgGgEQgPgNgCgSIAAgFQAAgMAHgJQAFgHAHgFQAQgJAhACIASAAQAVgBALgFQAGgDgBgEQAAgDgHgBQgSgDgLgEIgCgBQgNgIgEgNQgEgMAJgOQAIgNAOgFQAXgJAjAJQAjANAVADQAMADAeAAQATABAGgJQADgEAAgJQAAgKACgDQADgJAOgDIALgDIACAAIARgDIArgIIBWgPIAmgHIBAgMIAxgJIAJgCQAfgFATgCQANgCAmgBIADAAQAVgBAQADIASADQAIACAGAEIAFACIAMAFQALAFAHACQANADATgDQAvgFAwgKIAugJIAjgCIAkgCIATgBIAOAAQAJABAQAFQANADAZAAQCZgBBEAFIACAAQATACAPACIAWAFIAJACIARAEIAKAEIAGACQAqAHBWANQBVANAyAMQAPAEAFAHQAFAGABANQAAANgCAEQgDAFgLAEQgaAJg6ADIgLAAQghADgVAEQgLACgIADIgCABIgKAEIgOAJQgGADgEAEQgGAEABAEIABACQABADAFACQAQAGAhgBIBMAAIAZABIAUACQAiAHApAdQAZAUgEASQgDALgLAIQgFAFgIAEIgDACIgOAHIgPAGIgQAGIgTAFQgiAIgqAIIiYAVIgoAFIgkAFIgaAGIgVAEIgFACQgPAEgDAKQgCAGACAKIgCAGIgEAHQgFAFgHADQgIAEgVABIghABIgPAAQgUAAgJgBg");
	this.shape_324.setTransform(7.4,4.1);

	this.shape_325 = new cjs.Shape();
	this.shape_325.graphics.f("#D5FFFF").s().p("AFCDgIgEAAQgJgBgLgDIgXgHQgxgNgugEQgXgCgWAAIgRAAIgzACIgRABIhBACQguACgXACIgHAAQgkACgoAEIgKABIg0AEIgHABQgWABgOgBQgTgCgYgGQgUgGgWgIIgtgSIgBgBQgUgHgEgKQgEgJAGgJQADgIAJgIIACgBQAcgYAfgNIAKgDQgbgNgggBQgfgBgeAKQgNAEgjAQIgGADIgVAIQgKAEgJABQgPAFgMAAQgLABgSgDIglgIIgVgEIh1gaIhJgRQgYgFgNgIIgFgEQgQgNgBgSIgBgFQABgMAGgJQAFgHAIgFQAPgKAiACIASAAQAVgBALgFQAGgDgBgEQAAgDgHgBQgTgDgLgFIgCgBQgOgHgEgOQgEgMAJgOQAIgNAOgFQAXgKAjAKQAkANAVADQAMADAeAAQAUABAGgJQADgEAAgJQgBgKACgEQAEgIANgEIAMgCIABgBIATgDIArgHIBXgQIAmgHIBAgMIAxgJIAJgCQAggFATgCQANgCAmgBIAEAAQAVgBAQADIATADIAOAFIAEACIANAGQALAFAHACQANADAUgDQAvgFAwgKQAjgIAMgBQANgCAWAAIAjgCIAUgBIAOAAQAJABAQAFQANADAaAAQCbgBBEAFIACAAQATABAOADIAXAEIAKADIASAEIAKADIAGACICBAVQBWANAyANQAPAEAFAGQAGAHAAANQAAANgDAFQgDAFgLADQgbAKg8ACIgLABQgiACgWAFQgLACgJADIgCABIgKAEQgIADgGAFIgLAHQgFAEAAAEIACADQABADAFABQARAGAiAAIBOAAIAaAAIAVADQAjAHAqAdQAbAUgFATQgCALgLAIQgGAFgIAEIgDACIgOAGIgPAHIgRAGIgTAFQgiAIgrAHIiZAWIgpAFIgkAFIgaAGIgWAEIgFACQgQAEgDAKQgBAGABAKIgBAGIgEAHQgFAGgHADQgJAEgUABIgiABQghAAgLgCg");
	this.shape_325.setTransform(7.5,4.2);

	this.shape_326 = new cjs.Shape();
	this.shape_326.graphics.f("#D5FFFF").s().p("AFDDjIgEgBQgJgBgLgDIgXgHQgxgNgvgFQgXgCgXAAIgRAAIgzACIgRABIhCACIhFAEIgHAAQgkACgpAFIgKABIg1AEIgGAAQgXACgNgBQgUgBgXgHQgVgFgXgJIgsgSIgCgBQgUgIgEgJQgDgJAFgKQAEgIAJgIIACgCQAdgYAhgNIAKgDQgcgNgggBQgfgBgeAKQgNAEgjARIgGADIgVAIIgUAGQgQAEgMABQgLABgTgDQgRgCgVgGIgWgFIh1gZIhKgRQgYgGgNgHIgFgEQgQgNgCgTIgBgFQABgMAGgJQAFgHAIgFQAPgKAiACIATAAQAVgBALgFQAGgDgBgEQgBgEgHgBQgTgCgLgFIgDgBQgOgIgEgOQgEgNAIgOQAJgNAOgGQAXgJAjAKQAlANAUAEQANACAeABQAUABAGgKQADgEAAgJQgBgKACgEQADgJAOgDIAMgDIACAAIASgDIAsgHQAogGAwgKIAmgHIBBgMIAygJIAJgCIAzgIQANgCAmgBIAEAAQAVAAARACIASADQAJACAGAEIAEACIANAGQALAFAIABQAMADAUgCQAwgFAxgLQAjgHAMgCQANgBAWgBIAkgBIATgBIAOAAQAJABARAFQANADAaAAQCdgBBEAEIACAAIAiAEIAXAEIAKACIATAFIAKADIAGACICDAWQBXANAyANQAPAEAFAGQAFAHABANQgBAOgCAEQgDAFgMAEQgcAKg+ACIgMABQgiACgXAEQgMACgJADIgCABIgKAEQgIAEgHAEQgGAEgEAEQgFAEAAAEIABADQACADAFABQASAGAiAAIBRAAIAbAAIAVADQAlAHAsAeQAbAUgEATQgDALgLAIQgGAFgIAEIgDACIgPAHIgPAGIgRAGIgTAFQgjAIgrAIIiaAWIgpAFIglAFIgbAGIgXAEIgFABQgQAFgDAKQgBAGACAKIgCAGIgEAHQgFAGgHADQgJAEgUABIgiABIgPAAQgVAAgJgBg");
	this.shape_326.setTransform(7.7,4.3);

	this.shape_327 = new cjs.Shape();
	this.shape_327.graphics.f("#D5FFFF").s().p("AFFDkIgFgBQgIAAgLgEIgYgGQgxgOgwgFQgWgCgYAAIgRAAIgzACIgSABIhCACIhGAEIgGAAQgkACgqAFIgLABIg0AEIgHABQgXABgOAAQgTgCgYgGQgUgGgXgJIgtgSIgCgBQgUgIgEgJQgEgJAGgKQAEgJAJgHIADgCQAdgZAigNIALgEQgcgMgggBQgggBgeAKQgMAEgkARIgGADIgWAJIgTAGQgRAEgMABQgMABgTgCQgRgDgXgFIgWgFIh2gaIhLgRQgYgFgNgIIgGgEQgQgNgCgTIAAgFQAAgMAHgKQAEgHAIgFQAQgKAiACIATAAQAVgBALgFQAGgDgBgEQAAgEgIgBQgUgDgLgFIgDgBQgOgIgFgNQgEgOAJgOQAIgNAOgGQAXgKAkAKQAlAOAUAEQANACAfABQATABAHgKQACgEAAgJQgBgLACgDQAEgJANgEIANgCIACAAIATgDIAsgHIBYgQIAngHIBBgNIAygJIAJgCIA0gIQANgCAngBIADAAQAWAAARACIATADQAIACAGADIAFACIANAHQALAFAIABQAMAEAUgDQAxgFAxgLIAvgJIAkgCIAkgBIAUgBIAOgBQAJACAQAFQANADAbAAQCegBBEAEIACAAIAjADIAYAEIAKADIATAEIALADIAGACQArAJBZAOQBYANAyANQAPAEAFAHQAFAGABAOQgBAOgCAEQgEAGgLADQgeAKg/ACIgNABQgjACgYAFQgMACgJADIgCABIgLAEQgIADgHAFIgKAHQgGAEABAFIABACQACADAFACQASAGAkgBIBUAAIAcABIAWACQAmAHAsAfQAcAUgDAUQgDALgLAIQgGAFgJAEIgDACIgPAHIgQAGIgRAGIgTAFQgjAIgsAIIibAWIgqAGIglAFIgcAFIgXAEIgFACQgRAEgDAKQgBAGACAKQAAAEgBADIgEAHQgFAGgIADQgIAEgVABIgiABQgiAAgLgCg");
	this.shape_327.setTransform(7.9,4.4);

	this.shape_328 = new cjs.Shape();
	this.shape_328.graphics.f("#D5FFFF").s().p("AFGDnIgEgBQgJgBgLgEIgYgGQgxgOgwgFQgXgCgXgBIgRAAIg1ACIgRABIhDADIhGADIgHAAQgkADgqAFIgLAAIg1AFIgGABQgYABgOAAQgUgCgXgGQgVgGgXgJIgtgSIgCgBQgUgIgEgKQgEgJAGgKQAFgJAJgHIADgCQAegZAjgOIALgEQgcgMgggBQgggCgfALQgMAEglASIgFACIgWAKIgUAGQgRAFgNABQgMABgTgCQgSgDgXgFIgXgFIh3gaIhLgRQgZgGgNgIIgGgDQgQgNgCgUIAAgEQAAgNAGgKQAFgHAIgFQAPgKAjACIATAAQAVgBALgGQAHgDgCgEQAAgDgHgBQgVgDgMgFIgDgBQgPgIgFgPQgEgNAJgPQAIgNAOgGQAYgKAjAKQAmAOAUAEQANADAfABQAUAAAGgJQADgEgBgKQAAgKABgEQAEgJAOgEIANgCIACAAIATgDIAtgHQApgGAwgKIAngHIBCgNIAygKIAJgCQAigGATgCQAMgBAogBIADAAQAWgBARACIATADQAIACAHAEIAFACIANAGQALAFAHACQANADAVgDQAwgEAygLIAvgJIAkgDIAlgBIAUgBIAOAAQAJABARAGQANACAaAAQCggBBFAEIACAAIAjADIAYAEIALADIATAEIALADIAHACQArAJBaAOQBYAOAzANQAPAEAGAHQAFAGAAAPQgBAOgDAEQgDAFgMAEQgfAKhBACIgNABQgkACgZAEQgMACgKADIgCABIgLAEQgIAEgHAEIgKAIQgGAEABAFIABACQACADAFACQATAGAlgBIBWAAIAdABIAXACQAnAHAuAfQAdAVgEAUQgCALgLAJQgGAFgJAEIgEACIgPAGIgRAGIgRAGIgUAFQgiAIgsAIIidAXIgqAGIglAFIgdAFIgYAEIgFABQgRAFgDAKQgBAGACAKIgBAHIgEAHQgGAGgHADQgIAEgWABIgiABIgugBg");
	this.shape_328.setTransform(8,4.4);

	this.shape_329 = new cjs.Shape();
	this.shape_329.graphics.f("#D5FFFF").s().p("AFHDoIgEgBQgJgBgLgDIgYgHQgxgOgxgFQgXgCgYgBIgRAAIg1ACIgRABIhDADQgwABgXACIgHAAQgkADgrAFIgLABIg1AEIgHABQgYACgNgBQgUgBgYgHQgVgFgYgJIgtgSIgCgBQgUgJgEgKQgDgJAGgLQAEgIAKgIIADgCQAfgaAlgNIALgEQgdgNgggBQgggBgfALQgMAEglASIgGADIgWAJIgUAHQgRAFgOACQgMABgUgDQgSgCgYgGIgYgFIh4gaIhMgRQgZgFgNgIIgFgEQgRgNgCgUIAAgEQAAgNAGgKQAFgIAIgFQAPgKAjACIATAAQAWgBALgFQAGgEgBgEQAAgEgIgBQgVgCgMgGIgDgBQgQgIgFgOQgEgOAIgPQAIgOAPgGQAXgKAlALQAlAOAVAEQAMADAgABQAUABAGgKQADgFgBgJQAAgLABgEQAEgJAOgEIANgCIACAAIAUgCIAtgHQApgGAxgKIAogIIBBgNIAzgKIAKgCQAigGASgCQANgBAogBIADAAQAXgBARACIATADIAPAFIAFACIANAHQALAFAIACQANADAUgDQAxgEAygLQAkgIAMgCQANgBAYgBIAkgBIAUgBIAOAAQAJABASAGQAMACAbAAQCiAABFADIACAAIAjADIAZAEIALACIAUAFIAMADIAHACQAqAIBbAPQBaAOAzANQAPAEAFAHQAFAHABAPQgBAOgDAEQgEAGgMAEQggAJhDADIgNAAQglACgaAFQgNACgKADIgCABIgLADQgJAEgHAEIgKAIQgFAEAAAFIABACQACAEAGABQAUAHAlgBIBZgBIAeABIAXACQApAIAvAfQAeAWgDAUQgDALgLAIQgGAFgJAEIgEACIgQAHIgRAGIgSAFIgTAFQgjAJgsAIIieAXIgrAGIglAFIgeAFIgZAEIgFABQgRAFgDAKQgBAGACAKIgBAHIgEAIQgGAGgHADQgIAEgWABIgjABQgiAAgMgCg");
	this.shape_329.setTransform(8.2,4.5);

	this.shape_330 = new cjs.Shape();
	this.shape_330.graphics.f("#D5FFFF").s().p("AFJDqIgEgBQgJgBgLgDIgZgHQgxgOgygGQgXgCgXgBIgSAAIg1ACIgSABIhDACIhIAEIgHAAQgkADgrAFIgLABIg2AEIgGABQgZACgNAAQgVgBgYgHQgVgFgXgKIgugSIgCgBQgUgIgEgLQgEgJAHgLQAFgJAKgIIADgCQAfgaAmgNIAMgEQgdgOgggBQghgBgfAMQgMAEglASIgGADIgWAKQgLAEgKADQgRAGgOABQgNABgUgCQgTgDgZgFIgYgFIh5gaIhNgRQgZgGgNgIIgGgEQgQgNgCgUIgBgFQAAgNAHgKQAEgHAIgGQAQgKAjACIATAAQAWAAALgGQAHgEgCgEQAAgEgIgBQgWgDgMgFIgDgBQgQgIgGgPQgEgOAIgPQAIgOAPgGQAYgLAkALQAmAPAVAEQAMADAgABQAVABAGgKQACgFAAgJQgBgLABgEQAEgKAOgEIAOgCIACAAIAUgCIAugGQAqgHAxgJIAngIIBDgNIAzgLIAJgCQAjgGATgCQAMgBApgBIADAAQAWgBASACIATADQAJACAHADIAFACIANAHQALAFAIACQANAEAVgDQAxgFAygLQAlgIALgCQAOgBAXgBIAlgBIAUgBIAPAAQAJABARAGQANADAbAAQCjgBBFADIACAAIAkADIAaADIALADIAVAEIALADIAIACQAqAJBcAPQBbAOAzANQAQAFAFAHQAFAHAAAOQgBAPgEAFQgDAFgNAEQghAKhFACIgNAAQgmACgaAFQgOACgKADIgCABIgMAEQgJADgHAFQgGADgEAFQgGADABAFIABADQACADAGACQAUAGAngBIBcAAIAeAAIAYADQAqAHAxAgQAfAWgEAUQgCALgLAJQgGAFgKAEIgEACIgQAHIgSAGIgSAFIgTAFQgjAJgtAIIifAXIgrAGIgmAFIgfAFIgZAFIgFABQgSAEgDAKQgBAGADALIgBAHIgEAHQgGAHgHADQgJADgWABIgjABIgPAAQgWAAgJgBg");
	this.shape_330.setTransform(8.4,4.6);

	this.shape_331 = new cjs.Shape();
	this.shape_331.graphics.f("#D5FFFF").s().p("AFLDsQgLgCgOgEIgYgHQhJgVhKgCQgXAAgwACIhWADIhIAEQgsADg2AGIg3AFQgdADgPgBQgmgCg0gUIgwgUQgVgIgDgLQgEgJAHgLQAFgJAKgIQAnggAwgPQgdgNghgBQgggBgfALQgNAFglASQgzAageACQgZADg2gMIjggwQgggHgNgLQgSgOgBgYQAAgXATgNQAPgLAkACQAmACAPgIQAGgEgBgEQgBgEgIgBQgWgDgNgFQgTgIgGgRQgFgOAIgPQAIgPAPgGQAYgKAlALQAmAPAVAEQAMADAhABQAUABAGgKQADgFgBgKQgBgLACgEQAFgNAbgCQBDgGBdgTICfggQAqgIAVgCQAMgBAtgBQAzgBAYAKIATAJQALAFAIACQANAEAVgDQAxgFAzgLIAxgKQANgBAYgBIAlgBQAZgCAKABQAJABARAGQANADAcAAQCngBBFADQAmACAYAEIAtAKQAqAJBlARQBcAOAzAOQAQAEAFAHQAFAHAAAPQgBAPgEAFQgEAFgNAEQgiAKhGACQhHADgiAJQgaAHgOAOQgGAEABAFQABAFAIACQAVAHAogBIBegBQAmAAASADQAsAIAyAgQAfAWgDAVQgDATgfAMQg2AXhjARIkrAsQgXADgDAMQgBAGACALQAAAIgFAHQgFAGgIADQgIAEgWABIgkABQgjAAgLgBg");
	this.shape_331.setTransform(8.5,4.7);

	this.instance_26 = new lib.Tween3("synched",0);
	this.instance_26.parent = this;
	this.instance_26.setTransform(10.9,6.1);
	this.instance_26._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_275}]},1).to({state:[{t:this.shape_276}]},1).to({state:[{t:this.shape_277}]},1).to({state:[{t:this.shape_278}]},1).to({state:[{t:this.shape_279}]},1).to({state:[{t:this.shape_280}]},1).to({state:[{t:this.shape_281}]},1).to({state:[{t:this.shape_282}]},1).to({state:[{t:this.shape_283}]},1).to({state:[{t:this.shape_284}]},1).to({state:[{t:this.shape_285}]},1).to({state:[{t:this.shape_286}]},1).to({state:[{t:this.shape_287}]},1).to({state:[{t:this.shape_288}]},1).to({state:[{t:this.shape_289}]},1).to({state:[{t:this.shape_290}]},1).to({state:[{t:this.shape_291}]},1).to({state:[{t:this.shape_292}]},1).to({state:[{t:this.shape_293}]},1).to({state:[{t:this.shape_294}]},1).to({state:[{t:this.shape_295}]},1).to({state:[{t:this.shape_296}]},1).to({state:[{t:this.shape_297}]},1).to({state:[{t:this.shape_298}]},1).to({state:[{t:this.shape_299}]},1).to({state:[{t:this.shape_300}]},1).to({state:[{t:this.shape_301}]},1).to({state:[{t:this.shape_302}]},1).to({state:[{t:this.shape_303}]},1).to({state:[{t:this.shape_304}]},1).to({state:[{t:this.shape_305}]},1).to({state:[{t:this.shape_306}]},1).to({state:[{t:this.shape_307}]},1).to({state:[{t:this.shape_308}]},1).to({state:[{t:this.shape_309}]},1).to({state:[{t:this.shape_310}]},1).to({state:[{t:this.shape_311}]},1).to({state:[{t:this.shape_312}]},1).to({state:[{t:this.shape_313}]},1).to({state:[{t:this.shape_314}]},1).to({state:[{t:this.shape_315}]},1).to({state:[{t:this.shape_316}]},1).to({state:[{t:this.shape_317}]},1).to({state:[{t:this.shape_318}]},1).to({state:[{t:this.shape_319}]},1).to({state:[{t:this.shape_320}]},1).to({state:[{t:this.shape_321}]},1).to({state:[{t:this.shape_322}]},1).to({state:[{t:this.shape_323}]},1).to({state:[{t:this.shape_324}]},1).to({state:[{t:this.shape_325}]},1).to({state:[{t:this.shape_326}]},1).to({state:[{t:this.shape_327}]},1).to({state:[{t:this.shape_328}]},1).to({state:[{t:this.shape_329}]},1).to({state:[{t:this.shape_330}]},1).to({state:[{t:this.shape_331}]},1).to({state:[]},1).to({state:[{t:this.instance_26}]},41).to({state:[{t:this.instance_26}]},25).to({state:[{t:this.instance_26}]},35).to({state:[]},1).to({state:[{t:this.instance_26}]},397).to({state:[{t:this.instance_26}]},61).to({state:[]},1).wait(70));
	this.timeline.addTween(cjs.Tween.get(this.instance_26).wait(99).to({_off:false},0).to({y:-3.4},25).to({y:-16.7},35).to({_off:true},1).wait(397).to({_off:false,y:6.1},0).to({y:-16.7},61).to({_off:true},1).wait(70));

	// Layer_5
	this.shape_332 = new cjs.Shape();
	this.shape_332.graphics.f("#D5FFFF").s().p("AFLDsQgLgCgOgEIgYgHQhJgVhKgCQgXAAgwACIhWADIhIAEQgsADg2AGIg3AFQgdADgPgBQgmgCg0gUIgwgUQgVgIgDgLQgEgJAHgLQAFgJAKgIQAnggAwgPQgdgNghgBQgggBgfALQgNAFglASQgzAageACQgZADg2gMIjggwQgggHgNgLQgSgOgBgYQAAgXATgNQAPgLAkACQAmACAPgIQAGgEgBgEQgBgEgIgBQgWgDgNgFQgTgIgGgRQgFgOAIgPQAIgPAPgGQAYgKAlALQAmAPAVAEQAMADAhABQAUABAGgKQADgFgBgKQgBgLACgEQAFgNAbgCQBDgGBdgTICfggQAqgIAVgCQAMgBAtgBQAzgBAYAKIATAJQALAFAIACQANAEAVgDQAxgFAzgLIAxgKQANgBAYgBIAlgBQAZgCAKABQAJABARAGQANADAcAAQCngBBFADQAmACAYAEIAtAKQAqAJBlARQBcAOAzAOQAQAEAFAHQAFAHAAAPQgBAPgEAFQgEAFgNAEQgiAKhGACQhHADgiAJQgaAHgOAOQgGAEABAFQABAFAIACQAVAHAogBIBegBQAmAAASADQAsAIAyAgQAfAWgDAVQgDATgfAMQg2AXhjARIkrAsQgXADgDAMQgBAGACALQAAAIgFAHQgFAGgIADQgIAEgWABIgkABQgjAAgLgBg");
	this.shape_332.setTransform(8.5,4.7);

	this.shape_333 = new cjs.Shape();
	this.shape_333.graphics.f("rgba(213,255,255,0.992)").s().p("AFLDuQgKgBgOgEIgYgHQhJgVhKgBQgXgBgwACIgfABIg3ADIhIADQgrADg3AGIg2AEQgdADgPAAQgngCgzgUIgwgUQgVgIgDgKQgEgJAGgLQAFgJAKgIQAlgfAtgPQgdgNghgBQgggBgfALQgNAEglASIgRAIQgnARgZACQgZACg1gMQhxgYhugaQgfgHgNgLQgSgOgBgYQAAgWATgOQAPgLAkACQAkABAQgJQAGgDgBgEQgBgEgHgBQgWgDgMgGQgTgIgFgQQgFgOAJgPQAIgOAPgGQAYgLAkALQAnAOAUAEIAMABIAhACQAVABAGgKQACgEAAgKQgBgLACgEQAFgNAbgCQBEgGBcgTICegfQAqgIAVgCQANgCAsgBQAzgBAZAKIASAJQALAFAIACQANADAVgCQAxgFAzgLIAQgEIAhgFQANgCAYAAIAlgCQAZgCAKABQAJACARAFQANADAbAAQCngBBFAEQAmACAYAEIAtAJQAqAKBlAQQBaAPAzAOIABAAQAQAEAFAHQAFAHAAAPQgBAOgDAFQgDAFgNAEQggAKhEADQhEADggAKQgZAHgNANQgFAEAAAFQACAGAIACQAUAHAngBIAmABIA2ABQAkAAASAEQAqAIAvAgQAeAWgDAUQgEATgfAMQgqAShEAOIgqAIIkrAsQgXAEgDALQgBAGACALQAAAHgFAHQgGAHgHACQgJAEgWABIgjABIgQAAQgWAAgJgBg");
	this.shape_333.setTransform(8.4,4.7);

	this.shape_334 = new cjs.Shape();
	this.shape_334.graphics.f("rgba(213,255,255,0.984)").s().p("AFMDwQgKgBgOgEIgZgHQhIgUhKgBQgYgBgvACIgfABIg3ACIhHAEQgsACg2AGIg2AFQgdACgQAAQgmgCgzgUIgwgTQgUgIgEgKQgEgJAFgLQAFgIAJgIQAjgfArgOQgdgNgggBQghgBgfAKQgNAEglARIgRAIQgmAQgZACQgaACg0gMQhxgZhtgbQgegHgNgLQgSgPgBgXQAAgXATgOQAPgLAjABQAkABAPgIQAHgEgCgEQAAgEgHgBQgVgDgLgGQgSgIgFgQQgEgOAJgPQAIgOAPgGQAYgKAkAKQAmAOAVADIAMACIAhABQAUABAHgKQACgEAAgKQgBgKACgEQAGgNAagCQBEgHBcgSICegfQApgIAWgCQANgCAsgBQAygBAZAKIASAIQALAFAIACQANAEAVgDQAxgFAzgLIAQgDIAhgGIAkgBIAlgCQAZgCAKABQAJACASAFQANADAbAAQClgBBGAEQAmACAYAEIAtAKQArAJBjARQBaAOAzAOIABAAQAQAEAFAHQAFAHABAOQgBAPgDAEQgDAFgMAEQgeALhBACQhBAEgeAKQgZAIgMANQgFAEAAAFQACAFAIADQAVAHAmAAIAlACIA0ACQAjABARAEQAnAIAtAgQAdAWgEAUQgEATgeAMQgrARhEAOIgqAJIkqAsQgXADgDAMQgCAGACAKQAAAHgFAHQgFAGgIADQgJAEgVABIgkABQgiAAgMgBg");
	this.shape_334.setTransform(8.2,4.7);

	this.shape_335 = new cjs.Shape();
	this.shape_335.graphics.f("rgba(213,255,255,0.98)").s().p("AFNDyIgZgFIgYgHQhIgThKgBQgYgBgvACIgfABIg2ACIhIAEQgsACg1AFIg2AFQgdACgQAAQgmgCgzgUIgwgSQgUgIgFgKQgEgJAGgKQAEgJAJgHQAggeApgOQgdgNgggBQghgCgeAKQgOAEgkAQIgSAIQglAQgaABQgZABg0gLQhxgahrgbQgegIgNgLQgSgPAAgXQAAgXASgOQAPgLAiAAQAkAAAPgIQAHgEgCgEQAAgEgHgBQgUgDgLgGQgQgIgEgQQgEgNAJgPQAIgOAOgGQAYgKAlAJQAlANAWADIAMACIAhABQAUABAGgKQADgEAAgJQgBgLACgEQAGgMAbgCQBDgHBcgSQBngVA3gKQApgIAVgCQAOgCArgBQAygBAZAKIATAIQAKAFAIACQAOADAUgDQAxgEAzgLIAPgDIAhgGQAOgBAXAAIAlgCQAZgCAKABIAaAHQAOADAbAAQCjgBBHAEQAmACAZAEIAsAKQAsAKBiAQQBYAOA0AOIABAAQAQAEAFAHQAFAHABAOQAAAOgDAEQgDAGgLAEQgcAKg/ADQg+AEgcALQgXAIgMANQgFAEABAFQABAFAIACQAVAIAlABIAkACIAzAEQAiABAPAEQAmAKArAgQAbAVgEAUQgFASgeAMQgqAShEAOIgqAIQiUAXiWAWQgWADgEAMQgCAFACAKQAAAHgGAHQgFAGgHADQgJAEgWABIgjABIgPAAQgWAAgJgBg");
	this.shape_335.setTransform(8.1,4.7);

	this.shape_336 = new cjs.Shape();
	this.shape_336.graphics.f("rgba(213,255,255,0.973)").s().p("AFOD0IgZgFIgYgGQhIgThKgBQgYgBguACIggABIg2ACQgwACgYACQgrACg2AFIg2AEQgcADgQgBQgmgCgzgTIgwgSQgUgIgFgKQgEgIAFgKQAEgJAIgHQAegeAngNQgdgNgggCQgggBgfAJQgOAEgkAQIgRAHQgmAPgZABQgaABgzgMQhygahpgcQgegIgMgMQgRgPgBgXQAAgWASgOQAOgMAiAAQAkAAAPgJQAGgEgBgDQAAgEgHgBQgTgEgKgGQgPgIgEgQQgEgNAJgOQAJgOAOgGQAYgKAkAIQAmANAVADIANABIAgABQAUABAHgKQADgEAAgJQAAgKACgEQAGgNAagCQBEgHBbgSICdgeQApgIAWgCQAOgBAqgCQAygBAZAJIATAIQALAFAIACQANADAUgDQAxgEAzgKIAPgDIAhgGIAlgCIAlgBQAZgCAKABQAJACARAFQAOADAaAAQCjgBBIAEQAlACAZAEIAsAKQAsAKBiAQQBXAOA0AOIABAAQAQAFAFAGQAGAHAAAOQAAANgCAFQgDAFgLAEQgaALg7ADQg7AFgbALQgWAHgLAOQgFAEABAFQACAFAHACQAVAJAkABIAkADIAxAEQAgADAPAEQAkAKAoAgQAaAVgFAUQgFASgeAMQgqARhEAPIgqAIQiTAXiWAWQgWADgEALQgCAGACAKQgBAHgFAGQgGAGgHADQgJADgVABIgjACIgugBg");
	this.shape_336.setTransform(7.9,4.7);

	this.shape_337 = new cjs.Shape();
	this.shape_337.graphics.f("rgba(213,255,255,0.965)").s().p("AFOD1QgKAAgOgEIgYgGQhIgShKgCIhGACIggABIg2ACIhHAEQgsABg1AGIg2ADQgcADgQgBQgngCgygTIgwgRQgUgIgFgKQgEgIAFgKQADgHAHgIQAdgdAkgNQgdgNgggCQgggBgfAJQgOADgkAPIgRAHQglAOgZABQgbABgygMQhygbhogdQgdgJgMgLQgRgPgBgWQAAgXASgPQAOgLAigBQAiAAAQgKQAGgDgBgEQAAgEgGgBQgSgEgKgGQgPgIgDgPQgDgNAJgOQAJgOAOgGQAYgLAkAJQAlAMAWACIAMABQANABAUAAQAUABAGgKQADgDABgJQAAgLACgDQAGgNAagBQBEgIBbgSQBlgUA4gKQAogHAXgCQAOgCAqgBQAxgCAaAJIASAIQALAFAIACQANACAUgCQAygEAygLIAPgCQAXgFAKgBIAlgCIAlAAQAYgCALABQAJABARAFQAOACAaABQChgBBJAFQAlACAZAEIAsAJQAtALBgAQQBXAOA0AOIABAAQAQAEAFAHQAGAGABAOQAAANgCAEQgCAGgLADQgYAMg5ADQg4AGgZALQgUAHgLAOQgEAEAAAFQACAFAIACQAUAKAkABIAiAEIAvAFQAgAEANAEQAjAKAlAgQAZAWgFASQgGATgeAMQgqARhDAOIgqAIQiTAYiWAWQgWAEgEAKQgCAGABAJQgBAHgFAGQgFAGgIADQgJADgUABIgkACIgPAAQgVAAgKgCg");
	this.shape_337.setTransform(7.8,4.7);

	this.shape_338 = new cjs.Shape();
	this.shape_338.graphics.f("rgba(213,255,255,0.957)").s().p("AFPD4QgKgBgOgEIgYgFQhIgShJgBIhGABIggABIg2ACIhHADQgsACg1AFIg2AEQgcACgQgBQgmgCgzgSIgwgRQgTgIgFgJQgFgIAEgKQADgIAHgHQAbgcAigOQgdgMgggCQghgCgeAJQgOADgkAPIgRAGQglAOgZAAQgbABgygMQhygchmgeQgdgIgMgMQgQgPgBgXQAAgWARgOQAOgMAhgCQAigBAQgJQAGgEAAgDQAAgEgHgCQgRgEgIgGQgOgIgDgPQgDgNAJgOQAJgNAPgGQAYgKAjAIQAlALAWACIANABQAMABAUgBQATABAHgJQAEgEAAgJQAAgKADgDQAGgMAagDQBEgHBagSQBkgUA5gKQAogHAXgCQAOgCAqgBQAwgBAaAIIATAIQAKAEAJACQANADAUgDQAxgEAzgJIAPgDIAhgGIAkgBIAlgBQAYgCALABQAJABARAFQAOADAaAAQCgAABKAEQAkADAaAEIAsAJQAtAKBfAQQBXAOA0AOIABAAQAPAFAGAGQAGAHABANQAAANgCAEQgCAFgKAEQgVALg3AEQg1AGgXAMQgUAIgJAOQgFADABAFQACAFAHADQAVAJAjADIAhAEIAuAHQAeADAMAGQAhAKAjAgQAYAVgHATQgGASgdALQgrAShDAOIgpAJQiTAXiVAWQgWADgFALQgCAFABAKQgBAGgFAGQgFAGgIADQgJADgUABIgjACIgvgBg");
	this.shape_338.setTransform(7.6,4.6);

	this.shape_339 = new cjs.Shape();
	this.shape_339.graphics.f("rgba(213,255,255,0.949)").s().p("AFQD6QgLgBgNgEIgYgFQhIgRhJgBQgZgBgtACIggABIg2ACIhHADQgsACg0AEIg2AEQgcACgQAAQgngDgygRIgwgRQgTgIgFgJQgFgIAEgJQACgIAHgHQAYgbAggOQgdgMgggCQgggCgfAIQgPADgjAOIgQAGQglANgaAAQgaAAgygLQhygdhlgfQgcgIgMgNQgQgPgBgWQAAgWARgPQAOgMAhgCQAhgCAQgJQAGgEgBgDQABgEgGgBQgRgEgHgHQgOgIgCgPQgCgMAJgOQAJgNAPgGQAYgKAjAHQAkALAXABIAMABIAhAAQATABAHgJQADgEABgJQAAgJADgEQAHgMAZgCQBEgIBagRQBjgUA6gKQAogHAWgCQAPgCApgBQAwgBAaAIIATAHQALAFAIABQANADAUgDQAxgDAzgKIAPgDIAhgFIAkgBIAlgBQAYgCALABQAJABARAFQAOADAaAAQCeAABLAFQAkACAaAEIAsAJQAuAKBeAQQBVAOA1APIABAAQAPAEAGAGQAGAHABAMQABANgCAEQgCAGgJADQgUALgzAFQgyAGgWANQgSAIgJANQgEAEABAFQABAFAIADQAUAJAiAEIAhAEIArAJQAdAEAMAGQAfAKAhAgQAWAVgHATQgGARgeAMQgrARhCAPIgqAIQiSAYiVAWQgWADgFALQgCAFABAJQgBAGgGAGQgFAGgHACQgJAEgVABIgjABIgUAAIgaAAg");
	this.shape_339.setTransform(7.4,4.6);

	this.shape_340 = new cjs.Shape();
	this.shape_340.graphics.f("rgba(213,255,255,0.945)").s().p("AFRD7IgYgEIgYgFQhIgQhJgBQgZgBgtACIggABIg2ACIhGADQgsABg1AFIg1ADQgcACgQAAQgngDgygRIgwgRQgTgHgGgJQgEgIADgJQACgHAGgHQAWgbAegNQgdgMgggCQgggCgfAHQgPADgiANIgRAGQglAMgZAAQgbAAgxgMQhygdhjgfQgcgKgMgMQgQgPgBgWQAAgXARgOQAOgNAggCQAhgCAQgKQAGgDgBgEQABgEgGgBQgPgEgIgHQgMgIgCgOQgBgNAJgNQAJgNAOgGQAZgLAjAHQAkAKAWACIANAAIAgAAQATAAAIgIQADgEABgJQAAgJADgDQAHgMAZgCQBEgIBagRQBigUA6gKQAogHAXgCQAPgCAogBQAwgBAbAIIASAHQALAEAIACQANACAUgCQAxgEAzgJIAPgDQAWgEALgBQAOgBAWAAIAlgBQAYgCALABQAJABARAFQAOACAZABQCdAABMAFQAkACAaAEIAsAKQAuAJBdAQQBVAPA1AOIABAAQAPAEAGAGQAGAHACAMQABANgCAEQgBAFgJAEQgSALgxAFQguAHgUAMQgSAJgIANQgEAEABAFQACAFAHADQAVAKAgAEIAgAFIAqAKQAcAEALAGQAdALAeAhQAVAUgIASQgGASgdALQgrAShDAOIgqAJQiRAYiVAWQgVADgGAKQgCAFABAJQgCAGgFAGQgGAFgHADQgJADgUACIgjABIgUAAIgagBg");
	this.shape_340.setTransform(7.3,4.6);

	this.shape_341 = new cjs.Shape();
	this.shape_341.graphics.f("rgba(213,255,255,0.937)").s().p("AFSD9QgLgBgOgDIgYgFQhHgQhJAAQgZgBgtACIggABIg1ACIhHACIhgAGIg1ADQgcACgQAAQgngDgygRIgwgQQgTgHgGgJQgEgHACgJQACgHAGgHQAUgaAbgOQgdgLgggCQgggDgfAIQgPACgiANIgRAFQgkAMgagBQgbAAgwgMQhzgehhggQgcgKgLgMQgQgQgBgWQAAgWARgPQAOgMAfgDQAhgDAQgKQAGgDgBgEQABgEgGgBQgOgEgHgHQgLgIgCgOQgBgMAKgOQAJgMAOgGQAYgLAjAHQAkAJAXABIANAAIAgAAQATAAAHgIQAEgEABgIQAAgJADgEQAIgLAZgDQBEgIBYgRQBigTA7gKQAngHAXgCQAQgCAogBQAvgBAbAHIATAHQAKAEAIACQAOACATgCQAxgEAzgJIAOgCQAXgEAKgBQAPgBAWAAIAlgBQAXgCALABQAKABAQAFQAPACAZAAQCcABBMAFQAkACAaAFIAsAJQAvAJBcAQQBUAPA1AOIABAAQAPAEAGAHQAGAGACAMQABAMgBAEQgBAFgIAEQgQALguAGQgsAHgSANQgQAJgIANQgEAEABAFQACAFAHACQAVALAgAFIAfAGIAoALQAbAFAJAFQAcANAbAgQAUAUgIASQgHARgdAMQgrARhCAPIgqAIQiRAZiVAWQgVADgGAKQgCAFAAAIQgBAGgGAGQgFAFgHADQgKADgUABIgjACIgTAAIgagBg");
	this.shape_341.setTransform(7.1,4.6);

	this.shape_342 = new cjs.Shape();
	this.shape_342.graphics.f("rgba(213,255,255,0.929)").s().p("AFSEAIgYgEIgYgFQhIgPhJgBQgZAAgsACIggAAIg2ACIhGADQgsABg0AEIg1ADQgbACgRgBQgngCgxgRIgwgQQgTgHgGgIQgFgHACgJQABgHAGgHQARgZAZgNQgdgMgfgCQgggCgfAGQgPACgiAMIgRAGQgkALgagBQgbgBgwgMQhzgehfgiQgbgJgMgNQgPgPgBgXQAAgWAQgOQAOgNAfgEQAggDAQgKQAGgDAAgEQAAgEgFgBQgNgFgGgGQgLgIgBgPQgBgMAKgNQAJgMAPgGQAYgKAiAFQAkAJAXABIANAAIAgAAQATAAAIgJQADgEABgHQABgJADgDQAIgMAZgCQBDgJBZgRQBhgTA7gJQAngHAXgCIA4gDQAvgBAbAHIASAGQALAEAIACQANACAUgCQAxgEAygIIAPgDIAhgFIAkgBIAlgBQAXgBAMABQAJABARAEQAOADAZAAQCbAABNAGQAkACAaAEIAsAKQAvAJBbAQQBUAOA1APIABAAQAOAEAHAGQAGAGACAMIABAQQgBAFgIAEQgOALgrAGQgpAIgQANQgQAJgHAOQgDAEABAEQACAFAHADQAVALAfAFIAeAHIAmAMQAaAFAJAHQAZANAZAgQASATgIATQgIAQgcAMQgsARhCAPIgpAJQiQAZiVAVQgVADgGAKQgDAFAAAIQgBAGgGAGQgFAFgHACQgKADgUABIgiACIgcAAIgSAAg");
	this.shape_342.setTransform(7,4.6);

	this.shape_343 = new cjs.Shape();
	this.shape_343.graphics.f("rgba(213,255,255,0.922)").s().p("AFSEBQgKAAgOgDIgYgFQhHgOhJgBQgZAAgsABIggABIg1ACIhHACQgsACgzADIg1ADQgbACgRgBQgngCgxgQIgwgQQgTgHgGgIQgGgHADgJQAAgHAFgGQAQgZAWgNQgdgLgfgCQgggDgeAGQgQACgiALIgQAGQglAKgZgBQgcgCgvgLQhzgfhegjQgagKgMgNQgPgPAAgWQAAgWAPgPQAOgNAegEQAfgEARgKQAGgDgBgEQABgEgFgBQgMgFgFgGQgKgIAAgOQgBgMAKgNQAJgMAPgGQAYgLAiAGQAkAIAXAAIANAAIAgAAQASgBAIgIQAEgEABgHQABgJADgDQAIgLAZgCQBEgJBYgRQBggTA8gKQAmgGAYgCIA3gDQAvgBAbAHIATAGQAKAEAIABQAOACATgCQAxgEAygIIAPgCQAWgEALgBIAkgBIAlgBQAXgBALABQAKABAQAEQAPACAZABQCZAABOAGQAkADAaAEIAsAJQAvAKBbAPQBTAPA1AOIABAAQAOAEAHAGQAGAGADAMQABAMAAAEQgBAEgHAEQgMAMgpAGQglAIgPAOQgOAJgHAOQgDAEABAEQADAFAGADQAVALAeAGIAdAIIAlANQAYAFAIAIQAYANAWAgQARATgJASQgIARgcALQgsAShBAOIgqAJQiPAaiVAVQgVADgGAJQgDAFAAAIQgCAGgFAFQgGAFgHADQgKADgTABIgjACIgTAAIgbgBg");
	this.shape_343.setTransform(6.9,4.6);

	this.shape_344 = new cjs.Shape();
	this.shape_344.graphics.f("rgba(213,255,255,0.914)").s().p("AFTEDQgLAAgNgDIgYgFQhHgOhJAAQgZAAgrABIghABIg1ACIhGACQgsABg0AEIg1ACQgaACgRgBQgogCgwgQIgwgPQgTgHgGgIQgGgHACgIQAAgHAEgGQAOgYAUgNQgdgLgfgDQgggCgeAGQgQABgiALIgQAFQgkAJgagBQgbgCgvgMQhzgfhdgkQgagKgLgNQgPgPAAgWQAAgWAPgPQANgOAfgEQAegEARgLQAFgDAAgEQABgDgEgCQgMgFgEgHQgKgIABgNQAAgMAJgMQAKgMAPgGQAYgLAiAFQAjAHAXABIAOgBIAfgBQATAAAIgIQADgEACgHQABgIADgDQAJgLAYgDQBEgJBXgQQBggTA8gKQAngGAYgCIA3gDQAugBAbAGIATAGIASAFQAOACATgCQAxgDAygIIAPgDQAVgDAMgBIAkgBIAlgBQAXgBALABQAKABAQAEQAPACAZAAQCXABBPAGQAkADAaAEIAsAJQAwAKBZAPQBSAPA2AOIABAAQAOAFAHAGQAGAFADAMIACAPQgBAFgGADQgKAMgmAHQgjAJgNAOQgNAJgFAOQgDADABAFQACAFAHADQAUALAeAHIAcAIIAjAPQAXAFAHAJQAWAOAUAfQAPATgJASQgJARgcAKQgsAShBAPIgpAJQiPAaiVAVQgVADgGAJQgDAFAAAIQgDAFgFAFQgGAFgHACQgJAEgUABIgiABIgbABIgTgBg");
	this.shape_344.setTransform(6.7,4.6);

	this.shape_345 = new cjs.Shape();
	this.shape_345.graphics.f("rgba(213,255,255,0.91)").s().p("AFTEFIgYgDIgYgEQhGgOhJAAIhFABIggABIg1ABIhGADQgsABgzADIg1ADQgbABgRgBQgngCgxgQIgwgPQgSgGgHgIQgGgHACgHQAAgHADgGQAMgYASgMQgdgLgfgDQgggDgeAGQgRABghAKIgQAEQgkAJgZgBQgcgCgugMQh0gghbgkQgZgLgLgNQgPgQAAgWQAAgVAPgQQANgNAdgFQAegFARgLQAGgDAAgDQAAgEgEgCQgKgFgEgHQgIgIABgNQAAgMAKgMQAJgMAPgGQAYgKAiAEQAjAHAYAAIANAAIAggCQASAAAIgIQAEgDABgIQACgIADgDQAJgKAYgDQBEgJBXgRQBfgSA9gKQAlgGAZgCIA2gDQAugBAcAGIATAGQAKADAIABQAOADATgCQAxgEAxgIIAPgCIAhgEIAkgBIAlgBQAXgBALABQAKABAQAEQAPACAZAAQCWABBQAHQAjACAaAEIAsAJQAxAKBYAQQBSAOA1APIABAAQAPAEAHAGQAGAFADAMIACAOQAAAFgGAEQgIAMgjAHQggAJgLAPQgMAJgFAOQgDADABAFQADAFAGADQAVAMAcAHIAcAJIAhAPQAWAHAGAJQAUAOASAgQAOASgKASQgJAQgcALQgsAShBAPIgpAJQiOAaiVAVQgVADgHAJQgDAEAAAIQgDAFgFAFQgGAFgHACQgKADgTABIgiACIgbABIgTgBg");
	this.shape_345.setTransform(6.6,4.6);

	this.shape_346 = new cjs.Shape();
	this.shape_346.graphics.f("rgba(213,255,255,0.902)").s().p("AFUEHQgLAAgNgDIgYgEQhGgMhJgBIhEACIghAAIg1ACIhGACQgsABgzADIg1ACQgaACgRgBQgogDgwgPIgwgOQgSgGgHgIQgGgHABgHQAAgHADgFQAJgYAQgMQgdgLgfgDQgggCgeAEQgRABggAKIgRAEQgjAIgagCQgcgCgtgMQh0ghhZglQgagLgKgNQgPgQAAgVQAAgWAPgQQAMgOAegFQAdgFARgLQAFgDAAgEQABgDgDgCQgKgFgDgHQgIgIACgNQABgMAJgMQAKgLAPgGQAYgLAiAEQAiAGAYAAIAOgBIAfgBQASgBAJgHQADgEACgHQACgIADgDQAJgKAYgDQBEgJBXgQQBegSA9gKQAmgGAYgDIA3gCQAtgCAcAGIATAGQAKADAIABQAOACATgCQAxgDAxgIIAPgCQAVgDAMgBIAkgBIAlAAQAWgCAMABQAKABAQAEQAPACAYABQCVABBRAGQAjADAaAEIAsAJICJAZQBRAPA1AOIABAAQAPAFAHAFQAGAGADALIADAOQAAAFgFADQgGANghAHQgcAKgKAPQgLAJgEAOQgCAEABAEQACAFAHADQAUANAcAIIAaAJIAgAQQAVAIAFAJQASAPAPAfQANATgLARQgJAQgcALQgsAShBAPIgpAJQiNAaiVAVQgUADgIAJQgDAEgBAIQgCAFgGAFQgFAEgHACQgKADgTACIgjABIgaAAIgTAAg");
	this.shape_346.setTransform(6.5,4.5);

	this.shape_347 = new cjs.Shape();
	this.shape_347.graphics.f("rgba(213,255,255,0.894)").s().p("AFVEJQgLAAgNgDIgYgEQhGgMhJAAIhEACIghAAIg1ACIhFABIhfAEIg1ACQgaABgSAAQgngDgwgOIgwgPQgSgGgHgHQgGgHABgHQgBgGACgGQAHgWAOgNQgdgKgfgDQgggDgeAFQgRAAggAJIgQADQgkAIgZgCQgdgCgsgNQh1ghhXgmQgZgLgLgOQgNgQgBgVQAAgWAPgPQAMgPAdgFQAdgGARgLQAFgEAAgDQABgEgDgBQgJgFgCgIQgHgHACgNQABgMAKgMQAKgKAPgHQAYgKAhADQAjAGAYgBIANgBIAggBQASgBAIgIQAEgDACgHQACgHADgDQAKgLAXgCQBEgKBXgQQBdgSA+gKQAlgFAZgDQARgCAlgBQAtgBAdAGIASAFQAKAEAIABQAOACATgCQAxgEAxgHIAPgDIAhgDIAkgBIAlAAIAigBQAKABAQAEQAPACAYAAQCUACBSAGQAiADAbAEIArAJQAyAKBWAPQBRAOA2APIABAAQAOAEAHAGQAGAGAEAKIADAPQABAEgGADQgDANgeAIQgaAKgIAQQgJAJgEAOQgCADABAFQADAFAGADQAUANAbAIIAaAKQARAKANAIQATAIAEAJQAQARANAfQAMASgLARQgKAPgcALQgsAShAAPIgpAJQiNAbiVAVQgUADgIAIQgDAFgBAGQgDAFgFAFQgGAEgHADQgKADgSABIgjABIghABIgMAAg");
	this.shape_347.setTransform(6.3,4.6);

	this.shape_348 = new cjs.Shape();
	this.shape_348.graphics.f("rgba(213,255,255,0.886)").s().p("AE9EIIgYgDQhGgMhIAAIhEACIghAAIg1ABIhFACIhfAEIg1ACQgaABgRgBQgogDgvgOIgwgOQgSgGgIgHQgGgGAAgHQgBgGACgGQAFgWALgMQgdgKgfgDQgfgDgeAEQgRAAggAIIgQAEQgjAHgagDQgdgDgsgMQh1gihVgnQgZgLgKgOQgOgQAAgVQAAgWAOgPQAMgPAdgGQAcgGARgMQAFgDABgDQABgEgDgCQgIgFgCgHQgGgIADgNQABgLAKgLQALgMAOgGQAYgKAhADQAiAFAZgBIAOgBIAfgCQARgBAJgHQAEgEACgGQACgIAEgDQAKgJAXgDQBEgKBWgQQBcgSA/gJQAlgGAZgCQARgCAlgBQAtgCAcAGIATAFQAKADAIABQAOACATgCQAwgDAygHIAOgCQAVgDAMgBIAlgBIAkAAIAigBQALABAPAEQAPACAYAAQCSACBTAHQAjADAaAEIAsAIICHAaQBQAOA2APIABAAQAOAEAHAGQAHAFAEAKIADAOQABAEgEAEQgCANgbAIQgXALgGAPQgIAKgDAOQgCAEABAEQACAFAHADQAUANAaAKIAZALQARAKALAIQASAJADAKQAPAQAKAfQAKASgMARQgKAPgbALQgsAShAAPIgpAJQiNAbiUAVQgUADgIAIQgEAEgBAHQgDAFgGAFQgFAEgHACQgKADgSABIgjACIgtAAQgLAAgNgDg");
	this.shape_348.setTransform(6.2,4.5);

	this.shape_349 = new cjs.Shape();
	this.shape_349.graphics.f("rgba(213,255,255,0.878)").s().p("AFWENQgLAAgNgDIgYgDQhGgLhIAAIhEABIghABIg1ABIhFACIheADIg1ACQgaABgRgBQgogDgvgNIgwgOQgSgGgIgHQgGgGAAgHQgCgFACgGQADgVAIgMQgdgKgegDQgggEgeAEQgRAAggAIIgQADQgjAGgagDQgdgDgrgMQh1gjhUgoQgYgLgKgPQgNgPgBgVQAAgWAOgQQAMgOAcgIQAcgGARgMQAFgDABgDQABgEgDgBQgHgGgBgHQgFgIADgNQACgLAKgLQALgLAOgGQAYgKAhACQAiAEAZgBIANgBIAggCQARgBAJgHQAEgEACgGQADgHADgDQAKgKAXgDQBFgKBVgPQBbgSBAgJQAkgGAZgCIA3gDQAsgCAcAFIATAFQAKADAIABQAOACATgCQAwgDAygHIAOgCQAVgDAMAAIAkgBIAlAAIAigBQAKABAQAEQAPACAYAAQCRACBUAHQAiADAaAEIAsAJICHAZQBPAOA2APIABAAQAOAEAHAGQAHAFAEAKIAEANQABAFgEADQABANgZAJQgTALgFAQQgHAKgCAOQgCAEABAEQADAFAGADQAUAOAaAKIAXALQAQALALAJQARAJACALQANARAHAeQAJASgMARQgLAPgbAKQgsAShAAPIgpAKQiMAbiUAVQgUADgIAIQgEAEgBAGQgDAFgGAEQgGAEgGACQgLADgSACIgiABIghABIgMAAg");
	this.shape_349.setTransform(6.1,4.5);

	this.shape_350 = new cjs.Shape();
	this.shape_350.graphics.f("rgba(213,255,255,0.875)").s().p("AE+EMIgYgDQhGgKhIAAIhDABIghABIg1ABIhFACIheACIg1ACQgZABgSgBQgogDgvgNIgwgNQgRgGgJgHQgGgFAAgHQgCgGABgFQAAgVAHgLQgdgKgfgEQgfgDgeADQgSAAgfAHIgQADQgjAFgagDQgdgEgrgLQh1gkhSgoQgYgMgKgPQgNgQAAgVQAAgVANgQQAMgPAcgIQAbgHASgMQAEgDABgDQABgDgCgCQgHgGAAgHQgEgIAEgNQACgKAKgLQALgLAOgGQAZgKAgABQAiAEAZgCIAOgBIAfgCQARgBAJgHQAEgEACgGQADgHAEgCQAKgKAXgDQBEgKBVgQQBbgRBAgJQAkgGAZgCIA2gDQAsgCAdAFIATAFQAKADAIAAQAOACATgCQAwgDAxgGIAPgCQAUgDANAAIAkgBIAkAAIAigBQALABAPAEQAQACAXAAQCQACBUAHQAiADAbAEIArAJICHAZQBOAOA3APIABAAQAOAFAHAFQAHAFAEAKIAFANQABAEgDAEQACANgWAJQgQAMgDAQQgGAKgCAOQgBAEABAEQADAFAGADQAUAOAYALIAXAMQAQALAJAKQAQAKABALQALARAFAfQAIARgNARQgLAOgbALQgsAShAAPIgpAJQiLAciVAVQgTADgJAHQgDAEgCAHQgDAEgGAEQgGAEgGACQgLADgSABIgiACIgtABIgYgDg");
	this.shape_350.setTransform(6,4.5);

	this.shape_351 = new cjs.Shape();
	this.shape_351.graphics.f("rgba(213,255,255,0.867)").s().p("AE/EOIgYgDQhGgJhIAAIhDABIghABIg1ABIhFABIheADIg0ABQgZABgSgBQgogDgvgNIgwgMQgRgGgJgGQgGgGgBgHQgCgFAAgFQgBgUAEgMQgdgJgfgEQgfgDgeACQgSAAgfAGIgQADQgiAEgagDQgdgEgrgMQh1gkhRgpQgXgNgKgOQgMgQgBgVQAAgVANgQQAMgQAbgIQAbgHARgMQAFgDABgEQABgDgCgCQgFgGAAgHQgDgIAEgNQADgKAKgLQALgKAOgGQAZgKAgABQAhADAZgCIAOgCIAfgCQARgCAKgGQAEgEACgGQADgGAEgDQALgJAWgDQBFgLBUgPQBagRBAgJQAkgGAagCIA2gDQArgCAdAFIATAEIASAEQAOABATgCQAwgCAxgGIAPgCIAhgDIAkgBIAkAAIAigBQALABAPAEIAnACQCOACBWAIQAhACAbAFQAOACAdAGICHAZQBNAOA3AQIABAAQAOAEAHAFQAHAFAFAJIAFANQABAEgDAEQAFANgTAJQgOANgBARQgFAKgBAOQgBAEABAEQADAEAGAEQAUAOAYAMIAWANQAOALAJALQAPAKAAAMQAJASADAeQAGARgOAQQgLAPgbAKQgsAShAAPIgoAKQiLAciVAVQgTADgJAHQgEAEgCAGQgDAEgGAEQgFAEgHACQgLADgRABIgiACIgtABIgYgDg");
	this.shape_351.setTransform(5.8,4.5);

	this.shape_352 = new cjs.Shape();
	this.shape_352.graphics.f("rgba(213,255,255,0.859)").s().p("AE/ERIgYgDQhGgJhIAAIhDABIghABIg1ABIhEABIheACIg0ABQgZABgSgBQgogDgvgMIgvgNQgSgFgJgGQgGgGgCgGQgCgFAAgFQgEgTACgMQgdgJgegEQgggEgeACQgSAAgeAFIgQADQgiAEgagEQgegEgqgMQh1glhPgqQgXgNgKgPQgMgQgBgUQAAgVANgRQAMgPAagJQAagIASgMQAFgDABgDQABgEgCgCQgEgGABgHQgCgIAEgMQAEgKAKgLQALgKAOgGQAZgKAgAAQAhADAZgDIAOgBIAfgDQARgCAJgGQAFgDACgGQADgGAFgDQALgJAWgDICYgaQBZgRBBgJQAkgGAagCQASgCAjgBQArgBAeAEIATAEIASADQAOACASgCQAwgDAxgGIAPgBIAhgDIAkgBIAkAAQAVgBANABIAZAEIAnACQCNACBXAIQAiADAaAEIAsAIICFAZQBNAPA3APIABAAQAOAEAHAFQAIAFAEAJIAGANQACAEgDADQAHAOgQAJQgLANAAASQgDAKAAAOQgCAEACAEQADAEAFAEQAUAPAXAMIAVANQAOAMAIAMQANALgBAMQAIASAAAeQAFARgOAQQgMAPgaAKQgtASg/APIgpAKQiKAciUAVQgTADgKAHQgEADgCAGQgDAEgGAEQgGAEgGACQgLACgSACIgiACIgtABIgXgCg");
	this.shape_352.setTransform(5.8,4.5);

	this.shape_353 = new cjs.Shape();
	this.shape_353.graphics.f("rgba(213,255,255,0.851)").s().p("AE/ETIgYgDQhFgIhIAAIhDACIghAAIg2ABIhDABIheACIg0ABQgZABgSgBQgogDgugMIgwgNQgRgFgJgGQgHgFgCgGQgDgFgBgFQgFgSAAgMQgdgJgfgEQgfgEgeACQgTgBgeAFIgPACQgiAEgagEQgegFgpgMQh2gmhOgrQgWgMgKgQQgMgQAAgUQAAgVANgRQALgPAagKQAZgIATgNQAEgDABgDQACgDgCgCQgEgGADgIQgCgIAFgMQAEgKAKgKQALgKAPgGQAYgKAgAAQAgACAagDIAOgCIAfgDQARgBAJgHQAFgDADgFQADgGAEgDQAMgJAWgDICXgaQBYgRBCgJQAkgFAagCQATgCAigBQAqgCAfAEIASAEQAKACAIABQAOABASgBQAxgDAxgGIAOgBIAhgDIAkgBIAkAAQAVgBANABIAZAEQARACAWAAQCMADBXAIQAiADAbAEIArAIICFAZQBMAOA4AQIABAAQANAEAIAFQAHAFAFAJIAGALQADAFgCADQAIANgNALQgIANACASQgDAKABAOQgBAEACAEQACAFAGADQAUAQAWANIAUANQAOANAGAMQAMAMgCAMQAGATgCAeQAEARgPAQQgMAOgbAKQgtARg/AQIgoAKQiKAciUAVQgTADgJAHQgEADgDAGIgKAIQgFADgHACQgKACgSACIgiACIgtABIgXgCg");
	this.shape_353.setTransform(5.7,4.5);

	this.shape_354 = new cjs.Shape();
	this.shape_354.graphics.f("rgba(213,255,255,0.843)").s().p("AE+EVIgXgDQhGgHhIAAIhDACIghAAIg1ABIhDABIheACIgzAAQgZABgTgBQgogDgugMIgvgMQgSgFgJgFQgHgGgCgFQgEgFgBgFQgHgSgDgLQgdgJgegEQgfgEgeABQgTgBgeAEIgPACQgiADgagEQgegFgpgMQh2gnhMgsQgWgNgJgPQgMgQAAgVQAAgUAMgRQAMgQAZgKQAZgJASgMQAFgDAAgEQACgDgBgCQgDgGADgIQgBgIAGgMQAEgJALgKQALgKAOgGQAYgKAggBQAgABAagDIAOgCIAfgDQARgCAKgGQAEgDADgFQADgGAFgDQAMgIAVgDICXgbQBYgQBCgJQAjgFAbgCQATgCAigBQAqgCAeAEIATADIASADQAOABASgBQAwgDAxgFIAOgCIAhgCIAkgBIAlAAQAUgBAOABIAZAEIAnACQCKADBYAIQAiADAaAEQAPACAdAGICEAZQBMAOA3AQIABAAQANAEAIAFQAIAFAFAIIAHAMQACAEgBADQAKAOgKAKQgFAOAEATQgCAKACAOQgBAEABAEQADAEAGAEQAUAQAVAOIATAOQANANAGANQAKAMgCANQADATgEAeQACARgPAPQgNAOgaAKQgtASg/AQIgoAJQiJAdiUAVQgTADgKAGQgEADgDAGIgKAIQgFADgHABQgLADgRABIgiACIgsACIgYgCg");
	this.shape_354.setTransform(5.7,4.5);

	this.shape_355 = new cjs.Shape();
	this.shape_355.graphics.f("rgba(213,255,255,0.839)").s().p("AE8EXIgYgCQhFgHhIAAIhCACIgiAAIg0ABIhEABIhdABIg0AAQgYABgTgBQgogDgugMIgvgLQgSgFgJgFQgHgFgDgGQgEgFgBgEQgKgRgFgLQgdgJgegEQgfgEgeAAQgTgBgeADIgPACQgiACgagEQgegGgogMQh3gnhKgsQgVgOgJgPQgMgRAAgUQAAgVAMgQQALgRAZgKQAYgJATgNQAEgDABgDQACgEgBgCQgCgGAEgIQAAgIAGgMQAEgJALgKQALgJAPgGQAYgKAfgCQAhABAagDIAOgCIAfgEQAQgCAKgGQAFgDADgFQADgFAFgDQAMgIAWgDICWgbQBXgQBDgJIA9gHQAUgCAhgBQAqgCAfAEIASADIASACQAOACASgCQAwgCAxgFIAOgCIAhgCQAQgBAUAAIAlAAQAUgBANABIAZAEIAnACQCJADBZAIQAiADAbAEIArAIICEAZQBLAOA3AQIABAAQANAEAJAFQAHAFAFAIQAEAIAEADQADAEgBAEQAMANgIALQgBAPAFASQAAALACAOQgBAEACAEQADAEAFAEQAUAQAUAPIATAPQAMANAEAOQAKANgEANQACAUgHAeQABAQgQAPQgNAOgaAKQgtARg+AQIgpAKQiIAdiUAVQgTADgKAGQgEADgDAFIgKAIQgGADgGABQgLADgRABIgiACIgtACIgXgCg");
	this.shape_355.setTransform(5.8,4.5);

	this.shape_356 = new cjs.Shape();
	this.shape_356.graphics.f("rgba(213,255,255,0.831)").s().p("AE5EZIgXgCQhFgGhIAAIhCABIghABIg0ABIhFAAIhcABIg0AAQgYABgTgBQgpgDgtgLIgvgLQgRgFgKgFQgHgFgDgFQgFgFgCgEIgTgcQgdgIgegEQgfgFgeAAQgTgBgdADIgQABQghABgagEQgfgGgngMQh3gohIgtQgVgOgJgQQgLgQgBgUQAAgVAMgRQALgQAYgLQAYgKATgNQAEgDABgDQACgEgBgBQgBgHAFgIQAAgIAHgLQAFgKALgJQALgJAPgGQAYgLAfgBQAgAAAbgEIAOgCIAfgEQAQgCAKgGQAEgDAEgFQAEgFAEgCQANgJAVgDICWgaQBWgQBEgJQAigFAbgCIA1gDQApgCAfADIATADIARADQAPABARgCQAwgCAxgFIAOgBIAhgDIAkAAIAkAAQAUgBAOABIAZAEIAnACQCIADBaAJQAhACAbAFIArAIICEAYQBKAPA3AQIABAAQANADAJAFQAHAFAGAIQAEAHAEAEQADAEgBADQAPAOgFALQABAPAHATQABALADAOQgBAEACAEQADAEAFAEIAoAgIARAPQALAPAEAOQAJANgFAOQAAAUgKAeQAAAQgQAPQgOANgaAKQgtASg+AQIgoAKQiIAdiUAVQgSACgLAGQgEADgEAFQgEAEgGADQgFADgHACQgLACgRACIghACIgtABIgYgBg");
	this.shape_356.setTransform(6,4.5);

	this.shape_357 = new cjs.Shape();
	this.shape_357.graphics.f("rgba(213,255,255,0.824)").s().p("AE3EbIgYgCQhEgFhIAAIhCABIgiABIg0AAIhEABIhcABIg0AAIgrgBQgogDgtgLIgwgKQgRgFgKgFQgHgFgDgFQgFgEgDgEIgXgbQgdgJgegEQgfgEgeAAQgUgDgcADIgQABQghABgagFQgfgGgmgMQh4gphGguQgVgOgJgQQgLgRAAgUQAAgUAMgRQAKgRAYgLQAXgLATgNQAEgDACgDQACgDgBgCQAAgHAFgIQACgIAHgLQAFgJALgJQAMgKAOgGQAZgKAegCQAggBAbgEIAOgCIAfgEQAQgCAKgGQAFgDADgEQAEgFAFgDQANgIAVgDICWgbQBUgPBFgJQAigFAbgCIA1gDQAogCAgADIASADQAKACAIAAQAOABASgBQAwgDAxgEIAOgBIAhgDIAjAAIAlAAIAhAAIAZADIAnADQCGADBbAJQAhADAbAEIArAIICEAZQBJAOA4AQIABAAQANAEAIAFQAIAEAGAIQAEAHAEADQAEAEAAADQAQAOgCAMQAEAQAJATIAFAZIACAHQADAFAFAEIAnAhIAQAQQALAPADAPQAHAOgGAOQgCAVgMAdQgBAQgRAPQgOANgaAKQgtARg+AQIgoAKQiIAeiTAVQgSACgLAGQgFADgDAFIgLAGQgGADgGACQgLACgQABIgiADIgtABIgXgBg");
	this.shape_357.setTransform(6.2,4.5);

	this.shape_358 = new cjs.Shape();
	this.shape_358.graphics.f("rgba(213,255,255,0.816)").s().p("AE0EdIgXgCQhFgFhHABIhCABIgiABIgzAAIhEABIhdAAIgzAAIgrgBQgpgDgsgKIgwgLQgRgEgKgFQgHgEgEgFIgIgIIgcgaQgdgJgegEQgfgFgeAAQgUgDgcACIgPABQghAAgbgFQgegHgngMQh3gphFgvQgUgOgJgRQgKgQgBgUQAAgUALgRQALgRAXgMQAXgLATgOQAEgDACgDQACgDgBgCQABgHAGgIQACgIAIgLQAGgJALgJQAMgJAOgGQAYgKAfgDQAfgBAbgEIAPgDIAegEQAQgCAKgGQAFgDAEgEQAEgFAFgCQANgIAVgDICVgbQBUgPBFgJQAigFAbgCIA1gDQAogCAgADIATACIARACQAPABARgBQAwgCAxgEIANgCIAhgCIAkAAIAlAAIAhAAIAZADIAnACQCFAEBcAJQAgADAcAEIAqAIICDAZQBJAOA4AQIABAAQANAEAIAFQAIAEAGAHQAFAHAEADQAEAEAAAEQATAOAAAMIASAkIAHAZQAAAEACADQADAFAFADIAmAjIAQARQAKAPABAQQAGAOgHAOQgDAWgOAeQgDAPgSAPQgOAMgaAKQgtASg+AQIgoAKQiHAeiTAVQgSACgLAGQgFACgEAFIgLAGIgLAEQgMADgQABIghACIgtACIgYgBg");
	this.shape_358.setTransform(6.3,4.5);

	this.shape_359 = new cjs.Shape();
	this.shape_359.graphics.f("rgba(213,255,255,0.808)").s().p("AEyEfIgXgCQhFgEhHABIhCABIgiABIg0AAIhDAAIhdAAIgzAAIgrgBQgpgDgsgKIgvgKQgRgEgKgFQgIgEgEgFQgGgDgDgEIghgaQgdgIgegEQgegFgegBQgUgDgcACIgPAAQghgBgbgFQgfgHglgMQh4gqhDgwQgUgOgJgRQgKgRAAgTQAAgVALgRQAKgRAXgNQAWgLATgOQAEgDACgDQACgDAAgCQACgHAHgIQACgIAJgLQAGgIALgJQAMgJAPgGQAYgKAegDQAfgCAbgFIAPgDIAegEQAQgCALgGQAEgDAEgEQAFgEAFgDQANgHAVgEICVgaQBTgPBFgJQAigFAbgCIA1gDQAogCAfACIATADIASACQAOAAASgBIBggGIAOgBIAhgCIAkAAIAkAAIAiAAIAYADIAnACQCEAEBcAJQAhADAbAFIArAHICCAZQBIAOA5AQIABAAQAMAEAJAFQAIAEAGAHQAFAHAEADIAGAHQAUAOADANIAXAkIAJAaIACAHQADAFAFADIAlAkIAPARQAJARABAQQAEAPgHAOQgGAXgRAdQgEAPgSAPQgPAMgZAKQguARg9AQIgoAKQiGAfiUAVQgRACgMAFQgFADgEAEIgLAGQgFADgGABQgMACgQACIghACIgtACIgIAAIgPgBg");
	this.shape_359.setTransform(6.5,4.5);

	this.shape_360 = new cjs.Shape();
	this.shape_360.graphics.f("rgba(213,255,255,0.804)").s().p("AEuEiIgXgCQhEgDhHAAIhCACIgiAAIgzAAIhEAAIhcAAIgzAAIgrgCQgpgDgsgJIgvgKQgRgEgLgEQgHgEgFgFIgKgHIglgZQgdgHgdgFQgfgFgegCQgUgCgcAAIgPAAQghgBgagGQgfgHglgMQh4gqhCgxQgTgPgJgRQgJgRgBgTQAAgUALgSQAKgRAWgNQAWgMATgOQAEgDACgDQACgDAAgCQADgIAHgIQAEgIAJgKQAHgJALgIQAMgJAOgGQAZgKAegDQAfgDAbgFIAPgDIAegFQAPgCALgGQAFgCAEgEQAFgEAFgDQAOgHAUgDICVgbQBSgPBGgIIA9gHQAVgCAfgBQAogCAgACIATACIARABQAPABARgBIBggGIAOgBIAhgCIAjAAIAlAAIAhABIAZADIAmACQCDADBeAKQAgADAbAFIArAHQA5AKBJAPQBHAOA5AQIABAAQAMAEAJAEQAIAFAHAGQAFAHAEADQAFADABAEQAXAOAGANQANARAOAVIALAaIACAHIAIAIQAUATAQARQAIAJAGAKQAJAQgBARQAEAQgJAPQgHAXgTAdQgGAPgTAOQgPAMgZAKQgtARg+AQIgnALQiGAeiUAVQgRACgMAFQgFADgEAEIgLAGIgMADIgbAEIgiACIgsACIgYAAg");
	this.shape_360.setTransform(6.8,4.4);

	this.shape_361 = new cjs.Shape();
	this.shape_361.graphics.f("rgba(213,255,255,0.796)").s().p("AEsEkIgXgCQhFgDhHABIhBACIgiAAIg0AAIhDAAIhcAAIgzgBQgXAAgUgCQgpgDgrgJIgwgJQgQgEgLgEIgNgIIgLgHIgpgYQgdgIgegEQgegFgegCQgVgEgbABIgPgBQgggCgbgGQgfgHglgMQh4grhAgyQgTgPgIgRQgKgRAAgUQAAgUAKgRQAKgSAWgNQAVgNATgOIAGgGIADgFQAEgIAIgIQAEgIAKgKQAHgIALgIQAMgJAPgGQAYgKAegEQAegDAcgGIAPgDIAegFQAPgCALgGQAFgCAFgEQAEgEAGgCQAOgHAUgEICUgbQBRgOBHgIIA9gHQAWgCAegBQAngCAgABIATACIASACQAOAAARgBQAwgCAxgDIANgBIAhgCIAkAAIAkAAIAiABIAYACIAnACQCBAEBeAKQAgADAcAFIAqAHQA7AKBHAPQBGAOA5AQIABAAQANAEAJAFQAIAEAGAGQAGAGAFADIAHAHQAYAPAJANQAQASAQAUIANAbIACAGQADAFAFAEQAUATAPASQAIAKAFAJQAIASgBARQACAQgKAQQgJAXgVAdQgHAPgUAOQgPAMgZAJQguASg9AQIgnAKQiGAfiTAVQgRACgMAFQgGACgEAEIgMAGIgLADQgMACgPABIgiADIgsACIgXAAg");
	this.shape_361.setTransform(7,4.4);

	this.shape_362 = new cjs.Shape();
	this.shape_362.graphics.f("rgba(213,255,255,0.788)").s().p("AEoEmIgXgBQhEgDhHABIhBACIgiAAIgzAAIhDAAIhcgBIgzgBIgrgCQgpgDgrgIIgwgJQgQgEgLgEQgIgDgGgEIgMgHQgYgNgVgKQgdgIgegEQgegFgegDQgVgEgbAAIgPgBQgggCgagHQgggIgkgMQh4grg/gzQgSgPgIgSQgJgQgBgUQAAgUAKgRQAKgSAWgPQAUgMATgPQAEgCACgDIAEgGQAEgIAJgIQAFgIAKgKQAIgIALgIQAMgIAPgGQAYgKAegFQAegEAcgFIAPgEIAegFQAPgCALgGQAFgCAFgDQAFgEAFgCQAOgHAUgEQBFgNBPgOQBRgOBHgIIA9gHIA0gDQAmgCAhABIATACIARABIAggBIBggEIANgBIAhgCIAkAAIAkAAIAhABIAZACIAmACQCAAEBgALQAfADAcAEIAqAIQA7AKBHAOQBFAOA5ARIABAAQANADAJAFQAIAEAHAGIALAIIAIAHQAaAPALAOQAUASARAVQAIAMAHAPIADAGQADAFAFAEQATATAPATQAHAKAFAKQAHASgCASQABARgLAQQgLAYgYAcQgIAPgUAOQgQALgZAKQguARg8ARIgoAKQiEAfiUAVQgRACgMAFQgGACgEADIgMAGIgMADIgbADIghADIgsACIgMAAIgMAAg");
	this.shape_362.setTransform(7.2,4.4);

	this.shape_363 = new cjs.Shape();
	this.shape_363.graphics.f("rgba(213,255,255,0.78)").s().p("AElEoIgXgBQhEgChHABIhBABIgiABIg0AAIhDAAIhbgCIgzgBIgrgCQgpgDgrgIIgvgJQgQgDgMgEIgOgHIgNgGQgbgNgXgJQgdgIgdgFIg8gIQgVgEgbgBIgPgBQgggDgagHQgggIgjgMQh5gsg9g0QgSgQgIgRQgJgRAAgTQAAgUAKgSQAJgSAVgPIAogcIAFgFIAEgGQAGgIAJgIQAGgIALgKQAIgIALgHQANgIAOgGQAZgKAdgGQAegEAcgGIAPgDIAegGQAPgDALgFQAFgCAFgDIALgGQAOgGAUgEQBEgOBPgNQBQgOBIgJIA9gGIA0gDQAmgCAhABIASABIASABIAfAAIBggFIAOgBIAhgBIAjAAIAkAAIAiABIAYACIAmACQB/AEBgALIA8AHIAqAIQA7AKBGAOQBFAOA5ARIABAAIAVAIQAJAEAHAGIALAIQAGADADAEQAdAPANAOQAXASATAWIAQAbIADAGIAIAJQAUAUAOATQAGAKAFALQAGASgDATQAAARgMARQgNAYgaAdQgKAOgUANQgRAMgYAJQguASg9AQIgnALQiEAfiTAVQgRACgNAEQgFACgFAEIgMAEIgMADIgbAEIghACIgsADIgMAAIgLAAg");
	this.shape_363.setTransform(7.5,4.4);

	this.shape_364 = new cjs.Shape();
	this.shape_364.graphics.f("rgba(213,255,255,0.773)").s().p("AgXEqIhDAAIhbgBIgygCIgrgCQgpgDgrgIIgwgIIgbgHIgPgGIgOgHIg2gVQgdgHgdgFQgfgFgdgEQgWgEgagCIgPgBQgggEgagHQgggJgjgMQh5gsg7g2QgSgPgIgSQgIgQAAgUQAAgTAJgTQAKgSAUgPIAngdIAGgFIAEgGQAGgIALgJQAHgHALgKQAIgIAMgHQAMgHAPgHQAYgKAdgGQAegFAcgGIAPgDIAegHQAPgCALgFIAKgFQAGgEAGgCQAOgGAUgEQBEgOBOgNQBQgNBIgJQAggEAdgCIA0gEQAlgCAhABIATABIASABIAfgBIBfgEIAOAAIAhgBIAjAAIAlAAIAhABIAYACIAnABQB9AFBhALQAfADAcAFIAqAHQA8AKBFAOQBEAOA6ARIABAAQAMAEAJAEQAJADAHAGQAGAFAGADIAJAGQAfAQAQAOQAaAUAUAVQAKANAJAOIADAHIAIAIQATAUAOAVQAGAKAEALQAFAUgEASQgBASgNARQgOAZgdAdQgLANgVAOQgRALgYAJQgvASg8AQIgnALQiDAgiUAVQgQABgNAFIgLAEIgMAFIgMADIgbADIghADIgsADIgXAAIgXgBQhEgChHACIhBABIgiAAIgzAAg");
	this.shape_364.setTransform(7.8,4.5);

	this.shape_365 = new cjs.Shape();
	this.shape_365.graphics.f("rgba(213,255,255,0.769)").s().p("AgaEtIhDgBIhbgBIgygCIgrgCQgpgDgrgIIgvgIIgcgGIgPgGIgPgGIg7gVIg6gMIg7gJQgWgEgagDIgPgCQgggEgagHQghgJghgMQh6gug5g1QgRgRgIgRQgIgRAAgTQAAgUAJgSQAJgTAUgQIAmgdIAGgFIAFgGQAHgIALgJQAIgIAMgJQAIgHAMgIQAMgHAPgGQAYgKAdgGIA6gNIAQgEIAdgGQAPgDALgEIALgFIALgFQAPgGATgEQBFgOBOgNQBOgOBJgIIA9gGIAzgEQAmgCAhABIATABIARAAIAfAAIBggEIANgBIAhgBIAkAAIAkABIAhAAIAZADIAmABQB7AFBjALIA7AIIAqAHQA8AKBEAOQBEAOA5ARIABAAIAWAIQAIADAIAGIAMAHQAGADAEAEQAhAPATAPQAdAUAWAWQALANAJAOIAEAHIAIAIQATAVAMAVQAGAKAEAMQAFAUgFATQgDASgOASQgQAaggAcQgMANgVANQgSALgXAJQgvASg8ARIgnAKQiDAhiTAUIgeAGIgLAFIgMAEIgMACIgbAEIghACIgsADIgXAAIgXAAQhDgBhHACIhBABIgiAAIgZAAIgaAAg");
	this.shape_365.setTransform(8.1,4.5);

	this.shape_366 = new cjs.Shape();
	this.shape_366.graphics.f("rgba(213,255,255,0.761)").s().p("AgdEvIhDAAIhbgCIgygCIgrgCQgpgEgqgHIgwgHIgcgGIgPgGIgQgFIg/gUQgdgHgdgFIg8gLQgWgEgagDIgOgCQgfgFgbgIQghgJghgMQh6gug4g3QgQgQgIgSQgIgRAAgTQAAgUAJgSQAJgTAUgQIAmgeIAFgGIAGgFQAIgIALgJQAJgIAMgJQAJgHAMgHQANgIAOgGQAZgKAcgHIA6gNIAQgEIAdgGQAPgDAMgFIAKgEIAMgFQAPgGATgEQBFgOBNgNQBOgNBJgJIA9gGIAzgDIBHgCIATABIARAAIAfgBIBfgDIAOgBIAhAAIAjAAIAkAAIAiABIAYACIAmACQB6AEBjAMQAfADAcAEIArAHQA9ALBCAOQBDAOA6ARIABAAIAVAHQAJAEAIAFQAGAEAHADIALAGQAiAQAWAPQAgAUAYAXQAMANAKAOIAEAHIAIAIQATAWALAVQAGALADAMQAEAUgGAVQgEASgOASQgTAagiAcQgNAOgWANQgSAKgYAJQguASg8ARIgnAKQiCAhiTAUQgRADgNADIgMAEIgNAEIgLACIgbAEIghACIgrADIgYABIgWgBIiLACIhAABIgjAAIgYAAIgaAAg");
	this.shape_366.setTransform(8.4,4.5);

	this.shape_367 = new cjs.Shape();
	this.shape_367.graphics.f("rgba(213,255,255,0.753)").s().p("AASEyIgzAAIhCgBIhagCIgzgDIgqgCQgqgDgqgHIgvgHIgcgFIgQgGIgRgEIhEgUIg5gMIg8gKQgXgFgZgEIgOgCQgfgHgbgHQghgJgggMQh7gwg2g3QgQgRgHgSQgIgRAAgTQAAgTAJgTQAIgTATgRQASgPAUgPIAGgGIAFgFQAJgJANgIIAWgRQAJgIAMgGQANgHAPgGQAYgKAcgHIA7gPIAPgEIAegHQAOgDAMgEIAKgEIANgFQAPgGATgDQBFgPBNgNQBMgMBLgJIA8gGIAzgDIBHgCIASAAIASAAIAfAAIBfgEIANAAIAhgBIAjAAIAlABIAhABIAYABIAmADQB5AEBkALIA7AIIAqAHQA+ALBBAOQBCAOA6AQIABAAIAWAIIARAIQAGAEAHADIAMAGQAlAQAYAQQAjAVAaAXQANANAKAOIAFAHIAHAIQAUAWAKAWQAFAMADALQADAVgHAWQgFASgPATQgUAaglAdQgPANgWANQgSAKgYAJQgvARg7ARIgnALQiCAhiTAUQgQACgOAEIgMADIgNAEIgLACIgaADIghADIgsADIgXABIgXAAIiKACIhAABIgjAAg");
	this.shape_367.setTransform(8.7,4.6);

	this.shape_368 = new cjs.Shape();
	this.shape_368.graphics.f("rgba(213,255,255,0.745)").s().p("AAPE1IgzgBIhCgBIhagDIgygCIgrgCQgqgEgpgFIgwgIIgcgFIgRgFIgRgEIhIgTIg6gMIg7gLIgwgJIgOgEQgfgGgbgHQghgLgggMQh6gvg1g4QgQgRgHgTQgHgRAAgTQAAgTAIgSQAJgUASgRQARgQAUgQIAGgFIAGgFIAXgSQAKgIAOgJIAWgNQANgHAOgGQAZgKAcgIIA6gPIAPgEIAegHIAagIIALgEIAMgEQAQgFATgEQBEgPBNgNQBMgMBLgJIA8gGIAzgDIBGgCIATAAIARAAIAfgBIBfgDIAOAAIAhgBIAjABIAkAAIAhACIAYABIAmACQB4AEBlANIA7AIIAqAGQA+ALBAANQBCAOA6ASIABAAIAVAHIASAHIANAHIANAHQAnAPAbAQQAmAVAbAYQAPAOALANIAEAHIAIAJQATAWAKAXQAFALACAMQADAWgJAWQgGATgQAUQgWAbgnAcQgQANgYAMQgSAJgXAKQgvARg7ARIgnALQiBAhiTAVIgeAEIgNAEIgNADIgLACIgaAEIghACIgsADIgXABIgXAAIiJADIhBACIgiAAg");
	this.shape_368.setTransform(9,4.6);

	this.shape_369 = new cjs.Shape();
	this.shape_369.graphics.f("rgba(213,255,255,0.737)").s().p("AgnE3IhCgBIhagEIgygCIgrgCQgpgEgqgFIgvgHIgcgGIgSgDIgSgFIhNgSIg5gMIg8gLIgvgKIgOgEQgfgHgbgIQghgLgggMQh6gvgzg6QgQgRgGgTQgHgRgBgTQAAgTAIgTQAJgTASgSQAQgQAVgQIAGgFIAGgGIAZgSIAYgQIAXgNIAcgMQAYgKAcgJIA6gQIAQgFIAdgHIAagHIALgEIANgDQAQgGASgEQBFgPBMgMQBLgMBMgJIA8gGIAzgDIBGgDIATAAIARgBIAfAAIBggCIAMAAIAhgBIAjAAIAkABIAhABIAZABIAlACQB3AFBmAMIA6AIIAqAHQA/AKA/AOQBBAOA6ARIABAAIAWAIIARAGIAPAHIANAGQApAQAeAQQApAWAdAYQAQANAMAPIAEAGIAIAJQATAWAJAYQAEAMACAMQACAXgJAWQgIAVgRATQgYAbgpAcQgSANgYAMQgSAKgXAJQgwARg6ARIgnALQiBAiiTAUIgeAEIgNAEIgNADIgLACIgaACIghAEIgsACIgXABIgXABIiJAEIhAABIgjAAIgyAAg");
	this.shape_369.setTransform(9.3,4.7);

	this.shape_370 = new cjs.Shape();
	this.shape_370.graphics.f("rgba(213,255,255,0.733)").s().p("AgrE5IhCgBQgtgBgtgDIgxgCIgrgDQgqgDgpgGIgvgGIgdgFIgRgDIgUgEIhRgRIg5gMIg7gNIgwgLIgOgDQgegIgbgIQgigLgfgMQh7gxgxg6QgPgRgHgTQgGgSAAgSQAAgTAHgTQAJgUARgSQAQgRAVgQIAGgFIAGgGIAagSIAbgQIAXgMIAbgNQAZgKAbgJQAcgJAegIIAQgFIAdgHIAagHIAMgEIANgDIAjgJQBFgQBLgMQBKgMBMgIIA9gGIAygDIBGgDIATgBIARAAIAfgBIBggCIAMAAIAhAAIAjAAIAkABIAhABIAYABIAmACQB1AFBnAMIA7AIIApAHQBAAKA+AOQBAAOA7ARIABAAIAVAHIASAHIAPAGIAOAGQArAQAhARQAsAXAeAYQARANANAPIAFAGIAHAIQATAYAIAYQAEAMABAMQACAYgKAXQgJAVgTATQgZAdgsAbQgTANgYAMQgTAJgXAJQgvASg7ARIgnAKQiAAiiSAUIgfAFIgNADIgOACIgLACIgaADIggADIgsADIgXABIgXABQhDADhGABIhAABIgjAAIgYAAIgaAAg");
	this.shape_370.setTransform(9.7,4.7);

	this.shape_371 = new cjs.Shape();
	this.shape_371.graphics.f("rgba(213,255,255,0.725)").s().p("AAEE8IgzAAIhBgBIhagFIgygCIgqgDQgqgDgpgFIgvgGIgdgEIgSgEIgUgDIhWgRIg5gLIg7gOIgwgLIgOgFIg5gQQgigLgegNQh7gxgwg7QgOgSgHgTQgGgSAAgRQAAgUAHgSQAIgVARgTQAQgRAUgQIAGgFIAHgGIAcgTIAcgPIAXgMIAcgMQAZgKAbgKIA6gSIAQgFIAdgIIAagHIAMgDIAOgDIAigJQBFgPBLgMQBJgMBNgJIA8gFIAzgEIBFgDIATgBIASAAIAegBIBggBIAMAAIAhgBIAjABIAkABIAhABIAYAAIAmACQBzAFBoANIA7AIIApAHQBAAKA9AOQBAAOA7ARIABAAIAVAIIASAFIAQAGIAPAGQAtAQAjARQAvAXAhAZQARAOAOAPIAFAGIAHAIQAUAYAHAZQADAMABANQAAAYgLAXQgJAWgUAUQgbAdgvAbQgUAMgZAMQgTAJgXAJQgvASg7ARIgmALQiAAiiSAUIgfAEIgNADIgOACIgLACIgaACIghAEIgrADIgXABIgXABIiJAFIg/ABIgjAAg");
	this.shape_371.setTransform(10,4.7);

	this.shape_372 = new cjs.Shape();
	this.shape_372.graphics.f("rgba(213,255,255,0.718)").s().p("Ar7DhQk8hdgBiEQABiCE8heQE9hdG+AAQG/AAE9BdQE8BeABCCQgBCEk8BdQk9Bem/AAQm+AAk9heg");
	this.shape_372.setTransform(10.4,4.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_332}]},58).to({state:[{t:this.shape_333}]},1).to({state:[{t:this.shape_334}]},1).to({state:[{t:this.shape_335}]},1).to({state:[{t:this.shape_336}]},1).to({state:[{t:this.shape_337}]},1).to({state:[{t:this.shape_338}]},1).to({state:[{t:this.shape_339}]},1).to({state:[{t:this.shape_340}]},1).to({state:[{t:this.shape_341}]},1).to({state:[{t:this.shape_342}]},1).to({state:[{t:this.shape_343}]},1).to({state:[{t:this.shape_344}]},1).to({state:[{t:this.shape_345}]},1).to({state:[{t:this.shape_346}]},1).to({state:[{t:this.shape_347}]},1).to({state:[{t:this.shape_348}]},1).to({state:[{t:this.shape_349}]},1).to({state:[{t:this.shape_350}]},1).to({state:[{t:this.shape_351}]},1).to({state:[{t:this.shape_352}]},1).to({state:[{t:this.shape_353}]},1).to({state:[{t:this.shape_354}]},1).to({state:[{t:this.shape_355}]},1).to({state:[{t:this.shape_356}]},1).to({state:[{t:this.shape_357}]},1).to({state:[{t:this.shape_358}]},1).to({state:[{t:this.shape_359}]},1).to({state:[{t:this.shape_360}]},1).to({state:[{t:this.shape_361}]},1).to({state:[{t:this.shape_362}]},1).to({state:[{t:this.shape_363}]},1).to({state:[{t:this.shape_364}]},1).to({state:[{t:this.shape_365}]},1).to({state:[{t:this.shape_366}]},1).to({state:[{t:this.shape_367}]},1).to({state:[{t:this.shape_368}]},1).to({state:[{t:this.shape_369}]},1).to({state:[{t:this.shape_370}]},1).to({state:[{t:this.shape_371}]},1).to({state:[{t:this.shape_372}]},1).to({state:[]},1).wait(590));

	// Layer_17
	this.shape_373 = new cjs.Shape();
	this.shape_373.graphics.f("rgba(213,255,255,0.239)").s().p("Ag/A4QgKAAgIgEQgGgCgLgGQgLgFgLgCIgUgCIgTgBQgOAAghgFQgFgBgBgCQgBgBAAgEQACgIAJgDQAEgDALgBQgSgDgKgCQgPgFgJgIQgFgEACgEQABgCAEAAIAUgCIAVAAQAnAAAmgJQgBAAAAAAQgBgBAAAAQgBAAAAgBQgBAAAAgBQAAAAAAgBQgBgBAAAAQAAgBAAAAQAAgBABAAQABgEAFgEQALgFASABIAQABIAPAAIAMgCIAMgCQAFAAAEADQAAAAABAAQAAAAAAABQABAAAAABQAAAAAAABQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQArgIAbgCQApgDAfAKQAHACAAAEQAAAFgHABIgEACIgEACQA3gEA2ANIAOADIAHADQABAAAAABQAAAAAAABQABAAAAABQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQgBABAAAAQgBACgEAAIgtAEQgeADgQAGIADAEIAFAEQACACABACQABADgCACQgCACgDAAQgcAEgdgCIgJAAQgFABgDACIAHADQAGACAAAEQABAFgIADQgMADgUAAQgaAAgGABIgQADIgOADIgRAAIgSABIgSgBg");
	this.shape_373.setTransform(10.4,0.9);

	this.shape_374 = new cjs.Shape();
	this.shape_374.graphics.f("rgba(213,255,255,0.251)").s().p("AgsA8IgSgBIgGAAIgMgEIgCAAIgLgEIgGgEQgIgEgKgCIgFgBIgIgBIgJgCIgDAAIgFAAIgNgBIgIgBIgQgCIgQgDIgIAAIgEgBIgCgCQgCgBAAgDQABgGAEgDIAEgCIAKgDIAEgBQgTgDgKgDQgLgCgHgFIgJgFIgBgBQgEgEACgEQABgDAEAAIADgBIAMgBIAHAAIAGAAIACAAIADgBIAIAAIABAAIAHAAIAHgBIAIAAIAOgBIAQgCIAKgBIAIgDIADgBIADAAIADgBIgCgBIgBgCQgBgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABgBQABgDAFgEQAJgEANAAIAKAAIAQAAIAMAAIAEAAIAJgBIAEgBIAJgBIAEAAQAGgBADADQABAAAAAAQABAAAAABQAAAAABABQAAAAAAAAIAAABIAAAFIAEgBIAJgBIAYgFIAMgBIAKgBIAJgBIAHgBIAGAAIAKgBQAgABAZAGIADABQAHACAAAEQAAABAAAAQAAABAAAAQAAABgBAAQAAABAAAAQgBAAAAABQgBAAAAAAQgBAAgBABQAAAAgBAAIgEACIgBABIgCABIAegBIAkACIAGABIAFACIAFABIAEABIAWADIABABIAOAFIAEACIACAAQAAABAAAAQAAABABAAQAAABAAAAQAAABAAAAIgBAEIgBABIgCABIgCAAIgLABIgUACIgKACIgBAAIgWADIgMADIgIAEIAEADIAAABIAEADQACACAAACQABADgCADQgCABgDABIgTABIgpACIgKAAQgFAAgEADIAHADQAEABABACIAAADQABACgDADIgFACIgDACIgEABIgGABIgJAAIgMABIgFAAIgGAAQgRgBgGABIgOADIgCAAIgOADIgCAAIgSAAIgDAAIgPABIgCAAg");
	this.shape_374.setTransform(10.1,1);

	this.shape_375 = new cjs.Shape();
	this.shape_375.graphics.f("rgba(213,255,255,0.267)").s().p("AgrA+IgSAAIgHgBQgHAAgGgCIgBgBIgMgFIgGgCQgJgEgKgDIgFgBIgJgCIgJgBIgDgBIgFgBIgLgBIgHgBIgRgDIgRgCIgJAAIgEAAIgCgCQgBAAAAgBQgBAAAAgBQAAAAAAgBQAAgBAAgBQAAgEADgEIAEgCIAJgDIADgBQgTgDgMgDQgKgDgJgEIgJgGIgBgBQgEgEACgEIAAgBQABgCAEgBIADAAIAMgCIAIAAIAGAAIACgBIADAAIAHAAIABAAIAHgBIAHgBIAIgBIAPgCIAQgBIAMgBIAHgCIADgBIADgBIAEgBIgCgCIgBgBQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABgBQABgEAGgDQAJgEANgBIALAAIARAAIANAAIAEAAIAKgCIAEAAIAJgCIAEAAQAHAAAEACIADADIAAABIAAAFIAEgBIAJgBIAagFIAMgCIALgBIAJgBIAIAAIAAAAIAGAAIALAAQAigBAaAHIAEABQAHACAAAEQAAAAAAABQAAABAAAAQAAABAAAAQgBAAAAABIgEACIgDABIgBABIgCACIAfAAQAUAAASACIAGACIAFABIAFACIAEAAIAUAFIABABIALAEIAFABIABABIABAEIgBAEIgCABIgCABIgBAAIgJABIgSADIgJABIgCAAQgLACgIACIgMAEIgHAEIACAEIABABIADADQABAAAAABQAAAAABABQAAAAAAABQAAABAAAAQABADgDACQgBACgEAAIgUACQgVACgWAAIgKAAQgGABgEACIAGAEQAEABABACIAAACQAAADgDACIgFADIgDACIgDABIgIABIgJAAIgMABIgGAAIgGAAQgRgBgHABIgPACIgCAAIgPADIgCAAIgTAAIgDAAIgQABIgDAAg");
	this.shape_375.setTransform(9.8,1);

	this.shape_376 = new cjs.Shape();
	this.shape_376.graphics.f("rgba(213,255,255,0.278)").s().p("Ag8BBIgHgBQgIAAgGgCIgCgBIgMgEIgGgDQgJgEgLgDIgGgBIgIgCIgKgCIgDgBIgEgBIgLgCIgGgBIgRgDIgSgCIgKAAIgEAAIgCgCQgDgBAAgDQAAgEADgEIADgCIAIgDIADgBQgVgDgMgEQgLgDgJgEQgGgCgEgEIgBgBQgFgEACgFQACgDADgBIAEAAIANgCIAIAAIAHAAIACgBIACAAIAGgBIABAAIAGgBIAHgBIAJgCIAQgBIARgBIAMgBIAIgCIADgCIADgBIAEgCIgCgBIgBgCQAAAAAAgBQAAAAAAgBQABAAAAgBQAAAAAAgBQACgEAGgDQAKgEAOgBIALAAIASAAIANgBIAFAAIAKgCIAFAAIAKgCIAEAAQAHAAAEACQABABAAAAQABAAAAABQABAAAAAAQAAABAAAAIAAABIABAFIAEgBIAKgBIAagEIAOgDIALgBIAKgBIAIAAIAAAAIAHAAIALAAQAlAAAbAGIADABQAHACABAEQAAABAAAAQAAABAAAAQAAABAAAAQAAAAgBABIgDACIgDABIgBABIgBACIAgAAIAoADIAHACIAFACIAEABIAEABIARAFIABABIAKAEIAEACIABABQABAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAIgBAEIgCACIgCABIgBAAIgIABIgQADIgIABIgBAAQgKACgIACIgKAFIgIAEQAAADACACIABABIADACQAAABABAAQAAABAAAAQAAABAAABQAAAAAAABQAAADgCACIgGACIgUACQgXADgXAAIgLAAIgKADIAGADQABABAAAAQABAAAAABQABAAAAABQAAAAAAABIAAACQAAADgDACIgFADIgDACIgDACIgIABIgKAAIgMABIgHgBIgGAAQgSgBgIABIgPACIgDAAIgQADIgCAAIgTAAIgDAAIgRABIgDAAIgLAAIgIAAg");
	this.shape_376.setTransform(9.5,1.1);

	this.shape_377 = new cjs.Shape();
	this.shape_377.graphics.f("rgba(213,255,255,0.294)").s().p("Ag7BEIgHAAIgOgDIgCAAIgNgFIgHgDQgJgEgMgDIgGgBIgJgCIgJgCIgDgCIgEgBIgKgDIgFgBIgSgDIgTgCIgKAAIgEABIgDgCQgDgBAAgDQAAgEACgDIADgDIAGgDIACgBQgVgDgNgEQgLgDgKgEQgGgDgEgDIgBgBQgFgFABgFIAAAAQACgDAEgCIADAAIAOgCIAIAAIAHAAIADgBIACAAIAFgBIABAAIAGgCIAGgCIAJgCIARgBQAKAAAIgBIANgBIAIgCIADgCIADgBIAEgCIgCgBIAAgCQAAAAAAgBQAAAAAAgBQAAAAAAgBQABAAAAgBQADgEAGgDQAKgEAPgCIALAAIAUAAIANgBIAGAAIALgCIAEAAIALgCIAEAAQAHAAAFACIADAEIAAAAIABAFIAAAAIAFgBIAKAAIAcgFIAOgDIALgBIALgBIAJAAIAHAAIALAAQAoAAAbAGIAEABQAHACABAEQAAABAAAAQABABAAAAQAAABgBAAQAAABAAAAIgDACQgBAAgBAAQAAABAAAAQgBAAAAAAQAAABAAAAIAAABIgBABIAiABQAWABAUACIAHACIAFACIAEACIAEABIAOAFIABABIAIAEIAEACIABABQAAABAAAAQAAABAAAAQAAABAAAAQAAAAAAABQAAABAAAAQAAABAAAAQAAABgBAAQAAABAAAAIgCABIgCACIAAAAIgIABIgNACIgHACIgCAAQgIACgHADIgKAGIgIAEQABACACACIAAABIACADQACACgBADQABADgDACIgGACIgWACQgYADgYAAIgLAAIgLADQAAABAFADQABAAAAABQABAAAAAAQABABAAAAQAAABABAAIgBACQAAADgDADIgFADIAAABIgDABIgEACIgIABIgKAAIgNABIgHAAIgGgBIgbAAIgRACIgCAAIgRACIgDAAIgTABIgEAAIgSABIgCAAIgMAAIgJAAg");
	this.shape_377.setTransform(9.1,1.1);

	this.shape_378 = new cjs.Shape();
	this.shape_378.graphics.f("rgba(213,255,255,0.306)").s().p("AglBHIgVAAIgIAAIgOgCIgDgBIgNgEIgHgDIgWgHIgGgCIgJgCIgKgCIgDgCIAAAAIgEgCIgIgDIgFgCIgTgDIgTgBIgLAAIgEABIgDgCQgDgBgBgDQAAgDACgEIACgCIAFgDIACgBQgWgEgOgEQgMgDgKgFIgLgFIgBgBQgGgFACgFIAAgBQABgDAFgCIADAAQAGgCAJAAIAIAAIAIgBIACgBIACAAIAEgBIABAAIAFgCIAHgDIAJgCQAIgBAKAAIATAAIANgBQAFgBADgCIADgCIADgBQABgBAAAAQAAAAABgBQABAAAAAAQABAAABAAIgCgCIAAgBQAAgBAAAAQAAgBABAAQAAgBAAgBQABAAAAgBQADgDAGgDQALgFAPgBIAMgBIAVAAIAOgBIAGAAIALgCIAFgBIALgBIAEAAQAIgBAFADQAAAAABABQAAAAABAAQAAABABAAQAAABAAAAIABABIABAFIAFgBIAKgBIAegFIAPgCIAMgBIALgBIAJgBIAAAAIAHABIAMgBQAqAAAdAHIADABQAIACABADQABABAAAAQAAABAAABQAAAAAAAAQAAABgBAAIgCACQgBAAAAABQgBAAAAAAQgBAAAAABQAAAAAAAAIAAABIgBACIAkABIAsAEIAHACIAFADIAFACIADABQAIACAEADIAAABIAHAEIADACQAAAAABAAQAAAAAAAAQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAABQAAAAAAABIgBAEIgCACIgCABIAAAAIgHACIgLACIgGABIgBAAQgIACgFAEQgEADgFADIgJAFIACAEIABABIACADQAAABAAAAQAAABABAAQAAABAAABQgBAAAAABQAAADgDACQgCACgEAAIgWADIgzADQgHAAgEABQgHAAgFACQAAACAFACQAAABABAAQAAAAABABQAAAAAAABQAAAAAAABIAAACQgBADgDACIgEAEIgDACIgEACIgJABIgLABIgNAAIgBAAIgHAAIgHgBQgTgBgJAAIgRACIgCAAIgSADIgDAAIgUAAIgEAAIgTABIgDAAg");
	this.shape_378.setTransform(8.8,1.1);

	this.shape_379 = new cjs.Shape();
	this.shape_379.graphics.f("rgba(213,255,255,0.322)").s().p("AhBBKQgJAAgHgCIgCAAIgOgFIgHgCIgXgIIgGgCIgKgCIgKgDIgDgCIgDgCIgHgEIgEgCIgUgDIgUgBIgMABIgEAAIgDgBQgDgBgBgDQgCgDACgDIACgDIAEgDIABgBQgWgEgPgEQgNgDgLgFQgHgDgEgDIgCgBQgFgFACgFIAAgBQABgEAEgBIAEgBQAGgCAJAAIAJAAIAIgBIACgBIACAAIAEgBIAAAAIAFgDIAHgDIAJgDQAJgBAJAAIAUAAIAOgBQAFAAAEgCIADgCIADgCQAAgBABAAQAAAAABgBQAAAAABAAQABAAAAAAIAAgCIAAgBQAAgBAAAAQAAgBAAAAQABgBAAgBQAAAAABgBQACgDAHgDQAMgFAQgCIAMAAIAWgBIAPgBIAGAAIAMgCIAFgBIALgBIAFAAQAIgBAFADQADABABACIAAABIABAFIABAAIAFAAIALgBIAfgGIAPgCIANgBIALgCIAKAAIAAAAIAHABIANAAQAtgBAdAHIAEABQAIACABADQABABAAAAQAAABAAAAQAAABAAAAQAAABAAAAIgDACQAAAAgBABQAAAAAAAAQAAAAAAABQAAAAAAAAIgBABIAAACIAmABQAZACAUADIAIACIAFADIAEADIADABQAHACADADIgBABIAGAEIADACIAAABIAAAEIgCAEIgCACIgBACIgBAAIgEABIgKADIgFABIgBAAQgHACgEAEQgCAEgGAEIgIAEQAAABAAAAQAAABAAABQAAAAABABQAAAAAAABIABABIABADQABACgBADQAAADgDACQgCACgFAAIgXADQgaADgbABQgHgBgFABQgGABgGACQAAABAEADQABAAAAAAQABABAAAAQAAAAAAABQAAAAAAABIgBACQgBADgDADIgEAEIgDADIgEACIgJABIgMAAIgOABIgHgBIgIgBIgdgBIgSACIgCAAIgTADIgDAAIgVAAIgEAAIgUABIgDAAIgWAAIgEAAIgEAAg");
	this.shape_379.setTransform(8.5,1.2);

	this.shape_380 = new cjs.Shape();
	this.shape_380.graphics.f("rgba(213,255,255,0.333)").s().p("AhABNIgQgCIgDAAQgHgBgHgDIgHgDIgYgIIgHgCIgKgCIgLgDIgDgCIABgBIgDgCIgGgFIgDgCIgVgDIgVgBIgMABIgFAAIgDgBQgDAAgBgDQgCgDABgDIABgCIADgEIABgBQgXgEgQgEQgNgEgMgFIgMgFIgBgCQgGgFACgFIAAgBQABgEAFgCIADgBQAGgCAKAAIAJAAIAJgBIACgBIACgBIADgBIAAAAIAEgDIAHgDIAJgDQAJgCALAAIAUABIAPgBQAFAAAEgCIADgDIADgCQABgCAEAAIgBgCIAAgBIADgFQADgDAHgDQAMgFARgCIANAAIAWgBIAQgCIAGAAIANgCIAFgBIAMgBIAFAAQAIgBAGADQADABABACIAAABIACAFIAAAAIAGAAIAKgBIAhgFIAQgDIANgBIAMgCIAKAAIABAAIAHABIAOAAQAvAAAeAGIAEABQAIACACADQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAIgBACQgBAAAAABQgBAAAAAAQAAAAAAABQAAAAAAAAIAAABIAAACIAoACIAvAFIAIACIAFAEIAEADIACABQAGADACACIgBABIAEAFIADABIAAACIAAAEIgDAEIgCACIgBACIAAAAIgEABIgHACIgEACIgBAAQgGACgDAFQgCAEgFAEIgJAFIACAFIAAABIABADQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAEgDACIgHACIgYADQgcADgbABQgIAAgFABIgMADQgBAAAAAAQAAABABAAQAAAAABABQABABABAAQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAABIgBACQgBADgDADIgEAEIgDADIgEACIgKACIgMAAIgPAAIgIAAIgHgBIgfgCIgTACIgCAAIgUACIgDAAIgWABIgEAAIgVABIgDAAIgXAAIgEAAIgEAAg");
	this.shape_380.setTransform(8.2,1.2);

	this.shape_381 = new cjs.Shape();
	this.shape_381.graphics.f("rgba(213,255,255,0.349)").s().p("AhABQIgQgCIgDAAIgPgEIgIgDIgYgIIgHgCIgLgCIgLgEIgDgCIABgBIgDgCQgBgDgDgCIgDgDQgJgCgMgBIgWgBIgNABIgFABIgDgBQgDAAgCgDQgCgDABgDIAAgCQAAgBAAAAQAAAAABgBQAAAAAAgBQABAAAAAAIABgCQgYgEgRgEQgOgEgMgFQgIgDgFgDIgBgBQgGgGABgGIAAAAQACgFAEgCIAEgBQAGgCALAAIAJAAIAJgBIACgBIACgBIACgBIABAAIADgEIAHgEIAJgDQAKgCALABIAVABIAPgBQAGAAAEgDIACgDIADgCQACgCADgBIAAgBIABgCQAAAAAAgBQAAAAAAgBQABAAAAgBQABAAABgBQADgEAHgCQANgFARgCIAOgBIAXgBIARgBIAGgBIANgCIAGgBIANgBIAEAAQAJgBAGADQADABABACIABABIACAFIAAAAIAGAAIAKgBIAjgFIARgDIANgCIANgBIAKAAIABAAIAIABIAOAAQAxAAAfAGIAEABQAIACADADQAAABAAAAQAAABABAAQAAAAAAABQAAAAAAABIgCACQAAAAgBABQAAAAAAAAQAAAAAAABQAAAAAAAAIAAABIABACIApACQAcACAVAEIAJACIAFAEIADADIACACQAFADABACIgCABIADAFIACACIAAABIgBAEQAAACgCACIgCADIgBABIAAABIgDABIgFACIgDABQgFADgCAFQgCAFgFAEIgJAGIABAEIAAABIACADQAAACgBADQgBADgEACQgCACgFABIgZADQgcADgdACQgIgBgFABIgNADQgBAAAAABQAAAAABABQAAAAABABQAAAAABABQAAAAABAAQAAABAAAAQAAABAAAAQAAABAAABIgBACIgEAGIgFAEIgDADIgEACIgKACIgNAAIgPABIAAAAIgIgBIgIgBIgggCIgUACIgCAAIgVACIgDAAIgXABIgEAAIgWABIgDAAIgYAAIgFAAIgEAAg");
	this.shape_381.setTransform(7.9,1.3);

	this.shape_382 = new cjs.Shape();
	this.shape_382.graphics.f("rgba(213,255,255,0.361)").s().p("AhABTIgRgBIgDgBIgQgDIgHgDIgagJIgHgCIgLgCIgLgEIgDgDIAAgBIgCgCQgBgEgCgCIgCgDIgWgEQgLgBgMABIgNACIgFAAIgDgBQgEAAgCgCQgDgDABgDIAAgCQAAAAAAgBQAAAAAAgBQAAAAAAAAQABgBAAAAIAAgCQgZgEgSgFQgOgEgNgFQgIgDgFgEIgCAAQgGgFACgHIAAAAQABgFAEgCIAEgCQAHgCALAAIAKAAIAJgBIACgBIABgBIACgCIAAAAIADgEIAHgEIAKgEQAJgCAMABIAWABIAQAAQAGgBAEgCIACgDIADgDQACgCAEgBIAAgBIAAgCQABgCADgCQADgEAHgCQAOgFASgCIAOgBIAZgCIARgBIAHgBIANgCIAHgBIANgBIAEAAQAKgBAGADQADABABACIABABIACAFIAAAAIAGAAIALAAIAkgGIASgDIAOgCIANgBIALAAIAAAAIAJABIAOAAQA0AAAgAGIAEABQAJACACADQAAABABAAQAAABAAAAQAAAAAAABQABAAgBABIgBACQAAAAAAABQAAAAAAAAQgBAAABABQAAAAAAAAIAAABIABACIArADQAdACAWAEIAJACIAFAFIADADIACACQAEADgBADIgCABQAAAAAAABQAAAAAAABQABAAAAABQAAAAABABIABACIAAABIgBAEIgDAFIgCACIgBACIAAABIgEADIgCABQgEADgBAGQgBAFgFAEIgJAGQAAABAAAAQAAABAAAAQAAABAAABQABAAAAABIAAABIABADIgCAFQgBADgEACIgHADIgaADQgeAEgeABQgIAAgFABQgIABgGACQAAAAAAABQAAAAAAABQAAAAABAAQABABAAABQABAAAAAAQAAABAAAAQAAAAAAABQAAABgBAAIgBACIgFAHIgEAEIgDAEIgFACIgKACIgNAAIgQAAIAAAAIgJgBIgIgBIghgCQgIAAgMACIgDAAIgWACIgDAAIgYABIgEAAIgWABIgDAAIgaAAIgEAAIgFAAg");
	this.shape_382.setTransform(7.6,1.3);

	this.shape_383 = new cjs.Shape();
	this.shape_383.graphics.f("rgba(213,255,255,0.376)").s().p("AhBBXIgRgDIgDAAIgRgEIgHgCIgbgIIgHgDIgMgDIgLgEIgDgDIAAgBIgBgDIgCgGIgBgDIgYgEQgLgBgMAAIgOADIgFABIgEgBQgEAAgCgDQgDgCAAgCIAAgCIgBgFIAAgBIgsgJQgPgEgNgGQgJgCgFgFIgCgBQgGgEABgHIAAgBQABgFAFgCIAEgBQAHgDALAAIALgBIAJgBIADgBIAAgBIABgBIABAAQAAgBAAAAQAAgBAAAAQABgBAAAAQABgBAAgBIAGgFIALgEQAKgCAMABIAWABIARAAQAGAAAEgDIADgDIADgDQABgCAEgBIABgBIAAgCIAEgEQAEgEAIgDQAOgEASgDIAPgBIAagCIARgCIAIAAIAOgCIAGgBIAOgBIAFAAQAKAAAGACQADABACACIAAABIADAFIAGABIAMgBIAlgHIASgCIAPgCIANgBIAMgBIABAAIAIACIAPAAQA2gBAhAHIAFABQAIACADADIACADIgBADQAAAAAAAAQAAABAAAAQAAAAAAAAQAAABAAAAIAAABIACACIAsADIA1AGQAGABADADQADABACADIADAEQABAAAAAAQAAABAAAAQAAAAAAAAQAAABAAAAQAEADgCACIgDABIAAAFIACACIgBABIgBAFIgDAEIgCADIgBACQAAAAAAABQAAAAAAAAQAAAAAAAAQAAAAAAAAIgBACIgBABIAAABQgDACABAHQgBAFgFAFIgJAGIAAAFIAAABIABADIgCAGQgBADgEACQgDABgEABIgcAEQgfADgeACIgOABQgIABgHACQgBABAAAAQAAAAAAABQABAAAAABQABAAAAABQABAAAAABQAAAAAAAAQAAABgBAAQAAABAAABIgBABIgFAHIgEAFIgEAEIgEACQgEACgHAAIgNAAIgRAAIgJgBIgJgBQgVgCgNAAQgJgBgMACIgDAAIgXACIgDAAIgZABIgEAAIgXACIgEAAIgaABIgKAAg");
	this.shape_383.setTransform(7.4,1.4);

	this.shape_384 = new cjs.Shape();
	this.shape_384.graphics.f("rgba(213,255,255,0.388)").s().p("AhCBaIgSgCIgDAAQgJgBgIgDIgIgDIgcgIIgHgDIgMgDIgMgEIgCgEIAAAAIgBgEIgBgHIAAgDQgLgDgOgBQgLgBgNABIgOACIgGABIgDAAQgEAAgDgCQgDgDAAgCIgCgCQAAgBAAAAQgBgBAAAAQAAAAAAgBQAAAAAAgBIgBgCQgagEgUgFQgQgEgNgGQgJgDgGgEIgBgBQgHgFABgHIAAgBQACgFAFgDIADgBQAIgDALAAIALAAIAKgBIACgCIABgBQAAAAAAAAQAAAAAAgBQgBAAABAAQAAAAAAAAIAAgBIACgEQACgDAFgDIAKgEQAKgDANABQANADALAAIAQgBQAHAAAEgDIADgEIADgCQABgDAFgBIAAgCIABgBIAFgEQAEgEAHgDQAPgEATgDIAQgBIAbgCIASgCIAHgBIAPgCIAHgBIAOgBIAFAAQAKAAAHACIAFAEIAAAAIADAFIAAABIAHAAIAMgBIAngGIATgDIAOgCIAPgBIAMAAIAAAAIAJABIAQAAQA4AAAiAGIAFABQAIACADADIACAEIAAACQAAAAAAABQAAAAAAAAQAAAAAAABQAAAAABAAIAAABIACADQATAAAbADQAgADAXAEQAGABADACQADABACAEIADAEIABACQADAEgEACIgDABQgCACABADIAAABIgBACIgBAEIgDAFIgCADIAAACIAAAAQgBAAAAABQAAAAAAAAQABAAAAAAQAAAAABABIABACQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAABIAAAAQgCADACAHQAAAFgFAGQgEADgFADIAAAFIAAABIAAADQAAADgCACQgCADgEADIgIACIgcAEQggAEggACIgOABIgQADQAAAAAAABQAAAAAAABQAAAAAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQAAABgBABIgBACIgGAGIgDAFIAAABIgEADIgFADQgEABgHABIgOAAIgRAAIAAAAIgKgBIgIgBIgkgDIgWABIgDAAIgXACIgEAAIgaABIgEABIgYABIgDAAIgcABIgKAAg");
	this.shape_384.setTransform(7.3,1.4);

	this.shape_385 = new cjs.Shape();
	this.shape_385.graphics.f("rgba(213,255,255,0.404)").s().p("AhDBdIgTgCIgDAAQgJgBgJgCIgIgDIgdgJIgIgDIgMgDQgHgCgFgDIgCgEIAAAAIgBgEIAAgHIABgEQgLgDgOgBQgMgBgNABIgPACIgFACIgEgBQgFABgCgCQgEgCgBgDIgCgCIgCgEIgCgCQgbgEgUgFIgfgKQgJgDgGgFIgBgBQgHgFABgHIAAgBQABgGAFgDIAEgBQAIgDAMAAIALAAIAKgBIADgCIAAgBQAAgBAAAAQgBAAAAAAQAAAAAAAAQAAgBAAAAIABAAQgBgCACgDQACgDAEgDQAFgEAGgBQALgDANACQAOACAKAAIASAAQAHAAAEgDIADgEIACgDQACgDAEgBIABgCIABgBIAFgEQAFgEAIgDQAPgEAUgDIAQgBIAcgDIASgCIAIgBIAQgCIAHgBIAOgBIAGAAQAKAAAHACIAFAEIABAAIADAGIAAAAIAHAAIAMAAIApgHIATgDIAPgCIAPgBIANAAIAAAAIAKABIAQAAQA7AAAiAGIAFABQAJACADADIADAEQgBAAAAAAQAAABAAAAQAAAAAAABQAAAAABAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAABABIAAABIACACIAwADQAhAEAYAEIAKADQADACACADIADAFQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAQACAEgGACIgDABQgDACAAADIABACIgCACIgBADIgDAFIgDADIAAADIABAAQAAAAAAAAQAAABAAAAQAAAAABAAQAAAAABABIADABQAAAAAAAAQABABAAAAQAAAAAAAAQAAAAAAABIAAAAQAAADACAHQABAGgFAGQgEAEgFADIAAAFIgBABIAAADQAAACgDADQgBADgFADIgHACIgeAEQghAEghACIgPABIgQAEQAAAAgBAAQAAABAAAAQAAABAAAAQABABAAABQAAAAAAAAQAAABAAAAQAAAAgBABQAAAAAAABIgCACIgFAHIgEAFIAAABIgDADIgGADQgEACgHAAIgOAAIgSABIgBAAIgJgBIgJgCQgXgDgOAAIgXABIgDAAIgYACIgEAAIgbABIgEAAIgZABIgDABIgdABIgKAAg");
	this.shape_385.setTransform(7.2,1.5);

	this.shape_386 = new cjs.Shape();
	this.shape_386.graphics.f("rgba(213,255,255,0.416)").s().p("AhFBgIgUgCIgDAAIgSgDIgJgDIgdgJIgIgDIgNgDIgMgFIgDgEIABgBIgBgEIACgIIABgEQgMgDgOgCQgMgBgOACIgPADIgGABIgEAAQgFAAgCgCQgFgBgBgDIgCgCIgEgEIgCgBQgcgFgVgGQgRgEgPgGQgJgDgGgEIgCgCQgHgFABgHIAAgBQABgGAFgDIAFgCQAHgDANAAIAMAAIAKgBIADgCQAAgBAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAIgCgCIAAgBQgBgBACgEQACgDAEgEQAFgDAGgCQALgDAOACQAPADAKAAIASAAQAIgBAEgDIADgEIACgDQACgDAFgBIABgCIABgBIAFgEQAFgEAIgDQAQgFAVgCIAQgCIAdgCIATgDIAJgBIAQgCIAHgBIAPgBIAGAAQAKAAAHACIAGAEIABAAIADAGIAAAAIAHABIANgBIAqgHIAUgDIAQgCIAPgBIANAAIABAAIAKABIAQAAQA+AAAjAGIAFABQAJACAEADQAAABABAAQAAABAAAAQABAAAAABQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAAAABQABAAAAAAQAAAAAAABQAAAAAAAAQAAABAAAAQABAAAAABIABABIACACIAyAEQAiADAZAFIAKADQADACACAEIADAFQAAAAAAAAQAAABAAAAQAAAAAAABQgBAAAAAAQACAEgHACIgEABQgEACAAADIAAACIgCACIgCAEIgDAFIgDADQAAAAAAAAQAAABAAAAQAAABAAAAQAAAAABAAIAAABQAAAAAAAAQAAABABAAQAAAAABAAQAAAAABAAIAFACIADABIAAABIAEALQACAGgFAGIgJAHIgBAFIAAABIgBAEQAAACgDADQgCADgFACQgDACgFABIgeAFQgiAEgiACIgQABQgJABgHADQgBAAAAAAQgBABAAAAQAAAAAAABQABAAAAABIgCAEIgCACIgGAHIgDAFIAAABIgDAEIgGADIgMACIgPAAIgSAAIgBAAIgJgBIgKgCQgXgDgPAAQgKgBgNACIgDAAIgaACIgDAAIgcABIgFAAIgZABIgEABIgdABIgLAAg");
	this.shape_386.setTransform(7.1,1.5);

	this.shape_387 = new cjs.Shape();
	this.shape_387.graphics.f("rgba(213,255,255,0.431)").s().p("ACXBjIAAAAIgLgBIgJgCQgYgEgQAAQgKgBgOACIgDAAIgaACIgEAAIgdABIgFAAIgaABIgEABIgeABIgLAAIgUgBIgEAAQgKgBgJgDIgIgCIgfgKIgIgCIgNgEQgIgDgFgDQAAAAgBgBQAAAAAAgBQAAgBgBAAQAAgBAAAAIAAgBIAAgEIADgJIACgEQgMgDgPgCQgNgBgOACIgPADIgGACIgEgBQgFABgDgCQgFgBgCgCIgDgCIgEgEIgDgCQgcgFgXgGIgggKQgKgDgGgFIgCgBQgHgGAAgHIAAgBQABgGAGgEIAEgCQAIgDANABIAMgBIALgBQAAgBABAAQAAAAABAAQAAgBAAAAQAAAAAAAAIABgCQgBAAAAAAQgBAAAAgBQAAAAgBAAQAAgBAAAAQgBgCACgEQABgDAFgEQAFgEAGgCQALgDAOACQAQADAKABIATgBQAIAAAEgDQACgBABgDQAAgBAAgBQABAAAAgBQAAAAABgBQAAAAAAAAQACgDAFgBIABgCIACgBIAGgEQAFgEAIgDQARgFAVgCIARgCIAegDIAUgCIAJgBIAQgDIAIgBIAPgBIAGAAQALAAAHADIAGADIABABIADAFIABAAIAHABQAGABAIgCIArgHIAUgDIARgCIAPgBIAOAAIABAAIAKABIARABQBAgBAjAGIAGABQAJACAEADIADAEQAAAAAAAAQAAABAAAAQAAAAABABQAAAAAAAAQAAAAAAABQAAAAABAAQAAABAAAAQABAAAAABIAAABIAEACIAzAFQAkADAZAFIAKADQADACACAFIACAFQABAAAAAAQAAABAAAAQAAAAgBABQAAAAAAABQAAADgIADIgFABQgEACgBACIAAACIgCACIgCAEIgEAGIgCADQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAIABABQAAAAAAAAQABABAAAAQABAAABAAQAAAAABAAIAHACQABAAABAAQAAAAABAAQAAAAAAABQAAAAAAAAIABABIAGALQADAHgFAGQgEAEgGAEIgBAFIAAABIgBADIgEAGQgCADgFACIgIADIgfAFQgjAEgkACIgQACQgJABgIACQAAAAgBABQAAAAAAABQAAAAAAABQAAAAAAABIgDAEIgCACIgGAHIgDAGQgBACgDACIgFADQgEACgJAAIgPABIgTAAg");
	this.shape_387.setTransform(7.1,1.6);

	this.shape_388 = new cjs.Shape();
	this.shape_388.graphics.f("rgba(213,255,255,0.443)").s().p("ACcBmIAAAAIgLgCIgKgBQgYgEgRgBIgYABIgEAAIgbADIgEAAIgeABIgFAAIgbABIgEAAIgfABIgLAAIgVgBIgDAAQgLAAgJgCIgJgDIgggKIgIgDIgOgEQgIgCgEgDQgCgDAAgDIAAAAIAAgEIAEgKIADgEQgNgEgPgBQgNgBgPACIgPADIgHACIgEgBQgFABgEgBQgFgBgCgCIgDgCIgGgFIgDgBIg0gLQgSgFgQgFQgLgEgGgEIgCgCQgHgGABgIIgBgBQABgGAGgEIAEgBQAIgEAOAAIAMAAIALgCQABAAABAAQAAgBAAAAQABAAAAAAQAAgBAAAAQABAAAAAAQAAgBAAAAQAAAAAAAAQAAAAgBAAQAAAAgBgBQgBAAAAAAQAAAAgBgBQAAAAAAgBIAAAAQgCgCACgEQABgDAFgFQAFgEAGgCQAMgDAPACQAPADALABIAUAAQAIAAAEgEQACgBABgDQAAgBAAAAQAAgBABgBQAAAAAAgBQABAAAAgBQACgCAFgBIACgCIACgCIAGgDQAFgEAJgDQARgFAWgDIASgCIAegDIAVgDIAJgBIARgCIAIgBIAQgBIAGAAQALAAAIACQAEABACACIAAABIAFAGIAAAAIAIABIAOgBIAsgHIAVgEIARgBIAQgBIAOgBIABABIALABIARABQBDgBAkAGIAGABQAKACADADIAEADQAAABAAAAQAAABAAAAQAAAAABAAQAAABABAAQAAAAAAABQAAAAAAAAQAAABABAAQAAAAABAAIAAABIAEACIA1AGQAlAEAaAFIAKADQADACACAFIACAGQABAAAAAAQAAABgBAAQAAAAAAABQAAAAgBAAQAAAEgKADIgFABQgFABgCADIAAADIgDACIgCADIgEAGQAAAAAAABQgBAAAAAAQgBABAAAAQAAABAAAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAAAAAIABABQABACAFAAIAJACQABAAAAAAQABAAABAAQAAAAABABQAAAAAAAAIABAAIAIANQADAGgFAHQgDAEgGAEIgBAFIgBACIgBADIgEAFQgDADgFACIgIAEIggAEIhJAIIgRABQgJABgJACQAAABgBAAQAAABAAAAQAAABAAAAQAAABAAABIgEADIgCACIgGAHIgDAHIgEAEQgCACgDACQgFABgIAAIgQABIgUAAg");
	this.shape_388.setTransform(7,1.7);

	this.shape_389 = new cjs.Shape();
	this.shape_389.graphics.f("rgba(213,255,255,0.455)").s().p("AChBpIAAAAIgLgBIgLgCQgYgEgRgBQgMgBgOACIgDAAIgcACIgEAAIgfABIgGAAIgbACIgEAAIggABIgMABIgWgBIgDgBQgLAAgJgCIgJgDIghgKIgJgDIgOgEQgIgDgFgDQgCgDAAgCIABgBQgBgDABgCIAFgKIAEgEQgNgEgQgCQgNgBgPADQgGAAgKADIgHACIgFAAQgFABgEgBQgFgBgDgCIgEgCIgHgFIgDgCQgegFgYgGQgTgFgQgFQgLgEgGgEIgCgCQgIgHABgHIAAgBQABgHAFgEIAFgCQAIgDAOAAIANAAIALgCIADgCQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAgBAAAAIgEgCQgCgDABgEQABgEAFgFQAFgEAHgCQAMgDAPACQAQAEALAAIAUAAQAJAAAEgDQACgCABgDQAAgBAAgBQAAAAABgBQAAAAAAgBQAAAAABAAQACgEAFgBIACgCIACgBIAHgEIAOgGQASgFAXgDIASgDIAggDIAVgDIAKgBIARgCIAIgBIARgCIAGAAQAMAAAIADQAEABACADIAAAAIAFAGIAAAAIAIABIAPAAIAtgIIAWgEIASgBIAQgBIAPgBIABAAIALACIASAAQBFAAAlAGIAGABQAKACAEADIADADQAAABAAAAQABAAAAABQAAAAABAAQAAAAABABQAAAAAAAAQAAABAAAAQABAAAAABQABAAAAAAIABABIAEADIA3AFQAmAEAbAFQAGACAEACQADACACAFIACAGQAAABAAAAQAAAAAAABQAAAAAAAAQgBABAAAAQgBAEgMACIgFABQgGACgCADIgBACIgDACIgCAFIgFAFIgCADQAAABAAAAQAAABAAAAQAAAAAAABQAAAAABAAIABABQABABAFAAIAMACQAEAAABABIABABIAKANQAEAHgFAHQgDAFgGADIgCAGIgBABIgBADIgFAGQgCADgGACIgIADIgiAFIhLAIIgRABIgSAEQgBAAAAABQgBAAAAABQAAAAAAABQAAAAAAABIgEADIgDACIgGAIIgDAGIgEAFIgGAEQgEABgJABIgQAAIgVAAg");
	this.shape_389.setTransform(7,1.7);

	this.shape_390 = new cjs.Shape();
	this.shape_390.graphics.f("rgba(213,255,255,0.471)").s().p("ACnBsIgBAAIgLgBIgLgCQgZgEgSgBQgMgBgPABIgDAAIgdACIgEAAIggABIgGABIgcABIgEAAIghACIgMAAIgWgBIgEAAQgMAAgJgDIgJgCQgPgEgTgHIgJgCIgOgFQgJgDgEgDQgCgDAAgDIAAgBQAAgCABgDIAGgKIAFgFQgNgEgQgBQgPgBgPACQgGABgLADIgHACIgEAAQgGABgEgBQgGgBgDgCIgEgCIgIgEIgEgCQgfgGgZgGQgTgEgRgGQgLgEgHgFIgCgBQgIgHABgHIAAgCQABgHAFgEIAFgCQAIgEAPABIANgBIAMgCQABAAAAAAQABAAAAgBQAAAAABAAQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAAAgBAAQgDgBgBgCQgDgDABgEQABgFAFgEQAFgFAHgCQAMgEAQADQARAEALAAQAIABANAAQAJAAAEgEIADgFQAAgBAAgBQAAAAABgBQAAgBAAAAQAAAAABgBQACgDAGgCIACgBIACgCIAHgDQAGgEAJgDQASgFAYgDIATgCIAggEIAWgDIAKgBIASgDIAJgBIAQgBIAHAAQAMAAAIADQAEABADACIAAABIAFAFIABABIAIABQAGABAKgCIAugHIAWgFIASgBIARgBIAQgBIAAAAIALACIATABQBIAAAmAGIAGABQAKABAEADIAEAEIADACQAAABAAAAQABAAAAABQAAAAABAAQABABAAAAIABABIAEACIA4AGQAoAEAbAGQAHABAEADQADACACAFIACAGQAAABAAAAQAAABAAAAQAAABgBAAQAAABgBAAQgCAEgNACIgFABQgHACgDADIgBACIgDACIgDAEIgFAGIgCADQAAABAAABQAAAAAAAAQAAABAAAAQABAAAAAAIABABQACACAGAAIANABIAGACIACAAQAEADAIALQAFAIgFAHQgEAFgGADIgCAGIgBABIgBADIgFAGQgDADgGACQgDACgGABIgiAGQgnAFgmADIgSABIgTAEQgBABAAAAQgBAAAAABQAAAAAAABQAAAAAAABIgFADIgDADQgEADgCAEQgCADgBAEQgBADgDACIgGAEQgFABgJABIgRAAIgLABIgJgBg");
	this.shape_390.setTransform(6.9,1.8);

	this.shape_391 = new cjs.Shape();
	this.shape_391.graphics.f("rgba(213,255,255,0.482)").s().p("ACrBwIAAAAIgMgCIgLgCQgagEgTgCIgbABIgDAAIgeACIgEAAIghABIgGABIgdABIgEAAIgiACIgNAAIgWgBIgEAAQgMAAgKgCIgJgDIgjgLIgJgCIgPgFQgJgDgEgEQgCgDAAgDIAAgBIACgFIAHgLIAFgFQgNgEgRgCQgPgBgPADQgGABgLADIgIACIgEABQgGABgEgBQgHgBgDgBIgFgCIgJgFIgFgCQgfgGgagGQgUgFgSgGQgLgDgHgFIgCgCQgIgHAAgIIAAgBQABgHAGgFIAFgCQAIgEAQABIANgBIAMgCQABAAABAAQAAgBABAAQAAAAAAgBQAAAAAAAAQABgBAAAAQAAAAAAAAQAAAAgBgBQAAAAAAAAQgFgBgBgBIAAgBQgDgCABgFQABgFAFgFQAFgEAHgDQANgDAQACQARAFAMAAIAVAAQAJAAAFgDIACgGQABgDABgCQADgDAFgCIADgBIACgCIAIgEIAPgGQATgFAYgDIAUgDIAhgEIAXgDIAKgBIASgDIAKgBIARgBIAGAAQANAAAIADIAHADIABABIAFAFIABABIAIABQAHABAJgBQAXgDAZgFIAXgFIASgBIASgBIAQgBIAAAAIAMADIATAAQBKAAAnAGIAGABQAKABAFADIAEAEIAEACQAAABAAAAQAAAAABABQAAAAABAAQAAAAABABIABABIAFACIA6AHQApAEAcAGQAHABADADQAEADABAFIACAGQAAABAAAAQAAABAAAAQAAABgBAAQAAAAgBABQgDAEgOACIgGABQgIACgDADIgCADIgDACIgDAEIgFAGQgBAAAAAAQAAABgBAAQAAABAAAAQgBABAAAAQAAABAAAAQABABAAAAQAAAAAAABQAAAAABAAIABABQACACAHAAIAPABIAIACIACAAQAFADAJALQAFAIgFAIQgDAFgHAEIgCAFIgBACIgCADIgFAGIgJAFIgJADIgkAGQgnAFgoADIgSACIgUAEQgBAAAAAAQgBABAAAAQgBABAAAAQAAABAAAAIgFAEIgDACIgHAIIgDAHIAAAAIgEAFIgGAEQgFACgJAAIgRABIgMAAIgKAAg");
	this.shape_391.setTransform(6.9,1.9);

	this.shape_392 = new cjs.Shape();
	this.shape_392.graphics.f("rgba(213,255,255,0.498)").s().p("ACwBzIgBAAIgMgCIgLgCQgbgFgTgBIgcAAIgDAAIgfACIgEAAIgiACIgGAAIgeABIgEABIgjABIgNABIgXgBIgFAAQgMAAgKgCIgJgDIgkgLIgJgDIgPgFQgKgDgEgEQgCgDAAgDIAAgBIACgGIAJgLIAGgFQgOgFgRgBQgQgBgQADQgGAAgLAEIgIACIgEABQgHABgEgBQgHAAgDgCIgGgBIgLgFIgEgCQghgGgagHIgngLQgMgDgHgFIgCgCQgIgHAAgIIAAgCQABgHAGgFIAFgCQAIgEAQAAIAOAAIANgCQAAAAABgBQAAAAABAAQAAAAAAgBQAAAAABgBQAAAAAAAAQAAgBAAAAQgBAAAAAAQAAAAAAgBQgFgBgCgBIAAgBQgDgCABgGQAAgEAFgGQAGgFAHgCQANgEARADQASAFAMAAIAVABQAKAAAEgEIADgGQAAgEACgBQACgEAGgBIADgCIACgBIAIgEIAQgGQAUgFAZgEIAUgDIAigEIAXgDIALgCIATgCIAJgBIASgCIAHAAQANAAAJADIAHAEIAAAAIAGAGIAAAAIAJACIARAAIAxgJIAYgEIASgBIATgCIAQAAIABAAIALACIAUABQBNgBAnAGIAHABQAKACAFADIAFADQAAABAAAAQAAAAAAABQABAAABAAQAAABABAAQAAAAABABQAAAAAAAAQABABABAAQAAAAABAAIABABIAFADIA8AHQAqAFAdAFQAHACAEADQADACACAGIACAHQAAAAgBABQAAAAAAABQAAAAgBABQAAAAgBAAQgDAFgQACIgHABQgIACgEADIgDACIgDADIgDAEIgFAGQgBAAgBABQAAAAAAABQgBAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAIABAAQADACAHAAIASACIAIABIACAAQAGAEAKALQAGAJgFAIQgDAFgHAEIgCAFIgBACIgCADIgGAGIgKAGIgJACIgkAGIhSAJIgTACIgUAEQgEABAAADIgGADIgDACIgHAIIgDAHIAAABIgDAFIgHAEQgFACgJAAIgSABIgNAAIgJAAg");
	this.shape_392.setTransform(6.9,2);

	this.shape_393 = new cjs.Shape();
	this.shape_393.graphics.f("rgba(213,255,255,0.51)").s().p("AC0B2IgBAAIgMgCIgMgCQgbgFgUgBQgNgBgQABIgDAAIggACIgEAAIgjABIgFABIggABIgFAAIgkACIgNABIgYgBIgEAAQgNAAgJgCIgKgDQgRgEgUgHIgKgDIgPgFQgKgDgEgEQgCgDAAgEIABgBQAAgDACgDQAEgHAFgFIAHgFQgOgFgSgCQgPgBgRAEQgGABgMAEIgIACIgEAAQgHACgFgBQgHAAgEgBIgGgCIgMgFIgFgCIg9gNIgngLQgNgEgHgFIgCgCQgJgHABgIIAAgCQABgIAGgEIAFgDQAIgEARAAIAOAAIANgCQABgBAAAAQABAAAAgBQABAAAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQgBgBAAAAQgFgBgCgCIgBAAQgDgDAAgGQABgFAFgFQAGgFAHgDQANgEARADQATAFAMABQAIABAPgBQAJAAAFgEIACgGQABgEABgBQADgEAGgBIADgCIADgBIAIgEIAQgGQAVgGAZgDIAVgDIAjgEIAYgEIALgBIATgDIAKgBIATgCIAGAAQAOAAAJADIAHAEIABABIAFAFIABABIAJABQAHABAKgBQAZgDAZgFIAZgFIAUgBIASgCIARAAIABAAIAMACIAUABQBPAAAoAFIAHABQALACAFADIAFADIAEADQABAAAAAAQAAABABAAQAAAAABABQABAAAAAAIABABIAGADQAYACAlAFQAsAFAdAGQAIACADADQAEADABAFIACAIQAAAAAAABQAAAAAAABQgBAAAAAAQgBABgBAAQgEAFgSACIgHABQgJACgEADIgDADIgEACIgDAEIgGAGQAAABAAAAQgBAAAAABQAAAAgBABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAABABQAAAAAAAAIACABQADACAIAAIAUABIAJACIADAAQAHAEALAMQAHAJgFAIQgEAFgGAEIgDAGIgBABIgDAEIgGAGIgKAFIgKADIglAHIhUAJIgTACIgVAEQgEABAAACIgHAEIgDACQgFAEgDAEIgCAHIAAABIgEAGIgGAEQgFABgLABIgSAAIgMAAIgKAAg");
	this.shape_393.setTransform(7,2);

	this.shape_394 = new cjs.Shape();
	this.shape_394.graphics.f("rgba(213,255,255,0.525)").s().p("AC4B5IAAAAIgNgCIgMgCQgcgFgUgCQgOgBgQABIgDAAIghACIgFAAIgjACIgFAAIghACIgFAAIglACIgNAAIgZAAIgEAAQgNAAgKgCIgKgDQgRgEgVgHIgKgDIgQgGQgKgDgEgEQgCgEAAgDIABgBIACgGIALgNIAIgGQgPgFgSgBQgQgBgRADIgTAFIgHADIgFAAQgHACgFAAQgIAAgEgCIgHgBIgNgFIgFgDIg/gNQgVgFgUgGQgNgEgHgFIgCgCQgJgHAAgJIAAgCQABgIAHgFIAEgCQAJgFASABIAOgBIANgCQABAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAAAAAQgBAAAAgBQgGgBgCgCIAAAAQgEgDAAgGQAAgFAGgGQAFgFAIgDQANgEASADQATAFANABIAXABQAKAAAEgFQACgCABgEQAAgEACgBQACgEAHgCIADgCIADgBIAJgEIARgGQAVgFAagEIAVgDIAkgFIAZgDIALgCIAUgDIAKgBIATgBIAHAAQAOAAAJADIAIADIAAABIAGAGIABAAIAJACQAHABALgBQAZgEAagFIAagFIAUgBIATgBIARgBIABAAIAMADIAVABQBSgBApAGIAHABQAKABAGADIAFAEIAFACQABACAEABIAAABIAHADIA/AHQAtAGAdAGQAIACAEADQADACACAGIABAIQAAABAAAAQAAABAAAAQgBABAAAAQgBABgBAAQgFAFgTACIgIABQgKACgFADIgDACIgEADIgDAEIgGAGQgBABAAAAQgBABAAAAQAAABAAAAQgBABAAAAQAAABAAABQAAAAABABQAAAAAAAAQABABAAAAIACAAQAEACAIAAIAWACQAHAAADABIADAAQAIAEAMANQAIAJgFAJQgDAFgHAFIgDAFIgCACIgCADIgIAGQgDADgHADIgJADIgnAGQgrAGgrAEIgUACIgVAEQgEABgBACIgHAEIgEACQgEAEgDAEIgDAIIAAAAQgBADgDADQgDADgDACIgQACIgSAAIgOABIgKgBg");
	this.shape_394.setTransform(7,2.1);

	this.shape_395 = new cjs.Shape();
	this.shape_395.graphics.f("rgba(213,255,255,0.537)").s().p("AC8B9IAAAAIgNgCIgNgDQgcgFgVgCQgOgBgQABIgEAAIgiACIgEAAIgkACIgGAAIghABIgFABIgmACIgPABIgYgBIgFAAQgOAAgKgCIgKgCQgRgFgWgHIgKgDIgQgGQgKgEgFgEQgCgDABgEIAAgBQABgEACgDQAGgIAGgFIAJgGQgQgFgSgBQgRgBgRADQgGABgNAFIgIACIgFABQgHACgFAAQgJAAgEgBIgIgCIgNgFIgGgDQgjgGgegHQgVgFgVgHQgNgDgHgGIgDgBQgJgIABgJIgBgCQABgIAHgFIAFgDQAJgFASABIAPgBIANgCQABAAAAgBQABAAABAAQAAgBAAAAQAAAAAAgBQABAAAAAAQAAgBgBAAQAAAAAAAAQgBgBAAAAQgHgBgCgCIAAgBQgFgDAAgGQABgFAFgGQAGgGAHgDQAOgEATAEQATAFANABQAIABAQgBQAKABAEgFQACgCABgEQAAgFACgBQACgEAHgCIAEgCIADgBIAJgEQAHgDAKgDQAWgFAbgEIAVgDIAmgFIAZgEIAMgCIAUgDIALgBIATgBIAHAAQAOAAAKADQAFABADADIAAAAIAHAGIAAAAIAJACQAIACALgCQAagDAbgGIAagFIAUgBIAUgBIASgBIAAAAIANADIAWABQBUgBApAGIAIABQALABAFADIAGADQAAACAFABIAFADIABABIAHADIBBAIQAuAFAeAHQAIACAEADQAEADABAGIABAIQAAACgDACQgGAFgVACIgIABQgLACgFADIgEADIgEACIgEAEIgGAHQgCACgBACQAAAAABABQAAAAAAABQAAAAABABQAAAAAAAAIACABQAEACAKAAIAYABIALACIADAAQAJAEANANQAIAKgEAJQgEAGgHAEIgDAGIgCABIgCAEIgIAGQgEADgHACIgKADQgSAEgVADIhZAKIgUACIgWAEQgEACgBACIgIAEIgEACQgFADgCAFQgCADgBAFIAAAAQgBAEgDADIgHAEQgFACgLABIgTAAIgNAAIgLAAg");
	this.shape_395.setTransform(7.1,2.2);

	this.shape_396 = new cjs.Shape();
	this.shape_396.graphics.f("rgba(213,255,255,0.553)").s().p("ADBCAIgBAAIgNgCIgNgDQgdgGgWgBQgOgCgRABIgEAAIgiADIgFAAIglABIgGAAIgiACIgFAAIgnACIgPABIgZAAIgFAAQgOAAgKgCIgLgCQgRgFgWgHIgLgEIgQgGQgLgDgEgFQgCgDAAgEIABgBQAAgEADgDQAHgJAGgFIAKgGQgQgGgTgBQgRgBgSAEQgGABgNAEIgIADIgGABQgHACgFAAQgJABgFgCIgIgBIgPgFIgGgDIhCgOIgsgMQgNgDgIgGIgCgCQgJgHAAgKIAAgCQAAgIAHgGIAFgCQAJgFATAAIAPAAIAOgCQABAAAAgBQABAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAAAgBgBQgGgBgDgCIgBgBQgFgDABgGQAAgGAFgGQAGgGAIgDQAOgFATAEQAUAGANABIAYABQALAAAEgFQACgCABgEQAAgFACgCQACgEAHgCIAEgBIADgCIAKgDQAIgEAKgCQAWgGAcgEIAWgDIAmgFIAagEIAMgCIAVgDIALgBIAUgCIAHAAQAPAAAJADQAFACAEACIAAABIAHAGIABAAIAJACQAIABALgBQAagDAcgGIAbgFIAVgCIAUgBIASAAIABAAIANACIAWABQBXAAAqAFIAIABQALACAGADIAGADQAAABAFACQABABAFACIABABIAHACIBCAJQAwAGAfAGQAIACAEADQAEAEABAGIABAIQAAADgEABQgHAFgWADIgIABQgMACgGADIgEADIgEACIgFAEIgGAHQgCACgBACQAAABABAAQAAABAAAAQAAABABAAQAAABABAAIACAAQAEADALgBIAZACIANABIADABQAKAEAOANQAJAKgFAKQgDAFgHAFIgEAGIgBABIgDAEIgJAGQgEADgHADIgKADQgSAEgWADIhbAKIgVACQgLACgLADQgFABgCACIgIAEIgEACQgFAEgDAEIgCAIIAAABQgBADgDADQgDADgEACQgFACgLABIgUAAIgOAAIgKAAg");
	this.shape_396.setTransform(7.1,2.3);

	this.shape_397 = new cjs.Shape();
	this.shape_397.graphics.f("rgba(213,255,255,0.565)").s().p("ADFCDIgBAAIgNgCIgOgDQgcgGgXgBQgPgCgRABIgEAAIgjACIgFAAIgmACIgGAAIgjACIgFAAIgoACIgPABIgaAAIgFAAQgPAAgKgBIgLgDQgSgEgWgIIgLgEIgRgGQgLgEgEgEQgCgEAAgEIABgBQABgEADgEQAHgIAHgGIAKgGQgQgGgTgBQgSgBgSAEQgHABgNAFIgIADIgGABQgHACgGAAQgJABgGgBIgIgCIgQgFIgHgDQgkgHgggHIgsgMQgOgEgIgFIgCgCQgKgIAAgKIAAgCQABgJAHgFIAFgDQAJgFATABIAQgBQAJgBAFgCQAAAAABAAQABgBAAAAQABgBAAAAQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAgBgBAAQgHgBgDgDQgGgDAAgHQAAgGAGgHQAGgGAIgDQAOgFAUAFQAUAFANACQAJABAQgBQALABAFgFQACgCAAgFQABgFABgBQADgFAHgCIAEgCIAEgBIAKgDQAIgEAKgCQAXgGAcgEIAXgEIAngFIAbgEIAMgCIAWgDIALgBIAUgCIAHAAQAQAAAKAEQAFABADACIABABIAHAGIAAAAIAKADQAIABALgCQAcgDAcgGIAbgFIAWgCIAUgBIATgBIABABIAOACIAWABQBZAAArAFIAIABQALACAHADIAGADQABABAFACIAGADIABABIAHADIBFAIQAxAGAfAHQAJACAEAEQADADACAHIABAIQgBADgEACQgIAFgXACIgJABQgNACgGADIgEADIgFACIgFAFIgGAGQgDACAAADQAAAAAAABQAAAAAAABQABAAAAABQABAAABAAIACABQAFACALAAIAcACIANABIADAAQALAEAQAPQAJAKgEAKQgDAGgIAFIgEAGIgCABIgDAEIgJAGQgEADgHACIgLADIgpAIIhdALIgVACIgXAEQgFACgCACIgJAEIgEACQgGADgCAFIgDAJQAAADgDAEQgEADgEABQgFACgMABIgUABIgZgBg");
	this.shape_397.setTransform(7.1,2.3);

	this.shape_398 = new cjs.Shape();
	this.shape_398.graphics.f("rgba(213,255,255,0.58)").s().p("ADJCHIAAAAIgOgCIgOgEQgegGgXgCQgPgBgRABIgEAAIglACIgFAAIgmACIgHAAIgkACIgFAAIgpACIgPABIgbAAIgFABQgPAAgKgCIgLgDQgTgEgXgIIgLgEIgRgGQgLgEgFgFQgCgEABgEIABgBQABgEADgEQAHgJAIgGIALgGQgRgGgTgCQgSgBgTAFQgGABgOAFIgJADIgFABQgIADgGAAQgKABgFgBIgKgCIgRgFIgHgDQglgHgggHIgugMQgOgEgIgGIgDgCQgJgIAAgKIgBgCQABgJAHgGIAFgDQAKgFATABIAQgBQAJgBAGgCQABAAAAgBQABAAAAAAQABgBAAAAQAAgBAAAAQAAAAAAgBQAAAAAAgBQAAAAgBAAQgBAAAAAAQgIgCgDgCIgBAAQgFgEAAgHQgBgGAGgHQAGgHAIgCQAPgFAUAEQAVAGAOABIAZABQALAAAFgFQACgCAAgFQABgFABgBQADgFAHgCIAFgCIADgBIALgEIATgFQAXgGAdgFIAXgDIApgGIAbgEIANgCIAWgDIALgBIAVgCIAHAAQAQAAAKAEIAJADIABABIAHAGIABAAIAKADQAIABALgBQAcgEAegGIAcgFIAVgCIAWgBQANgBAGAAIABABIAOADIAXABQBbgBAsAFIAIABQAMACAGADIAHADQAAABAGACIAHADIABABIAIADIBGAJQAyAGAgAHQAJACAEAEQADADACAHIAAAJQAAADgEACQgJAFgZACIgJABQgOACgHAEIgFACIgFADIgEAEIgHAHQgDACAAACQAAADADABIACABQAGACALAAIAeABIAPACIADAAQAMAEARAPQAKALgFAKQgDAGgHAFIgFAGIgBACIgEADIgJAGIgMAGIgLADIgqAIIhgALIgVACIgYAFQgFABgCADIgKADIgEACQgGAEgDAFIgCAJIAAAAQgBAEgDADQgDADgEACQgGACgLABIgVAAIgaAAg");
	this.shape_398.setTransform(7.2,2.4);

	this.shape_399 = new cjs.Shape();
	this.shape_399.graphics.f("rgba(213,255,255,0.592)").s().p("ADOCKIgBAAIgPgDIgOgDQgegGgYgCQgPgBgSAAIgEAAIglACIgFAAIgoACIgGAAIglACIgGAAIgqADIgPABIgbAAIgFAAQgQABgLgCIgLgDQgTgEgYgJIgLgDIgSgHQgLgEgEgFQgCgEABgEIAAgCQABgEAEgDQAIgKAIgGIAMgHQgRgGgUgBQgTgBgSAEIgVAHIgJADIgGABQgIADgGAAQgKACgGgBIgKgCIgSgFIgIgDIhHgPIgvgMQgPgEgIgGIgCgCQgKgIAAgLIgBgCQABgJAHgGIAGgDQAJgGAUABIARAAQAJgBAFgCQABgBABAAQABAAAAgBQABAAAAgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQgBAAAAAAQgBgBAAAAQgJgBgDgDIgBAAQgGgEAAgHQgBgHAGgHQAGgHAJgDQAPgFAUAFQAWAGAOABQAIACASgBQALABAFgFQACgDAAgFQABgFABgCQADgFAHgCIAFgBIAEgCIALgDIAUgGQAYgFAdgFIAYgEIApgGIAcgEIANgCIAXgEIAMgBIAVgBIAHAAQAQAAALADIAJAEIABABIAHAGIABAAIAKADQAIABAMgCQAdgDAegGIAdgGIAWgBIAWgBQANgCAGABIABAAIAPADIAXABQBeAAAtAFIAIABQAMABAGADIAHADQABACAGABIAHADIACABIAIADIBHAKQA0AGAhAIQAJACAEADQADAEACAHIAAAJQAAADgFACQgJAGgbACIgJABQgPACgIADIgFADIgFADIgFAEIgHAHQgDACAAACQAAADADABIADABQAGADAMAAIAgABQAKAAAFABIAEABQANAEASAPQALALgFALQgDAGgIAFIgEAGIgCACIgEADIgKAHIgMAFIgLAEIgrAHIhiAMIgWACIgZAFQgFABgDADIgKADIgEADQgGADgDAFIgCAJIAAABQgBADgDAEQgDADgEACQgGACgMABIgVAAIgaAAg");
	this.shape_399.setTransform(7.2,2.5);

	this.shape_400 = new cjs.Shape();
	this.shape_400.graphics.f("rgba(213,255,255,0.608)").s().p("ADSCNIgBAAIgPgCIgOgEQgfgGgZgCQgPgCgSABIgFAAIgmACIgFAAIgoACIgHAAIgmACIgFAAIgrADIgQABIgcAAIgFABQgQAAgLgCIgLgCQgUgFgYgIIgLgEIgTgHQgLgEgFgFQgCgFABgEIABgBQABgFAEgEQAIgJAKgHIAMgHQgSgGgUgCQgTgBgTAFIgWAHIgJAEIgFABQgJADgGAAQgLACgGgBIgLgCIgTgFIgIgDIhJgPIgwgNQgPgEgIgGIgDgCQgKgIAAgLIAAgCQAAgKAHgGIAGgDQAKgGAUABIARAAQAKgBAFgCQABgBABAAQAAgBABAAQAAAAABgBQAAAAAAgBQAAAAAAgBQAAAAgBgBQAAAAAAAAQgBAAgBAAQgIgCgFgCIAAgBQgGgEgBgHQgBgHAGgHQAGgHAJgEQAPgFAVAFQAXAHAOABIAbABQALAAAFgFQACgCAAgFQABgGABgCQADgFAIgCIAFgBIAEgCIALgDIAUgGIA3gLIAYgDIArgHIAcgEIAOgCIAXgEIAMgBIAWgBIAHAAQARAAALADIAJAEIABABIAHAGIABAAIALADQAIABAMgBQAegEAegGIAegGIAWgBIAXgBQAOgCAGABIABAAIAPADIAYABQBgAAAuAFIAIABQAMABAHADIAHADQABACAGABIAIADIABABIAJADIBJAKQA1AHAhAIQAKACAEAEQADADACAIIAAAJQAAADgFACQgLAGgbACIgLABQgPACgIADIgGADIgFADIgFAEIgIAHQgDACAAADQAAADADABIADABQAHADANgBIAiABIAQACIAEAAQAOAFATAQQAMALgFALQgDAHgIAFIgFAGIgCABIgEAEIgKAGQgGAEgHACIgLADQgUAFgZADQgxAHgzAGIgWACIgZAFIgJADIgKAEIgFACQgGAEgDAFQgCAEAAAFIAAABQgBAEgDADQgDAEgFABQgFACgNABIgVABIgbgBg");
	this.shape_400.setTransform(7.3,2.5);

	this.shape_401 = new cjs.Shape();
	this.shape_401.graphics.f("rgba(213,255,255,0.62)").s().p("ADWCRIgBAAIgPgDIgPgEQgfgGgZgDQgQgBgTABIgEAAIgnACIgGAAIgpABIgHABIgmABIgGABIgsADIgQABIgdAAIgFAAQgQABgLgCIgMgCQgUgFgZgJIgLgEIgTgGQgMgFgEgFQgCgFABgEIABgCQABgEAEgEQAJgKAKgHIANgHQgSgHgVgBQgTgBgUAFQgHABgPAGIgJAEIgGABQgJADgGABQgLACgHgBIgLgCIgVgFIgIgDIhKgQQgagGgYgHQgPgEgJgGIgCgCQgLgIAAgMIAAgBQABgLAHgGIAFgDQALgGAVABIARgBQAJAAAGgDQABAAABgBQABAAAAAAQAAgBABAAQAAgBAAAAQAAgBAAAAQAAgBgBAAQAAAAgBAAQAAgBgBAAQgJgBgFgDIAAgBQgHgEgBgHQAAgHAGgIQAGgHAJgEQAPgFAWAFQAXAHAOABQAJACASAAQAMAAAFgGQACgCABgFQAAgGABgCQADgFAIgCIAGgCIAEgBIAMgEIAUgFIA4gLIAZgEIAsgHIAcgEIAOgDIAYgDIAMgBIAXgBIAIAAQAQAAAMADQAFABAEADIABAAIAIAHIABAAIAKADQAJABAMgBQAegEAggGIAegGIAXgCIAXgBQAOgBAHAAIABABIAPADQAJABAQAAQBiAAAvAFIAIABQAMABAHADIAIADQABABAHACIAIADIABABIAJADIBLAKQA2AIAiAHQAKADAEADQAEAEABAIIAAAKQgBADgFACQgLAGgdACIgLABQgQACgJADIgGADIgGADIgFAEIgHAHQgDADgBACQABADADACIADABQAHACANAAIAlABIARABIAEABQAPAEAUARQAMAMgEALQgDAHgIAFIgGAGIgCACIgEADIgLAHIgNAGIgLADIguAIIhmANIgXACIgaAFQgGABgDADIgLADIgFADQgGADgDAGQgCADAAAGIAAAAQgBAEgDAEQgDAEgFABQgGADgMAAIgWABIgQAAIgMAAg");
	this.shape_401.setTransform(7.3,2.6);

	this.shape_402 = new cjs.Shape();
	this.shape_402.graphics.f("rgba(213,255,255,0.631)").s().p("ADbCUIgBAAIgQgDIgPgEQgfgHgbgCQgQgCgTABIgEAAIgoACIgGAAIgqABIgHABIgnACIgGAAIgtADIgRABIgdABIgFAAQgRABgLgCIgMgDQgVgEgZgJIgMgEIgTgHQgMgFgEgGQgDgEACgFIABgBQABgFAEgEQAKgKAKgHIAOgHQgSgIgVgBQgUgBgUAFQgHACgPAGIgKADIgGACQgJADgHABQgMACgHgBIgLgBQgJgCgNgEIgJgDIhMgQQgagGgYgHQgQgEgJgGIgDgCQgKgJAAgMIgBgBQABgLAIgGIAFgEQALgFAVAAIASAAQAJgBAGgCQAEgCAAgCQAAgBAAAAQgBAAAAgBQAAAAgBAAQgBAAAAgBQgKgBgEgDIgBgBQgHgEgBgIQgBgHAGgIQAGgIAJgDQAQgGAXAGQAXAHAOABQAJACATAAQANAAAFgGQACgCAAgGQAAgFACgCQACgGAJgCIAGgCIAEgBIAMgDIAVgGIA5gLIAagEIAtgHIAdgFIAOgCIAZgEIAMAAIAXgCIAIAAQARAAAMADQAFACAEACIABABIAJAGIABABIAKADQAJABANgCQAegDAhgHIAegGIAYgBIAXgCIAWAAIABAAIAPADQAJACARAAQBkgBAwAFIAIABIAUAEIAIADIAIAEIAJADIABABIAKADIBMAKQA4AIAjAHQAJADAEAEQAEAEABAIIAAAKQgBADgFACQgMAGgfACIgLABQgRACgJAEIgGADIgHADIgFAEIgIAHQgDADAAACQAAADAEACIACABQAIACAOAAIAnABQAMAAAGACIAEAAQARAFAVARQAMAMgEALQgDAHgIAGIgGAGIgCACIgFADIgLAHIgOAGIgLADIguAJIhpAMIgXADIgbAFQgGABgEADIgMADIgEADQgHADgDAGIgCAJIAAABQAAAEgEAEQgDADgFACQgGADgNAAIgWABIgRAAIgLAAg");
	this.shape_402.setTransform(7.3,2.7);

	this.shape_403 = new cjs.Shape();
	this.shape_403.graphics.f("rgba(213,255,255,0.647)").s().p("ADeCXIgBAAIgPgDIgQgEQgggHgbgCQgRgCgTABIgEAAIgpACIgGAAIgrABIgHABIgoACIgGAAIguADIgRABIgeABIgGAAQgRABgLgCIgMgCQgVgEgagKIgMgEIgTgHQgNgFgEgGQgDgFACgEIABgCQABgFAEgEQALgLALgHIAPgHQgTgIgWgBQgUgBgVAFQgHACgPAGIgKAEIgGACIgQAEQgNACgHgBIgMgBIgXgGIgJgDIhOgQIg0gNQgQgFgJgFIgDgDQgKgIgBgNIAAgCQABgKAHgHIAGgEQALgFAWAAIASAAQAKgBAGgCQADgCAAgCQABgBgBAAQAAgBAAAAQgBgBAAAAQgBAAgBAAQgKgCgFgDIgBAAQgHgEgBgJQgBgHAGgJQAGgHAJgEQAQgGAXAGQAYAHAPACIAdACQAMAAAFgGQACgDABgFQAAgGABgCQADgGAJgCIAGgCIAEgBIANgDIAVgGIA7gLIAagFIAugHIAegFIAOgCIAZgEIANAAIAXgCIAJAAQARAAAMADQAGACAEACIABABIAIAGIABABIALADQAJABANgBQAggEAhgHIAfgGIAYgBIAYgCIAWAAIABAAIAPADQAKACARAAQBngBAwAFIAJABIAUAEIAIADIAJAEIAJADIABABIAKADIBPALQA5AIAjAHQAKADAEAEQAEAEABAIIAAALQgBADgGACQgNAGggADIgMABQgRACgKADIgHADIgGADIgGAFIgIAHQgDACgBADQABADADACIADABQAIACAQAAIAoABIATABIAFABQARAFAWASQAOAMgFAMQgDAHgIAFIgGAHIgCABIgFAEIgMAGIgOAHIgMADQgVAFgaAEIhrANIgYADIgbAFIgKADIgNAEIgFACQgHAEgDAGQgBAEAAAFIAAABQgBAEgDAEQgEAEgFACQgGACgNABIgXAAIgRAAIgMAAg");
	this.shape_403.setTransform(7.4,2.8);

	this.shape_404 = new cjs.Shape();
	this.shape_404.graphics.f("rgba(213,255,255,0.659)").s().p("ADjCaIgBAAIgQgDIgQgEQgggHgcgDQgSgCgTABIgFAAIgpACIgGAAIgsABIgHABIgpACIgHAAIgvAEIgRABIgeABIgGAAQgSABgLgCIgMgCQgWgFgagJIgMgFIgUgHQgNgFgEgGQgDgFACgFIABgBQABgFAFgFQALgLAMgHQAHgFAIgDQgTgIgWgBQgVgBgVAGIgXAIIgKAEIgGACQgKADgHABQgNADgIgBIgMgBQgKgCgOgEIgKgDIhPgRIg1gNQgRgFgJgGIgDgCQgLgJAAgMIAAgDQAAgKAIgHIAGgEQALgGAWABIATgBQAKAAAGgDQAEgCgBgCQAAgBAAAAQAAAAAAgBQgBAAAAAAQgBAAgBgBQgKgBgGgEIAAAAQgIgFgCgIQgBgIAHgIQAGgIAJgEQARgGAXAGQAZAHAOACQAKACAUAAQANAAAFgGQACgDAAgFQAAgGACgDQACgFAJgDIAHgBIAEgCIAOgDIAWgGIA7gLIAbgEIAvgIIAegFIAPgCIAagEIANgBIAYgBIAIAAQASAAAMADIAKAEIABABIAJAGIABABIALADQAJABAOgCQAggDAhgHIAggGIAZgCIAYgBIAXgBIABAAIAQAEQAJABASAAQBpAAAxAFIAJABIAVADIAIAEIAKADIAJADIACABIAKADIBQAMQA6AIAkAIQAKADAEAEQAEAEABAIIAAALQgBADgGADQgOAGghACIgMABQgTACgLAEIgGADIgHADIgGAEIgJAIQgDACAAADQAAAEAEABIADABQAJADAQgBIAqABQANAAAHACIAFAAQATAFAXATQAOAMgEAMQgDAIgJAFIgGAHIgDABIgFAEIgMAHQgGADgJADIgMADQgVAFgbAEIhtAOIgYADIgcAFIgLADIgNAEIgFADQgIADgCAGQgCAEAAAGIAAAAQAAAFgEAEQgEAEgEACQgGACgOABIgYAAIgRABIgMgBg");
	this.shape_404.setTransform(7.4,2.9);

	this.shape_405 = new cjs.Shape();
	this.shape_405.graphics.f("rgba(213,255,255,0.675)").s().p("ADnCeIgBAAIgQgEIgQgEQgigHgcgDQgSgCgUABIgEAAIgrACIgGAAIgsABIgIABIgqACIgGAAIgwAEIgSABIgfABIgGAAQgSABgMgCIgMgCQgWgEgbgKIgMgFIgUgHQgOgFgEgHQgCgEACgGIAAgBQACgFAFgFQALgLANgIQAIgFAIgDQgTgIgXgBQgVgBgWAGIgXAIIgKAEIgHACIgRAFQgNADgIgBIgNgBIgagGIgKgDIhRgRQgbgGgbgIQgRgEgJgGIgDgCQgLgJgBgNIAAgDQAAgLAIgHIAGgEQALgGAXABQALAAAIgBQAKAAAHgDQAEgCgBgCQAAgBAAAAQAAgBAAAAQgBgBgBAAQAAAAgBAAQgLgCgGgDIgBgBQgIgEgBgJQgCgIAHgJQAGgIAKgEQAQgGAYAGQAaAIAPACQAJABAVABQANAAAFgGQACgDAAgGQAAgGACgDQACgFAKgDIAGgBIAFgCIAOgDIAWgGIA9gLIAbgFIAwgHIAfgGIAQgCIAagEIANgBIAYgBIAJAAQASAAANADIAKAEIABABIAJAGIACABIALADQAJACAOgCQAggEAjgHIAhgGIAZgCIAZgBQAQgCAGABIACAAIAQAEQAJACASAAQBsgBAyAFIAJABIAVADIAJAEIAKADIAKADIABABIALADIBSAMQA7AJAlAIQAKADAEAEQAEAEABAJQABAJgBACQgBADgHADQgOAGgjADIgNABQgTACgLADIgIADIgHADIgGAFIgIAHQgEADAAADQABADADACIAEABQAJADAQgBIAtABQANAAAIACIAFAAQAUAFAYATQAPANgFANQgDAHgIAGIgHAGIgCACIgGAEIgNAGIgPAHIgMADQgWAFgbAEIhvAOIgZADIgdAFQgHACgEACIgOAEIgFACQgIAEgDAGQgBAEAAAGIAAABQgBAEgDAEQgEAEgFACQgGADgOAAIgYABIgSAAIgMAAg");
	this.shape_405.setTransform(7.5,2.9);

	this.shape_406 = new cjs.Shape();
	this.shape_406.graphics.f("rgba(213,255,255,0.686)").s().p("ADrChIgBAAIgRgDIgQgEQgigIgdgDQgSgCgUABIgFAAIgrABIgHAAIgtACIgIABIgrACIgGAAIgxAEIgSABIgfABIgGAAQgTABgMgBIgMgDQgXgEgbgKIgNgFIgVgHQgNgGgEgGQgDgFACgFIABgCQACgFAFgFQAMgMANgIQAIgFAJgDQgUgIgXgBQgWgBgVAGQgIACgQAHIgLAEIgGACQgKAEgIABQgOADgIAAIgOgCQgLgBgPgFIgLgDIhTgSIg3gNQgRgFgKgGIgDgCQgLgJgBgNIAAgDQABgLAIgHIAFgFQAMgGAXABIATAAQALgBAGgDQAFgCgBgCQAAgBAAgBQAAAAgBAAQAAgBgBAAQgBAAgBAAQgLgCgGgDIgBgBQgIgFgCgJQgCgIAHgJQAGgJAKgDQARgHAZAGQAZAJAQACQAJABAVAAQAOABAFgHQACgCAAgHQAAgGACgCQACgHAKgCIAHgCIAFgBIAOgDIAXgGIA+gLIAcgFIAxgIIAggGIAPgCIAbgEIAOgBIAYgBIAJAAQATAAANADIAKAEIABABIAKAGIABABIAMADQAJACAOgCQAhgEAjgHIAigGIAZgCIAagBQAQgCAHABIABAAIARAEQAJACATAAQBugBAzAFIAJABIAWADIAJAEIAKADIAKADIACABIALAEIBUAMQA9AIAlAJQAKADAEAEQAEAEABAKQABAIgBADQgCADgGADQgPAHglACIgNABQgUACgMAEIgIACIgHAEIgGAEIgJAIQgEACAAAEQABADAEABIADACQAKACARAAIAvABQAOAAAIABIAFABQAUAFAaAUQAPANgEANQgDAIgJAFIgHAHIgCACIgGAEIgNAGIgQAGIgMAEIgyAJIhyAPIgZADIgdAFIgMAEIgPAEIgFACQgIADgDAHQgBAEAAAGIAAABQgBAEgDAFQgEAEgFACQgGACgPABIgYABIgfgBg");
	this.shape_406.setTransform(7.5,3);

	this.shape_407 = new cjs.Shape();
	this.shape_407.graphics.f("rgba(213,255,255,0.702)").s().p("ADwCkIgCAAIgRgDIgRgFQgigIgegDQgSgCgVABIgEAAIgtACIgGAAIguABIgIABIgsACIgHABIgyADIgSABIggACIgGAAQgTABgMgBIgNgDQgXgEgcgKIgNgFIgVgIQgOgFgEgHQgCgFACgGIABgBQACgGAFgFQAMgMAOgIIASgIQgUgJgYgBQgWgBgWAGIgZAJIgKAFIgHACQgKAEgIABQgOAEgJgBIgOgBIgcgGIgLgDIhUgSIg5gOQgSgFgJgGIgDgCQgMgKgBgNIAAgDQABgLAIgIIAGgEQALgGAYABIAUgBQALgBAGgDQAEgCAAgCQAAgDgEAAQgMgCgGgDIgBgBQgJgFgCgJQgCgJAHgJQAGgJALgEQARgGAZAGQAaAJAQACQAJABAWABQAOAAAFgHQACgCAAgHQAAgGACgDQACgGAKgCIAHgCIAFgBIAPgEIAYgFIA/gMIAcgFIAygIIAhgGIAQgDIAbgEIAOAAIAZgCIAJAAQATAAANAEIALADIABABIAKAHIABABIAMADQAKACAOgCQAigEAkgHIAigHIAagBIAagCQARgBAGAAIACABIARAEQAKABASAAQBxAAA0AEIAJABIAWAEIAKADIAKAEIALADIACABIALADIBVANQA/AJAlAIQALADAEAFQAEAEABAKQABAJgBADQgCADgHADQgQAGgmACIgNABQgVACgNAEIgIADIgHADIgHAFIgJAIQgEACAAAEQABADAEACIAEABQAKADASgBIAwABQAPAAAJACIAFAAQAVAFAbAVQAQAOgEANQgDAHgJAGIgHAHIgDACIgGAEIgOAGIgQAHIgMADQgXAFgdAFIhzAPIgaADIgeAFIgNAEIgOAEIgGACQgIAEgDAGIgBALIAAAAQgBAFgDAEQgEAFgFACQgHACgOABIgZABIgfgBg");
	this.shape_407.setTransform(7.6,3.1);

	this.shape_408 = new cjs.Shape();
	this.shape_408.graphics.f("rgba(213,255,255,0.714)").s().p("AD0CoIgCAAIgRgEIgRgEQgjgJgfgDQgSgCgVABIgFAAIgtACIgHAAIguABIgJABIgtACIgGABIgzADIgTACIghABIgGAAQgUACgMgCIgNgCQgXgFgcgKIgNgFIgWgIQgOgGgEgHQgDgFACgFIABgCQADgGAFgFQANgMAPgJIASgIQgVgJgXgBQgXgBgXAGQgIACgRAIIgLAEIgHADQgKAEgIABQgPAEgJAAIgPgCQgMgBgRgFIgLgDIhWgTIg6gNQgSgFgKgGIgDgDQgMgJAAgOIgBgDQABgMAIgHIAGgFQAMgGAYABIAUgBQAMgBAGgDQAEgCAAgCQAAgDgEAAQgNgCgGgEIgBAAQgKgFgCgKQgBgJAGgJQAHgKAKgDQASgHAZAGQAbAJAQACQAJACAXAAQAOABAFgHQACgDAAgGQAAgHACgDQACgGAKgCIAIgCIAFgBIAPgEIAYgFIBBgMIAdgFIAzgJIAhgGIAQgDIAcgEIAOAAIAagCIAJAAQAUAAANAEQAGABAFADIABAAIAKAHIACABIAMADQAJACAPgCQAjgDAkgIIAjgHIAagBIAbgCQARgBAHAAIACABIARAEQAKABATAAQBzAAA0AEIAKABIAXAEIAJADIALAEIALADIADABIALADIBXANQBAAJAmAJQALADAFAFQAEAFABAJQAAAKgBADQgCADgHADQgRAGgnADIgOABQgWACgNAEIgJADIgIADIgHAFIgJAHQgEADAAADQABAEAEABIAEACQAKADATgBIAzABQAPAAAJACIAGAAQAWAFAcAVQARAOgEAOQgDAIgJAGIgIAHIgDABIgGAFIgOAGIgRAGIgNAEIg0AKIh2APIgaADIgeAGQgIABgGADIgPADIgGADQgJADgCAHQgCAEABAHIAAAAQgBAFgDAFQgEAEgGACQgGADgPABIgaAAIgfAAg");
	this.shape_408.setTransform(7.6,3.1);

	this.shape_409 = new cjs.Shape();
	this.shape_409.graphics.f("rgba(213,255,255,0.729)").s().p("AD4CrIgBAAIgSgEIgRgEQgjgJgggDQgTgCgVAAIgFAAIgvACIgGAAIgvACIgJAAIguACIgGABIg0AEIgUABIghACIgGAAQgUABgNgBIgNgCQgXgFgdgLIgOgFIgWgIQgOgGgEgHQgDgFACgGIABgCQADgGAFgFQAOgNAPgIIATgJQgVgJgYgBQgXgBgXAHIgaAJIgKAFIgIADIgTAGQgPAEgKgBQgGABgJgCIgegGIgMgEIhXgSIg7gOQgTgFgKgHIgDgCQgMgKgBgOIAAgDQAAgMAJgIIAGgEQAMgHAZABIAUAAQAMgBAGgDQAFgCgBgDQAAgDgEAAQgNgCgHgEIgBAAQgKgFgCgKQgCgJAHgKQAGgKALgEQASgHAaAHQAbAJAQADQAKABAXABQAOAAAFgHQADgDAAgGQAAgHABgDQADgHAKgCIAIgCIAFgBIAQgDIAZgGIBCgMIAdgFIA0gJIAigGIAQgDIAdgEIAOgBIAagBIAKAAQAUAAANADQAHACAEACIACABIAKAHIABAAIANAEQAJACAPgCQAkgEAlgIQAagFAJgBIAbgCIAbgBQASgCAHABIACAAIARAEQAKACAUAAQB2gBA1AFIAJABIAYADIAKADIALAEIAMAEIACABIAMADIBZANQBBAKAmAJQAMADAEAFQAEAEABAKQAAAKgBADQgCADgHADQgSAHgpACIgOABQgXACgOAEIgIADIgJAEIgHAEIgJAIQgEADAAAEQABADAEACIAEABQALADATAAIA1AAQAQAAAJACIAGAAQAYAGAcAVQASAPgEANQgDAJgJAGIgIAHIgDACIgHAEIgPAGIgQAHIgNADQgYAGgdAEIh5AQIgbADIgeAGIgPAEIgQAEIgGACQgIADgDAHQgBAEAAAHIAAABQAAAFgEAEQgEAFgGACQgGADgPABIgaAAIghAAg");
	this.shape_409.setTransform(7.6,3.2);

	this.shape_410 = new cjs.Shape();
	this.shape_410.graphics.f("rgba(213,255,255,0.741)").s().p("AD8CuIgBAAQgIgBgKgDIgSgEQgkgJgggDQgUgDgVABIgFAAIgwACIgGAAIgwABIgKABIguACIgHABIg1AEIgTABIgiACIgGAAQgVACgMgCIgOgCQgYgEgegMIgNgFIgXgIQgOgGgEgHQgDgGADgGIABgCQACgGAGgFQAOgNAQgJQAKgFAKgEQgWgJgYgBQgYgBgXAHIgaAKIgLAFIgIACQgLAFgJACQgPAEgKAAIgQgCQgNgBgSgFIgMgEIhagTIg7gOQgTgFgLgGIgDgDQgMgJgBgPIAAgDQAAgMAIgIIAHgFQAMgHAaABIAUAAQAMgBAGgDQAFgDgBgCQABgDgFAAQgNgCgIgEIgBgBQgKgFgCgKQgCgKAHgKQAGgJALgFQASgHAbAHQAcAKAQACQAKACAXAAQAPABAFgHQACgDAAgHQAAgHACgDQACgHALgCIAIgCIAGgBIAQgDIAZgGIBDgMIAegGIA1gJIAigGIARgDIAdgEIAPgBIAbgBIAJAAQAVAAANADIAMAEIABABIALAHIABABIANADQAKADAPgDQAlgDAlgIQAagGAKgBIAcgCIAbgBQASgCAHABIACAAIASAEQAKACAUAAQB4AAA2AEIAKABIAXADIALADIAMAEIAMAEIACABIANADIBaAOQBCAJAoAKQALADAFAFQAEAFABAKQAAAKgCADQgBADgIADQgTAHgqADIgPABQgYACgOADIgJAEIgIADIgIAFIgKAIQgDADAAADQAAAEAFABIAEACQALADAUgBIA3ABIAbACIAGAAQAYAGAeAWQASAPgEAOQgDAIgJAHIgIAHIgDABIgHAEIgQAHQgHAEgKACIgNAEQgYAGgeAFIh7AQIgbADIggAGIgOADIgRAEIgGADQgJADgDAHQgBAEABAHIAAABQgBAFgEAFQgEAEgFACQgHADgQABIgaABIghgBg");
	this.shape_410.setTransform(7.7,3.3);

	this.shape_411 = new cjs.Shape();
	this.shape_411.graphics.f("rgba(213,255,255,0.757)").s().p("AEBCxIgCAAIgSgEIgSgEQgkgKghgDQgVgCgVAAIgFAAIgxACIgGAAIgxACIgKAAIgvADIgHAAIg2AEIgUACIgiACIgHAAQgVABgMgBIgOgCQgYgEgfgMIgNgFIgXgJQgPgGgEgHQgDgGADgGIABgCQACgGAGgGQAPgNARgJQAKgGAKgDQgWgKgZgBQgYgBgYAHIgaALIgLAFIgIACIgUAHQgQAFgLgBQgGABgKgCIgggGIgNgEIhbgTIg9gPQgTgFgLgGIgDgDQgMgKgBgOIgBgEQABgMAIgIIAHgFQAMgHAaABIAVgBQAMgBAHgDQAEgCAAgDQAAgDgFAAQgOgCgHgEIgBgBQgLgFgCgLQgDgJAHgLQAHgKALgEQASgHAcAHQAcAKAQACQALACAXABQAPAAAFgHQADgDAAgHQAAgIABgCQADgHALgDIAIgCIAGgBIAQgDIAagFIBFgNIAegGIA2gJIAjgGIARgDIAegFIAPAAIAbgCIAKAAQAVAAAOAEIALAEIACABIALAHIABAAIANAEQAKACAPgCQAmgEAmgIQAbgGAJgBIAdgCIAbgBQATgBAHAAIACABIASAEQAKACAVAAQB7gBA2AEIAKABIAYAEIALADQACABAKADIANADIACABIANAEIBcAOQBEAKAoAJQAMAEAEAFQAEAEABALQAAAKgBADQgCAEgIADQgTAHgsACIgQABQgYACgPAEIgJADIgJAEIgIAFQgGADgEAFQgEADAAADQABAEAFACIAEABQAMADAVAAIA5AAQARAAAKACIAGABQAaAFAeAXQATAPgEAOQgCAJgKAHIgJAHIgDABIgHAFIgQAGIgRAHIgOADQgZAGgeAFIh9ARIgcADIggAGIgPAEIgRADIgHADQgJADgCAHQgCAFABAHIAAAAQAAAGgEAFQgFAEgFACQgHADgQABIgbABIghgBg");
	this.shape_411.setTransform(7.7,3.4);

	this.shape_412 = new cjs.Shape();
	this.shape_412.graphics.f("rgba(213,255,255,0.769)").s().p("AEFC1IgCAAIgSgEIgTgFQglgKghgDQgVgCgWAAIgFAAIgxACIgHAAIgxACIgKAAIgwADIgIAAIg2AEIgVACIgjACIgHAAQgVACgNgBIgOgDQgYgEgfgMIgOgFIgXgJQgQgGgEgIQgCgGACgGIABgCQADgGAGgGQAQgOARgJQAKgFALgEQgWgKgagBQgYgBgYAHQgJADgSAIIgMAFIgHADQgMAFgJACQgQAFgLAAIgRgBQgOgCgUgFIgNgEIhdgUIg+gOQgUgFgKgHIgDgCQgNgLgBgPIgBgDQABgNAJgIIAGgFQAMgHAbABQAMAAAKgBQAMgBAHgDQAEgCAAgDQAAgDgFgBQgPgCgIgDIgBgBQgLgGgCgLQgDgJAHgLQAHgKALgEQATgIAcAHQAdALARACQAKACAYAAQAPABAFgHQADgEAAgHQAAgHABgDQADgHALgDIAIgCIAGgBIARgDIAbgFIBGgNIAegGIA3gKIAkgGIASgDIAegFIAPAAIAcgCIAKAAQAVAAAOAEIAMAEIACABIALAHIABAAIANAFQALACAPgCQAngEAmgJQAcgGAKgBQAKgBASgBIAdgBQASgCAIABIACABIASAEQALACAUAAQB+gBA3AEIAKABIAZAEIALADIANAEIAMADIADABIANAEIBeAOQBFALApAJQAMAEAEAFQAEAFABAKQAAALgBADQgDAEgIADQgUAHgtACIgQABQgZACgQAFIgKADIgJADIgIAFIgKAIQgEADAAAEQABAEAFACIAFABQAMADAVAAIA7AAQASAAALACIAGAAQAbAGAfAXQAUAQgEAPQgCAIgKAHIgJAHIgDACIgIAEIgQAHIgSAHIgOADQgZAGgfAFIh/ARIgdAEIggAFIgQAEIgSAEIgHACQgJAEgDAHQgBAFABAHIAAABQgBAFgDAFQgFAFgFACQgHADgRABIgbAAIgiAAg");
	this.shape_412.setTransform(7.8,3.4);

	this.shape_413 = new cjs.Shape();
	this.shape_413.graphics.f("rgba(213,255,255,0.784)").s().p("AEJC4IgBAAQgJgBgKgDIgTgFQgmgKgigEQgVgCgXAAIgFAAIgyACIgHAAIgyACIgKABIgxACIgHABIg4AEIgVABIgjACIgHABQgWACgNgCIgOgCQgZgEgggMIgOgGIgYgJQgPgGgEgIQgDgGADgGIABgCQADgHAGgFQAQgPASgJQALgGALgEQgWgKgagBQgagBgYAIIgcALIgLAFIgIADQgMAFgJACQgRAFgLAAQgHABgLgCIgigGIgOgEIhegUIhAgPQgUgFgLgHIgDgCQgNgLgBgPIgBgEQABgNAJgIIAGgFQANgIAbABQANABAJgBQAMgBAHgDQAFgDgBgDQABgDgGAAQgPgCgIgEIgBgBQgLgGgDgLQgDgKAIgLQAGgKAMgFQATgHAcAHQAeALARACQAKACAZABQAPAAAGgHQACgEAAgHQAAgIABgDQADgHALgDIAJgBIAGgCIASgDIAagFIBIgNIAfgGIA4gKIAkgGIASgEIAfgEIAQgBIAcgBIAKAAQAVAAAPADIAMAEIACABIALAHIACABIANAEQAKADAQgDQAngDAogJQAcgGAKgBIAdgCIAdgCQATgBAHABIACAAIATAFQALACAVAAQCAgBA4AEIAKABIAZADIAMADIANAEIANAEIADABIAOADIBfAPQBGALApAKQANADAEAFQAEAGABAKQAAALgCADQgCAEgIADQgVAIgvACIgQABQgaACgQAEIgLAEIgJADIgIAFIgLAIQgEADAAAEQABAEAFACIAFABQANAEAWgBIA9AAQASABALABIAHABQAcAGAgAXQAVAQgEAPQgDAJgKAHIgJAHIgDACIgIAEIgRAHIgSAHIgOAEQgaAGgfAFIiCARIgdAEIghAFIgQAEIgTAEIgHADQgJADgDAHQgBAFABAHIAAABQgBAGgEAFQgEAFgGACQgHADgQABIgcAAIgPABIgUgBg");
	this.shape_413.setTransform(7.8,3.5);

	this.shape_414 = new cjs.Shape();
	this.shape_414.graphics.f("rgba(213,255,255,0.796)").s().p("AENC7IgBAAIgUgEIgTgFQgmgKgjgEQgVgCgXAAIgFAAIgzACIgHAAIgzACIgLABIgxACIgIABIg5AEIgVACIgkACIgHAAQgWACgNgBIgPgDQgZgEgggMIgPgGIgYgJQgQgGgEgIQgCgGACgHIACgCQACgHAHgGQARgOASgKQALgGAMgEQgXgKgagBQgagBgZAIQgIACgUAJIgMAFIgIAEQgMAFgJACQgSAFgLABIgSgBQgPgCgVgFIgOgEIhggVIhBgPQgUgFgLgHIgEgCQgNgLgBgPIAAgEQAAgNAJgJIAHgFQAMgIAcABQANABAKgBQAMgBAHgDQAFgDgBgDQAAgDgFgBQgPgCgJgEIgBgBQgMgFgDgMQgCgKAHgLQAHgLALgFQAUgHAcAHQAfALARADQAKACAZAAQAQABAGgIQACgDAAgIQAAgIABgCQADgIALgDIAKgCIAGgBIASgDIAbgFIBJgNIAfgGIA5gKIAlgHIATgEIAfgEIAQgBIAdgBIAKAAQAWAAAPADIAMAFIACAAIALAHIACABIANAFQALACAQgCQAogEAogJQAdgGAKgBQALgCASAAIAegCQATgBAIABIACAAIATAFQALACAVAAQCDgBA4AEIALABIAaADIALADIAOAEIAOAEIACABIAPAEIBhAPQBHALAqAKQANADAEAGQAFAFAAALQAAALgCADQgCAEgJADQgWAIgwACIgRABQgbACgQAEIgLAEIgJADIgJAFIgLAJQgEADAAAEQABAEAGACIAEABQANADAXAAIBAAAQATAAALACIAHABQAdAGAhAYQAWAQgEAQQgDAJgKAHIgKAHIgDACIgIAEIgRAHIgTAHIgOADQgaAHghAFIiDASIgeADIghAGIgRAEIgTAEIgIACQgJAEgDAHQgBAFABAHIAAABQgBAGgEAFQgEAFgGACQgHADgRABIgcABIgPAAIgVgBg");
	this.shape_414.setTransform(7.9,3.6);

	this.shape_415 = new cjs.Shape();
	this.shape_415.graphics.f("rgba(213,255,255,0.812)").s().p("AERC+IgBAAIgUgEIgTgFQgngKgkgEQgVgDgYAAIgFAAIg0ACIgHAAIg0ACIgKABIgzACIgIABIg5AEIgWACIglACIgHABQgXACgNgBIgOgDQgagEghgMIgPgGIgYgKQgQgGgEgIQgDgGADgHIABgCQADgHAHgGQARgPATgKQAMgGAMgEQgXgLgbgBQgagBgaAJQgIACgUAJIgMAFIgIAEIgWAIQgSAFgMAAQgIABgLgCQgPgBgVgGIgPgEIhigUIhBgPQgVgGgLgHIgEgCQgNgLgCgQIAAgEQAAgNAJgJIAHgFQANgIAcABIAXAAQANgCAHgDQAFgDgBgDQAAgDgFAAQgQgDgJgEIgBAAQgMgGgDgMQgDgLAHgLQAHgLAMgFQATgIAeAIQAfALARADQAKACAaABQAQAAAGgHQACgEAAgIQAAgIABgDQADgHAMgDIAJgCIAHgBIASgDIAcgFIBKgOIAggGIA6gKIAmgIIATgDIAfgEIARgBIAdgCIAKAAQAWAAAPAEQAIACAFACIACABIAMAHIABABIAOAFQALACARgCQAogEApgJQAdgHAKgBIAegCIAegBQAUgCAIABIACAAIATAFQALACAWAAQCFAAA5AEIALABIAaADIAMADIAOAEIAOADIADABIAPAEIBjAQQBJALAqAKQANAEAEAFQAFAGAAALQAAALgCAEQgCAEgJADQgXAIgyACIgRABQgcACgRAEIgLAEIgKADIgIAFQgHAEgEAFQgFADABAEQAAAEAGACIAFABQANAEAYgBIBBABQAUAAAMABIAHABQAeAGAiAZQAWARgDAPQgDAKgKAHQgEAEgGADIgEACIgIAEIgSAHIgTAHIgPAEQgaAGghAFIiGATIgeADIgiAGIgSAEIgTAEIgIACQgKAEgCAHQgBAFABAIIAAABQgBAGgEAFQgEAFgGACQgHADgSABIgdABIgkgBg");
	this.shape_415.setTransform(7.9,3.7);

	this.shape_416 = new cjs.Shape();
	this.shape_416.graphics.f("rgba(213,255,255,0.824)").s().p("AEWDCIgBAAIgVgFIgUgFQgmgKglgEQgWgDgYAAIgFAAIg1ACIgHAAIg1ACIgLABIgzACIgIABIg7AEIgVACIgmADIgHAAQgXACgOgBIgOgCQgbgFghgMIgPgGIgZgKQgQgGgEgJQgDgGADgHIABgCQAEgHAHgGQARgQAUgKQAMgGAMgEQgXgLgcgBQgagBgaAJQgIACgVAJIgMAGIgIADQgNAGgKADQgSAFgNABQgHAAgMgBQgQgCgWgFIgPgFIhjgVIhDgPQgVgFgLgHIgEgDQgOgLgBgQIgBgEQABgNAJgKIAHgFQANgIAdABIAXAAQANgCAHgDQAFgDgBgDQAAgDgFgBQgRgCgJgEIgBgBQgMgGgEgMQgDgLAIgMQAHgLAMgEQAUgJAeAJQAfALARADQALACAaAAQARABAFgIQACgDAAgIQAAgJABgDQAEgIALgCIAKgCIAHgBIATgDIAcgFIBLgOIAhgHIA7gKIAmgHIAUgEQATgDAMgBIARgBIAegCIAKAAQAXAAAQAEIAMAEIACABIANAHIABABIAOAFQALACARgCQApgEApgJIAogIIAfgCIAegBQAVgCAIABIACAAQAHABAMAEQALADAXAAQCHgBA6AEIALABIAbADIAMADIAPAEIAPADIACABIAQAEIBkARQBKALArAKQANAEAFAFQAEAGABAMQAAALgDAEQgCAEgJADQgYAIgzACIgSABQgcACgSAFIgLADIgLAEIgIAFQgHAEgFAFQgEADAAAEQABAEAGACIAFABQAOAEAYgBIBEAAQAUAAAMACIAIABQAeAGAkAZQAWARgDAQQgDAKgKAHQgEAFgGADIgEACIgJAEIgSAHIgUAHIgOAEQgbAGghAFIiJATIgeAEIgjAGIgSAEIgVAEIgHACQgKAEgDAHQgBAFABAIIAAABQAAAGgFAFQgEAFgGADQgHADgSABIgdABIglgBg");
	this.shape_416.setTransform(7.9,3.7);

	this.shape_417 = new cjs.Shape();
	this.shape_417.graphics.f("rgba(213,255,255,0.835)").s().p("AEaDFIgCAAIgUgFIgVgFQgngLglgEQgXgDgYABIgFAAIg2ABIgHAAIg2ACIgLABIg0ADIgIAAIg8AFIgWACIgmACIgHABQgYACgOgBIgPgCQgagFgigNIgPgFIgagKQgQgHgEgJQgDgGADgHIABgDQAEgHAHgGQASgQAVgKQAMgGANgFQgYgLgcgBQgbgBgaAJQgJADgUAJIgNAGIgIADQgNAGgLADQgSAGgNAAQgIABgMgCQgQgBgXgGIgPgEIhlgWIhEgPQgWgFgLgHIgEgDQgOgLgCgRIAAgDQAAgOAKgKQADgDAEgCQANgJAdACIAYgBQANgBAHgEQAGgCgBgDQAAgEgGAAQgRgDgJgEIgCgBQgNgGgDgMQgDgLAHgNQAHgLAMgFQAVgIAeAIQAgAMASADQALACAaABQARAAAGgIQACgDAAgIQgBgJACgDQADgIAMgDIAKgCIAHgBIATgDIAdgFIBNgOIAhgHIA8gKIAngIIAUgDIAggFIARgBIAegBIALAAQAXAAAQAEQAHABAGADIABABIANAHIACABIAOAFQALACASgCQApgEAqgKIApgIIAfgBIAfgCQAVgBAIAAIACABQAHABANAEQALACAXAAQCKgBA7AEIALABIAbADIAMADIAQAEIAPAEIADABIAPAEIBmARQBMALAsALQANADAEAGQAFAGAAAMQAAALgCAEQgDAEgJAEQgZAIg0ACIgSABQgeACgSAEIgMAEIgKADIgKAGQgGADgFAGQgEADAAAEQABAEAGACIAFACQAOADAZgBIBGABQAVAAAMABIAIABQAfAGAlAaQAYASgEAQQgCAKgLAHQgEAFgHADIgDACIgJAEIgTAHIgUAHIgPAEQgbAGgiAGIiLATIgfAEIgjAGIgTAEIgVAEIgIACQgKAEgDAIQgBAFABAIIAAAAQAAAGgEAGQgFAFgGADQgHADgSABIgeABIglgBg");
	this.shape_417.setTransform(8,3.8);

	this.shape_418 = new cjs.Shape();
	this.shape_418.graphics.f("rgba(213,255,255,0.851)").s().p("AEeDIIgBAAIgVgEIgVgGQgngLgngEQgWgDgZAAIgFAAIg3ACIgHAAIg3ACIgLABIg1ACIgIABIg9AFIgWACIgnACIgIABQgYACgOgBIgPgCQgbgEgigOIgQgFIgZgLQgRgHgEgIQgDgHADgHIABgDQAEgHAIgGQASgQAVgLQANgGANgFQgYgLgcgBQgcgBgaAJQgJADgVAJIgNAGIgIAEQgOAGgKADQgTAGgOABQgIAAgMgBQgQgCgYgGIgQgEIhngWIhFgPQgWgGgLgHIgEgDQgOgLgCgRIAAgEQAAgOAJgKIAIgFQANgJAeACIAYgBQANgBAIgEQAFgCgBgEQAAgDgGgBQgRgCgKgFIgBAAQgOgHgDgMQgEgLAIgNQAHgMAMgFQAVgIAfAJQAhALARADQALADAcAAQARABAFgIQADgEgBgIQAAgJABgDQAEgIAMgDIAKgCIAHgBIAUgDIAdgFIBOgOIAigHIA9gLIAngIIAVgDQAUgEANgBIARgBIAfgBIAKAAQAYAAAQAEQAIABAFADIACABIANAHIACABIAOAFQALADASgDQAqgEArgKIApgIIAggBIAfgCQAWgBAIAAIACABQAHABANAEQAMACAXAAQCMgBA8AEIALABIAcADIANADIAPAEIAQAEIADABIAQAEQAlAHBDAKQBMAMAtALQANAEAFAFQAEAGABAMQAAAMgDAEQgCAEgKAEQgZAIg3ACIgSABQgeACgTAEIgMAEIgLAEIgKAFQgGAEgFAFQgFADAAAEQABAFAGACIAGABQAPAEAZgBIBIAAIAiACIAIABQAhAGAmAbQAYASgEAQQgCAKgLAIQgEAEgHADIgEACIgJAFIgTAHIgVAHIgPAEQgcAGgiAGIiNAUIgfAEIgkAGIgUAEIgVADIgIADQgLAEgCAHQgCAFACAJIAAAAQAAAHgFAFQgEAGgHACQgHADgTABIgeABIgmgBg");
	this.shape_418.setTransform(8,3.9);

	this.shape_419 = new cjs.Shape();
	this.shape_419.graphics.f("rgba(213,255,255,0.863)").s().p("AEjDLIgCAAIgVgEIgVgGQgpgLgmgFQgYgCgYAAIgGAAIg3ABIgIAAIg4ACIgLABIg2ADIgIABIg+AEIgWACIgoADIgHABQgZACgOgBIgPgCQgcgFgjgNIgQgGIgagKQgRgHgEgJQgCgHADgIIABgCQAEgHAIgHQATgQAVgLQANgHAOgEQgZgMgcgBQgcgBgbAKQgJACgVAKIgNAGIgJAEIgYAJQgUAHgNAAQgJABgMgCQgRgBgYgGIgRgEIhogXIhHgPQgWgGgMgHIgEgDQgOgLgCgRIAAgEQAAgPAKgKIAHgGQANgIAfABQAOABAKgBQAOgCAHgDQAGgDgBgDQAAgEgGAAQgSgDgKgEIgCgBQgNgHgEgNQgEgLAIgNQAHgMANgFQAVgIAfAIQAhANATADQALACAbABQASAAAFgIQADgEgBgIQAAgJABgDQAEgJAMgDIALgCIAHgBIAUgDIAegEIBPgPIAjgHIA9gLIApgIIAUgEIAigEIASgBIAfgCIAKAAQAYAAARAEIANAEIACABIANAIIACABIAPAFQALADASgDQArgEAsgKIAqgIIAggCIAggBQAVgCAIABIACAAQAIABANAFQAMACAXAAQCPgBA9AEIALABIAcADIANADIAQAEIAQAEIAEABIAQAEIBpARQBPAMAtALQANAEAFAGQAEAGABAMQAAANgDADQgDAFgKADQgaAJg4ACIgSABQggACgTAEIgNAEIgLAEIgJAFQgHAEgFAFQgFADAAAFQABAEAHACIAFACQAQADAaAAIBKAAQAWAAANACIAIAAQAiAHAnAbQAZASgEARQgCAKgLAIQgFAEgGAEIgEABIgKAFIgUAHIgVAHIgPAEQgcAHgjAGIiPAUIggAEIglAGIgUAEIgWAEIgIACQgLAEgDAIQgBAFACAIIAAABQgBAGgEAGQgFAGgGACQgIADgSABIgfABIgmgBg");
	this.shape_419.setTransform(8.1,4);

	this.shape_420 = new cjs.Shape();
	this.shape_420.graphics.f("rgba(213,255,255,0.878)").s().p("AEnDPIgCAAIgVgFIgWgGQgpgLgngFQgYgCgZgBIgGAAIg4ACIgIAAIg4ACIgLABIg3ADIgJABQgdABghAEIgXACIgoACIgIABQgZACgOgBIgQgCQgcgEgjgOIgQgGIgbgLQgSgHgDgJQgDgHADgHIACgDQAEgHAIgHQATgRAXgLQANgHAOgEQgZgMgdgBQgdgBgbAKQgJACgWAKIgNAHIgJAEIgYAJQgUAHgOABQgJAAgNgBQgRgCgZgGIgRgEIhqgXIhIgQQgXgFgLgIIgEgCQgPgMgCgRIAAgFQAAgOAKgLIAHgFQAOgJAfABQAOABALgBQAOgBAHgEQAGgDgBgEQAAgDgHgBQgSgCgKgFIgCgBQgOgGgEgNQgDgMAHgNQAIgMAMgFQAWgJAgAJQAhAMATADQALADAcAAQASABAFgIQADgEAAgJQgBgJABgDQAEgJAMgDIALgCIAIgBIAUgDIAfgFIBQgOIAjgHIA/gMIApgIIAVgEIAigEIASgBIAfgCIAMAAQAYABAQADIAOAFIACAAIAOAIIABABIAPAFQAMADASgDQAsgEAsgKIArgIIAggCIAhgBQAWgCAIABIACAAQAIABANAFQAMACAYAAQCRgBA9AEIAMABIAdADIANADIARAEIAQAEIADABIARAEIBrASQBQAMAtALQAOAEAFAGQAFAGAAANQgBAMgCAEQgDAFgLADQgaAJg5ACIgUABQggACgUAFIgNADIgLAEIgKAFQgHAEgFAGQgFADAAAEQACAFAGACIAGABQAPAEAcAAIBLAAQAXAAAOABIAIABQAjAHAoAbQAZATgDARQgCALgMAHQgEAFgHADIgEACIgKAFIgUAHIgWAHIgPAEQgdAHgjAGIiRAUIghAEIglAGIgVAEIgXAEIgIADQgLAEgDAHQgBAGACAIIAAABQgBAGgEAGQgFAGgGADQgIADgTABIgfABIgngBg");
	this.shape_420.setTransform(8.1,4);

	this.shape_421 = new cjs.Shape();
	this.shape_421.graphics.f("rgba(213,255,255,0.89)").s().p("AErDSIgCAAIgWgFIgVgGQgqgMgogEQgYgDgZAAIgGAAIg5ABIgIAAIg6ADIgLAAIg4ADIgIABIhAAFIgXACIgpADIgIABQgZACgPgBIgPgCQgdgEgkgOIgQgGIgbgLQgSgIgEgJQgDgHAEgIIABgCQAEgIAJgHQAUgRAXgLQANgHAPgFQgagLgdgCQgdgBgcAKIgfANIgNAHIgJAEIgaAKQgUAHgOAAIgWAAQgSgCgagGIgRgFIhsgXIhIgQQgYgFgMgIIgEgDQgPgLgBgSIgBgEQAAgPAKgLQADgDAFgDQAOgJAfACQAOAAALgBQAOgBAIgEQAGgDgBgDQgBgEgGgBQgTgCgKgFIgCgBQgOgHgFgNQgDgMAHgNQAIgNANgFQAVgJAhAJQAiANATADQALADAdABQASAAAFgIQADgEAAgJQgBgJABgEQAEgIANgDIALgCIAHgBIAVgDIAfgFIBSgPIAkgHIBAgMIApgIIAVgEIAjgFIASgBIAggBIAMAAQAYAAARAEIAOAEIACABIAOAIIACAAIAPAGQAMADASgDQAsgEAtgKIAsgJIAhgBIAhgCQAWgCAJABIACABQAHABAOAEQAMADAYAAQCUgBA+ADIAMABIAdADIAOADIARAEIARAEIADABIARAEIBtATQBRAMAuAMQAOAEAFAGQAFAGAAANQgBANgCAEQgDAEgLAEQgbAJg7ACIgUABQghACgUAEIgOAEIgLAEIgKAFQgIAEgFAGQgFADABAEQABAFAGACIAGACQAQAEAcgBIBOAAQAXAAAPACIAIABQAkAGApAcQAaATgDASQgDALgLAHQgFAFgHADIgEACIgKAFIgVAHIgWAHIgPAEQgeAHgkAGIiTAVIghAEIgmAHIgVAEIgXADIgJADQgLAEgDAIQgBAFACAJIAAABQgBAGgEAGQgFAGgHADQgHADgUABIgfABIgogBg");
	this.shape_421.setTransform(8.2,4.1);

	this.shape_422 = new cjs.Shape();
	this.shape_422.graphics.f("rgba(213,255,255,0.906)").s().p("AEvDVIgCAAIgWgFIgWgGQgqgMgpgEQgYgDgaAAIgGAAIg6ABIgIAAIg6ACIgMABIg4ADIgJABIhBAFIgXACIgqADIgIABQgaADgOgBIgQgCQgdgFglgOIgQgGIgbgLQgTgIgDgJQgDgIAEgHIABgDQAEgIAJgHQAVgRAXgMQAOgHAPgFQgagMgegBQgdgBgcAKQgKADgWALIgOAGIgJAEQgOAHgMADQgUAIgPABQgJAAgOgBQgSgCgagGIgSgEIhugYIhJgQQgYgGgMgHIgEgDQgPgMgCgSIgBgEQAAgQALgKIAHgHQAOgJAgACQAPAAALgBQAOgBAIgEQAGgDgCgDQAAgEgHgBQgTgCgLgFIgBgBQgPgHgEgOQgEgMAIgNQAHgNANgFQAWgKAhAKQAjANATADQALADAdAAQATABAFgJQADgEAAgIQgBgKABgEQAEgIANgDIALgCIAIgBIAWgDIAfgFQAmgGAtgJIAkgHIBBgNIAqgIIAWgEIAjgFIATgBIAggBIAMAAQAZAAARAEIAOAEIACABIAOAIIACABIAPAFQAMADATgDQAtgEAugKIAsgJIAhgBIAigCQAXgCAIABIACABQAIABAOAEQAMADAZAAQCWgBA/ADIAMABIAdADIAPADIARAEIARAEIAEABIARAEQAnAIBIALQBSANAvAMQAOAEAFAGQAFAGAAANQgBAOgCAEQgDAEgMAEQgcAJg8ACIgUABQgiACgVAFIgOADIgMAEIgKAGQgHAEgGAFQgFAEABAEQABAFAHACIAGACQAQAEAdgBIBQAAQAYAAAOACIAJAAQAlAHAqAdQAbATgEASQgCALgLAIQgFAFgHADIgFACIgKAFIgVAHIgXAHIgQAEQgdAHglAGIiVAVIgiAFIgnAGIgVAEIgYAEIgJADQgMADgCAJQgBAFABAJIAAABQAAAGgEAHQgFAFgHADQgIAEgUABIggAAIgogBg");
	this.shape_422.setTransform(8.2,4.2);

	this.shape_423 = new cjs.Shape();
	this.shape_423.graphics.f("rgba(213,255,255,0.918)").s().p("AEzDYIgCAAIgWgFIgWgGQgrgMgpgFQgagDgZAAIgHAAIg7ABIgIAAIg7ADIgMABIg5ACIgJABIhBAGIgZACIgpADIgJABQgaACgOAAIgRgDQgdgEglgPIgRgGIgbgLQgTgIgEgJQgDgIAEgIIACgDQAEgIAJgHQAVgSAYgLQAPgHAPgFQgbgMgegBQgegBgcAKQgKADgWAKIgOAHIgJAEIgbALQgVAHgPABQgJABgOgBQgTgCgbgGIgSgFIhvgYIhLgQQgYgGgNgIIgEgCQgPgMgCgTIgBgEQABgQAKgLIAHgGQAPgJAgABQAPABALgBQAPgBAIgEQAGgEgCgDQAAgEgHgBQgUgCgLgFIgBgBQgQgHgEgOQgEgNAIgNQAHgNAOgGQAWgJAiAKQAjANATADQAMADAdABQATABAFgJQADgFAAgJQgBgJABgEQAEgJANgDIAMgCIAIgBIAWgDIAggFQAmgGAugJIAlgHIBCgNIAqgIIAWgEIAkgFIATgBIAhgCIAMAAQAZABASADIAOAFIACABIAPAHIABABQAJAEAHACQAMADATgDQAugEAugKIAtgJQAMgCAWAAIAigBQAXgCAJABIACAAQAIABAOAFQAMACAZAAQCZAABAADIAMABIAeADIAOACIASAFIASAEIADABIASAEQAoAIBJALQBTANAwAMQAOAEAFAHQAFAGAAANQgBAOgCAEQgEAFgLADQgdAKg+ACIgVABQgiACgWAEIgOAEIgMAEIgLAFQgHAFgGAFQgFAEABAEQABAFAHACIAGACQARAEAdgBIBTAAQAYAAAPACIAJABQAmAHArAdQAbATgDATQgCALgMAIQgFAFgHADIgFACIgKAFIgWAHIgXAHIgQAEQgeAIglAGIiYAVIgiAFIgnAGIgXAEIgYAEIgJADQgMAEgCAIQgCAFACAJIAAABQAAAHgEAGQgGAGgGADQgIAEgUABIghAAIgpgBg");
	this.shape_423.setTransform(8.3,4.3);

	this.shape_424 = new cjs.Shape();
	this.shape_424.graphics.f("rgba(213,255,255,0.933)").s().p("AE3DcIgBAAIgXgFIgXgHQgrgMgqgFQgagDgaAAIgGAAIg8ABIgIAAIg8ADIgMABIg6ACIgJABIhDAGIgZACIgqADIgIABQgbADgPgBIgQgCQgegFgmgOIgRgHIgcgLQgTgIgDgKQgDgHAEgJIABgCQAEgJAKgHQAWgSAYgMQAPgHAQgFQgbgNgfgBQgegBgdALQgJADgYALIgOAGIgJAFQgPAHgMAEQgWAHgPACQgJAAgPgBQgTgCgcgGIgSgFIhxgYIhMgRQgZgFgMgIIgFgDQgPgMgCgTIAAgEQAAgQAKgLIAIgHQAOgJAhABQAPABAMgBQAOgBAIgEQAGgEgBgDQAAgEgHgBQgUgDgMgFIgCgBQgPgHgFgOQgEgNAIgOQAIgNANgGQAXgJAiAKQAkANATAEQAMADAeAAQATABAGgJQACgEAAgJQgBgKABgEQAEgJANgDIANgCIAIgBIAWgDIAggFQAogGAugJIAlgIIBDgMIArgJIAXgEIAkgFIATgBIAigCIAMAAQAaABARADIAPAFIACABIAPAHIACABIAPAGQANADATgCQAugFAwgKIAtgJIAigCIAjgCQAXgBAJABIADAAIAWAGQAMADAaAAQCbgBBAADIANABIAeADIAPACIASAFIATAEIADABIATAEIByAUQBUANAwAMQAPAEAFAHQAFAGAAAOQgBAOgDAEQgDAFgMADQgeAKg/ACIgVABQgjACgWAEIgPAEIgMAEIgLAGQgIAEgGAGQgFADABAFQABAFAHACIAGACQASAEAegBIBUAAQAZAAAQACIAJABQAnAHAsAdQAcAUgDATQgCALgMAJQgFAEgIAEIgEACIgLAEIgWAIIgYAHIgQAEQgeAIgmAGIiaAWIgjAEIgoAHIgXAEIgZAEIgJACQgMAEgDAJQgBAFACAJIAAABQAAAHgFAHQgFAGgHACQgIAEgUABIghABIgOAAQgTAAgJgBg");
	this.shape_424.setTransform(8.3,4.3);

	this.shape_425 = new cjs.Shape();
	this.shape_425.graphics.f("rgba(213,255,255,0.945)").s().p("AE8DfIgCAAIgXgFIgYgHQgrgMgrgFQgagEgbAAIgGAAIg9ACIgIAAIg9ACIgMABIg7ADIgJABQgfABglAEIgZACIgrAEIgIABQgbACgPAAIgRgCQgegFgmgPIgRgGIgdgMQgTgIgEgKQgDgIAEgIIACgDQAEgIAKgIQAWgSAagMQAPgIAQgFQgbgMgggBQgegBgeAKQgJADgYAMIgOAGIgJAFIgcALQgWAIgQABQgKABgOgBQgUgCgcgGIgTgFIhzgZIhNgQQgZgGgNgIIgEgDQgQgNgCgSIAAgFQAAgQAKgLIAIgHQAPgKAhACIAbAAQAPgCAIgEQAGgDgBgEQAAgEgIgBQgUgCgMgGIgCAAQgQgIgFgOQgEgNAIgPQAIgNANgGQAXgKAjALQAkANAUAEQAMADAeABQAUABAGgKQACgEAAgJQgBgLABgDQAEgKAOgDIAMgCIAIgBIAXgCIAhgFIBXgQIAmgIIBEgNIAsgIIAWgFIAlgFIAUgBIAigBIAMAAQAaAAASAEIAPAEIACABIAPAIIACABIAQAGQAMADAUgDQAvgEAwgLIAugJQANgBAWgBIAjgBQAYgCAJABIACAAIAXAGQAMADAaAAQCegBBBAEIANABIAfACIAPADIATAEIASAEIAEABIATAFQAoAIBLAMQBXANAwANQAPAEAFAHQAFAGAAAOQgBAOgDAEQgDAFgMAEQgfAJhAACIgWABQgkACgXAFIgPAEIgNAEIgLAGQgIAEgFAGQgFADAAAFQABAFAIACIAGACQASAEAfgBIBWAAQAaAAAPACIAKABQAnAHAuAeQAdAVgDATQgCALgMAJQgGAEgIAEIgEACIgLAFIgXAHIgYAHIgQAEQgfAIgmAHIidAWIgjAFIgoAGIgYAEIgaAEIgJADQgMAEgDAIQgBAGACAJIAAABQAAAHgFAHQgFAGgHACQgIAEgVABIghABQgeAAgMgBg");
	this.shape_425.setTransform(8.4,4.4);

	this.shape_426 = new cjs.Shape();
	this.shape_426.graphics.f("rgba(213,255,255,0.961)").s().p("AFADiIgCAAIgXgFIgYgHQgsgMgrgGQgbgDgbAAIgGAAIg+ABIgIAAIg+ADIgMABIg8ADIgJABQggABglAEIgZADIgsADIgIABQgcADgPgBIgRgCQgfgEgmgQIgSgGIgdgMQgTgIgEgKQgDgIAEgJIACgDQAFgIAJgIQAXgTAagMQAQgIAQgFQgbgNgggBQgfgBgeALQgKADgYAMIgOAHIgKAFIgbALQgXAIgQACQgKAAgPgBQgUgCgdgGIgUgFIh0gZIhPgRQgZgGgNgIIgEgDQgQgMgCgTIgBgFQAAgRALgLIAIgHQAPgKAiACQAPABAMgBQAPgCAIgEQAHgDgCgEQAAgEgIgBQgVgDgMgFIgCgBQgQgHgFgPQgEgNAIgPQAIgOANgFQAYgKAjAKQAlAOAUAEQAMADAfAAQATABAGgJQADgEgBgKQgBgKACgEQADgKAOgDIANgCIAJgBIAXgDIAhgEQApgHAvgJIAngIIBFgNIAsgJIAXgFIAmgFIAUgBIAigBIAMAAQAbAAASAEIAPAFIACAAIAQAIIACABIAQAGQANAEAUgDQAvgFAxgLIAvgJQANgBAWgBIAkgBQAYgCAJABIACAAQAJACAOAFQANACAaAAQCggBBCAEIANABIAgACIAPADIATAEIATAFIAEABIATAEQApAIBNAMQBXAOAxANQAQAEAFAHQAFAGAAAPQgBAOgDAEQgEAFgMAEQggAKhCACIgWABQglACgXAFIgQADIgNAFIgLAFQgIAEgGAGQgFAEAAAFQACAFAHACIAHACQASAEAggBIBYAAQAaAAARACIAJABQApAHAvAfQAdAVgDATQgCAMgMAIQgGAFgIADIgEACIgMAFIgXAIIgYAHIgRAEQgfAIgnAHIifAWIgjAFIgpAHIgZAEIgaAEIgJACQgNAEgDAJQgBAGADAJIAAABQgBAHgEAHQgGAGgHADQgIAEgVABIgiABQgfAAgMgCg");
	this.shape_426.setTransform(8.4,4.5);

	this.shape_427 = new cjs.Shape();
	this.shape_427.graphics.f("rgba(213,255,255,0.973)").s().p("AFEDlIgCAAQgKgBgNgEIgYgHQgtgNgsgFQgbgDgbgBIgHAAIg+ACIgJAAIg+ACIgNABIg9ADIgJABQggACglAEIgaACIgsAEIgJABQgcADgPgBIgSgCQgfgFgngPIgSgHIgdgMQgUgIgDgKQgDgIAEgJIACgDQAEgJAKgHQAYgUAagMQAQgIARgFQgcgNgggBQgggBgeALQgKADgYAMIgOAHIgKAFIgdALQgXAJgQABQgKABgQgBQgUgCgegHIgUgEIh2gaIhPgRQgagGgNgIIgFgDQgQgNgCgTIgBgFQABgRAKgLIAIgHQAPgKAjACQAQAAALgBQAQgBAIgFQAHgDgCgEQAAgEgIgBQgWgDgMgFIgCgBQgRgIgFgPQgEgNAIgPQAIgOAOgGQAXgKAkALQAmAOAUAEQAMADAfABQAUABAGgKQADgEgBgKQgBgLACgDQADgKAPgEIANgCIAIgBIAYgCIAigFQApgGAwgKIAngIIBGgNIAtgKIAYgEIAmgFIAUgBIAjgCIAMAAQAbABATAEIAPAEIACABIAQAIIACABIARAGQAMAEAVgDQAwgFAxgLQAkgIAMgBQANgCAXAAIAkgCQAYgCAKABIACABQAIABAPAFQANADAbAAQCigBBDADIANABIAgADIAQACIATAFIAUAEIAEABIATAFQAqAIBOAMQBYAOAyANQAQAFAFAGQAFAHAAAPQgBAOgDAEQgEAGgNAEQggAJhEACIgWABQgmACgYAFIgQAEIgNAFIgMAFQgIAEgGAGQgFAEABAFQABAFAIACIAGACQATAEAgAAIBbgBQAbAAAQACIAKABQAqAHAwAgQAeAVgDAUQgCALgNAJQgFAFgIAEIgFABIgMAFIgYAIIgYAHIgRAFQggAHgnAHIihAXIgkAFIgqAHIgZAEIgbAEIgJACQgNAEgDAJQgBAGACAKIAAABQAAAHgEAHQgGAGgHADQgIAEgWABIgiABQgfAAgNgCg");
	this.shape_427.setTransform(8.4,4.6);

	this.shape_428 = new cjs.Shape();
	this.shape_428.graphics.f("rgba(213,255,255,0.988)").s().p("AFJDpIgCAAQgLgCgOgEIgYgHQgtgNgtgFQgbgEgcAAIgGAAIhAABIgJAAIg/ADIgNABIg9ADIgKABIhGAGIgaACIgtAEIgJABQgdADgPgBIgRgCQgggEgogQIgRgHIgegMQgUgIgEgLQgDgIAFgJIABgDQAFgJAKgIQAYgTAcgNQAQgIARgFQgcgOghgBQgggBgeAMIgjAPIgPAHIgKAFQgPAIgOAEQgXAJgRACQgLAAgPgBQgVgCgfgGIgUgFIh4gaIhQgRQgagGgOgJIgEgDQgQgMgDgUIAAgFQAAgRAKgMIAIgHQAQgKAjACQAQAAAMgBQAQgBAIgFQAGgDgBgEQgBgEgHgBQgWgDgNgFIgCgBQgRgIgFgPQgFgOAIgPQAIgPAOgGQAYgKAkALQAmAPAVAEQAMADAgAAQAUABAGgJQADgFgBgKQgBgKACgEQADgKAPgEIANgCIAJgBIAYgCIAjgFQApgGAxgKIAogIIBHgOIAugJIAXgFIAngFIAUgBIAkgCIAMAAQAcABATAEIAPAEIACABIAQAIIACABIARAGQANAEAVgDQAxgFAygLQAkgIAMgBQANgCAXAAIAlgCQAZgCAJABIADABQAIABAPAFQANADAbAAQClgBBEADIANABIAgADIARACIAUAFIAUAEIAEABIAUAFIB4AVQBbAOAyANQAQAFAFAHQAFAGAAAPQgBAPgEAEQgDAGgNAEQghAKhFACIgXABQgnACgZAEIgQAEIgNAFIgMAFQgIAFgGAGQgGAEABAFQABAFAIACIAHACQATAEAhgBIBdAAQAbAAARACIAKABQArAHAxAgQAfAWgEAUQgCAMgMAJQgGAFgIADIgFACIgMAFIgYAIIgZAHIgSAEQggAIgoAHIijAYIgkAFIgrAHIgZAEIgbAEIgKACQgOAEgCAJQgBAGACAKIAAABQAAAHgFAHQgFAGgHADQgJAEgWABIgjABQgfAAgMgBg");
	this.shape_428.setTransform(8.5,4.6);

	this.shape_429 = new cjs.Shape();
	this.shape_429.graphics.f("#D5FFFF").s().p("AFLDsQgLgCgOgEIgYgHQhJgVhKgCQgXAAgwACIhWADIhIAEQgsADg2AGIg3AFQgdADgPgBQgmgCg0gUIgwgUQgVgIgDgLQgEgJAHgLQAFgJAKgIQAnggAwgPQgdgNghgBQgggBgfALQgNAFglASQgzAageACQgZADg2gMIjggwQgggHgNgLQgSgOgBgYQAAgXATgNQAPgLAkACQAmACAPgIQAGgEgBgEQgBgEgIgBQgWgDgNgFQgTgIgGgRQgFgOAIgPQAIgPAPgGQAYgKAlALQAmAPAVAEQAMADAhABQAUABAGgKQADgFgBgKQgBgLACgEQAFgNAbgCQBDgGBdgTICfggQAqgIAVgCQAMgBAtgBQAzgBAYAKIATAJQALAFAIACQANAEAVgDQAxgFAzgLIAxgKQANgBAYgBIAlgBQAZgCAKABQAJABARAGQANADAcAAQCngBBFADQAmACAYAEIAtAKQAqAJBlARQBcAOAzAOQAQAEAFAHQAFAHAAAPQgBAPgEAFQgEAFgNAEQgiAKhGACQhHADgiAJQgaAHgOAOQgGAEABAFQABAFAIACQAVAHAogBIBegBQAmAAASADQAsAIAyAgQAfAWgDAVQgDATgfAMQg2AXhjARIkrAsQgXADgDAMQgBAGACALQAAAIgFAHQgFAGgIADQgIAEgWABIgkABQgjAAgLgBg");
	this.shape_429.setTransform(8.5,4.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_373}]},298).to({state:[{t:this.shape_374}]},1).to({state:[{t:this.shape_375}]},1).to({state:[{t:this.shape_376}]},1).to({state:[{t:this.shape_377}]},1).to({state:[{t:this.shape_378}]},1).to({state:[{t:this.shape_379}]},1).to({state:[{t:this.shape_380}]},1).to({state:[{t:this.shape_381}]},1).to({state:[{t:this.shape_382}]},1).to({state:[{t:this.shape_383}]},1).to({state:[{t:this.shape_384}]},1).to({state:[{t:this.shape_385}]},1).to({state:[{t:this.shape_386}]},1).to({state:[{t:this.shape_387}]},1).to({state:[{t:this.shape_388}]},1).to({state:[{t:this.shape_389}]},1).to({state:[{t:this.shape_390}]},1).to({state:[{t:this.shape_391}]},1).to({state:[{t:this.shape_392}]},1).to({state:[{t:this.shape_393}]},1).to({state:[{t:this.shape_394}]},1).to({state:[{t:this.shape_395}]},1).to({state:[{t:this.shape_396}]},1).to({state:[{t:this.shape_397}]},1).to({state:[{t:this.shape_398}]},1).to({state:[{t:this.shape_399}]},1).to({state:[{t:this.shape_400}]},1).to({state:[{t:this.shape_401}]},1).to({state:[{t:this.shape_402}]},1).to({state:[{t:this.shape_403}]},1).to({state:[{t:this.shape_404}]},1).to({state:[{t:this.shape_405}]},1).to({state:[{t:this.shape_406}]},1).to({state:[{t:this.shape_407}]},1).to({state:[{t:this.shape_408}]},1).to({state:[{t:this.shape_409}]},1).to({state:[{t:this.shape_410}]},1).to({state:[{t:this.shape_411}]},1).to({state:[{t:this.shape_412}]},1).to({state:[{t:this.shape_413}]},1).to({state:[{t:this.shape_414}]},1).to({state:[{t:this.shape_415}]},1).to({state:[{t:this.shape_416}]},1).to({state:[{t:this.shape_417}]},1).to({state:[{t:this.shape_418}]},1).to({state:[{t:this.shape_419}]},1).to({state:[{t:this.shape_420}]},1).to({state:[{t:this.shape_421}]},1).to({state:[{t:this.shape_422}]},1).to({state:[{t:this.shape_423}]},1).to({state:[{t:this.shape_424}]},1).to({state:[{t:this.shape_425}]},1).to({state:[{t:this.shape_426}]},1).to({state:[{t:this.shape_427}]},1).to({state:[{t:this.shape_428}]},1).to({state:[{t:this.shape_429}]},1).to({state:[]},1).wait(334));

	// Layer_19
	this.shape_430 = new cjs.Shape();
	this.shape_430.graphics.f("#D5FFFF").s().p("AFLDsQgLgCgOgEIgYgHQhJgVhKgCQgXAAgwACIhWADIhIAEQgsADg2AGIg3AFQgdADgPgBQgmgCg0gUIgwgUQgVgIgDgLQgEgJAHgLQAFgJAKgIQAnggAwgPQgdgNghgBQgggBgfALQgNAFglASQgzAageACQgZADg2gMIjggwQgggHgNgLQgSgOgBgYQAAgXATgNQAPgLAkACQAmACAPgIQAGgEgBgEQgBgEgIgBQgWgDgNgFQgTgIgGgRQgFgOAIgPQAIgPAPgGQAYgKAlALQAmAPAVAEQAMADAhABQAUABAGgKQADgFgBgKQgBgLACgEQAFgNAbgCQBDgGBdgTICfggQAqgIAVgCQAMgBAtgBQAzgBAYAKIATAJQALAFAIACQANAEAVgDQAxgFAzgLIAxgKQANgBAYgBIAlgBQAZgCAKABQAJABARAGQANADAcAAQCngBBFADQAmACAYAEIAtAKQAqAJBlARQBcAOAzAOQAQAEAFAHQAFAHAAAPQgBAPgEAFQgEAFgNAEQgiAKhGACQhHADgiAJQgaAHgOAOQgGAEABAFQABAFAIACQAVAHAogBIBegBQAmAAASADQAsAIAyAgQAfAWgDAVQgDATgfAMQg2AXhjARIkrAsQgXADgDAMQgBAGACALQAAAIgFAHQgFAGgIADQgIAEgWABIgkABQgjAAgLgBg");
	this.shape_430.setTransform(8.5,4.7);

	this.shape_431 = new cjs.Shape();
	this.shape_431.graphics.f("#D5FFFF").s().p("AFLDuQgKgCgOgEIgYgGQhJgVhKgCQgXAAgwACIgfABIg3ACIhIAEQgrACg3AGIg2AFQgdADgPgBQgngCgzgUIgwgTQgVgIgDgLQgEgJAGgLQAFgIAKgIQAkggAugOQgdgNghgBQgggCgfAMQgNAEglASIgRAIQgnARgZABQgZACg1gLIjfgyQgfgHgNgLQgSgPgBgXQAAgXATgOQAPgKAjABQAlABAQgIQAGgEgBgEQgBgEgIgBQgVgDgMgFQgTgIgFgRQgFgNAJgQQAIgOAPgGQAYgKAkAKQAnAOAUAEIAMACIAhACQAVAAAGgJQACgFAAgKQgBgKACgEQAFgOAbgCQBEgGBcgSICeggQAqgIAVgCQANgBAsgBQAzgBAYAJIATAJQALAGAIABQANAEAVgDQAxgEAzgMIAQgDIAhgGQANgBAYgBIAlgBQAZgCAKABQAJABARAGQANADAbAAQCngBBFADQAmACAYAEIAtAKQAqAJBlARQBaAOAzAOIABAAQAQAEAFAHQAFAHAAAPQgBAPgDAEQgEAGgMADQggALhEACQhEADgfAKQgaAHgNAOQgFAEAAAFQACAFAIACQAVAHAmAAIAmAAIA2ABQAlABARADQAqAIAvAhQAeAVgDAVQgEATgfAMQgqARhEAOIgqAIIkrAtQgXADgDAMQgBAGACALQAAAHgFAHQgGAGgHADQgJAEgWABIgjABQgjAAgMgBg");
	this.shape_431.setTransform(8.4,4.7);

	this.shape_432 = new cjs.Shape();
	this.shape_432.graphics.f("#D5FFFF").s().p("AFMDwQgKgBgOgEIgZgHQhIgUhKgBQgYgBgvACIgfABIg3ADQgwABgXACQgsADg2AFIg2AFQgdACgQAAQgmgCgzgUIgwgTQgUgIgEgKQgEgJAFgKQAFgJAJgIQAjgeArgPQgdgNghgBQgggBgfAKQgNAEglARIgRAIQgmAQgZACQgaACg1gMQhwgZhtgbQgegHgNgLQgSgPgBgXQAAgXATgOQAPgLAjABQAkABAPgJQAHgDgCgEQAAgEgHgBQgVgDgMgGQgRgIgFgQQgEgOAJgPQAIgOAPgGQAYgKAkAKQAmAOAVADIAMABQANACAUAAQAUABAHgKQACgEAAgKQgBgKACgEQAGgNAagCQBEgHBcgSICegfQApgIAWgCQANgCAsgBQAygBAZAKIASAIQALAFAIACQANADAVgCQAxgFAzgLIAQgDIAhgGQANgBAXgBIAlgBQAZgCAKABIAbAHQANADAbAAQClgBBGAEQAmACAYAEIAtAKQArAJBjARQBZAOA0AOIABAAQAQAEAFAHQAFAHABAOQgBAOgDAFQgDAFgMAEQgeALhBACQhBAEgeAKQgYAIgNANQgFAEABAFQACAFAHADQAVAHAmAAIAlACIA0ACQAjABARAEQAoAIAsAhQAdAVgEAUQgEATgeAMQgrARhEAPIgqAIIkqAsQgXAEgDALQgCAGACAKQAAAIgFAGQgGAGgHADQgJAEgVABIgkABIgugBg");
	this.shape_432.setTransform(8.2,4.7);

	this.shape_433 = new cjs.Shape();
	this.shape_433.graphics.f("#D5FFFF").s().p("AFNDyQgLgBgOgEIgYgGQhIgUhKgBQgYgBgvACIgfABIg2ACIhIAEQgsACg1AGIg2AEQgdADgQgBQgmgCgzgTIgwgTQgUgIgFgKQgDgJAFgKQAEgIAIgIQAhgeApgOQgdgNghgBQgggCgfALQgNADglARIgRAHQgmAQgZABQgaABg0gLQhxgahrgbQgegIgMgLQgSgPgBgXQAAgXASgOQAPgLAjAAQAkAAAPgIQAGgEgBgEQAAgEgHgBQgUgDgLgGQgQgIgFgQQgDgNAJgPQAIgOAOgGQAZgKAkAJQAlANAWADIAMACIAhABQAUAAAGgJQADgEAAgKQAAgKABgEQAGgNAbgCQBDgGBcgSQBngVA3gKQApgIAVgCQAOgCArgBQAygBAZAJIATAJQAKAFAIABQAOAEAUgDQAxgEAzgLIAPgDIAhgGIAlgCIAlgBQAZgCAKABIAaAHQAOADAbAAQCjgBBHAEQAmACAZAEIAsAKQAsAJBiARQBYAOA0AOIABAAQAPAEAGAHQAFAHABAOQAAAOgDAEQgDAGgLADQgcALg+ADQg+AEgcALQgXAHgMAOQgFAEABAFQABAFAIACQAVAIAlABIAkACIAyAEQAiABAQAFQAlAJArAgQAbAVgEAUQgFATgeALQgrAShDAOIgqAIIkqAtQgWAEgEALQgCAFACALQgBAHgFAGQgFAGgIADQgIAEgWABIgjABQgiAAgMgBg");
	this.shape_433.setTransform(8.1,4.7);

	this.shape_434 = new cjs.Shape();
	this.shape_434.graphics.f("#D5FFFF").s().p("AFOD0QgLgBgNgEIgZgGQhIgThKgBQgXgBgvACIgfABIg3ACIhHAEQgsACg1AFIg2AEQgcADgQgBQgngCgzgTIgwgSQgUgIgEgJQgEgJAFgKQADgIAIgIQAfgdAmgOQgdgNgggBQgggCgfAKQgOADgkAQIgRAHQgmAPgZABQgaABgzgMQhygahpgcQgegIgMgMQgRgPgBgXQAAgWASgOQAPgMAiAAQAjAAAPgJQAGgEgBgEQAAgDgGgCQgTgDgKgGQgQgIgEgQQgDgNAJgOQAIgOAPgGQAYgLAkAJQAlANAWACIAMACIAhABQAUAAAGgJQADgEAAgJQAAgKACgEQAGgNAagCQBEgHBbgSICegfQApgHAWgCQANgCArgBQAxgBAaAJIASAIQALAFAIACQANADAVgDQAxgEAzgKIAPgEIAhgFIAlgCIAlgBQAYgCAKABQAKACARAFQANACAbAAQCiAABIAEQAlACAZAEIAtAKQAsAKBhAQQBYAOAzAOIABAAQAQAFAFAGQAGAHABAOQAAANgDAFQgCAFgLAEQgaAKg7AEQg7AFgaALQgWAHgLAOQgFAEABAFQABAFAIACQAVAJAkABIAjADIAxAFQAgACAPAFQAkAJAoAgQAaAVgGAUQgFASgdAMQgrARhDAPIgrAIIkoAtQgXADgEALQgBAGABAKQgBAHgFAGQgFAGgIADQgJAEgVABIgjABIgugBg");
	this.shape_434.setTransform(7.9,4.7);

	this.shape_435 = new cjs.Shape();
	this.shape_435.graphics.f("#D5FFFF").s().p("AFPD2IgZgFIgYgGQhIgShKgBQgYgBguACIgfABIg2ACQgvACgZACQgrACg2AEIg1AEQgcADgRgBQgmgCgzgSIgwgSQgTgIgFgJQgEgJAEgJQADgJAIgHQAcgcAkgOQgdgNgggBQgggCgfAJQgOADgkAPIgRAHQglAOgaABQgaABgzgMQhxgbhogdQgdgJgMgLQgRgPgBgXQAAgWASgPQAOgLAigBQAigBAQgJQAGgEgBgDQAAgEgGgBQgSgEgJgGQgPgIgEgQQgCgNAJgOQAIgNAPgGQAYgLAkAJQAlALAVADIANABIAgABQAUAAAHgJQADgEAAgJQAAgKACgEQAHgMAagCQBDgIBbgRICdgfQApgHAWgCQAOgCAqgBQAxgBAaAJIATAHQAKAFAIACQAOADAUgDQAxgEAzgKIAPgDIAhgFQAOgCAWAAIAlgBQAZgCAKABIAaAGQAOADAaAAQChAABJAEQAlADAZAEIAtAJQAsAKBgAQQBXAOA0AOIABAAQAQAFAFAGQAGAHABANQAAAOgCAEQgCAFgKAEQgYALg5AEQg3AFgZALQgVAIgKAOQgEAEAAAFQACAFAIACQAUAJAkACIAiAEIAvAGQAfACAOAGQAiAJAlAhQAZAUgGAUQgGASgdALQgrAShDAOIgqAJQiTAXiVAWQgWADgFALQgCAGACAJQgBAHgFAGQgGAGgHADQgJADgVABIgjACIgugBg");
	this.shape_435.setTransform(7.7,4.7);

	this.shape_436 = new cjs.Shape();
	this.shape_436.graphics.f("#D5FFFF").s().p("AFPD4IgYgEIgYgGQhIgShKgBQgYAAgtACIggABIg2ACIhHADQgsACg1AEIg2AEQgbACgRAAQgmgCgzgSIgwgSQgTgHgFgKQgFgIAEgJQADgIAHgHQAagcAigOQgdgMgggCQgggCgfAJQgOADgkAOIgRAHQglANgZABQgbAAgygMQhygchlgeQgdgIgMgMQgRgPgBgXQAAgWASgPQAOgMAhgBQAigBAQgKQAGgDgBgEQAAgEgGgBQgRgEgJgGQgOgIgCgPQgDgNAJgOQAJgNAPgGQAYgKAjAHQAlAMAWACIANAAQANABATAAQATAAAIgJQADgEAAgJQAAgJADgEQAGgMAagCQBEgIBagRQBkgUA5gKQAogHAXgDQAOgBAqgBQAwgBAaAIIATAHQAKAFAIACQAOACAUgCQAxgEAzgKIAPgDQAWgEALgBIAkgCIAlgBQAYgBALABIAaAGQAOACAaABQCfAABKAEQAlACAZAEIAtAKQAtAJBfARQBWAOA0AOIABAAQAQAEAFAHQAGAGACANQAAANgCAFQgCAFgKAEQgVALg2AEQg0AGgYAMQgTAIgKANQgEAEABAFQACAFAHADQAVAJAiADIAiAEIAtAHQAeADAMAGQAhAKAiAhQAYAUgHATQgGASgdALQgrAShDAPIgqAIQiSAYiVAWQgWADgFAKQgCAGABAJQgBAHgFAGQgGAFgHADQgJADgVABIgjACIgTAAIgbgBg");
	this.shape_436.setTransform(7.6,4.6);

	this.shape_437 = new cjs.Shape();
	this.shape_437.graphics.f("#D5FFFF").s().p("AFQD6QgLgBgNgDIgYgGQhIgRhJgBIhGACIggABIg2ACIhHADQgsABg0AFIg2ADQgcADgQgBQgngCgygSIgwgRQgTgHgFgJQgFgIAEgKQACgHAHgHQAXgcAggNQgdgMgggCQgggCgfAIQgPADgiAOIgRAGQglANgaAAQgaAAgygMQhygdhkgfQgcgJgMgMQgRgPAAgWQAAgWAQgPQAPgMAggCQAhgCARgKQAFgDAAgEQAAgDgGgCQgQgEgIgGQgNgIgCgPQgCgNAJgNQAJgNAPgGQAYgLAjAIQAkAKAXACIAMABIAhAAQATAAAHgJQADgEABgIQAAgKADgDQAHgMAZgCQBEgIBagSQBjgTA6gKQAngHAXgCQAPgCApgBQAwgBAaAIIATAHQALAEAIACQANADAUgDQAxgEAygJIAQgDIAhgFIAkgCIAlgBQAYgBALABQAJABARAFQAOACAaAAQCeAABLAFQAkADAZAEIAtAJQAtAKBeAQQBWAOA0AOIABAAQAQAFAGAGQAFAGACANQABANgCAEQgCAFgJAEQgTALgzAFQgyAGgVAMQgSAJgJANQgEAEAAAFQACAFAIACQAUAKAiAEIAgAFIAsAIQAdAEALAGQAfALAgAgQAWAUgHATQgHASgdALQgrAShCAOIgqAJQiSAYiVAWQgWADgFAKQgCAFABAJQgBAHgGAGQgFAFgHADQgKADgUABIgjACIgugBg");
	this.shape_437.setTransform(7.4,4.6);

	this.shape_438 = new cjs.Shape();
	this.shape_438.graphics.f("#D5FFFF").s().p("AFRD8QgLgBgOgDIgYgGQhHgQhJgBIhGACIggABIg2ABIhGADQgsACg1AEIg1AEQgcACgQgBQgngCgygSIgwgQQgTgHgFgJQgFgIADgJQACgHAGgHQAWgbAdgNQgdgMgggCQgggCgfAHQgPADgiANIgRAGQglAMgZAAQgbgBgxgLQhygehjgfQgcgKgLgMQgQgPgBgXQAAgWAQgOQAOgNAggCQAhgDAQgJQAGgEAAgDQAAgEgGgCQgPgEgHgGQgMgIgCgPQgBgMAJgOQAJgMAPgGQAYgLAjAHQAkAKAWABIANABIAgAAQATAAAIgJQADgEABgIQAAgJADgEQAIgLAZgDQBDgIBagRQBigTA6gKQAogHAXgCQAPgCAogBQAwgBAbAHIASAHQALAFAIABQANADAUgDQAxgEAygJIAPgDIAhgEIAlgCIAlgBQAXgBALABQAKABAQAEQAPADAZAAQCdAABMAFQAkADAZAEIAtAJQAuAKBdAQQBVAOA0AOIABAAQAPAFAHAGQAFAGACANQABAMgBAEQgCAFgIAEQgSALgwAGQguAGgUANQgRAJgIANQgEAEABAFQACAFAHACQAVAKAgAFIAgAFIAqAKQAbAFALAFQAcAMAeAgQAVAUgIATQgHARgdAMQgrARhCAPIgqAIQiRAZiVAWQgVADgGAKQgCAFAAAJQgBAGgFAGQgGAFgHACQgJAEgVABIgiABIgUABIgagBg");
	this.shape_438.setTransform(7.3,4.6);

	this.shape_439 = new cjs.Shape();
	this.shape_439.graphics.f("#D5FFFF").s().p("AFRD+IgYgEIgYgFQhHgQhJgBIhGACIggABIg1ABIhHADQgsACg0AEIg1ADQgcACgQgBQgngCgygRIgwgQQgTgHgGgJQgEgIACgIQACgIAFgGQAUgaAbgNQgdgMgggCQgggDgfAIQgPACgiAMIgRAGQgkALgaAAQgbgBgwgMQhzgehhggQgbgKgMgMQgPgQgBgWQAAgWAQgPQAOgNAfgCQAhgDAQgKQAGgEgBgDQABgEgGgBQgOgFgGgGQgMgIgBgPQgBgMAKgNQAJgNAOgGQAZgKAiAGQAkAJAXABIANABIAggBQATAAAHgIQAEgEABgIQABgJACgDQAIgMAZgCQBEgIBYgRQBigUA7gJQAngHAXgCQAQgCAogBQAvgBAbAHIATAHQAKAEAIABQAOADATgDQAxgDAygJIAPgDQAXgEAKAAQAPgCAWAAIAlgBQAXgBALABQAKABAQAEQAOADAaAAQCbAABNAGQAkACAaAEIAsAJQAvAKBbAQQBVAOA0APIABAAQAPAEAHAGQAGAGACAMQABANgBAEQgBAFgIADQgQAMgtAFQgrAIgSANQgQAIgIAOQgDAEABAEQACAGAHACQAUALAgAFIAfAGIAoALQAaAFAKAGQAaANAbAgQAUATgIATQgIARgcALQgsAShCAOIgpAJQiRAZiVAWQgVADgGAJQgCAFAAAJQgCAGgFAGQgGAFgHACQgJADgUACIgjABIgTABIgbgBg");
	this.shape_439.setTransform(7.1,4.6);

	this.shape_440 = new cjs.Shape();
	this.shape_440.graphics.f("#D5FFFF").s().p("AFSEAQgLgBgNgDIgYgFQhHgPhJAAIhFABIggABIg2ACIhHACQgsACgzAEIg2ADQgbABgRAAQgngDgxgQIgvgQQgTgHgHgIQgFgIADgIQABgHAFgHQARgZAYgNQgdgMgfgCQgggCgfAGQgPACgiAMIgRAFQgkALgZgBQgcgBgvgLQhzgfhfgiQgbgKgMgMQgPgQgBgWQAAgWAQgPQAOgNAfgDQAfgEARgKQAFgDAAgEQABgDgFgCQgOgEgFgHQgLgIAAgOQgBgMAJgNQAKgMAOgGQAYgLAjAGQAkAJAXAAIANAAIAgAAQASAAAIgJQADgDACgIQABgJADgDQAIgLAYgDQBEgIBYgRQBhgTA8gKQAmgHAYgCIA3gDQAvgBAbAHIATAHQAKAEAIABQAOACATgCQAxgEAygIIAPgDIAhgEIAlgCIAkAAQAYgCALABQAKABAQAFQAOACAaAAQCZABBOAFQAkADAaAEIAsAJICKAaQBTAOA2AOIABAAQAOAFAHAGQAGAGACAMIABAPQgBAFgIAEQgNAMgrAGQgoAIgQANQgPAJgGAOQgEADABAFQACAFAHADQAVALAfAFIAeAHIAmAMQAZAFAIAIQAZANAZAgQASATgJASQgIARgcALQgsAShBAPIgqAIQiQAaiVAVQgVADgGAKQgCAEAAAJQgCAGgGAFQgFAFgHACQgKAEgTABIgjABIgbAAIgTAAg");
	this.shape_440.setTransform(7,4.6);

	this.shape_441 = new cjs.Shape();
	this.shape_441.graphics.f("#D5FFFF").s().p("AFTECQgLgBgNgDIgYgEQhHgPhJAAIhFABIggABIg2ACIhGACQgsABg0AEIg1ADQgbACgRgBQgngDgxgQIgvgPQgTgHgHgIQgFgHACgJQABgGAEgHQAPgZAWgMQgdgMgfgCQgggDgeAHQgQABgiALIgQAFQgkAKgagBQgbgBgwgMQhzgfhdgjQgbgKgLgNQgPgPgBgWQAAgWAQgPQANgNAfgEQAfgEARgLQAFgDAAgDQAAgEgEgCQgMgEgFgHQgKgIAAgOQAAgMAJgMQAKgNAOgGQAYgKAjAFQAjAIAXAAIANABIAggBQATgBAIgIQADgDABgIQACgIADgEQAIgLAYgCQBEgJBYgRQBggSA8gKQAngHAXgCIA4gDQAugBAbAHIATAGQAKAEAJABQANADAUgDQAwgDAygJIAPgCQAWgEALAAIAlgCIAkAAQAXgCAMABQAKABAQAEQAOADAZAAQCZABBOAGQAkACAaAEIAsAJQAwAKBaAQQBSAOA2APIABAAQAOAEAHAGQAGAGACALQACAMAAAEQgBAFgHADQgLAMgoAGQglAJgOAOQgOAJgGAOQgDADABAFQACAFAHACQAUAMAeAGIAdAIIAlANQAYAGAHAIQAXANAWAgQARATgKASQgIARgcALQgsARhBAPIgpAJQiQAaiVAVQgUADgHAJQgDAFAAAIQgCAGgFAFQgGAFgHACQgKADgTACIgjABIgSAAIgbAAg");
	this.shape_441.setTransform(6.8,4.6);

	this.shape_442 = new cjs.Shape();
	this.shape_442.graphics.f("#D5FFFF").s().p("AFTEEQgLgBgNgCIgYgFQhHgOhJAAIhEABIghABIg1ACIhGACIhfAEIg1ADQgbACgRgBQgngDgxgPIgvgPQgUgHgGgIQgGgHACgIQABgHADgGQAOgYATgNQgdgLgggCQgfgDgfAGQgPABgiALIgQAEQgkAKgagCQgbgBgvgMQhzgghcgkQgbgKgKgNQgPgQAAgVQgBgWAQgPQANgOAegFQAegEARgLQAGgDgBgDQABgEgEgBQgMgFgEgHQgJgIABgOQAAgLAJgNQAKgMAPgGQAYgKAiAEQAjAIAYAAIANAAIAggBQASgBAIgIQAEgDABgIQABgIAEgDQAJgLAYgCQBEgKBXgQQBfgSA8gKQAngHAYgCIA3gDQAtgBAcAHIATAFQALAEAHABQAOADATgDQAxgDAygIIAPgCIAhgFIAkgBIAlgBQAXgBALABQAKABAQAEQAPACAZABQCWABBQAGQAkACAZAEIAtAJQAwAKBZAQQBSAOA1APIABAAQAPAEAHAGQAGAGADALIACAPQgBAFgHAEQgIAMgmAGQghAJgNAPQgMAJgGANQgDAEABAFQADAFAGACQAVAMAdAHIAcAJIAiAOQAXAGAGAJQAWAOATAfQAPATgJASQgJAQgcALQgrAShCAPIgpAJQiPAaiVAVQgVADgGAJQgDAEgBAIQgCAGgFAFQgGAFgGACQgLADgSABIgjACIgbAAIgTAAg");
	this.shape_442.setTransform(6.7,4.6);

	this.shape_443 = new cjs.Shape();
	this.shape_443.graphics.f("#D5FFFF").s().p("AFUEGQgLgBgNgCIgYgFQhHgNhIAAIhFABIggABIg1ABIhGADQgsABg0ADIg1ACQgaACgSgBQgmgDgxgPIgwgPQgSgGgHgIQgFgGAAgIQABgHADgGQALgXARgNQgdgLgfgCQgggDgfAFQgQABggAKIgRAEQgjAJgagCQgcgCgugLQh0ghhagkQgagLgKgOQgPgPgBgWQABgVAPgQQANgOAdgFQAegFARgKQAFgEAAgDQABgEgEgBQgKgFgEgHQgIgIABgOQAAgLALgMQAKgMAOgGQAYgKAiAEQAiAGAYAAIAOAAIAfgCQATAAAHgIQAFgDABgIQACgHADgEQAJgKAYgDQBEgJBWgQQBfgTA+gJQAlgHAZgCIA2gDQAtgBAdAGIATAGIASAFQANACAUgCQAwgEAygHIAOgDQAWgDAMgBIAkgBIAlgBQAWgBAMABQAKABAQAEQAPACAYABQCWABBRAGQAjADAZAEIAsAJICKAZQBRAOA2APIABAAQANAEAIAGQAGAGADALIACAOQAAAFgFAEQgIAMgiAHQgfAKgLAOQgLAKgEANQgEAEACAEQACAFAGADQAVANAdAHIAbAJIAhAPQAVAIAGAJQASAOASAgQAOASgLASQgJAQgcALQgrARhBAPIgqAJQiOAbiUAVQgVADgHAJQgDAEgBAIQgCAFgGAFQgFAEgHADQgKADgTABIgjACIgaAAIgTAAg");
	this.shape_443.setTransform(6.6,4.6);

	this.shape_444 = new cjs.Shape();
	this.shape_444.graphics.f("#D5FFFF").s().p("AFUEIQgLgBgNgCIgXgEQhHgNhJAAIhEABIggABIg2ABIhFACQgtABgyADIg1ACQgaACgSgBQgngDgwgOIgwgPQgSgGgIgHQgFgHABgIQgBgGADgGQAIgXAPgMQgdgLgfgCQgfgDgfAEQgQABghAJIgQAEQgjAIgagCQgcgCgugMQh0ghhYglQgZgLgLgOQgOgQgBgVQAAgWAPgPQANgOAdgGQAdgFARgLQAGgDAAgEQABgEgEgBQgKgFgCgHQgIgIACgOQABgLAKgMQAKgLAOgGQAZgKAhADQAjAGAYgBIANAAIAggCQASAAAIgIQAEgDACgHQACgIADgDQAJgKAYgDQBEgKBWgQQBegSA+gJQAlgHAZgCIA2gDQAtgBAdAGIASAFQAKAEAJABQANACATgCQAxgDAygIIAOgCIAhgEIAlgBIAkgBQAXgBAMABQAKABAPAEQAPACAZAAQCUACBRAGQAjADAbAEIArAJICJAZQBQAOA2APIABAAQAOAEAHAGQAHAGADAKIADAPQAAAEgFAEQgFAMggAIQgbAKgJAPQgLAJgEAOQgCAEABAEQADAFAGADQAUANAcAIIAaAKIAfAQQAUAIAFAKQARAPAPAfQAMATgLARQgJAQgcAKQgsAShBAPIgpAJQiNAbiVAVQgUADgHAIQgEAEAAAIQgDAFgGAFQgFAEgHACQgKADgTACIgiABIgiABIgMAAg");
	this.shape_444.setTransform(6.4,4.6);

	this.shape_445 = new cjs.Shape();
	this.shape_445.graphics.f("#D5FFFF").s().p("AE9EHIgYgEQhGgMhJAAIhEACIggAAIg1ACIhGABIhfAEIg0ACIgsABQgngDgwgOIgwgPQgSgFgIgIQgFgGAAgIQgBgGACgGQAHgWAMgMQgdgLgfgCQgfgDgfAEQgQABghAIIgQADQgjAIgagCQgcgDgtgMQh0gihXgmQgZgLgKgOQgOgQAAgVQAAgWAOgQQANgNAcgHQAdgFARgMQAFgDAAgEQACgDgEgBQgJgGgBgHQgHgIACgNQACgLAKgMQAKgLAOgGQAZgLAhAEQAiAFAYgBIAOgBIAfgBQASgBAJgIQAEgDACgHQACgHADgDQAKgKAXgDQBEgKBWgQQBdgSA+gJQAmgGAYgDIA3gDQAsAAAdAFIATAFIASAFQAOABASgCQAxgDAygHIAOgCQAVgEAMAAIAkgBIAlAAQAWgCAMACQAKAAAQAEQAPACAYAAQCTACBTAHQAiADAbADIArAJICIAaQBQANA2AQIABAAQAOAEAHAFQAHAGAEALIADANQABAFgFADQgDANgdAIQgYALgIAPQgJAKgDANQgCAEABAEQACAFAHAEQAUANAbAIIAZALQARAKAMAIQATAIAEAKQAPAQAMAfQALASgLARQgKAPgcALQgsAShAAPIgpAJQiNAbiVAVQgUADgHAIQgEAFgBAGQgDAFgFAFQgGAFgHACQgKACgSABIgjADIgtAAIgYgDg");
	this.shape_445.setTransform(6.3,4.6);

	this.shape_446 = new cjs.Shape();
	this.shape_446.graphics.f("#D5FFFF").s().p("AFVEMIgYgDIgXgDQhHgLhIgBIhEACIghAAIg1ACIhFABIheAEIg1ABQgaACgSgBQgngDgwgOIgvgOQgSgFgIgHQgGgHAAgHQgCgGACgFQAEgWALgMQgdgKgfgDQgggDgeADQgRABggAIIgQADQgjAHgagDQgcgDgsgMQh1gjhVgnQgYgLgLgOQgNgQgBgVQAAgWAOgPQANgPAcgHQAcgGARgMQAFgDABgDQABgEgDgBQgIgGgBgHQgGgIADgNQACgLAKgLQAKgLAPgGQAYgKAhACQAiAFAZgCIANAAIAggDQARAAAJgIQAEgDACgGQACgIAEgDQAKgJAXgDQBEgKBVgQQBcgSBAgJQAkgGAZgCIA3gDQAsgBAdAFIASAFQAKADAJABQANACATgCQAxgDAxgHIAPgCQAVgDAMgBIAkgBIAkAAQAWgBANABQAKABAPADQAPACAYAAQCSACBTAHQAjADAaAEIAsAJICHAZQBPAOA3APIABAAQAOAEAHAGQAHAFADAKIAEAOQABAEgEAEQgBANgaAIQgVALgGAQQgIAKgCAOQgCADABAEQACAFAHADQAUAOAaAKIAYALQAQAKAMAJQARAJADAKQAOARAJAeQAKASgMARQgLAPgbALQgsAShAAPIgpAJQiNAbiUAVQgUADgIAIQgDAEgCAHQgDAFgGAEQgFAEgHACQgKADgSACIgjABIghABIgMAAg");
	this.shape_446.setTransform(6.2,4.5);

	this.shape_447 = new cjs.Shape();
	this.shape_447.graphics.f("#D5FFFF").s().p("AE+ELIgYgDQhGgLhIAAIhEACIghAAIg0ACIhGABQgsABgyACIg0ACQgaABgSgBQgogDgvgNIgvgOQgSgFgIgHQgGgGgBgHQgCgGACgFQACgVAIgMQgdgKgfgDQgggEgeAEQgRAAggAHIgQADQgiAGgagDQgdgDgsgMQh1gkhTgoQgYgLgKgPQgNgQAAgVQAAgVANgQQANgPAbgHQAbgHASgMQAFgDABgDQABgDgDgCQgHgGAAgHQgFgIADgNQADgKAKgLQAKgLAPgGQAYgLAhACQAhAEAZgBIAOgBIAfgDQARgBAJgHQAEgDADgGQACgHAEgDQAKgKAXgCQBEgLBVgQQBbgRBAgJQAlgGAZgCIA2gDQAsgBAdAFIATAEQAKADAIABQAOACASgCQAxgDAxgHIAPgCIAhgDIAkgBIAkAAQAWgBAMABIAaAEQAPACAYAAQCQACBVAHQAiADAaAEIAsAJICHAZQBOAOA3APIABAAQAOAFAHAFQAHAFAEAKIAEANQABAFgDADQABANgXAJQgTALgEARQgGAKgCAOQgCADABAEQADAFAGADQAUAOAZALIAYAMQAPALALAJQAQAJACALQAMARAGAfQAJARgNARQgLAPgbAKQgsAShAAPIgpAKQiMAbiUAVQgUADgIAIQgEAEgBAGQgDAFgGAEQgGAEgGACQgLADgSABIgiACIgtABIgYgDg");
	this.shape_447.setTransform(6,4.5);

	this.shape_448 = new cjs.Shape();
	this.shape_448.graphics.f("#D5FFFF").s().p("AE+ENIgXgDQhGgKhJAAIhDACIghAAIg1ABIhFACIheADIg0ABQgZABgSgBQgogDgvgNIgwgNQgSgFgIgHQgGgGgBgGQgCgGABgFQgBgUAGgMQgdgKgfgDQgfgEgeADQgSAAgfAGIgQADQgiAFgagDQgegEgqgMQh2gkhRgoQgYgMgKgPQgMgQgBgVQAAgVAOgQQAMgPAbgIQAbgHARgMQAFgDABgEQABgDgCgCQgGgGAAgHQgEgIAEgNQADgKAKgLQALgKAOgGQAYgLAhACQAhADAZgCIAOgBIAfgDQARgBAKgHQAEgDACgGQADgHAEgDQAKgJAXgDQBEgKBVgQQBagRBAgJQAlgGAZgCIA2gDQArgBAeAEIASAFIASADQAOACATgCQAwgDAygGIAOgCQAUgDANAAIAkgBIAlAAQAVgBANABIAZAEQAQACAXAAQCPACBVAIQAiACAbAFIArAIICHAZQBOAOA2AQIABAAQAOAEAHAFQAIAFAEAKIAFANQABAEgDADQADANgUAKQgPAMgDAQQgFALgBAOQgCADACAEQACAFAGADQAUAPAZALIAWAMQAPALAJALQAPAKABALQAKASAEAeQAHASgNAQQgLAPgbAKQgtASg/APIgpAJQiLAciUAVQgUADgIAHQgEAEgCAHQgDAEgGAEQgGAEgGACQgLADgSABIgiACIgtABIgYgDg");
	this.shape_448.setTransform(5.9,4.5);

	this.shape_449 = new cjs.Shape();
	this.shape_449.graphics.f("#D5FFFF").s().p("AE+EPIgXgDQhGgJhIAAIhDACIghAAIg1ABIhFACIheACIg0ABQgZABgSgBQgogDgvgMIgvgNQgSgFgIgHQgHgFgBgHQgDgFABgFQgDgUADgLQgdgKgegDQgggEgeACQgSAAgeAGIgQACQgiAFgagEQgegEgqgMQh2glhPgpQgXgNgKgPQgNgQAAgUQAAgVANgRQAMgPAagIQAbgIASgMQAEgDABgEQACgDgDgCQgFgGACgHQgEgIAFgNQADgKAKgKQALgLAPgGQAYgKAgABQAhADAZgDIAOgBIAfgDQARgBAKgHQAEgDADgGQACgGAFgDQAKgJAXgDQBEgLBUgPQBZgRBBgJQAkgGAagCIA2gDQArgBAdAEIATAEQAKADAIAAQAOACASgCQAxgDAxgGIAOgBIAhgDIAkgBIAlAAQAVgBANABIAZAEIAnACQCOACBWAIQAiADAaAEIAsAIICGAZQBNAOA3AQIABAAQANAEAIAFQAHAFAFAJQADAJACAEQACAEgDAEQAGANgSAJQgMANgBARQgEALAAAOQgCADACAEQACAFAGADQAUAPAYAMIAVANQAOALAJAMQAOAKgBAMQAIASACAfQAGARgOAQQgMAOgaAKQgtASg/AQIgpAJQiLAciUAVQgTADgJAHQgEAEgCAGQgDAEgGAEQgGAEgGACQgLACgSACIgiACIgtABIgYgDg");
	this.shape_449.setTransform(5.8,4.5);

	this.shape_450 = new cjs.Shape();
	this.shape_450.graphics.f("#D5FFFF").s().p("AE/ESIgYgDQhGgIhHAAIhEABIghABIg1ABIhEABIhdACIg0ABQgaABgSgBQgogDgugNIgwgMQgRgFgJgGQgHgGgBgGQgDgFgBgEQgEgUABgLQgdgJgfgEQgfgEgeACQgSgBgfAFIgPADQgjADgagDQgdgFgqgMQh1glhPgrQgWgMgKgPQgMgQAAgVQAAgVAMgQQAMgQAagJQAagIASgNQAFgDAAgDQACgDgCgCQgEgHACgHQgCgIAFgMQADgKALgKQAKgKAPgGQAYgLAgABQAhACAagDIAOgBIAfgEQAQgBAKgHQAEgDADgFQADgGAEgDQAMgJAWgDICXgaQBZgRBCgJQAjgFAagCQATgCAjgBQAqgCAeAEIATAEIASADQAOACASgCQAwgDAxgFIAPgCIAhgDIAkgBIAkAAIAiAAIAZAEQAQACAXAAQCNACBXAJQAhACAbAFIArAIICGAZQBMAOA3AQIABAAQAOAEAIAFQAHAFAEAJIAGAMQADAEgDADQAIAOgPAKQgJANABARQgDALAAAOQgBADACAEQADAFAFADQAUAQAXANIAUANQAOAMAHAMQANAMgCALQAHATgBAeQAEARgOAQQgMAOgbALQgsARhAAQIgoAJQiKAdiUAVQgTACgKAHQgEAEgCAGIgKAIQgFADgHACQgKADgSABIgiACIgtABIgXgCg");
	this.shape_450.setTransform(5.7,4.5);

	this.shape_451 = new cjs.Shape();
	this.shape_451.graphics.f("#D5FFFF").s().p("AE+EUIgXgDQhGgHhHAAIhDABIgiABIg1ABIhDABIheABIg0ABQgZABgSgBQgogDgugMIgwgMQgRgFgJgGQgHgFgCgGQgDgFgBgEQgHgTgBgLQgdgJgfgEQgfgEgeABQgTgBgdAFIgQACQgiADgagEQgegFgpgMQh2gmhMgsQgWgNgKgPQgMgQAAgVQAAgUAMgRQAMgQAZgJQAZgJATgNQAEgDABgDQACgDgCgCQgDgHADgHQgCgIAGgMQAEgKAKgKQALgKAPgGQAYgKAgAAQAgABAagDIAOgBIAfgEQARgBAJgHQAFgDADgFQADgGAFgCQALgJAWgDICXgbQBYgQBCgJQAjgFAbgCQATgCAigBQAqgCAeAEIATADQAKADAIAAQAOACASgCQAwgDAxgFIAPgCIAhgCIAkgBIAkAAIAiAAIAZAEIAnACQCLACBYAJQAhADAbAEIArAIICFAZQBMAOA3AQIABAAQAOAEAIAFQAHAFAFAIIAGAMQADAEgCAEQAKANgMAKQgGAOADASQgCALABAOQgBADABAEQADAFAGADQAUAQAVAOIAUAOQANANAGAMQAMAMgDAMQAFAUgEAeQADAQgPAQQgMAOgaAKQgtASg/APIgpAKQiJAdiUAVQgTACgKAHQgEADgCAGIgKAIIgMAFQgLACgRACIgiACIgtABIgYgCg");
	this.shape_451.setTransform(5.7,4.5);

	this.shape_452 = new cjs.Shape();
	this.shape_452.graphics.f("#D5FFFF").s().p("AE+EWIgYgCQhFgHhIAAIhDABIghABIg1AAIhDABIheACIgzAAQgZABgTgBQgogDgtgMIgwgLQgRgFgKgGQgHgFgCgFIgFgJQgJgSgEgLQgdgJgegEQgfgEgeAAQgTgBgeAEIgPACQgiACgagEQgegGgogLQh3gnhLgsQgVgOgKgPQgLgQgBgVQAAgVANgQQALgQAZgKQAZgKASgMQAEgDABgEQACgDgBgCQgCgHADgHQgBgIAHgMQAEgJALgKQALgKAOgGQAZgKAfgBQAgABAagDIAPgCIAegEQARgBAKgHQAEgDADgFQAEgFAEgDQAMgIAWgEICXgaQBXgQBCgJQAjgFAbgCQATgCAigBQAqgCAeADIATAEIASADQAOABASgCQAwgCAxgFIAOgCQAUgCANAAIAkgBIAkAAIAiAAIAZAEIAnACQCKACBYAJQAiADAbAEIArAIICEAZQBLAOA4AQIABAAQANAEAIAFQAIAFAFAIIAHALQADAEgCAEQAMANgJALQgDAPAFASQgBALACAOQgBADACAEQACAFAGADQAUARAVAOIASAOQANAOAFANQAKANgEAMQADAUgGAeQACARgQAPQgNAOgaAKQgtARg+AQIgpAKQiIAdiUAVQgTACgKAHQgEADgDAFQgEAEgGAEQgGADgGABQgLADgRABIgiACIgtACIgXgCg");
	this.shape_452.setTransform(5.7,4.5);

	this.shape_453 = new cjs.Shape();
	this.shape_453.graphics.f("#D5FFFF").s().p("AE6EYIgXgCQhFgHhHABIhDABIghABIg0AAIhFABIhdABIg0ABIgrgBQgogDgtgLIgwgLQgRgFgJgGQgHgEgEgGIgFgIIgSgdQgdgIgegEQgfgFgeABQgTgCgeADIgPACQgiABgZgEQgfgGgogMQh2gnhJgtQgVgOgKgQQgKgQgBgUQAAgVAMgRQALgQAYgLQAYgJATgNQAFgDABgDQACgEgBgCQgCgHAEgHQABgIAGgMQAFgJALgJQALgKAOgGQAZgKAfgCQAgABAagEIAPgCIAegEQAQgCAKgGQAFgDAEgFQADgFAFgCQAMgJAWgDICWgaQBWgQBDgJQAjgFAagCQAVgCAggBQAqgCAeADIATADIASADQAPABARgCQAwgCAxgFIAOgBIAhgDIAkAAIAlAAIAhAAIAZADIAnADQCIACBaAJQAhADAbAEIArAIICEAZQBLAOA3AQIABAAQANAEAJAFQAHAFAFAIQAFAHADAEQADAEgBADQAOAOgHALQABAPAHATQgBALADAOQAAADABAEQAEAFAEADIApAgQAJAHAJAIQALAOAEAOQAJANgEANQAAAVgIAeQAAAQgRAPQgNANgZAKQgtASg/AQIgoAJQiIAeiUAVQgSACgLAGQgEADgDAGIgKAHQgGADgHABQgKADgSABIghACIgtACIgYgCg");
	this.shape_453.setTransform(5.9,4.5);

	this.shape_454 = new cjs.Shape();
	this.shape_454.graphics.f("#D5FFFF").s().p("AE4EaIgXgCQhFgGhIABIhCABIgiABIg0AAIhEABIhcABIg0AAQgYAAgTgBQgpgDgsgLIgwgLQgRgEgKgFQgHgFgDgFQgFgEgCgEIgWgcQgdgIgegFQgfgEgeAAQgUgCgcADIgQABQghABgagFQgfgGgngMQh3gohHguQgVgOgJgQQgLgQAAgVQAAgUALgRQALgRAYgLQAYgKASgNQAFgDABgDQACgEgBgCQAAgHAFgIQABgIAHgKQAFgKALgJQAMgJAOgGQAYgKAfgCQAggBAbgEIAOgCIAfgEQAQgCAKgGQAEgDAEgEQAEgFAFgDQAMgIAVgDICWgbQBWgPBEgJQAigFAbgCQAUgCAhgBQApgCAfADIASADQAKACAIAAQAOABASgBQAwgDAxgEIAOgCIAhgCIAkAAIAkAAIAiAAIAZADIAmACQCHADBbAJQAhADAbAFIArAIICDAYQBKAPA4APIABAAQANAEAIAFQAIAFAFAHQAFAIAEADQADAEAAADQAQAOgEAMQADAPAJATIAEAaQAAADACAEQADAEAFAEIAnAhIARAQQALAPADAOQAHAOgFANQgBAVgLAeQgBAQgRAPQgOANgZAKQguARg+AQIgoAKQiHAeiUAVQgSACgLAGQgFADgDAFIgLAHIgLAEQgMACgQACIgiACIgsABIgGAAIgSgBg");
	this.shape_454.setTransform(6.1,4.5);

	this.shape_455 = new cjs.Shape();
	this.shape_455.graphics.f("#D5FFFF").s().p("AE1EcIgXgCQhFgFhHABIhCABIgiABIg0AAIhEABIhcAAIg0AAQgYAAgTgBQgogDgtgKIgwgLQgQgEgKgFQgIgEgEgFIgHgIIgbgbQgdgIgegFQgfgEgdgBQgUgCgdACIgPABQghAAgagFQgfgGgmgMQh4gphFgvQgVgOgJgRQgKgQAAgUQAAgUALgRQALgRAXgMQAXgLATgNQAEgDABgDIACgFQABgIAFgIQACgIAIgKQAFgJALgJQAMgJAPgGQAYgLAegCQAggBAbgEIAOgDIAfgEQAPgCALgGQAFgDADgEQAEgFAGgCQAMgIAVgDICWgbQBUgPBFgJIA9gHQAUgCAhgBQAogCAfADIATACIASACQAOABASgBIBggHIAOgBIAhgCIAkAAIAkAAIAiAAIAZADIAmACQCGADBcAKQAgADAbAEIArAIICDAYQBJAPA4AQIABAAQANAEAJAEQAIAFAFAHQAFAHAEADQAEAEAAAEQASAOgBAMIAQAjIAHAaIACAHQADAEAFAEIAmAiQAJAIAHAJQAKAPACAPQAHAOgHAOQgDAWgNAdQgDAQgRAPQgOAMgaAKQgtASg+AQIgoAKQiHAeiUAVQgSACgLAGIgIAHIgLAHIgLAEQgMACgQABIgiADIgsABIgYgBg");
	this.shape_455.setTransform(6.3,4.5);

	this.shape_456 = new cjs.Shape();
	this.shape_456.graphics.f("#D5FFFF").s().p("AEyEfIgXgCQhEgEhIAAIhCABIghABIg0AAIhEAAIhcABIgzgBIgrgBQgpgCgsgKIgwgKQgRgFgKgEQgIgFgEgEIgJgIIgfgaQgdgIgdgEQgfgFgegCQgUgCgcACIgPAAQghAAgagGQgfgGgmgNQh4gphEgwQgUgOgIgQQgKgRgBgUQAAgUALgRQALgSAXgMQAWgLATgOQAEgCACgDIACgGQABgIAHgHQACgIAJgLQAGgJALgIQALgKAPgFQAYgKAfgEQAfgBAbgFIAPgDIAegEQAPgCALgGQAFgDAEgEQAEgEAFgCQANgIAVgEICVgbQBUgOBFgJIA9gHQAVgCAggBQAogCAfADIATACIASABQAOACARgCQAwgCAxgEIAOgBIAhgCIAjgBIAlABIAhAAIAZADIAnACQCEADBcAKQAhADAbAFIArAHICCAZQBJAOA4AQIABAAQANAEAIAFQAIAEAGAHIAJAKQAEADABAEQAUAPACAMIAVAkIAJAaIACAHQADAEAFAEIAlAjQAJAJAGAIQAKARABAPQAFAPgIAOQgEAXgQAdQgEAQgSAOQgPANgZAJQguASg9AQIgoAKQiGAeiUAVQgSADgLAEQgFAEgEAEIgLAGQgFACgHABQgLADgQABIgiADIgsACIgYgBg");
	this.shape_456.setTransform(6.5,4.5);

	this.shape_457 = new cjs.Shape();
	this.shape_457.graphics.f("#D5FFFF").s().p("AEwEgIgXAAQhFgFhHACIhCABIgiAAIgzAAIhEABIhcAAIgzgBIgrgBQgpgEgsgJIgwgKQgQgEgLgFQgHgDgFgFIgKgHIgjgZQgdgIgegFQgfgEgdgCQgVgDgbABIgPAAQghgBgagFQgggIglgMQh4gqhCgxQgTgOgJgRQgKgRAAgTQAAgVALgRQAKgRAWgNQAWgMATgOQAEgDACgCQACgEAAgCQADgHAHgJQADgHAJgLQAHgIALgJQAMgJAOgFQAZgLAegDQAfgCAbgGIAPgDIAegEQAPgDALgFQAFgDAEgEQAFgEAFgCQANgIAVgDICUgbQBTgOBGgJIA9gHQAVgCAfgBQAogCAgACIATADIARABIAgAAQAwgDAwgEIAOgBIAhgBIAkAAIAkAAIAiAAIAYADIAnACQCDADBdALQAgADAcAEIAqAIQA6AJBIAPQBIAOA4ARIABAAQANADAJAFQAIAEAGAHQAFAGAFADQAEAEACADQAWAPAEANQANAQANAVIALAaIACAGQADAFAFAEIAkAkQAIAJAGAJQAJARAAAQQAEAPgIAQQgHAWgTAdQgFAPgSAPQgPAMgZAJQguATg9AQIgoAKQiGAeiTAVQgSACgMAFQgFADgEAEIgLAGIgMADIgbAEIghADIgtABIgXgBg");
	this.shape_457.setTransform(6.7,4.5);

	this.shape_458 = new cjs.Shape();
	this.shape_458.graphics.f("#D5FFFF").s().p("AEsEjIgXgBQhEgDhHABIhCABIgiAAIgzAAIhDAAIhcAAIgzgBIgrgBQgpgDgsgJIgwgKQgQgEgLgEQgIgEgFgEIgKgHIgogYQgdgIgegEQgegFgegDQgVgDgbABIgPgBQghgBgagGQgggIgkgMQh4gqhBgyQgTgPgIgRQgKgRAAgTQAAgVALgRQAKgSAWgNQAVgMATgOIAGgGIADgFQADgIAIgIQAEgIAKgLQAGgIAMgIQAMgIAOgGQAZgLAdgEQAfgDAcgFIAPgDIAegFQAPgCALgGQAFgCAEgEQAFgEAFgCQAOgHAUgEQBFgNBPgOQBSgOBHgJIA9gHQAVgCAfgBQAngCAgACIATACIARABIAgAAIBggFIAOgBIAhgCIAjAAIAlAAIAhAAIAZADIAmACQCCAEBeAKQAgADAcAEIAqAIQA6AKBIAOQBHAOA4ARIABAAQANAEAJAEQAIAEAHAHQAFAGAFADQAEADACAEQAZAOAHAOQAQARAPAVIAMAaIADAHQADAEAFAEQATATAQASQAIAJAFAKQAIARgBASQADAPgKAQQgIAXgVAdQgHAPgTAOQgPAMgZAJQguASg9AQIgoAKQiFAfiTAVQgSACgMAFQgFADgEAEIgMAFIgLADQgMADgQABIghACIgsADIgYgBg");
	this.shape_458.setTransform(6.9,4.4);

	this.shape_459 = new cjs.Shape();
	this.shape_459.graphics.f("#D5FFFF").s().p("AEpElIgXgBQhEgChHABIhCABIgiAAIgzAAIhDAAIhcgBIgygBQgYAAgTgBQgpgDgsgJIgwgJIgbgIQgIgDgFgEIgMgHIgsgXQgdgIgegFQgegFgegCQgVgEgbAAIgPgBQgggCgbgGQgfgIgkgMQh5grg/gzQgSgPgIgSQgJgQgBgUQAAgUAKgRQAKgSAWgOQAUgNAUgOIAFgGIAEgFQAEgIAJgJQAFgIAKgJQAHgIAMgJQAMgIAOgGQAZgKAdgEQAegEAcgGIAPgDIAegFQAPgDALgFQAGgCAEgEQAFgEAFgCQAOgHAUgDQBFgOBPgNQBRgOBHgJIA9gHQAWgCAegBQAngCAgACIATABIASACQAOAAARgBIBggFIAOgBIAhgBIAjAAIAlAAIAhAAIAZADIAmACQCAAEBfAKQAgADAcAFIAqAHICBAYQBHAPA4AQIABAAQANAEAJAEQAIAEAHAGQAGAGAFADIAHAHQAaAPALANQATASAQAVQAIANAGAOIADAHIAIAIQAUATAPATQAHAKAFAKQAHASgCASQACAQgLAQQgKAYgYAcQgIAPgTAOQgQALgZAKQguASg9AQIgnAKQiFAfiTAVQgRACgNAFIgKAGIgLAFIgMADIgbAEIghACIgtACIgLAAIgMAAg");
	this.shape_459.setTransform(7.2,4.4);

	this.shape_460 = new cjs.Shape();
	this.shape_460.graphics.f("#D5FFFF").s().p("AElEnIgXgBQhEgChHACIhBABIgiAAIgzAAIhDAAIhcgBIgygBIgrgCQgpgDgrgIIgwgJQgQgEgLgEQgJgDgFgEIgNgGIgxgXQgdgHgdgFIg8gIQgWgEgagBIgPgBQgggDgbgGQgggIgjgMQh5gsg9g0QgSgQgIgRQgJgRAAgTQAAgUAKgSQAKgSAVgPIAngbQAEgDACgDIAEgFQAFgIAJgJQAGgIALgJQAHgIAMgIQAMgIAPgGQAYgKAdgFQAegEAcgGIAQgEIAdgFQAPgDAMgFIAJgGQAFgDAGgCQAOgHAUgDQBFgOBPgOQBQgNBHgJIA9gHIA0gDQAmgCAhACIATABIARABIAggBIBggEIANgBIAhgCIAkAAIAkABIAhAAIAZADIAmACQB/AEBgAKQAfADAcAFIArAHQA7AKBGAPQBFAOA5AQIABAAIAVAIQAJAEAHAGIALAIIAIAHQAdAPANAOQAWATASAVQAJANAHAOIADAHIAIAIQAUAUAOATQAHAKAEALQAHASgDASQAAARgMARQgMAYgaAdQgJAOgVAOQgQALgYAJQguASg9ARIgnAKQiEAgiUAUQgRACgMAFQgGACgFADIgLAFIgMADQgMACgPABIghADIgsACIgMABIgMgBg");
	this.shape_460.setTransform(7.5,4.4);

	this.shape_461 = new cjs.Shape();
	this.shape_461.graphics.f("#D5FFFF").s().p("AhZEqIhbgCIgzgBIgrgCQgpgDgrgIIgvgIIgcgHIgPgHIgNgGIg2gWQgdgHgdgFQgegFgegEQgVgEgbgBIgOgCQgggDgbgHQgggJgigMQh6gsg7g1QgSgQgIgRQgIgRAAgTQAAgUAJgSQAKgTAUgPIAngcIAGgGIAEgFQAGgIAKgJQAHgIALgJQAIgIAMgHQAMgIAPgGQAYgKAdgGQAegFAdgGIAPgEIAegGQAOgCAMgFIAKgFIALgGQAOgGAUgEQBFgOBOgNQBPgOBJgIIA8gHIA0gDQAmgCAhABIATABIARABIAfgBIBggEIAOAAIAhgCIAjAAIAkABIAiAAIAYADIAmABQB+AFBhALQAfADAcAEIAqAHQA8ALBFAOQBEAOA6ARIABAAIAVAHQAJAEAHAGIALAIIAKAGQAeAQAQAOQAZATAUAWQAKAMAIAPIADAGIAIAJQAUAUANAUQAGAKAEALQAGATgEATQgBASgMARQgOAZgdAcQgLAOgVAOQgQALgYAJQgvASg8AQIgnALQiEAgiTAUQgRACgNAEIgKAFIgNAFIgLADIgbADIghADIgsACIgXAAIgXAAQhEgChHACIhBABIgiAAIgzAAIhDAAg");
	this.shape_461.setTransform(7.8,4.4);

	this.shape_462 = new cjs.Shape();
	this.shape_462.graphics.f("#D5FFFF").s().p("AgZEsIhDAAIhbgCIgygBIgrgCQgqgEgqgHIgvgIIgdgHIgOgGIgPgFIg6gVQgdgHgdgFIg8gKQgVgEgbgDIgOgBQgggFgbgHQgggJgigMQh5gtg6g1QgSgQgHgSQgIgRgBgTQAAgUAKgSQAJgTAUgPIAngdIAFgGIAFgFQAHgJALgIQAHgIAMgKIAUgOQANgIAOgGQAZgKAdgGIA6gMIAPgEIAegGQAOgDAMgFIALgFIALgFQAPgGATgEQBEgOBOgNQBPgNBJgJIA9gGIAzgDQAlgCAiAAIASABIASABIAfgBIBggEIANAAIAhgBIAkAAIAkAAIAhABIAYACIAmACQB8AEBjALQAeADAdAFIAqAHQA8AKBEAOQBEAOA5ARIABAAQAMAEAKAEQAIAEAIAFQAGAFAGADQAGADAEADQAhAPASAPQAdAUAVAWQALANAJAOIAEAHIAIAIQATAVAMAVQAHAKADALQAFAUgFAUQgCASgOARQgQAagfAcQgMAOgVANQgSALgYAJQguASg8AQIgnALQiDAgiTAUQgRADgNADIgLAFIgNAEQgFACgGABIgaADIgiADIgsADIgXAAIgXgBQhDAAhHABIhBABIgiAAIgaAAIgZAAg");
	this.shape_462.setTransform(8.1,4.5);

	this.shape_463 = new cjs.Shape();
	this.shape_463.graphics.f("#D5FFFF").s().p("AgdEvIhCgBIhbgCIgygCIgrgCQgqgDgqgHIgvgIIgcgGIgQgGIgPgFIg/gUIg6gMIg7gKQgXgFgZgDIgPgCQgfgFgbgHQgggJgigMQh5gug5g3QgQgQgIgSQgIgRAAgTQAAgUAJgSQAJgTAUgQIAmgeIAGgFIAFgGQAIgIALgJQAJgIAMgJQAJgHAMgHQAMgIAPgGQAYgKAdgGIA6gOIAPgDIAegHQAOgDAMgEIAKgFIAMgFQAQgGASgDQBFgPBOgNQBNgNBKgIQAfgEAdgCIA0gEQAlgCAhABIATAAIASAAIAfAAIBfgEIANAAIAhgBIAkAAIAkABIAhAAIAZACIAlACQB7AEBjAMIA7AIIAqAHQA9AKBDAOQBDAOA6ARIABAAIAVAIQAJADAHAFIANAHIALAHQAjAPAVAPQAfAVAYAWQAMANAKAPIAEAGIAHAIQAUAWALAVQAGALADAMQAEAUgGAUQgDATgPASQgSAaghAcQgOANgWANQgRALgYAJQgvASg7AQIgnALQiDAhiTAUQgQACgOAEIgLAEIgNAEIgLACIgbAEIghACIgsADQgLABgMgBIgXAAIiKACIhBABIgiAAIgZAAIgaAAg");
	this.shape_463.setTransform(8.4,4.5);

	this.shape_464 = new cjs.Shape();
	this.shape_464.graphics.f("#D5FFFF").s().p("AggExIhCgBIhbgCIgygCIgrgCQgpgEgqgGIgwgHIgcgGIgQgGIgQgEIhEgUIg5gMIg8gLIgwgIIgOgCQgfgGgbgIQghgJgggMQh6gvg3g3QgQgRgHgSQgIgRAAgTQAAgUAIgSQAJgTATgRIAmgeIAGgGIAFgFQAJgJAMgJQAKgIANgIQAJgHAMgHQANgHAOgGQAZgKAcgIIA6gOIAQgEIAdgHQAOgCAMgFIALgEIAMgFQAQgFASgEQBFgPBNgNQBNgNBKgIQAfgEAdgCIA0gDQAkgCAiAAIATAAIARAAIAfgBIBfgDIAOAAIAhgBIAjAAIAkABIAhABIAZACIAmABQB5AFBkAMQAeADAdAEIAqAHQA9ALBCAOQBCAOA6ARIABAAIAWAHIAQAIIAOAHIALAHQAlAPAYAQQAjAVAZAXQANANALAOIAEAGIAHAJQAUAWAKAWQAGALACAMQAEAVgHAVQgFATgQASQgTAbglAcQgOANgXANQgSAKgXAJQgvASg7ARIgnAKQiCAhiTAUIgeAGIgMAEIgNADIgLACIgbAEIghACIgsADQgLABgMAAIgXAAIiJACIhBABIgiAAIgZABIgagBg");
	this.shape_464.setTransform(8.7,4.6);

	this.shape_465 = new cjs.Shape();
	this.shape_465.graphics.f("#D5FFFF").s().p("AgjE0IhCgBIhbgDIgygCIgrgCQgpgDgqgHIgvgHIgcgGIgRgEIgRgFIhIgSIg6gMIg7gLIgwgKIgOgDQgfgGgbgHIhBgXQh6gvg1g4QgQgRgHgTQgHgRgBgTQAAgTAJgSQAIgUATgRQARgQAUgQIAGgEIAGgGQAKgJANgJQAKgIANgJIAWgNIAcgNQAYgKAcgIIA6gOIAQgFIAdgHIAagHIALgFIANgDQAQgGASgEQBFgPBMgNQBMgMBLgIIA8gGIA0gEIBGgCIATABIARgBIAfAAIBfgEIANAAIAhAAIAjAAIAkABIAiABIAYABIAmACQB4AFBkAMIA7AIIAqAGQA+AKBBAOQBBAOA7ASIABAAIAVAHIARAHIAOAHIANAHQAmAQAbAPQAmAWAbAXQAOAOALAOIAFAGIAIAJQATAWAKAXQAEALACAMQADAWgIAVQgGAVgQASQgWAbgnAcQgQANgXANQgSAJgYAKQgvARg7ARIgmALQiCAhiTAUIgeAFIgMAEIgNADIgLACIgbADIghADIgrADIgYAAIgWABIiKADIhAABIgjAAIgZAAIgZAAg");
	this.shape_465.setTransform(9,4.6);

	this.shape_466 = new cjs.Shape();
	this.shape_466.graphics.f("#D5FFFF").s().p("AALE3IgyAAIhCgCIhagDIgygCIgrgDQgpgDgqgGIgvgGIgcgFIgSgFIgSgEIhMgSIg6gLIg7gNIgwgKIgOgDQgfgHgbgIQghgKgfgMQh7gwgzg6QgPgRgHgTQgHgRAAgSQAAgUAIgSQAIgUASgSQAQgQAVgQIAGgFIAGgFQALgJAOgJIAZgRIAWgMIAcgNQAYgKAcgJIA6gQIAQgEIAdgHIAagHIALgEIANgEIAigJQBFgQBMgMQBLgMBMgJIA8gFIAzgEIBGgCIATgBIARAAIAfgBIBggCIAMAAIAhgBIAjABIAkAAIAhABIAZACIAlABQB3AFBmANQAeADAcAEIAqAHQA/ALA/ANQBBAOA7ASIABAAIAVAHIASAHIAOAGIANAHQApAQAeAQQApAWAcAYQAQANAMAOIAEAHIAIAIQATAXAJAXQAFAMABAMQACAXgJAWQgHAVgSATQgXAcgpAbQgSANgYAMQgSAKgXAJQgvASg7AQIgnALQiBAiiTAUIgeAFIgNADIgNADIgLABIgaAEIghACIgsAEIgXABIgXAAIiJAEIhAABIgjAAg");
	this.shape_466.setTransform(9.3,4.6);

	this.shape_467 = new cjs.Shape();
	this.shape_467.graphics.f("#D5FFFF").s().p("AAHE5IgyAAIhCgBIhagEIgxgCIgrgDQgqgDgpgGIgvgGIgdgFIgRgEIgUgDIhQgRIg6gMIg7gNIgwgLIgOgDQgegIgbgIQgigLgegMQh7gxgyg6QgPgRgGgTQgHgSAAgSQAAgTAHgTQAJgUARgSQAQgRAVgQIAGgFIAGgGIAbgSQALgIAPgIIAXgMIAbgNQAZgKAbgJQAcgJAegIIAQgEIAdgIIAagHIAMgEIANgDIAjgJQBFgQBLgMQBKgMBMgIIA9gGIAygDIBGgDIATgBIARAAIAfgBIBggCIAMAAIAhAAIAjAAIAkABIAhABIAYABIAmACQB1AFBnAMIA7AIIApAHQBAAKA+AOQBAAOA7ARIABAAIAVAIIASAGIAPAGIAOAGQArAQAhARQArAXAfAYQARANAMAPIAFAGIAIAIQATAYAIAYQAEAMABAMQABAYgKAXQgIAVgTATQgZAdgsAbQgTAMgYAMQgTAKgXAJQgvASg7AQIgnALQiAAiiSAUIgfAFIgNADIgNACIgMACIgaADIggADIgsADIgXABIgXABIiJAEIhAABIgjAAg");
	this.shape_467.setTransform(9.7,4.7);

	this.shape_468 = new cjs.Shape();
	this.shape_468.graphics.f("#D5FFFF").s().p("AAEE8IgzAAIhBgCQgugBgsgDIgygCIgqgDQgqgDgpgFIgvgGIgdgEIgSgEIgUgDQgsgIgqgJIg5gLQgegHgdgHIgvgMIgPgEIg5gQQghgLgfgNQh7gxgvg7QgPgSgHgTQgGgSAAgRQAAgUAHgSQAJgVARgTQAPgRAUgQIAGgFIAIgGIAbgTIAcgPIAXgMIAcgMQAZgKAbgKIA6gSIAQgFIAdgIIAagHIAMgDIAOgDIAigIQBFgQBLgMQBJgMBNgJIA8gFIAzgEIBGgDIASgBIASAAIAegBQAvgBAxAAIAMAAIAhgBIAjABIAkABIAhABIAYAAIAmACQBzAFBoANQAeADAdAFIApAHQBAAKA9AOQBAAOA7ARIABAAIAVAIIASAGIAQAFIAPAHQAtAPAjARQAvAXAgAaQASANANAPIAGAGIAHAIQATAYAIAZQADAMABANQAAAYgLAXQgKAWgTAUQgbAdgvAbQgUAMgZAMQgTAJgXAJQgvASg7ARIgmALQiAAiiSAUIgfAEIgNACIgOADIgLABIgaADIghADIgrAEIgXABIgXAAQhDAEhGACIg/ABIgjAAg");
	this.shape_468.setTransform(10,4.7);

	this.shape_469 = new cjs.Shape();
	this.shape_469.graphics.f("#D5FFFF").s().p("Ar7DhQk8hdgBiEQABiCE8heQE9hdG+AAQG/AAE9BdQE8BeABCCQgBCEk8BdQk9Bem/AAQm+AAk9heg");
	this.shape_469.setTransform(10.4,4.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_430}]},516).to({state:[{t:this.shape_431}]},1).to({state:[{t:this.shape_432}]},1).to({state:[{t:this.shape_433}]},1).to({state:[{t:this.shape_434}]},1).to({state:[{t:this.shape_435}]},1).to({state:[{t:this.shape_436}]},1).to({state:[{t:this.shape_437}]},1).to({state:[{t:this.shape_438}]},1).to({state:[{t:this.shape_439}]},1).to({state:[{t:this.shape_440}]},1).to({state:[{t:this.shape_441}]},1).to({state:[{t:this.shape_442}]},1).to({state:[{t:this.shape_443}]},1).to({state:[{t:this.shape_444}]},1).to({state:[{t:this.shape_445}]},1).to({state:[{t:this.shape_446}]},1).to({state:[{t:this.shape_447}]},1).to({state:[{t:this.shape_448}]},1).to({state:[{t:this.shape_449}]},1).to({state:[{t:this.shape_450}]},1).to({state:[{t:this.shape_451}]},1).to({state:[{t:this.shape_452}]},1).to({state:[{t:this.shape_453}]},1).to({state:[{t:this.shape_454}]},1).to({state:[{t:this.shape_455}]},1).to({state:[{t:this.shape_456}]},1).to({state:[{t:this.shape_457}]},1).to({state:[{t:this.shape_458}]},1).to({state:[{t:this.shape_459}]},1).to({state:[{t:this.shape_460}]},1).to({state:[{t:this.shape_461}]},1).to({state:[{t:this.shape_462}]},1).to({state:[{t:this.shape_463}]},1).to({state:[{t:this.shape_464}]},1).to({state:[{t:this.shape_465}]},1).to({state:[{t:this.shape_466}]},1).to({state:[{t:this.shape_467}]},1).to({state:[{t:this.shape_468}]},1).to({state:[{t:this.shape_469}]},1).to({state:[]},1).wait(133));

	// Layer_15
	this.shape_470 = new cjs.Shape();
	this.shape_470.graphics.f("#D5FFFF").s().p("AFLDsQgLgCgOgEIgYgHQhJgVhKgCQgXAAgwACIhWADIhIAEQgsADg2AGIg3AFQgdADgPgBQgmgCg0gUIgwgUQgVgIgDgLQgEgJAHgLQAFgJAKgIQAnggAwgPQgdgNghgBQgggBgfALQgNAFglASQgzAageACQgZADg2gMIjggwQgggHgNgLQgSgOgBgYQAAgXATgNQAPgLAkACQAmACAPgIQAGgEgBgEQgBgEgIgBQgWgDgNgFQgTgIgGgRQgFgOAIgPQAIgPAPgGQAYgKAlALQAmAPAVAEQAMADAhABQAUABAGgKQADgFgBgKQgBgLACgEQAFgNAbgCQBDgGBdgTICfggQAqgIAVgCQAMgBAtgBQAzgBAYAKIATAJQALAFAIACQANAEAVgDQAxgFAzgLIAxgKQANgBAYgBIAlgBQAZgCAKABQAJABARAGQANADAcAAQCngBBFADQAmACAYAEIAtAKQAqAJBlARQBcAOAzAOQAQAEAFAHQAFAHAAAPQgBAPgEAFQgEAFgNAEQgiAKhGACQhHADgiAJQgaAHgOAOQgGAEABAFQABAFAIACQAVAHAogBIBegBQAmAAASADQAsAIAyAgQAfAWgDAVQgDATgfAMQg2AXhjARIkrAsQgXADgDAMQgBAGACALQAAAIgFAHQgFAGgIADQgIAEgWABIgkABQgjAAgLgBg");
	this.shape_470.setTransform(8.5,4.7);

	this.shape_471 = new cjs.Shape();
	this.shape_471.graphics.f("rgba(213,255,255,0.992)").s().p("AFMDuQgLgCgOgEIgYgGQhJgVhKgCQgXAAgwACIggABIg2ACIhIAEQgrADg3AFIg2AFQgdADgQgBQgmgCgzgUIgwgTQgVgIgEgKQgDgKAGgKQAEgJAKgIQAlggAugOQgdgNghgBQgggBgfALQgNAEglASIgVAJQgkAQgYABQgZADg2gMIjfgyQgfgHgMgLQgTgPgBgXQAAgXATgOQAPgKAkABQAlABAPgIQAGgEgBgEQAAgEgIgBQgWgDgMgFQgSgIgGgRQgEgNAIgQQAJgOAOgGQAYgLAlALQAmAOAVAEIAMACQAMABAVABQAUAAAGgJQADgFAAgKQgBgKACgEQAFgOAbgCQBDgGBdgSICeggQAqgIAVgCQANgBAsgBQAzgBAYAJIATAJQALAFAIACQANAEAVgDQAxgFAzgLIAOgDQAZgFAKgBQANgCAYAAIAlgBQAZgCAKABIAaAGQANADAcAAQCmAABFADQAmACAZAEIAtAKQAqAJBkARQBaAOAyAOIACAAQAQAEAFAHQAFAHABAPQgBAPgDAEQgEAFgMAEQggALhEACQhEADggAKQgZAHgOAOQgFAEABAFQABAFAIACQAVAHAnAAIAkAAIA4ABQAkABASADQApAIAwAhQAeAVgEAVQgEATgeAMQgqARhDAOIgsAJIkrAsQgXADgDAMQgBAGACALQAAAHgFAHQgGAGgHADQgJAEgWABIgjABQgjAAgLgBg");
	this.shape_471.setTransform(8.4,4.7);

	this.shape_472 = new cjs.Shape();
	this.shape_472.graphics.f("rgba(213,255,255,0.984)").s().p("AFNDwIgZgFIgYgGQhJgVhKgBQgXAAgvACIghAAIg1ADIhIAEQgsACg2AFIg2AFQgdADgPgBQgngCgzgUIgwgSQgUgIgEgLQgEgJAFgKQAFgJAJgHQAjgfArgOQgdgOghgBQghgBgeAKQgNAEglASIgVAJQgjAPgZABQgZACg1gMIjdgzQgfgIgNgLQgSgPgBgXQAAgXATgOQAOgLAkABQAkABAQgJQAGgDgBgEQgBgEgHgBQgVgDgLgGQgRgIgFgQQgFgOAJgPQAIgOAPgGQAYgKAlAKQAmANAVAEIALABQANACAVAAQAUABAGgKQADgEAAgKQgBgLACgDQAFgNAbgDQBEgGBcgSICeggQApgHAWgCQANgCAsgBQAygBAZAJIATAJQAKAFAJACQANADAUgDQAygEAzgLIANgDIAjgGQAOgBAXgBIAlgBQAZgCAKABQAJABARAGQAOADAbAAQClgBBGADQAmADAZAEIAtAJQAqAKBkAQQBYAPAzANIACABQAQAEAFAHQAGAHAAAOQAAAOgDAFQgEAFgMAEQgeAKhAADQhBAEgeAKQgZAIgMANQgFAEAAAFQACAFAIADQAVAHAlAAIAkACIA2ACQAjABAQAEQAoAIAtAhQAdAVgEAUQgFATgeAMQgqARhDAOIgrAJQiVAXiWAVQgXAEgDALQgCAGACALQAAAHgGAHQgFAGgHADQgJADgVABIgkACQgiAAgMgCg");
	this.shape_472.setTransform(8.2,4.7);

	this.shape_473 = new cjs.Shape();
	this.shape_473.graphics.f("rgba(213,255,255,0.98)").s().p("AFODyQgLgBgOgEIgYgGQhJgUhKgBQgXAAgvACIggABIg2ACIhIADQgrADg2AFIg2AEQgdADgQgBQgmgCgzgTIgwgSQgUgIgFgKQgEgJAGgKQADgJAJgHQAhgfApgOQgdgMghgCQgggBgfAKQgOADgkARIgVAJQgjAOgYABQgaACg0gMQhygahrgbQgegIgMgLQgSgPgBgXQAAgXASgOQAPgLAjAAQAjAAAQgJQAGgDgBgEQAAgEgHgBQgUgDgLgGQgQgIgFgQQgDgNAIgPQAJgOAOgGQAYgLAlAKQAmANAVADIAMABIAhACQAUAAAGgJQADgFAAgJQAAgKACgEQAGgNAagCQBEgHBbgSQBngVA3gKQAqgHAVgDQAOgBArgBQAygBAZAJIATAIQALAFAIACQANADAVgDQAxgEAzgKIANgDIAjgGIAlgCIAlgBQAZgCAKABQAJABARAFQAOADAbAAQCjAABIAEQAlACAZAEIAtAJQArAKBjAQQBYAPAzAOIACAAQAQAEAFAHQAFAHABAOQAAAOgDAEQgDAFgLAEQgcALg+ADQg+AEgdALQgXAHgMAOQgEAEAAAFQACAFAIACQAUAIAmABIAiACIA0AEQAiABAQAFQAlAJArAgQAbAVgEAUQgFATgeAMQgqARhDAOQgVAFgXAEIkqAtQgWADgEALQgCAGACAKQAAAHgFAHQgGAGgHACQgJAEgWABIgjABIgPAAQgWAAgJgBg");
	this.shape_473.setTransform(8,4.7);

	this.shape_474 = new cjs.Shape();
	this.shape_474.graphics.f("rgba(213,255,255,0.973)").s().p("AFOD0QgKgBgOgDIgYgHQhJgShKgCQgXAAgvACIggABIg2ACIhHADQgsACg2AGIg2AEQgcACgQAAQgngCgygTIgxgSQgTgIgFgKQgEgJAFgKQADgIAJgHQAegeAngOQgegMgggCQgggCgfAKQgOAEgkAPIgVAJQgjAOgYAAQgaACg0gMQhxgbhqgcQgegIgMgLQgSgPgBgYQAAgWASgOQAPgMAiAAQAjgBAQgIQAGgEgBgEQAAgEgHgBQgSgEgLgFQgPgIgEgQQgDgNAJgPQAIgOAPgGQAYgKAkAJQAlAMAWADIAMABIAhABQAUABAHgJQACgFABgJQgBgKACgEQAHgMAagCQBEgHBbgSICegfQApgIAWgCQANgBArgBQAygBAZAIIATAIQALAFAIACQANADAVgDQAxgEAzgKIANgDQAZgFAKgBIAlgBIAlgCQAZgBAKABQAJABARAFQAOADAaAAQCjAABIAEQAmACAZAEIAsAJQAsAKBiAQQBXAPA0AOIACAAQAPAEAGAHQAFAGABAOQAAAOgCAEQgDAGgLAEQgaAKg7AEQg7AEgbAMQgWAHgLAOQgEAEAAAFQACAFAIACQAUAJAlABIAhADIAzAFQAgACAPAFQAkAKAoAfQAaAVgFAUQgFASgeAMQgrARhCAPIgsAIQiTAYiWAWQgXADgEALQgBAGABAKQgBAGgFAHQgFAGgIACQgJAEgVABIgjABIgQABQgVAAgKgCg");
	this.shape_474.setTransform(7.9,4.7);

	this.shape_475 = new cjs.Shape();
	this.shape_475.graphics.f("rgba(213,255,255,0.965)").s().p("AFPD3QgKgCgOgDIgYgGQhJgShJgBQgZAAguABIggABIg1ACIhIADQgsADg1AFIg2ADQgcADgQAAQgngDgzgTIgwgRQgTgIgFgKQgFgIAFgKQADgHAIgIQAcgcAkgOQgdgNgggCQghgCgeAJQgOAEgkAPIgVAIQgjANgYABQgaABgzgMQhygchogdQgegIgMgLQgRgQgBgWQAAgXASgPQAOgLAigBQAjgBAPgJQAGgEAAgEQAAgDgHgBQgSgFgJgGQgPgHgDgPQgDgOAJgOQAJgOAOgFQAYgLAkAIQAlAMAWACIAMACIAhAAQAUABAHgKQADgEAAgIQAAgKACgEQAHgMAagCQBEgIBagRQBmgVA4gKQApgHAWgDQAOgBAqgBQAxgCAaAJIATAIQALAFAIACQANACAVgCQAxgEAzgLIANgCQAZgFAKgBIAlgBIAlgBQAYgCALABQAJABARAFQAOACAaABQChgBBKAFQAlACAZAFIAtAJQAsAKBhAQQBXAOAzAOIACAAQAQAEAFAHQAGAGABAOQAAAOgCAEQgCAFgLAEQgXALg5AEQg4AFgZAMQgVAHgKAOQgEAEAAAFQACAFAIACQAUAKAkABIAgAEIAxAGQAgADANAFQAiAKAmAgQAZAVgGATQgGASgdAMQgrARhDAOIgrAJQiTAYiWAWQgWAEgFAKQgBAFABAKQgBAHgFAGQgGAGgHACQgJAEgVACIgjABIgQAAQgVAAgKgBg");
	this.shape_475.setTransform(7.7,4.7);

	this.shape_476 = new cjs.Shape();
	this.shape_476.graphics.f("rgba(213,255,255,0.957)").s().p("AFQD5QgLgBgNgDIgZgGQhIgShJgBQgZAAgtACIghAAIg1ACIhHAEQgsACg1AEIg2AEQgcACgRAAQgmgCgzgTIgwgRQgUgIgFgJQgEgIAEgKQADgHAHgIQAagcAigNQgdgNgggCQghgBgfAIQgOADgjAPIgVAIQgjAMgYAAQgbABgygMQhygchngeQgdgJgMgLQgRgQAAgXQAAgWARgPQAOgMAhgBQAjgBAQgKQAGgDgBgEQAAgEgGgBQgRgEgJgGQgOgIgDgPQgCgNAJgOQAJgOAPgGQAYgKAjAIQAlALAXACIALABIAhAAQAUABAHgJQADgEAAgJQABgKACgDQAHgMAZgDQBEgHBbgSQBlgUA5gKQAogHAWgCQAPgCAqgBQAwgBAbAIIASAIQALAEAIACQAOADAUgDQAxgEAygKIAOgCIAjgGQAOgBAXAAIAlgCQAYgBALABIAaAGQAOADAaAAQCgAABKAEQAlADAZAEIAtAJQAtAKBgAQQBWAOA0APIACAAQAPAEAGAGQAGAHABANQABANgCAEQgCAGgKADQgWAMg2AEQg1AGgXAMQgUAIgJANQgEAEAAAFQACAFAIADQAUAJAjADIAgAEIAvAHQAeAEAMAFQAhAKAjAhQAXAUgGATQgGASgeAMQgrARhCAPIgrAJQiSAYiXAVQgWAEgEAKQgCAFABAKQgBAGgGAGQgFAGgHADQgKADgUABIgkACIgPAAQgVAAgKgBg");
	this.shape_476.setTransform(7.6,4.6);

	this.shape_477 = new cjs.Shape();
	this.shape_477.graphics.f("rgba(213,255,255,0.949)").s().p("AFRD7IgYgEIgZgGQhIgRhJgBQgZAAgtACIghABIg1ACIhHADQgsABg1AFIg2ADQgbADgRgBQgngCgygSIgwgRQgUgHgFgJQgFgIAEgKQACgIAHgGQAYgcAggOQgdgMghgCQgggCgfAJQgOACgjAOIgVAIQgjALgYAAQgbAAgygLQhygdhlgfQgcgJgMgMQgRgPgBgXQAAgXARgOQAOgMAhgCQAigCAQgKQAGgDgBgEQAAgEgGgBQgQgEgIgGQgNgIgCgPQgCgNAJgOQAJgNAPgGQAYgKAkAHQAkALAXABIAMABIAhAAQATAAAHgIQADgEABgJQAAgJADgEQAHgMAZgCQBEgIBagRQBkgUA6gKQAogHAXgCIA4gDQAwgBAbAIIASAHQALAEAIACQAOADAUgDQAxgEAygJIAOgDIAjgFIAlgCIAlgBQAYgBALABQAJABARAFQAOACAaAAQCfABBLAEQAlADAZAEIAsAJQAuAKBfAQQBVAOA0APIACAAQAQAEAGAHQAFAGACANQABANgCAEQgCAFgJAEQgTALg0AFQgxAGgWAMQgSAJgJANQgFAEABAFQACAFAHADQAVAJAiAEIAfAEIAtAJQAdAEAMAGQAeALAhAgQAWAUgHATQgHASgdALQgrAShCAOIgrAJQiSAZiWAVQgWAEgFAKQgCAFABAJQgCAHgFAGQgGAFgHADQgJADgVABIgjACIgugBg");
	this.shape_477.setTransform(7.4,4.6);

	this.shape_478 = new cjs.Shape();
	this.shape_478.graphics.f("rgba(213,255,255,0.945)").s().p("AFSD9QgLgBgNgDIgYgFQhIgRhKgBIhGACIggABIg1ACIhHACIhhAGIg2AEQgbACgRgBQgngCgygRIgwgRQgTgHgGgJQgFgIAEgJQACgIAGgGQAWgbAdgOQgdgMgggCQghgCgeAIQgPACgjAOIgUAHQgjALgYAAQgbgBgygLQhzgehjggQgcgJgMgMQgQgQgBgWQAAgXARgOQAOgNAggCQAhgDARgKQAFgDAAgEQAAgDgFgCQgQgEgHgHQgMgIgCgOQgBgNAJgNQAJgNAPgGQAYgLAjAHQAlAKAWABIAMABIAhAAQATAAAIgJQADgDABgJQAAgJADgDQAIgMAZgCQBEgIBZgSQBkgTA6gKQAogHAXgCQAPgCAogBQAwgCAbAIIATAHQALAEAIACQANADAUgDQAxgEAzgJIANgCQAYgFAMAAQAOgCAWAAIAlgBQAYgBALAAQAKACAQAEQAOADAaAAQCeAABMAFQAkADAaAEIAsAJQAvAKBdAQQBVAOA1APIACAAQAPAEAGAHQAGAGACAMQAAANgBAEQgBAFgJAEQgSALgwAFQgvAHgUANQgRAIgIAOQgEAEABAFQACAFAHACQAVALAgAEIAfAFIArAKQAcAFAKAFQAdAMAeAhQAVAUgIASQgHASgdALQgrARhCAPIgrAJQiRAZiWAWQgWADgFAKQgDAFABAJQgCAGgFAGQgGAFgHADQgJADgVABIgjACIgugBg");
	this.shape_478.setTransform(7.2,4.6);

	this.shape_479 = new cjs.Shape();
	this.shape_479.graphics.f("rgba(213,255,255,0.937)").s().p("AFTEAQgLgBgNgDIgYgFQhIgQhKgBQgZAAgsABIghABIg1ACIhHADQgsABg0AFIg2ADQgbACgRgBQgngCgygRIgwgRQgTgHgGgIQgFgIADgJQABgHAGgHQAUgaAbgNQgegMgggCQgggDgeAIQgQACgiANIgUAGQgjALgYgBQgbAAgxgMQh0gehhghQgcgJgLgNQgQgPgBgXQAAgXAQgOQAOgNAggDQAggDARgKQAFgDAAgEQABgEgGgBQgOgFgGgGQgMgIgBgPQgBgMAJgNQAKgNAOgGQAYgKAkAGQAkAJAXABIAMABIAggBQATAAAIgIQADgEABgIQABgJADgDQAIgMAZgCQBEgJBZgRQBigTA7gKQAogHAXgCQAPgCApgBQAvgBAbAHIATAHQALAEAIACQAOACAUgCQAwgEAzgJIANgCQAYgFAMAAIAkgCIAlgBQAYgBALABIAaAFQAOADAaAAQCcABBNAFQAlACAZAFIAtAJQAvAKBcAPQBUAPA1AOIACABQAPAEAGAGQAGAGADAMQABANgBAEQgBAFgJAEQgPALguAGQgsAHgSANQgQAJgHAOQgEADABAFQACAFAHADQAUAKAhAGIAdAFIAqAMQAaAFAKAGQAaAMAcAgQATAUgIATQgHARgdALQgrARhCAPIgrAJQiRAZiWAWQgVADgGAKQgDAFABAJQgCAGgFAFQgGAGgHACQgKADgUACIgjABIgbAAIgTAAg");
	this.shape_479.setTransform(7.1,4.6);

	this.shape_480 = new cjs.Shape();
	this.shape_480.graphics.f("rgba(213,255,255,0.929)").s().p("AFUECIgYgEIgZgFQhHgPhKgBIhFACIghAAIg1ACIhGADQgtABg0AEIg1ADQgbACgRgBQgogCgxgRIgwgQQgTgGgGgJQgFgHACgJQABgHAFgGQASgaAYgNQgdgMgggCQgggDgfAHQgPACgiAMIgUAGQgiAKgZgBQgcgBgwgLQhzgfhggiQgcgJgLgNQgQgQgBgXQAAgWARgPQANgNAfgDQAggEARgKQAGgDgBgEQABgEgFgBQgNgFgGgGQgLgIAAgPQgBgMAKgNQAJgMAPgGQAYgLAjAGQAkAJAXAAIAMABIAhgBQASAAAIgIQAEgEABgIQABgJADgDQAIgLAZgDQBEgIBZgRQBhgTA8gKQAngHAXgCQAQgCAogBQAvgBAcAHIASAGQALAEAIACQAOACAUgCQAxgEAygIIANgDIAkgFIAkgBIAlgBQAXgBAMABQAKABAQAEQAOADAaAAQCbABBOAFQAkADAaAEIAsAJQAwAKBbAQQBUAOA1APIACAAQAPAEAGAGQAGAGADAMIAAAQQgBAFgHAEQgOAMgrAGQgoAHgRAOQgPAJgHAOQgDADABAFQACAFAHADQAUALAgAGIAcAGIAoANQAZAEAJAIQAZANAZAgQASATgJATQgHARgdALQgsARhBAPIgrAJQiQAaiXAVQgVADgGAKQgCAFAAAIQgCAGgGAGQgFAFgHACQgKADgUABIgjACIgcAAIgSAAg");
	this.shape_480.setTransform(6.9,4.6);

	this.shape_481 = new cjs.Shape();
	this.shape_481.graphics.f("rgba(213,255,255,0.922)").s().p("AFVEEIgZgEIgYgFQhHgOhKgBIhFACIggAAIg1ACIhHADQgsABg0AEIg2ADQgbABgRgBQgngCgxgQIgwgQQgTgGgHgJQgFgHACgIQABgHAEgGQAQgaAWgMQgdgMgggCQgggDgfAGQgQACghALIgUAGQgiAKgZgBQgcgCgvgMQh0gfhfgjQgbgKgLgMQgPgQgBgXQAAgWAQgPQANgOAfgEQAfgDARgLQAGgDAAgEQAAgDgEgCQgNgFgFgHQgKgIAAgOQAAgLAKgNQAJgNAPgGQAYgKAjAFQAkAIAXAAIAMABIAhgBQASAAAIgJQAEgDABgIQABgIADgEQAJgLAYgCQBFgJBYgRQBhgTA8gJQAngHAYgCIA3gDQAvgCAcAHIATAHQAKADAIACQAOACAUgCQAxgEAygIIANgCQAYgEALgBQAPgBAWAAIAlgBIAjgBIAZAGQAPACAZABQCaAABPAGQAkADAaAEIAtAJQAwAKBaAQQBTAOA1APIACAAQAPAEAHAGQAGAGACAMQACALAAAEQgBAFgHAEQgLAMgpAGQglAJgPAOQgOAJgGAOQgDADABAFQACAFAHADQAUALAfAHIAbAHIAmAOQAYAFAIAIQAXANAXAgQAQAUgJASQgIAQgcALQgsAShBAPIgrAJQiQAaiWAVQgVADgHAKQgCAEgBAJQgCAFgFAGQgGAEgHADQgKADgTABIgjACIgcAAIgSAAg");
	this.shape_481.setTransform(6.8,4.6);

	this.shape_482 = new cjs.Shape();
	this.shape_482.graphics.f("rgba(213,255,255,0.914)").s().p("AFVEGIgYgEIgYgEQhHgOhKAAQgZgBgsACIggABIg1ABIhHADQgsABg0ADIg1ADQgbACgRgBQgogDgwgPIgxgQQgSgGgHgIQgFgHABgIQAAgHAFgGQANgZAUgNQgegLgfgCQgggDgfAGQgQABghALIgUAFQgiAJgZgBQgcgCgvgMQh0gghdgjQgagLgMgNQgPgQgBgWQAAgWAQgQQANgNAfgFQAegEARgLQAGgDAAgEQABgDgFgCQgLgFgFgHQgJgIABgOQAAgLAKgNQAKgMAOgGQAZgKAiAEQAjAIAYAAIAMAAIAhgBQASgBAJgIQADgDACgIQABgIADgDQAJgLAYgDQBFgJBYgQQBggTA8gKQAngGAYgCIA3gDQAvgCAcAHIATAGQAKAEAIABQAOACAUgCQAxgEAygIIANgCQAYgEALAAIAlgCIAlAAQAXgCAMABQAJABAQAEQAPADAZAAQCZABBQAGQAkADAaAEIAsAJQAxAKBZAQQBSAOA2APIACAAQAOAEAHAGQAHAGACALIACAQQAAAEgHAEQgJAMgmAHQgiAJgNAOQgNAKgFANQgDAEABAFQACAFAHADQAUALAeAIIAbAHIAkAQQAXAFAGAJQAWAOAUAgQAPATgKASQgIAQgcALQgsARhBAPIgrAKQiQAaiWAVQgVAEgHAJQgCAEgBAIQgCAGgGAFQgFAEgHADQgKADgUABIgjACIgbAAIgTAAg");
	this.shape_482.setTransform(6.6,4.6);

	this.shape_483 = new cjs.Shape();
	this.shape_483.graphics.f("rgba(213,255,255,0.91)").s().p("AFWEIQgLgBgOgCIgYgFQhHgNhJAAIhFABIghABIg0ABIhHACIhgAFIg1ACQgbACgRgBQgogCgwgQIgwgPQgTgGgHgIQgFgHABgIQAAgGADgGQALgYASgNQgdgLgggCQgggDgfAFQgQABghAKIgUAFQghAIgZgBQgdgCgugMQh1ghhbgkQgagLgLgNQgPgQAAgXQAAgVAPgQQANgOAegFQAegFARgLQAGgDAAgDQAAgEgEgCQgKgFgEgHQgIgIABgOQABgLAKgMQAKgMAOgGQAZgLAiAFQAjAGAYAAIAMAAIAhgCQASAAAIgIQAEgDACgIQABgIADgDQAKgKAYgDQBEgJBYgRQBfgSA9gKQAngGAYgCQARgCAmgBQAugCAcAGIATAGQALAEAIABQAOACATgCQAxgDAygIIAOgCIAjgFIAkgBIAlgBQAXgBAMABQAKABAQAEQAPADAYAAQCYABBRAGQAjADAbAEIAsAJICKAaQBRAOA2APIACAAQAOAEAHAGQAHAGADALIACAPQAAAFgGADQgHANgjAHQgfAJgMAPQgLAJgFAOQgDAEABAEQADAGAGACQAVANAcAIIAaAIIAjAQQAVAHAGAJQAUAPARAfQAOATgKARQgJARgcALQgsARhBAPIgrAKQiPAaiWAWQgVADgHAIQgDAFgBAHQgCAGgFAFQgGAEgHADQgKADgTABIgjACIgbAAIgTAAg");
	this.shape_483.setTransform(6.5,4.6);

	this.shape_484 = new cjs.Shape();
	this.shape_484.graphics.f("rgba(213,255,255,0.902)").s().p("AFXEKQgLgBgOgCIgYgEQhHgNhJAAIhFABIggABIg1ABIhGACQgtABgzADIg1ADQgbABgRgBQgogCgwgPIgxgPQgSgGgHgIQgGgGABgIQgBgGAEgGQAIgXAQgNQgegLgfgCQgggEgfAFQgQABghAKIgUAEQghAIgZgCQgdgCgtgMQh2gihZglQgagLgLgNQgOgRgBgWQAAgWAPgPQANgPAdgFQAegGARgLQAGgDAAgDQABgEgEgCQgKgFgCgHQgIgIACgOQABgLAKgMQAKgMAPgGQAYgKAiAEQAjAGAYgBIAMAAIAhgCQASAAAJgIQADgDACgIQACgHADgDQAKgLAYgCQBEgKBXgQQBfgSA+gKQAmgGAYgCQARgCAmgCQAugBAcAGIAUAFQAKAEAIABQAOACATgCQAxgDAygIIAOgCQAXgDAMgBIAkgBIAlgBIAjAAIAZAFQAQACAYABQCWABBSAGQAkADAaAEIAsAJICKAaQBRAOA2APIACAAQAOAEAHAGQAHAGADALIADAOQAAAFgGAEQgFAMggAIQgcAKgKAPQgKAJgEAOQgDAEABAEQADAFAGADQAVANAbAJIAaAJIAgARQAVAHAEAKQASAPAPAgQANASgLARQgKAQgbALQgtAShAAPIgrAJQiPAbiWAWQgUADgIAIQgDAEgBAIQgCAFgGAFQgGAEgHADQgKADgTABIgjACIgaAAIgTAAg");
	this.shape_484.setTransform(6.4,4.6);

	this.shape_485 = new cjs.Shape();
	this.shape_485.graphics.f("rgba(213,255,255,0.894)").s().p("AFXEMIgYgCIgYgFQhHgMhJABQgagBgrACIggAAIg1ABIhGACQgtACgyADIg1ACIgtAAQgngDgxgPIgwgNQgSgHgIgHQgFgGAAgIQgBgGADgGQAGgWANgNQgdgKgfgDQgggDgfAEQgRAAggAJIgUAFQghAGgZgCQgdgCgtgMQh2gjhXgmQgagKgKgOQgPgRAAgWQAAgWAOgQQANgOAdgGQAdgGASgLQAFgDAAgEQABgDgDgDQgJgFgCgHQgHgIADgNQABgLAKgMQAKgLAPgHQAYgKAiADQAjAGAYgBIANAAIAggCQASgBAJgIQAEgDACgHQACgHADgEQAKgJAXgEQBFgJBXgRQBdgSA/gJQAmgGAZgDIA2gCQAugCAdAGIATAFQAKAEAIAAQAOACAUgCQAwgDAygHIAOgCQAWgEANAAIAkgBIAlgBIAjAAQAKABAPAEQAQACAYAAQCVACBTAHQAjADAbAEIAsAJICJAZQBQAPA2APIACAAQAOAEAIAFQAGAGAEALIADAOQABAFgFADQgDANgeAIQgZAKgIAQQgJAKgDANQgDAEABAEQADAFAGAEQAUANAcAJIAYAJIAfATQATAIAEAKQAPAQANAfQALATgLARQgKAPgcALQgsAShAAPIgrAJQiOAciWAVQgVADgHAIQgEAFgBAGQgCAGgGAEQgGAFgHABQgKAEgTABIgjACIgiAAIgMAAg");
	this.shape_485.setTransform(6.2,4.6);

	this.shape_486 = new cjs.Shape();
	this.shape_486.graphics.f("rgba(213,255,255,0.886)").s().p("AFYEOIgZgCIgXgEQhHgLhJAAIhFABIghABIg0ABIhGACIhfADIg1ACQgbABgRgBQgogCgwgOIgwgOQgTgGgHgHQgGgHAAgHQgCgGACgFQAFgWAKgNQgdgKgfgDQgggDgeADQgSABggAIIgTAEQghAGgZgCQgdgDgtgMQh2gjhWgnQgZgLgLgOQgOgRAAgWQAAgWAOgQQANgOAcgHQAdgGARgMQAFgDABgEQABgDgDgCQgIgGgBgHQgGgIADgNQACgLAKgLQAKgMAPgGQAYgKAiADQAiAFAZgCIAMAAIAhgDQARAAAJgIQAEgDACgHQADgHADgDQAKgKAYgDQBEgKBXgQQBdgRA/gKQAlgGAZgCIA3gDQAtgCAdAGIATAFIATAEQAOACATgCQAxgEAxgGIAOgCQAXgEAMAAIAlgBIAlgBQAWgBAMABQAKABAQAEQAPACAYAAQCUACBUAHQAjADAaAEIAsAJICJAZQBQAPA2APIACAAQAOAEAIAGQAHAFADAKIAEAOQABAFgEADQgBANgbAJQgWALgGAQQgJAKgCAOQgCADABAFQACAFAHADQAUANAaAKIAYALQARAKAMAJQASAJACAKQAOARAKAfQAKASgMARQgKAPgbALQgtARhAAQIgqAKQiOAbiXAVQgUADgIAIQgDAEgCAHQgCAFgGAFQgGAEgHACQgKADgTABIgjACIghAAIgMAAg");
	this.shape_486.setTransform(6.1,4.5);

	this.shape_487 = new cjs.Shape();
	this.shape_487.graphics.f("rgba(213,255,255,0.878)").s().p("AFZEQIgZgCIgYgEQhGgKhJAAIhFABIggABIg1ABIhGACQgsAAgzADIg1ABIgsABQgogDgvgOIgxgNQgSgGgIgHQgGgGAAgHQgCgGACgFQACgVAIgNQgdgKgfgDQgggEgfAEQgRAAggAHIgTAEQghAGgZgDQgegDgsgMQh2gkhVgoQgYgMgKgOQgOgQgBgWQAAgWAOgQQANgPAcgHQAcgHASgMQAFgDAAgDQABgEgCgCQgHgGgBgHQgFgIADgNQADgLAKgLQALgLAOgGQAZgKAhACQAiAEAZgCIANAAIAggDQARgBAKgHQAEgDACgHQACgHAEgDQAKgJAYgDQBEgKBWgQQBcgSBAgJQAlgGAagCIA2gDQAtgCAdAFIAUAFQAKADAIABQAOACATgCQAxgDAxgHIAOgCQAWgDANAAIAlgBIAkgBIAjAAIAZAEQAQADAYAAQCSACBVAHQAjADAbAEIAsAJICIAZQBPAPA3APIACAAQAOAEAHAGQAHAFAEAKIAFAOQABAEgEAEQABANgYAIQgTAMgEARQgIAKgBAOQgCADABAEQADAFAGAEQAUAOAZAKIAXALQAQAMALAJQARAKACAKQAMARAHAfQAJASgNARQgKAPgcAKQgsAShAAQIgqAJQiOAciWAVQgUADgIAIQgEAEgCAHQgDAEgGAFQgFAEgHACQgLADgSABIgjACIghAAIgMAAg");
	this.shape_487.setTransform(6,4.5);

	this.shape_488 = new cjs.Shape();
	this.shape_488.graphics.f("rgba(213,255,255,0.875)").s().p("AFZESQgLAAgNgCIgYgDQhGgKhJAAIhEABIghABIg1ABIhFABIhfADIg1ACQgaABgSgBQgogDgwgNIgwgNQgSgGgIgHQgGgGgBgGQgCgGABgFQAAgVAGgMQgdgKgfgDQgggEgfADQgSAAgfAHIgTADQghAFgZgDQgegEgrgMQh3gkhTgpQgYgMgKgOQgOgRAAgWQAAgVAOgQQAMgQAbgIQAcgHASgMQAFgDAAgDQACgEgDgCQgGgGAAgHQgEgIAEgNQADgKAKgLQALgLAPgGQAYgLAhACQAiAEAagDIAMAAIAggDQARgBAKgHQAEgDACgGQADgHAEgDQALgKAWgCQBFgLBWgQQBbgRBBgJQAlgGAZgCQASgCAlgBQAsgCAeAFIATAEIASAEQAPACASgCQAxgDAxgHIAOgBQAWgDANgBIAlgBIAkAAIAjAAQAKABAPADQAQACAYABQCRACBWAHQAjADAaAEIAsAJICIAZQBPAPA3APIACAAQANAFAIAFQAHAFAEAKIAFANQACAEgEAEQADANgVAJQgQAMgDARQgGAKgBAPQgBADABAEQADAFAGADQAUAPAYALIAWAMQAQALAKALQAPAKABALQAKASAFAfQAHARgNARQgLAOgbALQgtASg/APIgrAKQiMAciXAWQgUACgIAIQgEAEgCAGQgDAFgGAEQgGAEgGACQgLADgSABIgjACIghAAIgNAAg");
	this.shape_488.setTransform(5.8,4.5);

	this.shape_489 = new cjs.Shape();
	this.shape_489.graphics.f("rgba(213,255,255,0.867)").s().p("AFaEUIgZgBIgXgEQhHgJhJAAIhEABIghABIg1ABIhEABIhfADIg1ABIgsAAQgogDgvgNIgxgMQgRgGgJgGQgGgGgBgHQgDgFABgFQgDgUAEgMQgdgKgfgDQgggEgeACQgTAAgfAGIgTADQggAFgagEQgdgEgrgMQh3glhSgpQgXgNgKgOQgOgRAAgWQAAgWANgQQAMgPAbgJQAbgIATgMQAEgDABgDQACgEgDgCQgFgGABgHQgDgIAEgNQADgKALgLQALgLAPgGQAYgKAhABQAiADAZgCIANgBIAggDQARgBAKgHQAEgDACgGQADgHAEgDQALgJAXgDQBFgLBVgPQBagRBCgKQAkgFAagCQATgCAjgCQAsgBAeAEIATAEQAKADAJABQAOACATgCQAwgDAygGIAOgCQAVgDAOAAIAkgBIAlAAQAVgBANABIAaAEQAQACAXAAQCQADBXAHQAiADAbAFIAsAIICIAZQBNAPA4APIACABQANAEAIAFQAHAFAFAJIAFANQACAFgDADQAFANgSAKQgNANgBARQgFAKAAAPQgCADABAEQADAFAGADQAUAPAYAMIAVANQAPALAJAMQAOALAAALQAIASACAfQAGARgNARQgMAOgbALQgtARg/AQIgqAKQiNAciWAWQgUACgIAIQgEADgDAHQgDAEgGAEQgGAEgGACQgLACgSACIgjACIghABIgMgBg");
	this.shape_489.setTransform(5.7,4.5);

	this.shape_490 = new cjs.Shape();
	this.shape_490.graphics.f("rgba(213,255,255,0.859)").s().p("AFCEVIgYgDQhGgJhJAAIhEACIghAAIg1ABIhEABIhfADIg1ABQgZAAgTgBQgogCgvgNIgwgMQgSgGgJgGQgGgFgCgHQgDgFAAgFQgEgTABgMQgdgJgfgEQgfgEgfACQgSgBgfAGIgTACQghAEgZgDQgegFgqgMQh4glhPgrQgXgNgKgOQgNgRgBgWQAAgWANgQQAMgQAbgJQAagIASgNQAFgDABgDQACgDgCgCQgFgHACgHQgCgIAFgNQADgKALgKQALgLAPgGQAYgKAhAAQAhADAagDIANgBIAggDQARgCAJgGQAFgDACgGQADgGAFgDQALgJAWgDQBFgLBVgQQBagQBCgKQAkgFAagCQATgCAjgCQArgBAfAEIATAEIATADQAOACATgCQAwgDAxgGIAOgBIAjgDIAlgBIAkAAQAWgBANABIAZAEQAQACAYAAQCOADBYAIQAiADAbAEIAsAIICHAZQBNAPA4APIACABQANAEAIAFQAIAFAEAJIAGANQADAEgDADQAHAOgPAKQgKANAAASQgDAKAAAPQgBADABAEQADAFAGADQAUAQAXANIAUAMQAOANAIAMQANALgBAMQAGATAAAfQAFARgPAQQgMAOgaAKQgtAShAAQIgqAKQiMAdiWAVQgTADgKAHQgEADgCAGQgEAEgGAEQgFAEgHACQgLACgSACIgiACIguABIgYgCg");
	this.shape_490.setTransform(5.6,4.5);

	this.shape_491 = new cjs.Shape();
	this.shape_491.graphics.f("rgba(213,255,255,0.851)").s().p("AFCEXIgYgDQhGgIhJAAIhDACIghAAIg1ABIhFABIheACIg1ABQgZABgTgCQgogCgvgMIgwgNQgRgFgKgGQgGgFgCgGQgEgFAAgFQgGgTgCgLQgdgJgegEQgggEgfABQgSgBgfAFIgTACQggADgZgDQgfgFgpgMQh4gmhOgsQgXgNgKgPQgMgRgBgWQAAgVANgRQAMgQAagJQAZgJATgNQAFgDABgDQABgDgBgCQgEgHADgIQgCgIAGgMQAEgJAKgLQAMgKAOgGQAZgLAgAAQAhACAbgDIAMgBIAggEQARgBAKgHQAEgDADgFQADgGAFgDQALgJAXgDQBFgLBUgPQBZgRBCgJQAkgFAbgDIA2gDQArgCAeAEIAUAEIASADQAPABASgBQAwgDAygFIANgCIAkgDIAkgBIAlAAIAiAAIAZAEQARACAXABQCNACBZAJQAiADAbAEIAsAIICGAZQBNAPA4APIACABQANAEAIAFQAIAFAFAJIAGAMQADAEgCADQAJAOgNALQgHANADASQgDALABAOQgBAEACAEQACAFAGADQAUAQAWAOIATANQAOANAHANQALAMgCAMQAFAUgDAeQAEARgPAPQgNAOgaALQgtASg/APIgqALQiMAdiWAVQgTADgKAGQgEAEgDAFQgEAFgGADQgFAEgHABQgLADgSABIgiACIguACIgYgCg");
	this.shape_491.setTransform(5.5,4.5);

	this.shape_492 = new cjs.Shape();
	this.shape_492.graphics.f("rgba(213,255,255,0.843)").s().p("AFBEaIgYgDQhGgIhJABIhDABIghABIg1ABIhEAAIhfACIg0AAQgZABgTgBQgpgDgugLIgwgNQgRgEgKgGQgHgFgCgGQgEgFgBgEQgIgSgEgMQgdgJgfgEQgfgFgfACQgTgCgeAFIgTABQggADgZgEQgfgFgpgMQh4gnhNgtQgWgNgJgPQgNgRAAgWQAAgVAMgRQAMgQAZgKQAZgJATgNQAFgDABgEQACgDgCgCQgCgHADgHQgBgJAGgLQAFgKALgLQALgJAPgGQAYgLAhAAQAgABAbgEIANgBIAfgDQARgCAKgGQAFgDADgGQADgFAFgDQALgJAXgDICYgaQBYgRBEgJIA+gIIA2gDQAqgBAfADIAUADQAKADAIABQAPABASgCQAwgCAygFIANgCIAkgDIAkgBIAlAAQAUgBAOABIAZAEQARACAXABQCMACBaAJQAhADAcAFQAPABAcAHICGAZQBMAOA4AQIACAAQAOAEAIAFQAHAFAGAIIAHANQADAEgCADQAMAOgLAKQgEAPAFASQgCAMACAOQgBADACAEQACAFAGAEQAUAPAVAPQAKAGAIAIQAOAOAFAOQALAMgDAMQACAVgFAdQACARgPAQQgNANgaAKQguATg/APIgpAKQiMAeiWAVQgTADgKAHQgEADgDAFQgEAEgGAEQgGADgHABQgLADgRACIgiACIguABIgYgBg");
	this.shape_492.setTransform(5.6,4.5);

	this.shape_493 = new cjs.Shape();
	this.shape_493.graphics.f("rgba(213,255,255,0.839)").s().p("AE/EcIgYgCQhGgHhJAAIhDABIghABIg0ABIhFAAIheACIg0AAQgZABgTgCQgpgCgugMIgwgLQgRgFgKgFQgHgFgDgGQgEgFgCgEIgQgdQgdgJgfgEQgfgEgfAAQgTgBgeAEIgTABQggACgZgFQgfgFgogMQh5gohLgtQgWgNgJgQQgMgRgBgWQAAgVANgRQALgQAZgLQAYgKATgNQAFgDABgDQACgEgBgCQgCgHAEgHQAAgIAHgMQAFgJALgLQALgJAPgGQAZgLAggBQAgABAbgEIANgCIAggEQAQgBAKgGQAFgDADgFQAEgGAEgCQANgJAVgDICZgbQBXgQBEgJIA+gHIA2gEQAqgBAgADIATADIASADQAPABASgCQAwgCAygFIANgBIAkgDIAkgBIAlAAQAUAAAOABQALAAAOADIAnACQCLAEBbAIQAiADAbAFIAsAIICFAZQBMAOA4AQIACABQANAEAJAFQAHAEAGAIIAHAMQADAEAAADQANAOgIAMQAAAOAFATQAAALACAPQAAADACAEQACAFAGADQAUARAUAPIASAPQAMAOAFAPQAJAMgEAOQABAUgIAeQABAQgQAQQgOANgZALQguARg/AQIgqALQiKAdiXAWQgSACgLAGQgEAEgDAFQgEAEgGADQgGADgHACQgLACgRACIgjACIgtABIgYgBg");
	this.shape_493.setTransform(5.7,4.5);

	this.shape_494 = new cjs.Shape();
	this.shape_494.graphics.f("rgba(213,255,255,0.831)").s().p("AE8EeIgYgCQhGgGhIAAIhDACIghAAIg0ABIhFAAIheABIg0ABIgsgBQgpgDgugLIgwgLQgRgFgKgFQgHgFgDgFQgFgFgCgEIgVgcQgdgJgfgEQgfgFgfABQgTgCgeADIgSABQggABgagEQgfgGgngMQh5gphKguQgVgOgJgPQgMgSgBgVQAAgVAMgRQALgRAZgLQAYgLATgNQAFgDABgDQACgDgBgDQAAgHAEgIQABgIAHgLQAFgJAMgKQALgKAPgGQAZgKAggCQAgAAAbgEIANgCIAfgEQARgCAKgGQAFgCADgFQAEgGAFgCQAMgIAWgDICYgbQBWgQBFgJQAjgFAbgCIA2gEQAqgCAfADIAUADIASADQAPABASgCQAwgCAxgFIAOgBIAjgCIAkgBIAlAAIAiAAIAZAEQARACAXAAQCJADBcAJIA9AIIAsAIICFAZQBLAOA4AQIACABQANAEAJAFQAHAEAGAIQAFAIADADQAEAEgBAEQAQAOgFALQACAQAIATIAEAaQgBADACAEQADAFAFADIAoAhQAJAIAHAHQAMAQAEAPQAIANgFAOQgBAVgLAeQAAAQgRAPQgNANgaAKQguASg+AQIgqAKQiKAfiXAVQgSACgLAGQgEADgEAFIgKAHQgGADgHACQgLACgRABIgiADIguABIgYgBg");
	this.shape_494.setTransform(5.9,4.5);

	this.shape_495 = new cjs.Shape();
	this.shape_495.graphics.f("rgba(213,255,255,0.824)").s().p("AE5EgIgXgCQhGgFhIABIhDABIgiAAIgzABIhFAAIheABIg0AAQgZAAgTgBQgpgDgtgKIgxgLQgQgFgLgFQgHgEgEgFQgFgFgCgEIgagbQgdgJgegEQgggFgeAAQgUgCgdACIgTABQgfABgagFQgfgGgngNQh6gohIgwQgUgOgKgPQgLgSgBgWQAAgUAMgSQALgRAYgMQAYgKATgOQAEgDACgDQACgDgBgCQABgIAFgIQACgIAHgLQAGgJALgKQAMgJAPgGQAZgKAfgCQAggBAcgFIAMgBIAggFQAQgCALgGQAEgCAEgFQAEgFAFgDQANgHAVgEICYgbQBWgPBFgJQAjgFAbgCIA2gEQApgCAgADIATADQAKACAJAAQAPABARgBQAwgDAygEIANgBIAkgDIAkAAIAkAAIAjAAIAZADQARACAWABQCIADBdAJQAhAEAcAEQAQACAbAGICFAZQBLAOA4AQIACABQANAEAJAFQAIAEAGAIIAIAKQAEAEAAAEQASAOgCAMQAFAQAJAUIAGAaQAAADACAEQADAFAFADIAmAiIAQAQQALAQADAQQAHAOgHAOQgCAVgNAeQgCAQgRAPQgOANgaAKQguASg+AQIgqAKQiJAfiXAVQgSACgLAGQgFADgEAFQgEADgGADQgGADgHACQgLACgRABIgiADIgtABIgZgBg");
	this.shape_495.setTransform(6.1,4.5);

	this.shape_496 = new cjs.Shape();
	this.shape_496.graphics.f("rgba(213,255,255,0.816)").s().p("AE3EjIgXgCQhGgFhIABIhDABIgiAAIgzABIhFAAIhdABIg0gBIgsgBQgpgDgugKIgwgKQgRgFgKgEQgIgFgDgFIgJgIIgegaQgdgIgegFQgggFgegBQgVgCgcACIgTAAQgfAAgagFQgfgHgngMQh6gphGgxQgUgOgJgQQgMgRAAgWQAAgVALgRQALgRAYgNQAXgLATgOQAEgDACgDQACgDAAgCQABgIAGgIQADgIAIgLQAGgJAMgJQAMgJAOgGQAZgLAfgCQAggBAcgGIANgBIAfgFQAQgCALgGQAFgDADgEQAFgFAFgCQANgIAVgDICXgbQBVgQBGgIQAjgFAbgDIA2gDQApgCAgADIATACIATACIAhAAIBggHIAOgBIAkgCIAkAAIAkAAQAUgBAPABQALABAOACIAnACQCHAEBeAKQAhADAbAEIAsAIICEAZQBKAOA5ARIACAAQANAEAJAFQAHAEAHAHQAFAHAEAEQAEAEABADQATAPABAMIATAlIAIAaQAAADACAEQADAFAFADIAmAjIAOARQALAQABARQAGAOgHAPQgFAWgPAdQgEAQgRAPQgPAMgZAKQguASg+ARIgqAKQiJAfiXAVQgSACgLAGQgFADgEAEIgLAGQgFADgHABQgMADgQABIgiACIguACIgYAAg");
	this.shape_496.setTransform(6.3,4.5);

	this.shape_497 = new cjs.Shape();
	this.shape_497.graphics.f("rgba(213,255,255,0.808)").s().p("AE0ElIgXgCQhGgEhIABIhDABIghAAIg0ABIhEAAIheAAIg0AAIgsgBQgpgEgtgJIgwgKQgRgEgLgFQgHgEgEgEIgKgIIgigaQgegIgegFQgfgFgegBQgVgDgcACIgTAAQgfgBgagFQgfgIgngLQh6grhEgxQgUgPgJgQQgLgSgBgVQAAgVAMgSQAKgRAXgNQAXgMATgOQAEgCACgDQADgDAAgDQACgIAHgIQADgIAJgLQAGgJAMgJQAMgJAPgGQAYgJAggEQAfgCAcgFIANgCIAfgFQAQgDALgFQAFgCAEgEQAEgFAGgDQANgHAVgDICXgbQBUgPBHgKIA+gHIA1gDQApgCAgACIAUACIASACIAhAAIBggGIAOgBQAVgCAPAAIAkgBIAkABIAjAAIAYADIAoACQCFAEBfAKQAhADAcAEIArAIICEAZQBJAPA5AQIACAAQANAFAJAEQAIAFAHAGQAFAHAEAEQAFADABAEQAWAOADANIAYAmIAKAaQAAADACAEQADAEAFAEIAlAkQAIAJAGAIQAJASABARQAEAPgIAPQgHAXgRAdQgFAPgSAPQgPAMgZAKQgvASg9AQIgqALQiJAfiWAVQgSADgMAFQgFADgEAEIgLAGQgGADgGABQgMACgRABIgiACIgtADIgYgBg");
	this.shape_497.setTransform(6.5,4.5);

	this.shape_498 = new cjs.Shape();
	this.shape_498.graphics.f("rgba(213,255,255,0.804)").s().p("AExEoIgXgCQhGgEhIABIhCABIgiAAIgzABIhEAAIheAAIg0gBIgrgBQgqgDgtgJIgwgKQgQgEgLgEQgIgEgFgFIgKgHIgngZQgdgIgegFQgggFgegCQgVgDgcABIgSAAQgfgCgagGQgggHgmgMQh6grhDgyQgUgPgIgQQgLgSAAgVQAAgVAKgSQALgSAWgNQAWgMAUgPQAEgCACgDIADgGQADgHAIgJQAEgIAJgKQAHgJAMgJQAMgIAPgHQAYgKAfgDQAggDAcgGIANgCIAfgGQAQgCALgFQAFgDAEgEQAEgEAGgCQAOgHAUgDICXgcQBTgPBIgIIA+gIIA1gDQAogCAhACIATACIATABIAgAAIBhgGIAOgBIAjgCIAkAAIAlAAIAiABIAZADIAnACQCEAEBgAKIA9AHIArAIQA6ALBKAOQBIAOA6ARIACAAQAMAFAJAEQAIAEAHAHIAKAJQAFAFACACQAXAPAHANIAcAoIAMAaIACAGQADAGAFADIAkAlQAIAKAFAIQAJATAAARQADAPgJAQQgJAXgUAeQgGAPgTANQgPANgZAKQgvASg9AQIgqALQiIAgiWAUQgSACgMAFQgFADgFAEIgLAGQgGACgGACQgMACgQABIgiADIgtACIgNAAIgMAAg");
	this.shape_498.setTransform(6.7,4.5);

	this.shape_499 = new cjs.Shape();
	this.shape_499.graphics.f("rgba(213,255,255,0.796)").s().p("AEuEqIgXgBQhGgDhIABIhCABIgiAAIgzAAIhEAAIhdAAIg0gBIgsgBQgpgEgtgIIgwgKIgcgIQgIgEgFgEIgLgHIgrgYQgegIgegFQgfgFgegCQgVgDgcAAIgSgBQgfgCgagGQgggIglgMQh7grhBgzQgTgPgJgRQgLgSAAgWQAAgUALgSQAKgSAWgOQAVgNAUgOQAEgDACgDIADgFQAEgJAJgIQAFgIAKgKQAHgJAMgIQAMgJAPgGQAZgKAfgEQAegDAdgGIANgDIAfgFQAQgDALgFQAFgCAEgEQAFgEAGgCQAOgHAUgEICWgbQBTgPBIgJIA+gGIA1gEQAogCAhACIATABIATACIAggBIBhgFIAOgBIAjgCIAkAAIAlABQATgBAPABIAZADIAnACQCDAEBhAKQAgAEAcAEIArAIQA7AKBJAOQBHAPA6AQIACABQANAEAJAEQAIAEAHAHQAGAGAFADQAFAEACADQAaAPAJAOQARASAQAVIAOAbIACAHQADAFAFADQAUAUAPATQAIAJAFAJQAIATgCASQACAQgKAQQgKAYgXAdQgHAPgUAOQgQAMgYAKQgvASg9AQIgqALQiHAgiXAVQgSACgMAFIgKAGIgLAFQgGADgHABIgcADIgiADIgtACIgLAAIgNAAg");
	this.shape_499.setTransform(7,4.4);

	this.shape_500 = new cjs.Shape();
	this.shape_500.graphics.f("rgba(213,255,255,0.788)").s().p("AEUErQhGgChIABIhCABIghAAIg0AAIhEAAIhdgBIgzgBQgYAAgUgBQgqgDgsgJIgwgJQgQgDgMgFIgNgHIgNgGIgwgYQgdgIgegFQgfgFgegDQgWgDgbgBIgSgBQgfgDgagGQgggIglgMQh7gshAg0QgSgPgJgRQgKgTAAgVQAAgUAKgSQAKgTAWgOIApgcIAFgGIAEgFQAFgJAJgIQAGgIAKgKQAIgIAMgJQANgIAOgGQAZgKAfgFQAegEAdgGIANgDIAfgGQAQgCALgFQAFgCAFgEQAFgEAFgCQAPgHAUgDICWgcQBSgOBIgJIA+gGIA1gEQAogCAhABIAUACIASABIAggBIBhgEIAOgBIAjgCIAkAAIAlAAIAiABIAYACIAnADQCCAEBiAKQAhAEAcAEIArAIQA7AKBIAPQBHAOA6ARIACAAIAWAIQAIAEAHAGQAGAGAFADIAIAHQAcAQAMAOQAUASASAWIAPAbIADAHIAIAIQAUAUAOAUQAHAJAFAKQAHATgCATQAAARgLAQQgMAZgZAdQgJAOgUAOQgQAMgYAJQgvASg9ARIgqALQiHAgiXAVQgRACgMAFQgGACgFADIgMAGIgMADIgcADIgiADIgtACIgYAAIgXgBg");
	this.shape_500.setTransform(7.2,4.4);

	this.shape_501 = new cjs.Shape();
	this.shape_501.graphics.f("rgba(213,255,255,0.78)").s().p("AgUEuIhEAAIhdgBIgzgBIgsgCQgqgDgsgIIgwgJQgQgDgMgEIgOgHIgNgGIg1gXQgdgIgdgFQgggFgegEQgWgDgbgCIgSgBQgegDgagHQghgIgkgMQh7gtg+g1QgTgQgIgRQgKgSAAgVQAAgUAKgTQAJgSAWgPIAogdIAGgFIAEgGQAGgJAKgIIASgSQAIgIAMgIQAMgIAPgGQAZgLAegFQAfgEAdgHIANgDIAfgGQAPgCAMgFQAFgCAFgEQAFgEAGgCQAOgGAUgEICWgbQBRgOBJgJQAhgEAdgCIA1gEQAngCAiABIATABIATABIAggBIBggEIAOgBIAjgBIAkAAIAlAAIAiABIAZACIAnACQCAAFBjAKIA9AIIArAIQA8AKBGAPQBHAOA6ARIACAAIAWAIQAIAEAHAGIAMAJIAJAGQAeAQAPAOQAXATAUAXIAQAbIAEAGIAIAJQATAVAOAUQAGAKAFAKQAGAUgEATQAAARgMARQgOAZgcAdQgKAOgUAOQgRALgYAKQgvASg9ARIgpALQiHAgiXAVQgRACgNAEIgLAGIgMAFIgMADIgcADIgiADIgtACIgYAAIgXgBQhFgBhIABIhCABIgiAAIgaAAIgZAAg");
	this.shape_501.setTransform(7.5,4.4);

	this.shape_502 = new cjs.Shape();
	this.shape_502.graphics.f("rgba(213,255,255,0.773)").s().p("AgXExIhDAAIhdgCIgzgBIgsgCQgqgDgsgIIgwgIIgcgHIgPgHIgOgGIg5gWIg7gMQgfgGgegEQgWgEgbgCIgSgCQgegDgagHQghgJgjgMQh8gug9g1QgSgQgIgRQgKgTAAgVQAAgUAKgTQAKgSAUgQIAogdIAGgGIAFgGQAHgIAKgJIATgSQAJgHAMgIQANgIAPgGQAYgKAfgGQAegFAdgHIANgDIAfgHQAPgCAMgFIAKgFIALgGQAPgGAUgEQBGgOBQgNQBQgOBKgJIA9gGIA1gEQAngCAiABIATABIATABIAggBIBggEIAOgBIAjgBIAkAAIAlAAIAiABIAZACIAmACQCAAFBkALIA8AIIArAHQA9ALBFAOQBGAPA6AQIACABIAWAIQAJAEAHAFIANAIIAKAHQAgAQARAPQAaATAWAXIASAbIAEAHIAIAJQATAUANAVQAGAKAEALQAGAUgFAVQgCARgNASQgQAZgeAdQgLAOgVANQgRALgYAKQgwASg8ARIgpALQiHAhiXAUQgRADgNAEIgLAFIgMAEIgMADIgcADIgiADIgtACIgYABIgXgBQhFgBhIACIhCABIgiAAIgaAAIgZAAg");
	this.shape_502.setTransform(7.8,4.5);

	this.shape_503 = new cjs.Shape();
	this.shape_503.graphics.f("rgba(213,255,255,0.769)").s().p("AgaE0IhDgBIhdgCIgzgBIgsgDQgqgCgrgIIgxgIIgcgHIgPgFIgPgGIg+gVIg6gNIg+gKQgWgEgbgDIgRgCQgegEgbgHQghgJgigNQh9gug7g3QgRgQgIgRQgKgSAAgWQAAgTAKgTQAJgTAUgQIAogfIAGgFIAFgGQAIgIALgKQAIgIAMgJIAWgPQANgIAPgGQAYgKAegGQAegGAegHIANgEIAfgGQAPgDAMgEIAKgGIAMgEQAPgHAUgDQBGgPBPgNQBPgOBLgIIA9gHIA1gDQAmgDAiABIAUABIASAAIAhAAIBggEIAOgBIAjgBIAkAAIAkABIAiAAIAZADIAnACQB+AFBlALIA8AIIArAHQA9ALBFAOQBFAPA7AQIACABIAVAIQAJADAIAGIANAHIAKAHQAiAQAUAPQAeAVAXAWQALANAJAPIAEAGIAIAJQATAVANAWQAFALAEAKQAFAWgGAUQgDASgOASQgSAbghAcQgMAOgWANQgRALgYAJQgwATg8AQIgpAMQiGAgiXAWQgRACgNADIgMAFIgMAEIgMACIgcAEIgiACIgsADIgZABIgXgBQhFAAhIACIhBABIgiAAIgZAAIgaAAg");
	this.shape_503.setTransform(8.1,4.5);

	this.shape_504 = new cjs.Shape();
	this.shape_504.graphics.f("rgba(213,255,255,0.761)").s().p("AgdE3IhEgCIhcgCIgzgCIgsgBQgqgEgrgGIgxgIIgcgHIgQgFIgPgFIhCgVIg7gMQgfgHgegEQgXgFgagDIgSgCQgegFgagHQghgKgigMQh9gvg5g3QgRgRgIgSQgJgTgBgUQAAgVAKgSQAJgUAUgQQASgPAVgQIAGgGIAFgFQAJgJAMgJIAWgRIAVgPQANgHAPgHQAZgJAegHIA7gPIAOgDIAfgGQAOgDANgFIAKgFIAMgFQAQgFATgEQBGgPBPgNQBOgNBLgJIA+gGIA0gEQAmgCAjAAIAUAAIASABIAggBIBggDIAOAAIAjgBIAkAAIAlABIAiAAIAYACIAnACQB9AFBmALIA8AJIArAHQA+AKBDAOQBFAPA7ARIACAAIAVAJIARAIIAOAIIALAGQAkAQAXAQQAhAUAYAYQANANAKAPIAEAGIAHAJQAUAVALAXQAGALACALQAFAWgHAVQgEATgPASQgUAagjAdQgOAOgWAMQgSALgYAJQgvATg9AQIgpALQiFAiiXAVQgQACgOADIgMAFIgNAEIgMACIgcAEIghACIgtADIgYAAIgXAAIiNACIhCABIghABIgzAAg");
	this.shape_504.setTransform(8.4,4.6);

	this.shape_505 = new cjs.Shape();
	this.shape_505.graphics.f("rgba(213,255,255,0.753)").s().p("AASE5IgzAAIhDgBIhcgCIgzgCIgsgCQgqgEgrgGIgxgIIgcgFIgQgGIgRgEIhHgUIg6gMIg+gMQgXgFgZgDIgSgDQgegGgagIQgigJghgNQh9gvg4g5QgQgQgIgSQgJgTAAgVQAAgUAJgTQAJgTATgSQASgPAVgQIAGgFIAGgGQAJgJANgJIAXgRIAXgPQANgHAPgGQAZgKAdgIQAegGAegJIANgDIAfgHIAbgHIALgFIAMgEQAQgGATgEQBGgOBOgOQBOgNBMgIIA+gGIA0gEQAlgCAjAAIAUAAIASAAIAggBIBggDIAOAAIAjgBIAkAAIAlABIAiABIAYABIAnACQB8AGBmALIA9AJIAqAGQA/ALBCAOQBEAPA7ARIACABIAWAHIARAIIAOAHIANAHQAmAQAZAQQAkAVAaAYQAOANALAPIAEAGIAHAJQAUAXAKAXQAFALADALQADAXgIAWQgFATgQATQgVAbgmAcQgQANgWANQgTAKgXAKQgwASg8ARIgpALQiFAiiWAVQgRACgOADIgMAEIgNAEIgMACIgcADIgiADIgsADIgYABIgYAAIiMACIhBABIgiAAg");
	this.shape_505.setTransform(8.7,4.6);

	this.shape_506 = new cjs.Shape();
	this.shape_506.graphics.f("rgba(213,255,255,0.745)").s().p("AAPE8IgzAAIhDgBIhcgDIgzgCIgsgDQgqgDgrgGIgwgHIgdgGIgRgEIgSgFIhLgTIg6gMIg9gMIgxgJIgRgEQgegGgagIQgigKghgMQh+gxg1g5QgRgRgHgSQgJgTAAgVQAAgUAJgTQAIgUATgRQASgQAVgRIAGgFIAGgGQAKgJAOgJQALgIAOgJIAWgOQAOgHAPgGQAZgKAdgIIA7gQIAOgDIAfgIQAOgDAMgEIALgEIANgEQAQgGATgEQBGgPBOgNQBNgNBNgIIA9gGIA0gEQAlgCAkAAIAUAAIASgBIAgAAIBfgDIAOAAIAkgBIAkAAIAkABIAiABIAYACIAnACQB7AFBnAMIA8AIIArAHQA/AKBCAPQBDAOA7ARIACABIAWAIIASAHIAOAHIANAGQApARAcAQQAmAWAdAYQAOAOAMAPIAEAGIAIAJQATAWAKAYQAEALACAMQADAXgJAXQgGAUgRATQgXAcgpAcQgRANgXAMQgTALgXAJQgwASg8ARIgoAMQiFAiiXAUIgeAFIgNAEIgNADIgMACIgcADIghADIgtADIgYABIgXABIiMADIhCABIghAAg");
	this.shape_506.setTransform(9,4.6);

	this.shape_507 = new cjs.Shape();
	this.shape_507.graphics.f("rgba(213,255,255,0.737)").s().p("AgoE+IhDgBIhcgDIgzgCIgrgDQgrgDgqgGIgxgHIgcgFIgSgEIgSgEQgpgJgngJIg6gNIg9gMIgxgLIgRgDQgegHgagIQgigLghgMQh9gxg1g6QgQgSgHgSQgIgTAAgVQAAgUAIgTQAIgUATgSQARgRAVgQIAGgFIAHgGQALgKAOgJIAagQQALgHANgHQANgHAPgGQAZgKAdgIIA8gRIANgEIAfgIIAbgHIALgEIANgEQAQgFATgEQBGgPBOgNQBMgMBNgJIA+gFIA0gEQAkgDAkAAIAUgBIASAAIAggBIBggCIANAAIAkgBIAjABIAlAAIAiABIAYACIAnACQB5AFBpAMIA8AJIArAHQA/AKBBAOQBCAPA8ARIACABIAWAHIASAHIAPAHIAOAGQAqARAfAQQAqAXAeAZQAPANANAPIAEAGIAIAJQATAXAJAZQAEALACAMQACAYgKAYQgIAUgSAUQgZAcgrAcQgSANgYAMQgTAKgXAJQgwASg8ASIgoALQiEAiiXAVIgfAFIgNADIgOADIgMACIgbADIgiADIgsADIgYABIgXAAIiMAEIhBABIgiAAIgZABIgagBg");
	this.shape_507.setTransform(9.4,4.7);

	this.shape_508 = new cjs.Shape();
	this.shape_508.graphics.f("rgba(213,255,255,0.733)").s().p("AgrFBIhDgCIhcgCIgzgDIgrgDQgrgDgqgGIgwgGIgdgFIgSgDIgUgFQgrgIgpgJIg6gMIg9gNIgxgMIgRgDQgdgIgagJQgjgKgggNQh+gxgzg8QgPgRgHgTQgIgTAAgUQAAgUAIgTQAIgUASgUQAQgQAWgRIAGgFIAHgGQAMgKAPgJIAbgRIAYgMIAdgOQAZgJAdgKIA7gSIAOgDIAegIIAbgHIAMgDIANgFQARgFASgDQBHgPBNgOQBLgMBOgIIA+gGIAzgDIBJgEIATgBIASAAIAhgBIBggCIANAAIAjgBIAkABIAkABIAiABIAZABIAmACQB4AGBqANIA8AIIAqAGQBBALA/AOQBCAPA8ARIACABIAWAHIASAGIAQAHIAPAGQAsARAhARQAtAXAgAZQARAOANAPIAFAGIAHAJQATAXAJAZQADANABALQACAZgLAYQgJAVgTAVQgbAdguAbQgTAMgYANIgrATQgwARg7ASIgpALQiDAjiXAVIgfAFIgOACIgNACIgMACIgcAEIghACIgtAEIgYABIgXABQhEADhIABIhBABIgiAAIgyAAg");
	this.shape_508.setTransform(9.7,4.7);

	this.shape_509 = new cjs.Shape();
	this.shape_509.graphics.f("rgba(213,255,255,0.725)").s().p("AAEFEIgzgBIhDgBIhbgDIgzgEIgrgCQgrgEgqgFIgxgGIgcgEIgTgDIgUgEQgugHgrgKIg6gLIg9gPIgxgMIgRgEIg3gQQgjgMgfgNQh/gygxg7QgPgSgHgTQgIgUAAgUQAAgUAIgTQAIgVASgUQAPgRAWgQIAGgGIAIgGQANgKAPgJIAdgQIAZgNIAcgMQAZgKAdgJIA8gUIANgEIAfgIIAbgHIALgDIAOgDIAjgJQBHgQBMgNQBLgLBOgJIA+gFIA0gFQAjgCAlgBIAUgBIASAAIAggCIBggBIANAAIAjAAIAkAAIAkABIAiABIAYACIAnACQB3AFBqANIA8AJIArAGQBBAKA+AOQBBAPA9ASIACAAIAWAIIASAGIAQAFIAQAHQAuARAlARQAwAYAhAZQASAOAOAPIAFAGIAHAJQATAYAIAaQADAMABAMQAAAagMAZQgKAWgUAUQgdAdgwAcQgUAMgZAMQgUAKgXAJQgwASg8ASIgoALQiDAjiXAUIgfAFIgOACIgOACIgMABIgbAEIgiADIgsADIgYACIgXABQhEADhIACIhAABIgiAAg");
	this.shape_509.setTransform(10,4.8);

	this.shape_510 = new cjs.Shape();
	this.shape_510.graphics.f("rgba(213,255,255,0.718)").s().p("AsPDnQlEhgAAiHQAAiGFEhgQFGhgHJAAQHKAAFGBgQFEBgAACGQAACHlEBgQlGBgnKAAQnJAAlGhgg");
	this.shape_510.setTransform(10.4,4.8);

	this.shape_511 = new cjs.Shape();
	this.shape_511.graphics.f("#D5FFFF").s().p("AieCLQgZgCgSgHQgQgFgcgQQgagMgcgGQgUgDgdgBIgwgBQgjgChSgNQgLgCgDgEQgEgFACgKQAFgRAVgKQAMgFAagEQgtgGgYgHQgmgLgXgUQgMgNAFgIQADgFAKgBQAVgDAdgBIAzAAQBhgCBegVQgGAAgDgGQgDgGABgGQADgJANgIQAbgPAuADIAmADQAWACAPgCIAegFQATgDALgBQAOgBAIAGQAFADABAGQACAGgDAFQBtgWBEgEQBjgGBPAZQAQAFAAAJQABALgRADIgLAEQgHACgCAFQCIgMCEAgIAlAKQANADAEAEQADADABAFQABAFgCADQgEAFgLABIhuALQhLAIgoAOQACAFAHAFIALAJQAGAFACAGQACAIgFAEQgDAEgKABQhFAJhGgDIgWAAQgNABgJAFQADADAQAGQANAEACAKQACANgVAGQgdAJgxAAQhAABgQACIgmAGQgYAFgOACQgOABgcAAIgsABIgtgBg");
	this.shape_511.setTransform(10.4,0.9);

	this.shape_512 = new cjs.Shape();
	this.shape_512.graphics.f("#D5FFFF").s().p("AhuCOIgugBIgHgBQgRgCgNgEIgHgCIgVgJIgXgMQgMgGgNgEQgPgFgPgDIgBAAIgTgDIgLgBIgOgBIgDAAIgugCIgHgBIgmgEIglgFIgggEIgEgBQgKgBgEgEQgEgFACgJQACgKAHgGQAGgGAJgFQAIgDAPgDIANgDQgtgGgZgIQgYgGgSgLQgLgGgIgIIgCgCQgLgLAFgHQADgGAKgBIAKgBIAegDIALAAIATAAIAFAAIAFAAIATgBIABAAIASgBIAPgBIATgCIAigCIAlgEIAZgEIARgDIAIgDIAJgCIAKgCQgFAAgDgFIgBgBQgDgGACgGQADgJAOgIQATgKAfgCIAYAAIAmADIAgAAIAGAAIAegFIABAAQARgEAMAAIACAAQANgBAHAFQAFAEACAGQABAEgBAEIgBACIAIgCIALgCIASgDIA6gJIAdgEIAWgCIAWgCIALgBIAJgBIAQAAIAXgBQBJACA8ATIABAAQAPAEABAJQAAAIgJAEIgGACIgLAEQgEABgCADIgDADQAmgDAmAAQArAAAqAFIAOACIAMACIALACIAKACQAcAEAbAHIAEABIAjAKQALADAEADIABABQADADABAEQABAFgDAEQgCADgGABIgFACIgBAAIgFABIggADIgzAFIgRACIgNACQgeADgYAFIgeAJIgNAFQABAFAHAFIACACIAIAGQAGAFACAHQABAHgEAEQgEAEgJABQgYAEgXABQgvADgvgBIgXAAQgNABgJAFQADADAPAGQAKADADAGIABAEQABAIgIAGIgIAFIgEABIgEABIgHACIgQADIgUACIgbABIgFAAIgMAAIgNAAQgrABgNABIgcAFIgLACIgcAFIgKABQgOACgcAAIgpABIgEAAg");
	this.shape_512.setTransform(10.1,0.9);

	this.shape_513 = new cjs.Shape();
	this.shape_513.graphics.f("#D5FFFF").s().p("AhrCPIgvgBIgHgBQgRgBgOgEIgGgDQgJgCgNgHIgXgLIgZgKIgegJIgCAAIgTgCIgKgBIgOgCIgCgBIgtgCIgGgBIgngEIgmgFIgfgDIgEgBQgLgCgDgDQgFgEACgKQACgJAGgHQAGgGAJgEQAHgDAOgDIAMgDQgtgGgZgIQgZgGgSgLQgLgGgJgIIgCgCQgKgLAEgIIAAgBQADgEAKgCIAKgCIAfgCIAKAAIATgBIAFAAIAFAAIATgBIABAAIAQgBIAQgDIATgBIAigCIAlgEIAagEIARgDIAIgDIAIgCIALgCQgFgBgDgFIAAgBQgDgFACgGQADgJAOgIQAUgLAfgBQALgBANABIAnACIAgAAIAGAAIAfgFIABAAQARgEAMAAIACAAQANgBAIAFQAFAEACAFQABAFgBAEIgBACIAIgCIALgCIATgCIA6gKIAegEIAWgCIAWgCIAMgBIAJAAIAPgBIAYAAQBLABA8ATIABAAQAPAFABAHQABAJgJAEIgGACIgKADQgEACgCADIgCACQAlgCAoABQAsAAApAEIAPADIALACIALACIAKACQAbAFAZAHIADABIAiAJQAKADAEADIABABQADADABAFQAAAFgCADQgDAEgGABIgFABIgBAAIgEABIgfAEIgwAFIgQACIgMACQgdADgXAGQgPADgOAGIgNAFQACAFAFAFIADACIAHAGQAGAFABAHQACAHgFAFQgDADgKABIgwAGQgvACgwgBQgQAAgHABQgMABgKAFQACADAPAGQAKACACAHIABAEQABAHgIAHIgIAFIgEABIgEABIgHADIgRACIgUACIgaACIgGAAIgMgBIgOAAIg4ACIgcAEIgLACIgcAEIgLACQgPABgcAAIgpACIgEAAg");
	this.shape_513.setTransform(9.8,1);

	this.shape_514 = new cjs.Shape();
	this.shape_514.graphics.f("#D5FFFF").s().p("AhoCQIgvgBIgHAAQgRgCgPgEIgGgCQgJgCgNgHIgYgLIgZgKQgPgFgQgDIgBAAIgTgEIgKgCIgNgCIgDAAQgNgCgdgBIgGAAIgngGIgmgDIgggEIgFAAQgKgCgEgDQgEgFABgJQACgIAGgHQAFgFAIgFQAHgDANgDIAMgDQgtgHgbgHQgYgHgTgKQgLgHgJgHIgCgDQgLgLAFgHIAAgBQADgFAJgCIALgCIAegDIALAAIAUAAIAFgBIAEAAIASgBIABAAIAQgCIAPgCIATgCIAjgDIAlgDIAagDIARgEIAIgCIAJgDIAKgDQgEAAgDgEIgBgCQgCgFACgGQAEgJAOgHQAUgLAfgCIAZAAIAnACQATABAOgBIAGgBIAfgEIABAAQARgEANgBIACAAQANAAAIAFQAFADACAGQACAFgBADIgBACIAIgBIALgCIATgDIA7gKIAegDIAXgCIAWgDIAMgBIAJAAIAQgBIAYAAQBMACA9ASIABAAQAPAFABAIQABAIgJAEIgFACIgKAEQgDABgCACIgCADQAlgCApABQAtABAqAFIAOACIAMACIAKADIAJACQAaAFAXAGIAEABIAfAKQAKADADADIABABQADADABAEQAAAFgCAEQgDADgGABIgFACIgBABIgEABIgdADIguAFIgPACIgLABQgcAEgVAGIgcAKIgNAFQABAFAGAFIACACIAHAHQAFAEACAHQABAHgFAFQgDADgKABQgYAEgYACQgwADgwgBIgYAAQgNACgJAFQACACAOAHQAJADACAFIABAEQAAAIgHAGIgIAFIgEACIgEACIgHACIgRACIgVACIgbABIgFAAIgMAAIgOAAQgrAAgOACQgLAAgSADIgLACIgdAFIgKACQgPABgdAAIgqABIgEAAg");
	this.shape_514.setTransform(9.4,1.1);

	this.shape_515 = new cjs.Shape();
	this.shape_515.graphics.f("#D5FFFF").s().p("AiVCSIgHgBQgRgCgPgEIgGgBQgJgDgNgGIgZgMIgagKQgPgFgPgDIgCAAIgTgEIgKgCIgMgCIgDAAQgMgDgbgCIgHAAIgngFIgngEIgggDIgEAAQgLgCgDgDQgFgEABgJQABgIAGgHQAFgFAIgFQAGgDAMgDIAMgDQgugGgbgIQgZgHgTgKQgMgHgJgHIgCgCQgKgMAEgIIAAAAQADgGAJgCIALgCQANgCASgBIALAAIAUAAIAFgBIAEAAIARgBIAAAAIAPgDIAPgDIAUgCQARgCASAAQAUgBASgCIAagDIARgEIAIgDIAIgDIALgDQgEAAgCgEIgBgCQgCgFACgGQAEgJAOgHQAVgKAggDIAYAAIAoACQATABAOgBIAGgBIAggFIABAAQARgDANgBIACAAQANAAAIAEQAGAEACAFIABAJIgBACIAIgCIALgBIAUgDIA8gKIAegEIAXgCIAWgCIAMgBIAKAAIAQAAIAYgBQBOACA9ARIABAAQAPAFABAIQACAIgJAEIgFACQgIADgBABQgDABgCADIgCADQAmgDApABQAuABAqAGIAPACIALADIAKADIAJADQAYAEAWAHIADABIAeAJQAJADADADIABABQADADAAAEQABAFgDAEQgDADgGACIgFABIgBAAIgEACIgbADIgrAFIgOACIgLABQgaAEgUAHIgbAKIgNAGQABAFAGAFIACACIAGAGQAFAFACAGQABAIgFAEQgEAEgKABQgXADgZACQgxAEgxgBIgYABQgNABgJAFQABADAOAFQAIADACAGIABAEQAAAIgHAGIgIAGIgEABIgEACIgHACIgRADIgVACIgcABIgFAAIgMAAIgOgBIg6ABQgLABgSADIgLACIgeAFIgKABQgQACgcAAIgrABIgEAAIgcAAIgUAAg");
	this.shape_515.setTransform(9.1,1.1);

	this.shape_516 = new cjs.Shape();
	this.shape_516.graphics.f("#D5FFFF").s().p("AiSCTIgIgBQgRgBgPgEIgGgBIgXgJIgZgMIgagKIgfgJIgBAAIgTgEIgKgCIgMgCIgCAAQgMgDgagCIgGgBIgogFIgngEIghgCIgEgBQgKgBgEgDQgFgEABgJQABgIAFgGQAFgFAHgFQAGgDALgDIALgDQgugHgcgIQgZgHgTgKQgMgGgJgIIgDgCQgKgLAEgIIAAgBQADgGAJgCIALgCIAfgDIALAAIAUgBIAFAAIAFgBIAPgBIABAAIAOgDIAPgDIATgDQASgCASAAQAUgBASgCIAbgDIASgDIAHgEIAIgDIALgDQgEAAgCgEIgBgCQgCgFADgFQAEgJAOgIQAWgKAggCQAMgBANAAIAoACQATAAAOgBIAGAAIAggFIABAAQARgEAOAAIACAAQAOgBAIAFQAFADADAGIABAIIgBACIAJgBIALgBIAUgDIA8gKIAfgEIAXgDIAXgCIAMgBIAKAAIAQAAIAYAAQBQABA9ASIABAAQAPAEACAIQACAIgJAEIgEACQgIACgBACQgDABgCADIgBACQAlgBArABQAuABArAFIAOADQAGABAGADIAJADIAJACQAXAFAUAGIADABIAbAKQAJADADADIABABQADADAAAEQAAAFgDAEQgCADgGABIgFACIgBAAIgEACIgZADIgpAFIgNACIgKABQgZAEgTAHIgZALIgOAGQACAFAFAFIABACIAHAHQAEAEABAHQABAHgFAEQgEAEgJABQgYAEgaACQgxADgxAAQgRAAgIABQgNABgKAFQACADANAFQAIADABAGIABAEQAAAIgHAGIgIAGIgEABIgEACIgHACIgSADIgVACIgbABIgGAAIgMAAIgPgBQgrAAgPABQgLAAgTAEIgLABIgfAFIgJABQgQACgdAAIgrABIgEAAIgcAAIgUAAg");
	this.shape_516.setTransform(8.8,1.1);

	this.shape_517 = new cjs.Shape();
	this.shape_517.graphics.f("#D5FFFF").s().p("AiQCVIgIgBQgRgBgPgEIgGgCQgLgCgNgGIgYgLIgbgLIgfgJIgCAAIgTgEIgKgDIgLgCIgCgBQgLgDgZgCIgFgBIgogFIgogEIghgBIgEgBQgLgBgEgDQgFgEABgIQAAgIAFgGQAFgFAGgFQAFgDALgDIAKgDQgugHgcgIQgagHgUgKQgMgGgJgIIgCgCQgLgLAEgJIAAgBQADgGAJgCIALgCQANgDATAAIALAAIAUgBIAFgBIAEAAIAPgCIAAAAIAOgDIAPgEIATgDQASgCASAAQAVAAASgCIAbgDIASgEIAHgDIAIgEIALgDQgEgBgCgEIAAgBQgCgFACgFQAFgJAPgIQAWgKAggCQAMgBANAAIApACIAigBIAGgBIAggFIABAAQARgDAOgBIACAAQAOAAAJAEQAFAEACAFQACAEAAAEIgBACIAJgBIALgBIAUgCIA+gLIAfgEIAXgCIAXgCIANgBIAJgBIAQABIAZAAQBSABA9ARIABAAQAPAFACAHQACAIgIAEIgEACQgIACAAACIgFADIgBADQAmgBArABQAwACAqAFIAPADIALAEIAKADIAIADQAWAFASAGIACABIAaAJQAJADACADIABABQADAEAAAEQAAAFgDADQgDADgGACIgFACIgBAAIgDACIgYADIgmAFIgMACIgJABQgYAEgRAIIgZALIgNAHQABAFAEAFIACACIAGAGQAEAFABAGQABAHgFAEQgEAEgKABIgyAGQgxAEgzAAIgYABQgNABgLAFQABACANAGQAIADABAGIABAEQgBAHgHAGIgIAHIgEABIgEACIgHADIgSACIgVACIgcACIgGgBIgMAAIgPgBIg7AAQgLABgTADIgLACIgfAEIgKACQgRABgcAAIgsACIgEAAIgcAAIgVAAg");
	this.shape_517.setTransform(8.5,1.2);

	this.shape_518 = new cjs.Shape();
	this.shape_518.graphics.f("#D5FFFF").s().p("AiOCWIgHAAQgSgBgPgEIgHgCQgKgCgNgGIgZgLIgbgKIgggKIgCAAIgTgEIgJgDIgLgDIgCgBQgKgDgXgDIgGgBIgogFIgogDQgPgCgTABIgEgBQgLgBgEgDQgEgDAAgJQAAgHAEgGQAEgFAGgFQAFgDAKgDIAKgDQgvgHgdgIQgZgHgVgKQgMgGgJgIIgDgCQgLgLAEgKIAAAAQADgGAJgCIALgDQAOgDASgBIAMAAIAUAAIAFgBIAEgBQAIAAAFgCIABAAIANgDIAOgFIAUgDQARgCAUAAQAUAAASgCIAbgDQAKgBAJgCIAHgEIAIgEIALgDQgEgBgBgEIgBgBQgBgFACgFQAFgJAPgHQAWgKAhgDIAZgBIAqABQATABAPgBIAGgBIAhgGIABAAQARgDAOAAIADAAQANgBAJAFQAGADACAFQACAFAAADIAAACIAIAAIAMgBIAUgDIA+gKIAggEIAXgDIAYgCIAMgBIAKAAIAQAAIAZAAQBUABA9ARIABAAQAPAFADAIQACAHgHAEIgFACQgHACAAACIgEADIgCADQAngBAsACQAwACArAFIAPADIALAEIAJAEIAHADQAWAFAQAGIACABIAYAJQAIADADADIAAABQACADABAFQgBAEgDAEQgDADgFACIgFACIgBAAIgEACIgWAEIgjAEIgMACIgIABQgWAEgQAIIgYANIgNAGQABAFAEAFIACACIAFAGQAFAFAAAGQABAHgFAEQgFAEgJABQgZAEgaACQgyAFgzAAIgZABQgNABgLAEQABADAMAGQAHADABAFIABAEQgBAIgHAGIgIAGIgDACIgEACIgIADIgSADIgVACIgdABIgFAAIgNgBIgPgBIg8AAQgMAAgSADIgMACIgfAFIgLABQgQACgdAAIgsABIgFAAIgcAAIgVAAg");
	this.shape_518.setTransform(8.2,1.2);

	this.shape_519 = new cjs.Shape();
	this.shape_519.graphics.f("#D5FFFF").s().p("AhZCYIgyAAIgIgBQgSgBgPgDIgGgCQgLgCgNgGIgagLIgbgKQgQgGgQgEIgCAAIgTgFIgJgDIgKgEIgCAAQgJgEgXgDIgEgBIgpgFIgpgDQgOgBgUAAIgEAAQgLgBgEgDQgFgDAAgIQAAgIAEgFIAJgKQAEgDAKgDIAIgDQgugHgegIQgagIgVgJQgMgHgKgHIgCgDQgLgLAEgJIAAgBQACgGAJgCIALgEQAOgCATgBIAMAAIAUgBIAFgBIAEgBIAMgBIABAAIAMgEIAOgFIAUgEQASgCATAAQAVAAASgBIAcgDQAKgBAIgDIAHgEIAIgEIALgDQgDgBgCgEIAAgBQgBgFACgFQAGgJAPgHQAXgKAggDIAagBIAqABIAjgBIAGgBIAhgFIABAAQARgDAPgBIACAAQAOAAAJAEQAGADACAGQADAEAAAEIgBACIAJgBIAMgBIAUgCIA/gLIAggEIAYgCIAXgCIANgBIAKgBIARABIAZAAQBVABA9ARIABAAQAQAEACAIQADAHgHAEIgEACQgHACAAACIgEADIgBADQAngBAtACQAxACArAGIAPADQAGACAFADIAJAEIAHADQAUAFAPAGIABABIAWAJQAIADACADIABABQACADAAAEQgBAFgDAEQgDADgGACIgFACIAAAAIgDACIgVAEIggAEIgLACIgIABQgVAEgOAJIgXANIgNAGQAAAFAFAFIABACIAFAHQAEAFAAAGQABAGgFAFQgFADgJACIg0AGQgzAEgzABIgZAAQgOACgKAEQAAADAMAGQAGADABAFIAAAEQgBAHgHAHIgHAGIgEACIgEACIgIADIgSADIgVACIgdABIgGAAIgMgBIgPgBQgsgBgRAAQgMABgTADIgMACIggAEIgLACQgQABgdAAIgtACIgEAAg");
	this.shape_519.setTransform(7.9,1.3);

	this.shape_520 = new cjs.Shape();
	this.shape_520.graphics.f("#D5FFFF").s().p("AhWCZIgzAAIgIAAQgSgBgQgEIgGgBQgLgCgNgGIgagLIgcgKQgQgGgQgEIgBAAIgUgFIgJgEIgJgEIgCAAQgIgFgVgDIgFgBIgpgGIgpgCQgPgBgTABIgFAAQgKgBgFgDQgFgDAAgIQgBgHAEgGQADgEAFgFQAEgDAJgDIAIgDQgvgHgfgJQgagHgVgKQgNgGgJgHIgDgDQgLgLAEgKIAAAAQACgHAJgCIALgEQAOgDATAAIAMAAIAVgBIAFgBIADgBIAMgCIAAAAIAMgEIAOgGIATgEQASgDAUABQAWABASgCIAcgDQAKgBAIgDIAHgEIAIgEIALgEQgDAAgBgEIgBgBQgBgFADgFQAGgJAPgHQAXgKAhgDIAbgBIAqABIAjgBIAGgBIAigGIABAAQAQgDAQAAIACAAQAPgBAJAFQAGADACAFQADAEAAAEIgBACIAJgBIAMAAIAVgDIBAgKIAggFIAYgCIAYgCIANgBIAKAAIAQAAIAaAAQBXACA9AQIABAAQAQAEADAIQADAHgHAEIgEACQgGACAAACIgDADIgBADQAmgBAvADQAyACArAGIAPADQAGACAFADIAIAFIAHADQASAFANAGIACABIAUAJQAHADACADIABABQABADAAAEQAAAFgDADQgDADgGACIgFADIgBAAIgDACIgTAEIgdAEIgKABIgHACQgUAEgNAJIgWAOIgNAHQABAFADAFIACACIAEAGQAEAFAAAGQAAAHgFAEQgEADgKACQgZAEgbACQgzAFg0AAIgaABQgOACgKAEQAAADALAFQAGADAAAGIABAEQgCAHgHAGIgHAHIgDACIgEACIgIADIgTADIgWACIgdABIgFAAIgNgBIgQgBQgrgBgSAAQgNAAgSADIgMACIghAEIgLACIgtACIguABIgEAAg");
	this.shape_520.setTransform(7.6,1.3);

	this.shape_521 = new cjs.Shape();
	this.shape_521.graphics.f("#D5FFFF").s().p("AiOCaQgTAAgQgEIgGgBQgLgCgNgGQgMgEgPgHIgcgKQgQgGgQgEIgCAAIgTgGIgJgEIgJgEIgCAAQgHgFgUgEIgEgBIgqgGIgqgCQgOgBgUACIgEgBQgLAAgEgDQgGgDAAgHQgBgHADgGIAIgIQADgEAIgDIAHgDQgvgHgfgJQgbgHgVgLQgNgFgKgIIgCgCQgMgLAEgKIAAgBQACgHAJgCQAFgDAGgBQAOgDAUgBIAMAAIAVgBIAFgBIADgBIAKgCIABAAIALgFIANgGQAKgDAKgBQASgDAUABQAWABASgBIAdgDQAKgBAIgDIAHgEQAEgDAEgCQAEgCAHgCQgDAAgBgEIAAgBQgBgFADgFQAGgIAPgIQAYgJAhgDQANgCAOABIArAAIAjgCIAGgBIAjgFIAAAAQARgDAQgBIADAAQAOAAAJAEQAGADADAFIADAIIAAACIAJAAIAMgBIAVgCIBAgLIAhgEIAYgDIAYgBIANgBIAKgBIARABIAaAAQBZABA9AQIABAAQAQAFADAHQADAHgGAEIgDACQgHACABABQgCACgBACIgBADQAngBAvADQAzADArAGIAPADQAGACAFADQAEAEAEABIAGAEQASAFALAGIABABIATAJQAGACACADIABABQABAEAAAEQgBAEgDAEQgDADgGACIgFADIAAAAIgDACIgRAEIgbAEIgJABIgHACQgSAEgMAKQgIAHgMAHIgOAHQABAFADAFIACACIAEAHQADAEAAAGQAAAHgFAEQgFAEgJABIg1AHQg0AEg1ABIgaABQgNABgLAFQgBADALAFQAGADAAAFIAAAEQgCAIgHAGIgHAHIgDACIgEACIgIAEIgTADIgWABIgeABIgFAAIgNgBIgQgBQgsgCgSABIggADIgMABIggAFIgMABQgRACgdAAIguABIgEAAIg0ABIgHgBg");
	this.shape_521.setTransform(7.3,1.4);

	this.shape_522 = new cjs.Shape();
	this.shape_522.graphics.f("#D5FFFF").s().p("AiMCcQgTgBgQgDIgGgBQgMgCgNgGQgMgEgPgHIgcgKQgQgGgRgEIgCgBIgTgFIgIgFIgJgEIgCAAQgGgGgTgDIgDgCQgTgDgYgDQgTgCgXAAQgOAAgVABIgEAAQgLgBgEgCQgGgDAAgHQgBgGACgGIAHgIQADgEAHgDIAGgDQgvgIgggIQgagIgWgKQgOgFgJgIIgDgCQgLgMADgKIAAgBQACgGAJgDIALgEQAOgDAUgBIAMAAQANAAAJgBIAFgCIACgBQAGAAAEgCIAAAAIAKgFIAOgGQAJgEALgBQASgDAUABQAWABATgBIAcgCQALgBAIgEQAEgBADgDIAHgFQAFgCAHgCQgDgBgBgDIAAgCQAAgEADgFQAGgIAQgHQAYgKAigDIAagBIAsgBIAjgBIAHgBIAigGIABAAQARgDARAAIACAAQAOgBAKAEQAGADADAGQACAEABADIAAACIAJAAIAMAAIAWgCIBBgLIAggFIAZgCIAZgCIANgBIAKAAQAIgBAJACIAbAAQBZABA+AQIABAAQAQAEAEAHQADAHgGAEIgDACQgGACABABIgDAEIAAADQAmgBAxADQAzADAsAGIAPAEQAGACAFAEQAEADAEACIAFADQARAGAJAGIABAAIAQAJQAHADABADIABABQABADAAAEQgBAFgEAEQgDADgFACIgFACIgBABIgCACIgQAEIgYAEIgJABIgFACQgRAEgLAKQgHAHgMAIIgNAIQAAAFADAEIABACIAEAHQADAFAAAFQAAAHgGAEQgEAEgKABQgZAEgcADQg1AFg1ABIgbABQgNABgLAFQgBADAKAFQAFADAAAFIAAAEQgCAHgHAHIgHAHIgDACIgEACQgEADgEABQgIACgLABIgXACIgeABIgFgBIgNAAIgQgCIg/gCIggADIgMACIghAEIgMACQgRABgdAAIgvACIgFAAIgzABIgIgBg");
	this.shape_522.setTransform(7,1.4);

	this.shape_523 = new cjs.Shape();
	this.shape_523.graphics.f("#D5FFFF").s().p("AiKCeQgTgBgQgDIgGgBQgMgCgNgGQgNgEgPgHIgdgKQgQgGgRgFIgBAAIgUgGIgIgFIgIgEIgCAAQgFgHgRgDIgEgCQgSgDgYgDQgUgCgXAAQgOAAgVACIgFAAQgKgBgFgCQgFgCgBgIQgCgGADgFQACgEADgEQACgEAHgDIAGgDQgwgIghgJQgagHgXgKQgNgGgKgHIgDgDQgLgLADgKIAAgBQACgHAJgDIALgEQAOgEAUAAIANAAIAWgBIAFgCIACgBIAJgCIAAgBIAJgFIANgHQAKgEAKgBQATgDAVABQAWACASgCIAdgCQALgBAIgDQAEgCADgDIAHgFQAFgCAHgCQgDgBAAgDIgBgCQAAgEAEgFQAGgIAQgHQAYgKAjgDIAbgBIArgBIAlgCIAGgBIAjgFIABAAQAQgDASgBIACAAQAPAAAJAEQAGADAEAFIADAIIAAACIAJAAIAMAAIAVgDIBDgLIAhgEIAZgDIAZgCIANgBIALAAQAHAAAKABIAbAAQBbABA+AQIABAAQAQAEAEAHQAEAHgGAEIgCACQgGACABABQAAAAgBABQAAAAAAABQgBAAAAABQAAABAAAAIgBADQAnAAAxADQA1ADArAGIAQAEQAGACAEAEIAIAGIAFADQAPAFAIAGIAAABQAGAFAJAEQAGADABADIABABQABADgBAEQgBAFgDADQgDADgGADIgFACIgBABIgCACIgNAEIgWADIgIACIgFACQgPAEgJALQgHAHgMAIIgNAIQAAAFADAFIABACIADAGQADAFAAAGQgBAGgFAEQgFAEgKABIg1AHQg2AFg1ACIgbABQgOABgLAFQgBADAJAFQAFADgBAFIAAAEQgCAHgHAGIgHAIIgDACIgEADIgIADQgIACgLABIgXACIgfABIgFAAIgNgBIgQgCQgsgCgUAAIggADIgMABIgiAFIgMABIgvACIgvABIgFAAIg0ABIgIAAg");
	this.shape_523.setTransform(6.7,1.5);

	this.shape_524 = new cjs.Shape();
	this.shape_524.graphics.f("#D5FFFF").s().p("AiICfQgTAAgRgDIgGgCQgMgBgNgGQgMgEgQgHIgdgKQgQgGgRgFIgCAAIgUgGIgHgFIgIgFIgCgBQgEgGgQgEIgDgBQgTgEgYgDQgUgCgXABQgOgBgWADIgEAAQgLgBgFgCQgFgCgBgHQgCgGACgFIAEgIQACgEAGgDIAFgDQgwgIghgJQgbgHgXgLQgOgFgKgHIgCgDQgMgLADgLIAAgBQACgHAJgDIALgEQAOgEAVAAIAMAAQANAAAJgCIAFgCIADgBQAEAAADgCIAJgGIANgIQAJgEALgBQASgEAWACQAWACATgBIAdgCQAMgBAHgEIAHgFIAHgFQAFgDAHgBQgDgBAAgEIAAgBQAAgEADgFQAHgIAQgHQAZgJAjgEQANgBAOAAIAsgBIAlgCIAGgBIAkgGIABAAQAQgDASAAIACAAQAPgBAKAEQAGADADAFQADAEABAEIAAACIAJAAIANAAIAVgCIBEgLIAhgFIAZgCIAZgCIAOgBIAKgBIASACIAbAAQBdABA+APIABAAQAQAEAEAHQAEAHgFAEIgCACQgCAAgBABQAAAAgBABQAAAAAAAAQAAABAAAAQAAABgBAAQAAABAAAAQgBABAAAAQAAABAAAAIAAADQAmAAAzADQA1AEAsAGQAJACAHACQAFACAFAFIAHAFQAEACABACQAOAFAGAGIAAABIANAJQAFADABADIABABQABADgBAEQgBAEgEAEQgDADgGACIgFADIAAABIgCACIgMAEIgTADIgHACIgEACQgPAEgHALQgGAIgLAIIgOAIQAAAFADAFIABACIADAHQACAEAAAGQgBAGgGAEQgFAEgJABQgaAFgdADQg1AFg3ABIgbACQgOABgLAFQgCADAJAFQAEACAAAGIAAADQgDAHgHAHIgGAIIgEACIgEADIgIADQgIACgLABIgYACIgeABIgGAAIgNgBIgQgCIhBgDIghADIgMACIgiAEIgMABIgvACIgwACIgFAAIg1ABIgIgBg");
	this.shape_524.setTransform(6.4,1.5);

	this.shape_525 = new cjs.Shape();
	this.shape_525.graphics.f("#D5FFFF").s().p("AiGChQgTgBgRgCIgGgCQgMgBgNgFQgNgEgQgHIgdgLQgRgGgRgFIgBAAIgUgHQgFgCgDgDIgHgFIgBgBQgEgHgPgEIgCgBQgTgEgZgDQgUgCgYABQgOAAgVACIgFAAQgLAAgEgCQgGgCgBgHQgDgFACgFIAEgIQABgEAFgDIAEgDQgwgIgigJQgbgHgXgLQgOgGgKgHIgDgCQgMgMADgKIAAgCQADgHAIgDIALgFQAOgDAVgBIANAAQANAAAJgBIAFgCIACgBIAHgDIAAAAIAIgGQAEgEAJgEQAJgEAKgCQATgEAWACQAXACATgBIAdgCQAMgBAIgDIAGgFIAHgGQAFgDAHgBQgCgBgBgEIAAgBQAAgEAEgFQAIgIAQgHQAZgJAjgEQANgBAOAAIAtgBIAlgDIAHgBIAkgFIAAAAQAQgDATgBIACAAQAPAAAKAEQAHADADAFQADADABAEIAAACIAKAAIAMABQALAAALgCIBEgLIAigFIAZgDIAagCIAOgBIAKAAIASABIAbABQBfABA+APIACAAQAPAEAFAGQAEAHgFAEIgCACQgBAAgBABQgBAAAAABQAAAAAAAAQAAABAAAAQAAABgBAAQAAABAAAAQAAAAgBABQAAABAAAAIAAADQAnAAAzAEQA3ADAsAHQAJACAGACQAGADAFAEQADAEAEACIAEAEQANAFAEAGIAAABIALAJQAFADAAADIABABQABADgBADQgCAFgDAEIgJAFIgFADIgBABIgBACIgLAEIgQADIgGACIgDACQgOAEgGAMQgFAIgLAIIgNAJQgBAFADAFIABACIACAGQACAFgBAFQAAAHgGAEQgFADgKACQgaAEgdADQg2AFg3ACIgcACQgOABgLAFQgCACAIAGQAEACgBAFIAAAEQgEAHgGAHIgGAIIgDACIgEADIgJAEQgIACgMABIgXACIgfAAIgFAAIgOgBIgQgCQgtgDgVAAQgOAAgTADIgMABIgjAEIgMACQgTABgdAAIgwACIgFAAIg2ABIgIAAg");
	this.shape_525.setTransform(6.1,1.6);

	this.shape_526 = new cjs.Shape();
	this.shape_526.graphics.f("#D5FFFF").s().p("AiDCiQgUAAgRgDIgGgBQgNgCgNgEQgNgEgQgHIgegLIghgLIgCAAIgUgHQgFgDgCgDIgHgFIgBgBQgDgHgNgFIgDgBQgTgFgZgCQgVgCgXABQgOAAgWADIgEAAQgLAAgFgCQgGgCgBgGQgDgGABgEIADgIQABgEAEgDIAEgDQgxgIgigJQgcgIgXgKQgPgGgKgHIgDgDQgMgLADgLIAAgBQADgIAIgDIALgFQAOgEAWAAIAMAAIAXgCIAFgCIACgBIAFgDIAHgHQAFgEAIgEQAJgEALgCQATgEAWACQAXACATAAIAegCQAMgBAIgEQADgCADgDQADgEAEgCQAEgDAIgCQgBAAAAAAQAAAAgBgBQAAAAAAgBQAAgBAAgBIAAgBQAAgEAEgFQAIgIAQgGQAagKAjgEQAOgBAOAAIAtgCIAlgCIAHgBIAkgGIABAAQAQgDATgBIADAAQAPAAAKAEQAGADAEAFQADAEABADIAAACIAKABIANAAQAKAAALgCIBGgLIAigFIAZgCIAagCIAOgBIALgBIASACIAbAAQBhABA+APIACAAQAPAEAFAGQAFAHgFADQAAAAAAABQAAAAgBAAQAAABAAAAQAAAAAAABQgBAAgBABQgBAAAAABQgBAAAAAAQAAABABAAQAAABgBAAQAAAAAAABQAAAAAAABQgBABAAAAIABADQAmAAA1AEQA3AEAsAHIAQAEQAGADAEAEIAHAHQADACAAACQANAFACAGIgBABQADAEAGAFQAFACAAADIAAABQABADAAAEQgCAFgEADQgDAEgGACIgFADIAAABIgCACIgIAEIgOADIgFACIgDACQgMAEgFAMQgEAJgLAIQgGAFgHAEQAAAFACAFIAAACIACAHQACAEgBAGQgBAGgGAEQgFADgJACIg4AIQg3AFg4ACQgRAAgLACQgOABgMAEQgCADAIAFQAEADgCAFIAAAEQgEAGgGAHIgGAJIgDACIgEADIgJAEQgIACgMABIgYACIgfAAIgFAAIgOgBIgRgCQgsgDgWAAQgOAAgTACIgNACIgjAEIgMABIgwACIgxACIgFAAIg2ABIgIgBg");
	this.shape_526.setTransform(5.8,1.6);

	this.shape_527 = new cjs.Shape();
	this.shape_527.graphics.f("#D5FFFF").s().p("AiBCkQgUAAgRgDIgGgBQgNgCgOgEQgNgEgQgHIgegLIgigLIgCAAQgMgEgIgEQgFgDgCgDIgGgFIgBgBQgCgIgMgFIgCgBQgTgFgagCQgVgCgXABQgOAAgXAEIgEAAQgLAAgFgCQgGgCgBgGQgEgFABgFIACgHQAAgEAEgDIADgDQgxgIgjgKQgcgHgYgKQgPgHgJgGIgDgDQgMgLADgLIgBgCQADgHAIgEQAFgDAGgCQAOgEAWAAIANAAQAOAAAJgCIAFgCIABgCQADAAACgCIAAgBIAGgHQAEgEAJgFQAJgEALgCQATgEAWACQAYADATgBIAegCQAMAAAIgEQADgCADgEQADgEADgCQAFgDAIgCQgBAAAAAAQAAgBgBAAQAAgBAAgBQAAAAAAgBIAAgBQABgEAEgFQAIgHAQgHQAagJAkgEIAcgCIAugCIAmgDIAGgBIAlgFIABAAQAQgDATgBIADAAQAPgBAKAFQAHACAEAFQADAEABAEIABACIAJAAIANABQALAAALgCIBGgLIAjgGIAagCIAagCIAOgBIAKAAIASABIAcABQBjABA+AOIACAAQAQAEAFAGQAEAHgEADIgBADQgBAAgBABQgBAAAAABQAAAAAAAAQAAABABAAIgBAEIAAADQAnAAA1AEQA4AFAtAHIAQAEQAFADAFAFIAGAGQADADAAACQALAFABAGIgBABQACAEAFAEQAEADAAADIAAABQABADgBAEQgCAEgDAEIgJAGIgFADIgBABIgBACIgHAEIgLADIgEACIgCACQgLAEgDANQgEAJgKAJIgOAJQAAAFABAEIABACIABAHQACAEgBAGQgBAGgGAEQgFADgKACQgaAFgeADQg4AFg4ADIgcACQgPABgMAEQgCADAHAFQADADgBAFIgBADQgEAHgGAHIgGAIIgDADIgEADQgEADgFABQgIACgMABIgYACIggABIgFgBIgOgBIgRgCQgsgDgXgBQgOAAgUADIgMABIgkAEIgMABIgxACIgxACIgFAAIg3ABIgIAAg");
	this.shape_527.setTransform(5.5,1.7);

	this.shape_528 = new cjs.Shape();
	this.shape_528.graphics.f("#D5FFFF").s().p("Ah/CmQgUgBgSgCIgGgBQgNgCgNgEIgdgLIgfgLIgjgLIgBgBQgNgDgIgEQgEgDgCgEIgGgGIgBAAQgBgJgLgFIgBgBQgUgFgZgCQgWgCgXABQgOAAgXAEIgFABQgLAAgFgCQgGgBgCgGQgDgFAAgFIABgHQAAgDADgEIACgEQgxgIgkgJQgcgHgYgLQgPgGgKgGIgDgDQgMgMADgLIgBgCQADgHAIgEQAFgDAGgCQAOgEAWAAIAOAAIAXgCIAFgDIABgBIADgDQABgDAFgFQAEgFAIgFQAJgEALgDQATgDAXACQAYADATAAIAfgCQAMgBAIgEQADgCADgEQADgEADgCQAFgDAIgCQAAAAgBgBQAAAAAAgBQAAAAAAgBQgBAAAAgBIAAgBQABgEAEgFQAJgHARgHQAagJAkgEIAcgCIAvgCIAmgDIAHgBIAlgGIAAAAQAQgDAUgBIADAAQAPAAALAEQAHADADAEIAFAIIABACIAJABIAOAAIAWgBIBHgMIAjgFIAagDIAagBIAOgBIALgBIASACIAdABQBkAAA+AOIACAAQAQAEAFAHQAFAGgEADIgBACQgBABAAAAQgBABAAABQAAAAAAAAQAAABABAAIgBAEIAAADQAoAAA2AFQA5AEAsAIQAKACAGACQAGADAEAFQAEAFADACQABABAAAAQABABAAAAQAAABAAAAQAAABAAAAQAKAGgBAGIgCABQABAEAFAEQADADAAADIAAABIAAAGQgCAFgEAEIgJAFIgFAEIAAABIgBACIgGAEIgIADIgDACIgCACQgJAEgCANQgCAJgLAKQgGAFgIAEQAAAFABAFIABACIABAGQABAFgBAFQgBAGgGAEQgGAEgJABQgbAFgeADQg5AGg4ADIgdABQgPACgMAEQgCADAGAFQADADgCAEIgBAEIgKAOIgGAIIgDADIgEADIgJAEQgIADgMABIgYABIghABIgFAAIgOgCIgRgCQgsgEgYAAQgOAAgUACIgNABIgkAEIgMACQgUABgdAAIgyACIgFAAIg4ACIgIAAg");
	this.shape_528.setTransform(5.2,1.7);

	this.shape_529 = new cjs.Shape();
	this.shape_529.graphics.f("#D5FFFF").s().p("Ah9CnQgUAAgSgCIgGgBQgOgCgNgEQgNgEgQgHIgggLIgigLIgCgBQgMgEgIgEQgFgDgCgEIgFgGIgBAAQAAgJgJgFIgCgCQgUgFgZgCQgWgCgYACQgNAAgYAEIgEAAQgLABgGgCQgGgBgCgGQgEgFAAgEIABgHQgBgDACgEIACgEQgygIgkgJQgdgIgYgKQgQgGgKgIIgDgBQgMgMADgMIAAgBQACgIAIgEQAFgDAGgCQAOgFAXAAIANAAQAOAAAJgCQAEgBABgBQABgBAAAAQABAAAAgBQAAAAAAAAQAAAAgBAAIADgDIAAAAQAAgDAFgFQAEgFAIgFQAJgFALgDQATgEAXADQAZADATAAIAfgBQAMgBAIgEIAGgGQADgFADgCQAFgDAIgCQAAgBgBAAQAAAAAAgBQAAAAAAgBQAAgBAAAAIAAgBQABgEAEgFQAJgHARgHQAbgJAkgEIAdgCIAvgDIAmgDIAHgBIAlgGIABAAQAQgCAVgBIACAAQAQgBALAEQAGADAEAFQAEADABAEIABACIAKABIANABQALAAALgCIBIgLIAjgGIAbgCIAagCIAPgBIAKAAQAIAAALACIAdAAQBlABA/AOIACAAQAQADAFAHQAFAGgDADIAAACQgBABgBAAQAAABAAAAQAAABAAAAQAAABABAAQAAAAgBABQAAAAAAABQAAAAAAABQAAAAAAABIABADQAnAAA3AFQA6AFAtAHQAKACAGADQAGADAEAGIAGAHQABAAAAABQAAAAABABQAAABAAAAQAAABAAAAQAJAGgDAGIgCAAQAAAEAEAFQADADgBADIAAABIAAAGQgDAFgEADQgDAEgGACIgFAEIAAAAIgBADQgEADABABIgGADIgCACIgBABQgIAFgBAOQgBAJgLAKIgNAJQgBAFABAFIABACIAAAHQABAEgBAFQgCAGgGAEQgFAEgKABQgbAFgeAEQg5AGg6ACIgdACQgPACgMAEQgDADAGAFQACACgCAFIAAADIgLAOIgGAJIgDADIgEADIgJAFQgHACgNABIgZACIghAAIgFAAIgOgCIgRgCQgtgEgYgBQgOAAgUACIgNACIglAEIgMABQgVACgdAAIgyACIgFAAIg5ACIgIgBg");
	this.shape_529.setTransform(4.9,1.8);

	this.shape_530 = new cjs.Shape();
	this.shape_530.graphics.f("#D5FFFF").s().p("Ah7CpQgUAAgSgCIgGgBQgOgCgNgEQgOgEgQgHIgggLIgjgMIgCAAQgMgEgIgEQgFgEgBgDIgFgHIgBAAQABgKgIgFIgBgCQgUgFgagCQgWgCgYACQgOAAgXAFIgFAAQgLABgFgCQgHgBgCgGQgEgEAAgEIgBgHQgBgDABgEIABgEQgygIglgKQgdgHgYgKQgQgGgKgIIgDgCQgNgLADgMIAAgCQACgIAIgEQAFgDAGgCQAOgFAXAAIAOAAQAOAAAJgCQAEgBABgCQABAAAAgBQAAAAAAAAQABAAgBAAQAAAAAAAAIABgEIAAAAQAAgDAFgFQADgFAIgGQAJgFALgDQAUgEAXADQAZAEATgBIAggBQAMgBAIgEQADgCADgEQACgFAEgCQAEgDAJgCQgBgBAAAAQAAAAAAgBQAAAAAAgBQAAgBAAAAIAAgBQABgEAFgFQAJgHARgGQAbgJAlgFIAdgCIAwgDIAmgDIAHgBIAmgGIABAAQAPgDAWgBIACAAQAQAAALAEQAHADAEAEQAEAEABADIABACIAKABIANACQALAAAMgCQAlgFAkgHIAjgFIAbgDIAbgCIAOgBIALAAQAIAAALACIAdABQBnAAA/AOIACAAQAQAEAGAGQAFAGgDADQAAAAAAABQAAAAAAAAQAAAAAAABQAAAAAAAAQgBABAAAAQgBABAAAAQAAABABAAQAAABABAAQAAAAgBABQAAAAAAABQAAAAAAABQABAAAAABIAAADQAoABA4AFQA7AFAsAHQAKACAHADQAFADAEAGIAGAHQACADAAACQAHAGgEAFIgCABQgCAEADAFQADACgBADIAAABQABADgCAEQgCAEgEAEIgJAGIgFAEIAAAAIgBADQgBABgBAAQAAABgBAAQAAABAAAAQABAAAAABIgDADIgBACIgBABQgGAFAAAOQAAAKgKAKQgGAFgIAFQgBAFABAFIAAACIAAAGQABAEgBAGQgCAFgGAEQgGAEgKABQgbAFgfAEQg5AGg6ADIgeACQgOACgNAEQgDADAFAFQACACgCAFIgBADIgLAOIgGAJIgDADIgEADQgEADgFACQgHACgNABIgZACIghAAIgFAAIgPgCIgRgCQgtgEgZgBQgPAAgUACIgMABIglAEIgNABIgyACIgzACIgFAAIg5ACIgJAAg");
	this.shape_530.setTransform(4.6,1.8);

	this.shape_531 = new cjs.Shape();
	this.shape_531.graphics.f("#D5FFFF").s().p("Ah7CqQgUAAgSgCIgGgBQgPgBgNgEQgOgEgQgHIgggLIgkgMIgBAAQgNgEgIgFQgFgDgBgEIgEgHIAAgBQABgJgHgGIAAgCQgVgFgagDQgWgBgYACQgOAAgYAFIgFABQgKAAgGgBQgHgBgCgFQgFgEAAgEIgCgHQgCgDABgEIAAgEQgygIgmgKQgcgHgagKQgQgHgKgHIgDgDQgMgLACgMIAAgBQACgJAIgEIALgGQAOgEAYAAIANAAQAPAAAJgDQAEgBABgBQAAgBAAAAQABAAAAAAQAAgBAAAAQgBAAAAAAIABgDIAAgBQgBgDAEgFQAEgGAIgGQAJgFALgDQAUgEAXADQAaAEATAAIAfgBQANgBAIgEQADgDADgEQACgFAEgCQAEgEAIgCQAAAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBIAAgBIAHgIQAJgHASgGQAbgJAlgFIAegCIAwgDIAngEIAGgBIAngGIABAAQAPgCAWgBIACAAQARgBALAEQAHADAEAEQAEAEABAEIABACIAKABIAOABQALAAAMgCQAlgFAkgGIAkgGIAbgCIAbgCIAPgBIALgBIATADIAdAAQBpABA/ANIACAAQAQAEAGAGQAGAGgDADIAAACQgBABAAAAQAAABAAAAQAAABAAAAQABABABAAIAAAEIABACQAnACA5AFQA8AFAtAIQAKACAHADQAFADAEAGIAGAIQAAABAAAAQABABAAABQAAAAAAABQAAAAAAABQAGAGgHAFIgCABQgCAEACAEQACADgBADIAAABIgBAHIgHAIQgDADgGADQgDABgCACIAAABIAAADQgBABgBAAQAAABAAAAQAAABAAAAQAAABABAAIAAADIgBABQAAABABAAQAAAAAAAAQAAABAAAAQAAAAAAAAQgFAFACAPQAAAKgKAKIgOAKIAAAKIAAACQgBADABADQAAAFgCAFQgCAGgGADQgFAEgKABQgcAGgfADQg6AHg7ADIgdACQgPACgNAEQgEADAFAEQACADgDAFIgBADIgLAOQgDADgCAGIgDADIgEADIgJAFQgIACgOABIgZACIghABIgFgBIgPgBIgRgDQgtgEgagBQgPgBgUACIgNACIglADIgNACIgzACIg0ACIgFAAIg5ACIgJgBg");
	this.shape_531.setTransform(4.5,1.9);

	this.shape_532 = new cjs.Shape();
	this.shape_532.graphics.f("#D5FFFF").s().p("Ah7CsQgUAAgTgCIgGgBQgPgBgNgEQgOgEgRgGIgggMIgkgMIgBAAQgNgEgIgFQgFgEgBgEIgDgHIgBgBQADgKgGgGIAAgCQgVgFgagDQgWgBgZACQgOABgYAFIgFABIgQAAQgHgCgCgFQgGgDgBgEIgCgHQgCgDAAgEIgBgEQgygIgngKQgdgIgZgKQgRgGgKgHIgDgDQgNgLACgMIAAgCQACgIAJgFQAEgDAHgDQAOgFAYAAIANAAQAPAAAJgCQAEgBABgCQABAAAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQAAgBAAAAQAAgBAAAAIAAgBQgBgDAEgGQADgFAIgGQAJgGALgDQAUgEAYADQAaAEATAAIAggBQANAAAHgFQAEgCACgFQADgEADgDQAEgEAJgCIAAgEIAAgBQACgDAFgFQAKgGASgHQAbgJAmgEIAdgDIAxgDIAngEIAHgBIAngGIABAAQAPgDAXgBIACAAQAQAAAMAEQAHACAEAFQAEADACAEIABACIAKABIAOACQALAAAMgCIBKgMIAkgGIAcgCIAbgCIAPgBIALAAIATACIAeABQBqABBAANIABAAQARADAGAGQAGAGgCADQAAAAAAABQAAAAAAAAQAAAAAAABQAAAAAAAAQAAABgBAAQAAABAAAAQAAABABAAQAAABABAAIABAEIABACQAnACA7AGQA8AFAtAIQALACAGADQAFADAEAHIAFAIQACADgBACQAFAGgIAFIgDABQgDAEACAEQABADgBADIAAABIgCAGIgHAJIgJAFIgFAEIAAABIAAADQgBABAAAAQAAABAAABQAAAAABABQAAAAABAAIACADIABABQAAAAAAABQABAAAAAAQAAAAAAABQAAAAAAAAQgEAFADAPQACALgKAKQgGAGgIAFQgBAFAAAEIAAACIgBAHQABAEgCAFQgCAGgHAEQgGADgJACQgcAFgfAEQg7AGg7AEIgfACQgPACgMAEQgEACAEAFQABADgDAEIgBADIgMAOQgDAEgCAGIgDADIgEAEQgEADgFABQgIADgNABIgaABIghABIgFgBIgPgBIgSgDQgtgFgagBQgQAAgUACIgNABIgmAEIgNABQgVACgfAAIgzACIgFAAIg6ACIgJAAg");
	this.shape_532.setTransform(4.4,1.9);

	this.shape_533 = new cjs.Shape();
	this.shape_533.graphics.f("#D5FFFF").s().p("Ah7CuQgVAAgTgCIgGgBQgPgBgNgEQgOgEgRgGIghgMIgkgMIgBAAQgOgFgHgEQgFgFgBgEIgCgHIgBgBQADgLgEgGIAAgCQgVgGgagCQgXgBgZACQgNABgZAGIgFAAIgRABQgGgBgDgFQgGgEgBgDIgDgHQgDgDgBgEIgBgEQgzgIgngKQgdgIgagKQgRgGgKgIIgDgDQgNgKACgNIAAgCQACgIAIgFQAFgEAGgCQAPgFAXAAIAOAAQAPAAAKgCQAEgCABgBQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBIAAAAQgBgEADgGQADgGAIgGQAJgGALgDQAUgEAZADQAaAFATAAIAggBQANgBAIgFQADgCADgEQACgFADgDQAFgEAIgCIABgEIAAgBQACgEAFgEQALgGARgHQAdgIAlgFIAegDIAxgEIAogDIAHgCIAngGIABAAQAPgCAXgBIADAAQAQgBAMAEQAHADAEAEIAHAHIABACIAKACIAOABQALABAMgCQAmgFAlgHIAlgGIAbgDIAcgBIAPgBIALgBIAUADIAdABQBtAAA/ANIACAAQAQADAHAGQAGAGgBADQgBAAAAABQAAAAAAAAQAAAAABABQAAAAAAAAQgBABAAAAQAAABAAAAQAAABABAAQABABABAAIAAAEIACACQAnACA8AGQA9AGAtAIQALACAGADQAGAEADAGIAFAJQABAAAAABQAAABAAAAQAAABAAAAQAAABgBABQAEAGgKAFIgDABQgEAEABAEQABADgBADIgBABIgCAGIgHAIIgJAGIgFAEIAAABIAAADQgCAEAFAAIAFADIABABQABAAAAABQAAAAABAAQAAAAAAABQAAAAAAAAQgCAFAEAQQACALgKAKQgFAGgIAFIgBAKIAAACIgCAGQABAEgDAGQgCAFgHAEQgGADgJACQgcAFggAEQg8AHg7AEIgfACQgPABgNAEQgEADADAFQABADgDAEIgCADIgMAOIgEAKIgDADIgEAEIgJAFQgIACgOABIgaACIgiAAIgFAAIgPgCIgSgDQgtgFgbgBQgPgBgUACIgOABIgmAEIgNABIg1ACIg0ACIgFAAIg7ADIgIAAg");
	this.shape_533.setTransform(4.4,2);

	this.shape_534 = new cjs.Shape();
	this.shape_534.graphics.f("#D5FFFF").s().p("Ah8CvQgVAAgTgBIgGgBQgPgBgNgEQgPgDgRgHIghgMIgkgMIgCgBQgOgEgHgFQgFgEAAgFIgCgHIgBgBQAEgLgDgHIABgBQgVgHgbgCQgXgBgZADQgNAAgaAGIgEABIgRABQgHgBgDgFQgGgDgCgEIgEgGQgDgDgCgEIgCgEQgzgJgngKQgegHgbgKQgQgGgLgIIgDgDQgNgLACgMIAAgCQACgJAIgFQAFgEAGgCQAPgFAYAAIAOAAQAPAAAJgDQAFgBAAgCQABAAAAgBQAAAAAAAAQAAAAAAgBQAAAAgBAAQAAAAgBgBQAAAAAAAAQgBgBAAgBQAAAAAAgBIgBAAQgBgEADgGQACgGAIgHQAJgGAMgDQAUgFAZAEQAaAFATAAIAhgBQAOAAAHgFQADgDADgEQACgFADgDQAEgEAJgCIABgEIABgBQACgEAFgEQALgGASgGQAcgJAmgFIAfgDIAxgEIAogEIAHgBIAogGIABAAQAPgDAXgBIADAAQARAAALAEQAIACAEAEIAHAHIABACIAKACQAIACAGAAQALAAANgCQAmgFAmgHIAlgGIAbgCIAcgCIAPgBIAMAAIATACIAfABQBuABA/AMIACAAQAQAEAHAFQAHAGgBADIAAACQAAABAAAAQAAABAAAAQAAABABAAQABABABAAQAAABAAAAQAAAAAAABQAAAAAAABQAAAAABABIABACQAoACA8AGQA+AGAuAJQALACAGADQAFAEAEAGIAEAJQACADgCACQADAHgMAFIgDABQgFADAAAFQAAACgBADIgBABIgCAHIgHAIQgEADgGADQgDACgCACIAAABQAAABAAAAQAAAAAAABQAAAAAAAAQABABAAAAQgCAEAGAAIAIADIACABQABAAAAABQABAAAAAAQAAAAAAABQAAAAAAAAQgBAFAGAQQADALgJALQgGAGgIAFIgCAKIAAACIgBAHQAAAEgDAFQgDAFgGAEQgGADgKACQgcAFggAFQg8AGg9AEIgfADQgPABgNAEQgFADADAFQABACgEAFIgBADIgNAOQgCAEgCAGIgDADIgEAEIgJAFQgIACgOABIgaACIgjAAIgFAAIgPgCIgSgDQgtgFgcgCQgPAAgVACIgNABIgnADIgNACIg1ACIg1ACIgFAAIg7ACIgJAAg");
	this.shape_534.setTransform(4.4,2);

	this.shape_535 = new cjs.Shape();
	this.shape_535.graphics.f("#D5FFFF").s().p("AilCwIgGgBQgQgBgNgEQgPgDgRgHIghgMIglgMIgCgBQgNgEgIgFQgEgFgBgEIgBgIIgBgBQAFgMgCgGIABgCQgVgHgbgCQgXgBgZADQgOABgZAGIgFABIgRABQgHgBgDgEQgHgDgCgEIgFgGQgEgDgCgEIgCgEQg0gJgogKQgegIgbgJQgRgHgKgHIgEgDQgNgLACgNIAAgCQACgJAIgFQAFgEAGgCQAPgGAYABIAOAAQAQgBAJgCQAEgCABgBQABgBAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBgBAAAAQgBgBAAAAIAAgBQgCgEACgGQADgHAIgGQAJgHAMgDQAUgFAZAEQAbAFATABIAhgBQAOAAAHgGQADgCACgFQADgFADgDQAEgEAJgCQAAgBAAAAQAAAAAAgBQABAAAAgBQAAgBABAAIAAgBIAIgHQALgHASgGQAdgJAmgFIAfgDIAygEIApgEIAHgCIAogGIAAAAQAQgCAYgBIACAAQARgBAMAEQAHACAFAFQAEADADAEIABACIAKABQAIACAHAAQALABANgCQAmgFAmgHIAlgGIAdgDIAcgBIAPgBIALgBIAUADIAfABQBvAABAANIACAAQARADAHAFQAGAGAAADQAAAAAAAAQAAABAAAAQAAAAAAAAQAAABABAAQgBABAAAAQAAABAAAAQABABAAAAQABABABAAIACAEIACACQAnACA+AHQA/AGAtAIQALADAGADQAGAEADAHIAFAJQABADgCACQACAHgOAFIgDAAQgHAEgBAFQABACgCADIgBABIgCAGIgIAJIgJAGIgFAEIAAABQAAABAAAAQAAAAAAABQAAAAAAAAQAAAAAAABQAAAEAHAAIAKADIADABQAAAAABABQABAAAAAAQABAAAAAAQAAABAAAAQAAAFAIARQADALgJAMQgFAGgIAFIgDAJIAAACIgCAHQAAAEgDAFQgDAFgHAEQgGADgJACQgdAGghAEQg8AHg9AEIgfADQgQABgNAEQgFADACAFQAAACgEAEIgBADIgNAOQgCAEgCAGIgDAEIgEAEQgEADgFACQgIADgOABIgbABIgiAAIgFAAIgQgCIgSgDQgtgGgdgBQgQgBgUACIgOABIgnAEIgNABIg2ACIg1ACIgFAAIg8ADIgJAAIgKAAIgegBg");
	this.shape_535.setTransform(4.4,2.1);

	this.shape_536 = new cjs.Shape();
	this.shape_536.graphics.f("#D5FFFF").s().p("Ah+CyQgVABgUgCIgGAAQgQgBgNgEQgPgDgSgHIghgMIglgNIgCAAQgOgFgHgFQgEgEgBgFIgBgIIAAgBQAGgMgBgHIABgCQgVgHgbgCQgYgCgZAEQgNABgaAHIgFAAIgRACQgIgBgDgEQgHgDgCgDIgGgGIgHgHIgDgEQg0gJgpgKQgegIgbgKQgSgGgKgIIgEgCQgNgLACgNIAAgDQABgJAIgFQAFgEAHgCQAOgGAZAAIAOAAQAQAAAKgDQAEgBABgCQAAAAAAgBQABAAgBAAQAAgBAAAAQAAAAgBAAQgDgBgCgDIAAgBQgDgDADgHQACgHAIgHQAJgHAMgDQAUgFAZAEQAcAGATAAIAhAAQAOgBAIgFQADgDACgFQACgFADgDQAEgEAKgDIACgDIAAgBQADgEAFgDQALgHATgGQAdgIAngGIAfgDIAzgEIAogFIAIgBIAogGIABAAQAPgDAYgBIADAAQARAAAMADQAHADAFAEIAHAHIACACIAKACIAOACQAMABANgCQAngFAmgIIAmgGIAcgCIAdgCIAPgBIAMAAIAUADIAeABQByAABAAMIABAAQARADAIAFQAHAGgBADQAAAAAAAAQAAAAABABQAAAAAAAAQAAABABAAQgBABAAAAQAAABABAAQAAABABAAQABABABAAIACAEIACACQAnADA/AGQBAAHAtAIQALADAHADQAFAEADAHIAFAKQABADgDACQABAHgPAEIgEABQgIAEgCAEQAAADgCADIAAABIgDAGIgIAIIgJAGQgEACgBADIAAABQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAAAABQAAAEAJAAIAMADIAEABIAEACQACAFAIARQAFAMgJAMQgFAGgJAFIgCAKIgBACIgCAGQgBAEgDAFQgDAGgHADQgGAEgKABQgcAGghAEQg9AHg+AFQgTABgNACQgPABgOAEQgFADACAEQgBADgEAEIgBADQgIAGgFAIIgEAKIgDAEIgEAEQgEADgGACQgHADgPABIgbABIgjABIgFgBIgPgCIgTgDQgtgGgdgCQgQAAgVACIgNABIgoADIgOABIg2ACIg1ADIgGAAIg8ADIgJgBg");
	this.shape_536.setTransform(4.4,2.1);

	this.shape_537 = new cjs.Shape();
	this.shape_537.graphics.f("#D5FFFF").s().p("Ah/C0IgpgBIgGAAQgQgBgOgEQgPgDgSgHIgigMIglgNIgBAAQgPgFgHgFQgEgFAAgFIgBgJIAAAAQAHgNABgHIABgCQgWgHgbgCQgYgCgZAEQgOABgaAHIgFABIgRACQgHgBgEgEQgHgCgDgDIgHgGQgFgDgDgEIgEgEQg0gJgqgKQgegIgcgKQgRgGgLgIIgEgDQgNgLACgNIAAgCQABgJAIgGQAFgEAHgDQAOgFAZAAIAPAAQAQAAAJgDQAFgCAAgBQABgBAAAAQAAgBAAAAQAAAAgBgBQAAAAgBAAQgDgBgCgDIgBAAQgDgEACgIQACgGAJgIQAIgHAMgDQAVgFAaAEQAbAGATAAIAiAAQAOAAAIgGQADgCACgFQACgGADgDQAEgEAKgDIACgDIAAgBQADgEAGgDQAMgHASgGQAegIAngGIAfgDIAzgFIAqgEIAHgCIApgGIAAAAQAPgCAZgBIADAAQARgBAMAEQAIACAFAEQAFADACAEIACACIAKACIAPADQALAAAOgCQAngFAngHIAmgHIAcgCIAdgCIAQgBIALAAIAVADIAfABQBzABBAALIABAAQARADAIAGQAHAFAAADQAAAAAAAAQAAAAABABQAAAAAAAAQABABAAAAQgBACAFACIACAEIACACQAoADA/AHQBBAGAuAJQALADAGADQAGAEADAIIAEAJQABADgDADQAAAHgSAEIgEABQgIAEgDAEQAAADgDADIAAABIgDAGIgJAIIgJAGQgEACgBADIAAABQAAAAAAABQAAAAAAAAQABABAAAAQAAAAAAABQABAEAJAAIAPADIAFABIAFACIANAXQAFAMgJAMQgFAGgIAGIgDAJIgBACIgDAHQgBAEgDAFQgDAFgHADQgGAEgKABQgdAGghAFQg+AHg+AFIggACQgQACgOAEQgFADABAEIgFAHIgCADQgIAGgFAIQgDAEgBAGIgDAEIgEAEQgEAEgFACQgIACgPABIgbACIgkAAIgEgBIgQgCIgTgDQgtgGgegCQgRgBgUACIgOABIgoAEIgOABIg2ACIg2ACIgGAAIg9ADIgJAAg");
	this.shape_537.setTransform(4.4,2.2);

	this.shape_538 = new cjs.Shape();
	this.shape_538.graphics.f("#D5FFFF").s().p("AEYC2IgFgBIgQgCIgTgDQgugHgegCQgRgBgUACIgOABIgpADIgOACIg3ACIg2ACIgGAAIg+ADIgJAAQgVABgVgCIgGAAQgQgBgNgDQgPgDgTgHIgigMIglgNIgCgBQgOgFgHgFQgFgFAAgFIAAgJIAAgBQAIgNACgHIACgDQgWgHgbgCQgZgBgZAEQgOABgaAIIgFABIgSABQgHAAgEgEQgIgCgDgDIgIgGIgJgHIgFgDQg0gKgqgKQgfgIgcgKQgSgGgLgHIgDgDQgNgMABgNIAAgCQABgKAIgFQAFgEAHgDQAOgGAaAAIAOAAQAQAAAKgDQAFgCAAgBQAAgBAAAAQAAgBAAAAQAAAAAAAAQgBgBAAAAQgEgBgDgDIAAgBQgEgEACgHQACgHAIgIQAJgHAMgDQAUgGAbAEQAcAHATAAIAiAAQAOAAAIgGQADgCACgGQACgGADgCQAEgFAKgDIACgDIABgBQADgDAGgEQAMgGASgGQAfgIAngGIAggEIAzgEIAqgFIAHgCIAqgGIAAAAQAPgCAagBIACAAQASgBAMAEQAIACAFAEQAFADACAEIACACIALACIAOADQAMABANgDQAogFAngHIAmgHIAdgCIAdgCIAQgBIAMAAIAUADIAgABQB0ABBBALIABAAQARADAIAFQAIAFAAADIACADQgBACAGACIACADIADADQAnACBBAIQBCAHAuAIQALADAGAEQAGAEADAHIADALQABADgDACQgCAHgTAFIgEAAQgKAEgDAEIgEAGIAAABIgEAGIgIAIIgKAGQgDACgCADIABABQAAABAAAAQAAABAAAAQAAAAAAABQAAAAABAAQABAEAKABIASACIAGABIAFACQAFAGALASQAGAMgJAMQgEAHgJAGIgEAJIAAACIgEAHQgBAEgDAEQgEAGgHADQgGADgKACIg/ALQg+AHg/AFIggADQgQACgOADQgGADABAEQgBADgFAEIgCADQgIAGgFAIQgDAEgBAHIgCAEIgEAEQgFADgFACQgIADgPABIgcABIgaABIgJAAg");
	this.shape_538.setTransform(4.4,2.3);

	this.shape_539 = new cjs.Shape();
	this.shape_539.graphics.f("#D5FFFF").s().p("AEaC3IgEAAIgQgCIgTgEQgugHgggCQgQAAgVABIgOACIgpADIgOABIg4ACIg3ADIgFAAIg/ADIgJAAQgWAAgUgBIgGAAQgRgBgNgEQgPgDgTgGIgjgMIglgOIgCAAQgPgFgGgGQgFgFABgGQgBgEABgFIAAAAIAMgVIACgDQgWgHgcgCQgYgBgaAEQgNABgbAIIgFABQgLACgHAAQgIAAgEgDQgHgCgEgDIgJgGQgFgDgFgEIgGgEQg1gJgqgLQgfgIgdgJQgSgGgLgIIgDgDQgOgMACgNIgBgCQACgJAIgHQAFgDAGgDQAPgHAaABIAPAAQAQgBAKgCQAEgCABgCQAAAAAAgBQAAAAAAgBQAAAAAAAAQgBAAgBAAQgFgCgCgDIgBgBQgEgEACgIQABgHAIgIQAJgIAMgDQAVgFAaAEQAdAHATABIAjAAQAOAAAHgHQAEgCABgGQACgFADgDQAEgGAKgCIADgEIABAAIAJgHQAMgGATgFQAfgJAogGIAggDIA0gGIAqgFIAHgBIAqgGIAAAAQAPgDAagBIADAAQASAAAMADQAIADAFADIAIAHIACACIALADIAOACQAMABAOgCQAogFAngIIAngGIAdgCIAdgDIAQgBIAMAAIAVAEQAMABAUAAQB2AABAALIACAAQARADAIAFQAIAFABADIACACQAAACAFACIADAEIADACQAoADBBAIQBDAHAuAJQALADAGAEQAGAEADAHIADALQABADgEADQgCAHgVAEIgFABQgKADgFAFIgEAGIgBABIgDAGIgJAHIgKAHQgDACgCADIABABQAAAAAAABQAAAAAAABQAAAAABAAQAAABAAAAQACAFALAAIAVACIAHABIAFACQAGAFANATQAHANgJANQgEAGgJAGIgEAJIgBADIgEAGIgFAIQgDAFgHAEQgHADgKACQgdAGgiAFQg/AIhAAEIggAEQgQACgOADQgHADAAAEIgGAHIgCACQgIAHgGAIIgDALIgDADIgEAFQgEADgGACQgIADgPABIgbABIgVABIgQgBg");
	this.shape_539.setTransform(4.5,2.4);

	this.shape_540 = new cjs.Shape();
	this.shape_540.graphics.f("#D5FFFF").s().p("AEdC5IgEAAIgQgCIgUgEQgugHgggCIgmAAIgOABIgpAEIgOABIg4ACIg4ACIgGAAIg/AEIgJAAIgqAAIgHgBQgRAAgNgEQgPgDgTgGIgjgNIgmgNIgCgBQgPgFgGgGQgFgFABgGQgBgEACgFIAAgBIAOgWIADgCQgXgHgcgCQgYgCgaAFQgOABgbAIIgFABIgSADQgIAAgEgDQgIgCgEgCIgKgGQgGgDgFgEIgHgEQg1gKgrgKQgfgIgdgKQgSgGgLgIIgEgDQgOgMACgNIgBgCQACgKAIgGQAEgEAHgDQAPgGAaAAIAPAAQARAAAJgDQAFgCAAgCQABgBAAAAQAAgBAAAAQAAAAgBAAQAAgBgBAAQgGgBgDgDIgBgBQgEgEABgIQACgIAIgIQAJgIAMgDQAUgGAbAFQAdAHATABIAjAAQAPAAAHgGQAEgDABgGQACgGADgCQAEgGAKgCIADgEIABgBIAKgGQAMgGAUgGQAfgIAogGIAggEIA1gGIAqgFIAHgBIAqgHIABAAQAPgCAagBIADAAQASAAANADQAHACAGAEIAIAHIACACIALACQAIADAHAAQALABAOgCQApgFAngIIAogGIAdgDIAegBIAQgBIAMgBQAIABANADQAMABAUAAQB4AABAALIACAAQARADAJAFQAIAFABADIADACQgBACAGACIADADIADADIBqALQBEAHAuAKQAMACAGAFQAFADADAJIADAKQABAEgEACQgEAHgWAFIgFABQgMADgFAFIgFAFIgBABIgEAGIgJAIIgJAGQgEADgBACIAAACQAAAAAAABQAAAAAAAAQABABAAAAQAAAAABABQACAEANAAIAXACIAHACQAFAAACACQAHAFAOATQAIANgIANQgFAHgJAGIgEAJIgBACIgFAHQgBAEgEAFQgEAEgHAEQgHADgJACQgeAGgiAFQhAAIhAAFIghADQgQACgOAEQgHACgBAFIgHAGIgCADQgJAGgFAIIgDALIgDAEIgEAEQgEAEgGACQgIADgPABIgcACIglgBg");
	this.shape_540.setTransform(4.5,2.4);

	this.shape_541 = new cjs.Shape();
	this.shape_541.graphics.f("#D5FFFF").s().p("AEhC7IgFAAIgQgDIgUgEQgugHghgCIgmAAIgOABIgqADIgOACIg5ACIg4ACIgGAAIg/AEIgKAAQgWABgVgBIgGgBQgRAAgNgDQgQgDgTgHIgjgMIgngOIgCAAQgOgGgHgGQgEgFABgGQgBgFACgEIAAgCIAQgWIADgCQgWgIgcgCQgZgBgaAEQgOACgcAJIgFABIgSACQgIABgEgDQgIgCgFgCIgLgFIgMgIIgHgEQg2gJgsgLQgfgIgdgKQgTgFgLgIIgEgDQgNgMABgOIgBgCQACgKAIgGQAEgFAHgDQAPgGAbAAIAPAAQAQAAAKgDQAFgCAAgCQAAgBAAAAQAAAAAAgBQAAAAgBAAQAAAAgBgBQgGgBgDgEIgCAAQgEgFABgIQABgIAIgIQAJgIAMgEQAVgGAbAGQAdAHAUABIAjAAQAPAAAHgGQAEgDABgGQACgGADgDQAEgGAKgCIAEgEIAAAAIALgHQAMgFAUgGQAfgIApgGIAggEIA2gGIAqgGIAIgBIAqgHIABAAQAOgCAcgBIACAAQASAAANADQAIACAGAEIAIAGIACACIALADQAIADAHAAQALACAQgDQAogFAogIIAngGIAegDIAegBIAQgBIAMgBQAJABAMADQANABAUAAQB5AABBALIACAAQARADAJAEQAIAFACADIADACQAAACAGACIAEAEIACACQApAEBDAIQBEAIAvAJQAMADAGAEQAFAEADAIIADAMQAAADgEADQgFAHgYAEIgGABQgMADgGAFIgGAFIgBABIgEAGIgJAIIgKAGQgEADgBADIAAABQAAABAAAAQAAABABAAQAAABAAAAQABAAAAAAQAEAFANAAIAaACIAIABQAFABACABQAJAGAPATQAJAOgIANQgFAHgJAGIgFAJIgBACIgEAHIgGAIQgEAFgHAEQgHADgKACQgeAGgjAFQhAAIhBAFIghAEQgQABgOAEQgIADgBAEIgIAGIgCADQgJAGgFAIQgCAEgBAHIgCAEIgEAFQgFAEgGACQgIADgPABIgcABIgWABIgPgBg");
	this.shape_541.setTransform(4.5,2.5);

	this.shape_542 = new cjs.Shape();
	this.shape_542.graphics.f("#D5FFFF").s().p("AEkC9IgFgBIgQgCIgUgEQgugIgigCQgRgBgVABIgPABIgqADIgOACIg5ACIg5ACIgGAAIhAAEIgJAAIgsAAIgGAAQgSAAgNgEQgQgCgTgHIgkgNIgmgNIgCgBQgPgFgHgHQgEgFABgGQAAgFACgFIABgBQAKgPAIgIIADgDQgXgIgcgCQgZgBgbAFQgNACgcAJIgFABIgTADQgHAAgFgCQgJgBgFgDIgLgFIgOgHIgIgEQg2gKgsgLQgggIgegJQgSgGgMgIIgEgDQgNgMABgOIgBgCQACgKAIgHQAEgEAHgEQAPgGAbABIAPAAQARgBAKgDQAFgCAAgCQAAgBAAAAQAAAAAAgBQgBAAAAAAQgBAAAAgBQgHgCgEgDIgBAAQgFgFABgJQABgIAIgIQAJgJAMgDQAVgGAcAFQAdAHATACIAkAAQAPAAAHgGQAEgDABgGQACgHACgCQAFgGAKgDIAEgDIABgBIAKgGQAOgGATgFQAggJApgGIAhgEIA1gGIArgGIAIgBIArgHIAAAAQAPgCAcgBIADAAQASAAANADQAIACAFAEQAGADADADIACACIALADQAJADAHAAQALACAQgDQAogFAogIIAogHIAegCIAegBIARgBIAMgBQAIABANADQANABAUAAQB7ABBBAKIACAAQARACAJAFQAJAFACADIADACQABACAGACIAEADIADADQAoADBEAJQBGAIAvAJQAMADAFAFQAGAEADAIIACAMQAAADgFADQgFAHgbAFIgFAAQgOAEgGAEIgHAGIgBABIgEAFIgKAIIgKAHQgEACgBADIABACQAAAAAAABQAAAAAAABQABAAAAAAQABABAAAAQAEAEAOAAIAdACIAJABQAGABACACQAKAFAQAUQAKAOgIANQgEAIgJAGIgGAJIgBACIgFAHQgCAEgFAEQgEAFgHADQgHADgJACQgeAHgkAFQhBAIhBAGIgiADQgQACgOADQgIADgCAEIgIAGIgDADQgJAGgFAIQgCAEgBAIIgCAEIgEAFQgFAEgFACQgJADgQABIgcABIgPABIgWgBg");
	this.shape_542.setTransform(4.5,2.6);

	this.shape_543 = new cjs.Shape();
	this.shape_543.graphics.f("#D5FFFF").s().p("AElC/IgEAAIgRgDIgUgEQgugIgigCQgSgBgVABIgOABIgrADIgPABIg5ACIg6ADIgFAAIhBAEIgKAAIgsAAIgGAAQgSAAgNgEQgQgCgTgHIglgNIgmgOIgCAAQgQgGgGgGQgEgGABgGQAAgFADgFIAAgBQAMgQAJgIIADgDQgXgIgcgCQgagBgaAFQgOACgcAJIgFACIgTADQgIABgFgDQgJgBgFgCIgNgFIgPgHIgIgEQg2gKgtgLQghgIgdgKQgTgFgMgIIgEgDQgNgNAAgNIAAgDQABgKAIgHQAFgEAHgEQAOgGAcAAIAPAAQARAAAKgDQAFgCAAgDQAAAAAAgBQAAAAAAAAQAAgBgBAAQgBAAAAAAQgIgCgEgEIgBAAQgGgFABgJQABgIAIgJQAJgJAMgDQAVgHAcAGQAeAIATABIAlABQAPgBAHgGQADgDACgGQABgHADgCQAEgGAKgDIAFgDIABgBIALgGQANgGAUgFQAggIAqgHIAggEIA3gGIArgGIAIgBIArgHIABAAQAOgDAcAAIADAAQASgBAOADIAOAGIAJAGIACACIALAEIAPADQAMABAQgCQAogFApgIIApgHIAegCIAegCIARgBIAMAAQAIAAAOAEQAMABAVAAQB9AABBAKIABAAQASADAJAEQAJAFACADIAEACQABACAHACIAEADIADADIBtAMQBHAIAvAKQAMADAGAFQAFAEADAJIACAMQAAADgFADQgHAHgcAEIgGABQgPADgHAFIgIAFIAAABIgFAGIgKAIIgKAGQgEADgBADIABABQAAABAAAAQAAABAAAAQABABAAAAQAAABABAAQAFAEAPAAIAfACIALABIAIACQALAGASAVQALAOgIANQgEAIgKAGIgFAKIgCACIgFAGIgHAIQgEAFgIADQgHAEgKABQgeAHgjAFQhCAIhCAGIgiAEQgQACgPADQgIADgCAEIgJAGIgDADQgKAFgEAJQgCAEgBAIIgCAEIgEAFQgFAEgGACQgIADgQABIgdABIgWAAIgQAAg");
	this.shape_543.setTransform(4.6,2.7);

	this.shape_544 = new cjs.Shape();
	this.shape_544.graphics.f("#D5FFFF").s().p("AEnDBIgEgBIgRgCIgUgFQgvgIgjgCQgSgBgVABIgOABIgsADIgOABIg6ACIg6ADIgGAAIhCAEIgJAAIgsAAIgHAAQgSAAgNgDQgQgDgUgGIgkgNIgogOIgBgBQgQgFgGgHQgEgGABgGQAAgGADgFIABgBQAMgQAKgIIAEgDQgXgIgdgCQgagCgaAGQgOACgcAKIgGABIgSADQgIABgFgCQgKAAgFgCIgOgFIgQgIIgJgEQg3gKgugLQgggIgegJQgTgGgMgIIgEgDQgOgMABgOIAAgDQABgKAIgHQAEgFAHgDQAPgHAcABIAPAAQASgBAKgDQAEgCABgDQAAAAAAgBQAAAAgBAAQAAgBgBAAQAAAAgBgBQgIgBgFgEIgBAAQgGgFAAgJQABgJAIgJQAJgJAMgEQAVgGAdAGQAeAIATABIAlABQAPAAAIgHQADgDABgGQABgHADgDQAEgGALgDIAFgDIAAgBIAMgFQAOgGAUgFQAhgIApgHIAhgEIA3gHIAsgGIAIgBIArgHIABAAQAOgDAdAAIADAAQASgBAOADQAIACAGAEQAGADADADIADACIALAEIAPADQAMACAQgDQApgFApgIIApgHIAfgCIAegCIARgBIAMAAQAJAAANAEQAMABAVAAQB/AABBAKIACAAQASACAJAFQAJAEADADIAEACQABACAHACIAEAEIAEACQAoAEBGAJQBIAJAvAJQAMAEAGAEQAFAEADAKIACAMQgBADgFADQgIAIgeAEIgGAAQgQAEgIAEIgIAGIgBABIgFAFIgKAIIgKAHQgEACgBADIABACQAAABAAAAQAAABAAAAQAAAAABABQAAAAABAAQAGAFAQAAIAiACIALABIAJACQANAGATAVQALAOgHAOQgEAIgKAGIgGAJIgBACIgHAHIgHAIQgEAFgIADQgHADgKACQgeAHgkAFQhCAIhDAHIgiADQgRACgPAEQgIACgDAEIgKAGIgCADQgKAFgFAJQgCAEgBAIIgCAEIgEAFQgEAFgGACQgIADgRABIgdABIgmAAg");
	this.shape_544.setTransform(4.8,2.8);

	this.shape_545 = new cjs.Shape();
	this.shape_545.graphics.f("#D5FFFF").s().p("AEoDDIgEgBIgRgDIgUgEQgvgIgkgDQgSgBgVABIgPABIgrACIgPACIg7ACIg6ADIgGAAIhCAEIgKAAIgtABIgGgBQgSAAgOgCQgQgDgUgHIglgMIgngOIgCgBQgQgGgGgHQgEgFACgIQAAgFADgFIABgBQANgQAMgKIAEgCQgYgIgcgCQgbgCgaAGQgOACgdAKIgFACIgTADQgIABgFgCQgKAAgGgCIgPgFIgRgHIgKgEQg3gKgugMQghgHgegKQgUgFgLgIIgFgDQgNgNAAgOIAAgDQABgKAIgIQAEgEAHgEQAPgHAcABIAQAAQARAAAKgEQAFgCAAgCQABgBAAgBQAAAAgBgBQAAAAgBAAQgBAAgBgBQgIgBgFgEIgCAAQgGgGAAgJQAAgJAJgJQAIgJANgEQAVgHAdAHQAeAHAUACIAlABQAQAAAHgHQADgDABgHQABgGADgDQAEgGALgDIAFgDIABgBIAMgFQAOgGAUgFQAhgIAqgHIAigEIA3gHIAsgHIAIgBIAsgHIABAAQAOgDAdAAIADAAQATgBANADQAJACAGAEIAJAGIADACIALADQAJADAHABQALACARgDQApgEAqgJIApgHIAfgCIAfgCIARgBIAMAAQAIAAAOAEQAMACAWgBQCAAABBAKIACAAQASADAKAEIAMAHIAEACQACACAHACIAFAEIADACQApAEBHAKQBIAIAvAKQANADAGAFQAFAEACAJIACANQAAAEgGACQgJAJggADIgGABQgRADgJAEIgJAGIgBABIgFAGIgLAIIgJAGQgFADAAADIAAABQAAABABABQAAAAAAABQABAAAAAAQABABAAAAQAGAEARAAIAlACIAMABIAKADQANAGAVAVQAMAOgHAPQgEAIgJAGIgHAKIgCACIgGAGIgIAIQgFAFgHADQgHADgKACQgfAGgkAGQhDAIhDAHIgjAEQgQACgQAEQgIACgEAEIgKAGIgDACQgKAFgFAJQgCAFAAAHIgDAFIgEAFQgEAEgGACQgIADgRACIgdABIgXAAIgQAAg");
	this.shape_545.setTransform(5,2.9);

	this.shape_546 = new cjs.Shape();
	this.shape_546.graphics.f("#D5FFFF").s().p("AEqDFIgFgBQgHAAgKgDIgUgEQgvgJgkgDQgSgBgWABIgPABIgsADIgPABIg7ACIg7ADIgGAAIhDAEIgJABIgtAAIgHAAQgSAAgOgCQgQgDgUgHIglgMIgogPIgCgBQgQgGgGgGQgEgHACgGQAAgGAEgFIABgCQAOgQANgKIAEgCQgYgJgdgCQgagBgbAGQgNACgeALIgFABIgTAEQgIABgGgCQgKAAgGgBIgQgFIgTgHIgKgEQg3gLgvgLQghgIgfgJQgUgGgLgIIgFgDQgOgMABgPIgBgDQABgLAIgGQAFgGAHgDQAPgHAcABIAQAAQASgBAKgDQAFgDAAgCQAAgBAAgBQAAAAAAAAQgBgBgBAAQAAAAgCAAQgJgCgFgEIgCAAQgGgGgBgJQAAgJAJgKQAIgJANgEQAVgHAeAGQAeAJAUABIAlABQAQAAAHgGQADgEABgGQABgIADgCQAEgHALgDIAGgDIABAAIAMgGIAjgKQAigIAqgHIAigFIA4gHIAsgGIAIgCIAsgHIABAAQAOgCAegBIADAAQATAAANADQAJACAGADQAGADAEADIADACIALAEIAQAEQALABARgCQApgFArgJIApgHIAfgCIAggCIARgBIAMAAQAJABANADQANACAVAAQCCAABCAJIABAAQASACALAFIANAGIAEADQACACAHACIAFADIAEADIBxANQBJAKAvAKQANADAGAFQAFAEACAKIACANQgBADgGADQgKAIghAEIgHABQgSADgKAEIgJAGIgBABIgGAFIgLAIIgJAHQgFACAAAEIAAABQAAABABAAQAAABAAAAQABABAAAAQABAAAAABQAHAFASAAIAnABIANABQAHABAEABQAPAGAWAWQANAPgHAPQgEAIgKAGIgHAKIgBACIgHAGIgJAIQgFAFgHADQgHADgKACQgfAHglAFQhDAJhEAHIgjAEQgRABgPAEQgJADgEADIgLAGIgDADQgLAFgEAJQgCAEgBAIIgCAFIgEAFQgFAEgGADQgIADgRABIgdABIgQAAIgXAAg");
	this.shape_546.setTransform(5.1,2.9);

	this.shape_547 = new cjs.Shape();
	this.shape_547.graphics.f("#D5FFFF").s().p("AEsDGIgFAAQgIgBgJgCIgVgFQgvgJgkgDQgTgBgWABIgPABIgsADIgPABIg7ACIg8ADIgGAAQgjABghADIgJABIguABIgHAAQgSAAgOgDQgQgCgVgHIglgNIgogPIgCAAQgQgGgGgHQgEgHACgHQABgGAEgFIAAgBQAQgSANgJIAFgDQgYgJgdgBQgbgCgbAGQgNADgeALIgFABIgTAFQgJABgGgCQgKABgHgCIgQgEIgUgIIgLgEQg3gKgwgMQgigIgfgJQgUgGgMgIIgEgDQgOgMAAgPIAAgDQABgLAHgHQAFgFAHgEQAPgHAdABIAQAAQASgBAKgDQAFgDAAgCQAAgBAAAAQAAgBAAAAQgBgBAAAAQgBAAgBAAQgKgCgGgEIgCgBQgHgFAAgKQgBgJAJgKQAIgKANgEQAVgHAeAHQAfAJAUABIAmABQAQAAAHgHQADgDABgHQABgHACgDQAEgGAMgDIAGgDIABgBIAMgFQAPgFAVgFQAigIAqgHIAigFIA5gIIAsgGIAJgCIAtgHQAOgCAfgBIADAAQASAAAOADQAJACAGADIALAGIACACIAMAEIAQAEQALACARgDQAqgFArgJIApgHIAggCIAfgCIASgBIAMAAQAJABAOADQAMACAWAAQCDAABCAJIACAAQASACAKAEIAOAHIAFACQACACAIACIAFAEIAEACIByAOQBKAKAvAKQANADAGAFQAFAFACAKIABANQAAAEgHADQgLAHgjAEIgHABQgTADgLAFIgKAFIgBABIgGAFIgLAIIgKAHQgEADgBADIABACQAAAAAAABQABAAAAABQAAAAABABQABAAAAAAQAIAFATAAIAqABIAOACQAHAAAEACQAQAGAXAWQAPAQgHAOQgEAJgKAGIgHAKIgCACIgIAGIgIAIQgFAEgIAEQgIADgJACQgfAGgmAGIiIAQIgkAEQgQACgQADQgJADgEAEIgNAFIgDADQgLAFgEAJIgCANIgCAEIgEAGQgFAEgGACQgIAEgRABIgeABIgQAAIgXgBg");
	this.shape_547.setTransform(5.3,3);

	this.shape_548 = new cjs.Shape();
	this.shape_548.graphics.f("#D5FFFF").s().p("AEtDIIgEAAIgSgDIgUgFQgvgJgmgDQgTgCgVABIgQABIgtACIgPACIg7ACIg9ADIgGAAQgjABghADIgKABIguABIgGAAQgTAAgOgCQgRgDgUgGIgmgNIgpgPIgBgBQgRgGgGgHQgEgHADgHQABgGAEgGIABgBQAQgSAPgJIAGgDQgZgJgdgCQgbgBgcAGQgNACgeAMIgGACIgTAEQgIACgGgCQgLABgHgCIgRgEIgWgHIgMgEIhogWQghgIgggKQgUgGgMgHIgEgEQgOgMAAgPIgBgDQABgLAIgHQAFgGAHgEQAPgHAdABIAQAAQASAAAKgEQAFgDAAgCQABgBgBAAQAAgBAAAAQgBgBAAAAQgBAAgBgBQgLgCgGgDIgCgBQgHgGgBgKQgBgJAJgLQAIgJANgEQAWgIAeAHQAfAJAUACIAmABQAQABAHgIQADgDABgHQABgHADgDQAEgHALgDIAGgDIABgBIANgFIAlgKQAigIArgHIAigFIA5gIIAtgGIAIgCIAugHIAAAAQAOgCAfgBIADAAQATAAAOADQAJABAGADIALAHIADACIALAEIARAEQALACARgDQAqgFAsgJIAqgHIAggCIAfgCIASgBIAMAAIAXAEQAMACAXAAQCFAABCAIIABAAQATADAKAEIAPAGIAFADIAKAEIAGADIAEACIBzAPQBLAKAwAKQANAEAFAFQAGAEACALIAAANQAAAEgHADQgNAIglAEIgHAAQgUADgLAFIgLAFIgBABIgHAFIgLAIIgKAHQgEADgBADIABACQAAADAEABQAIAFAUAAIAsABIAPABIAMACQASAGAYAXQAPAQgHAPQgDAIgKAHIgIAJIgCACIgIAHQgDAEgGAEQgFAEgIADQgIADgJACQggAHglAGQhFAJhFAHIgkAEQgRACgPAEQgKACgFAEIgNAGIgDACQgLAFgFAJQgBAFAAAIIgCAFIgEAFQgFAFgGACQgJADgRABIgeACIgQAAIgYgBg");
	this.shape_548.setTransform(5.4,3.1);

	this.shape_549 = new cjs.Shape();
	this.shape_549.graphics.f("#D5FFFF").s().p("AEvDKIgEAAQgIgBgKgCIgVgFQgvgKgmgDQgUgBgVABIgQAAIgtADIgPABIg8ACIg+ADIgGAAQgjACghADIgKAAIgvACIgGAAQgTAAgOgCQgRgCgVgHIgmgNIgpgQIgCAAQgQgGgGgIQgEgGADgIQABgGAFgGIABgBQARgSAQgKIAGgDQgZgJgdgCQgcgBgbAGQgOADgeAMIgGABIgTAFQgJACgGgBQgLABgHgCIgTgEIgWgHIgNgEQg3gLgygMQghgIgggJQgVgGgMgIIgEgDQgPgMAAgQIAAgDQABgLAHgHQAFgGAHgEQAPgHAeABIAQAAQASgBALgEQAFgCAAgDQAAgCgEgBQgMgCgGgEIgCgBQgIgGgBgKQgBgKAJgKQAIgKANgEQAWgIAeAHQAgAKAUACIAmABQARAAAHgHQADgDABgIQAAgHADgDQAEgHALgDIAHgDIABgBIAOgFIAkgJQAjgIArgHIAjgGIA6gIIAtgHIAIgBIAugHQAOgDAgAAIADAAQATgBAOADQAJACAHADIALAGIADACIALAEQAJADAIABQALACASgCQAqgFAsgJIAqgIIAggCIAggBIASgBIANgBIAWAFQANACAWAAQCHAABCAIIACAAQASACALAEIAPAGIAGADIALAEIAGADIAEACIB0AQQBMAKAwAKQANAEAFAFQAGAEACALIAAAOQgBAEgHADQgOAIgmADIgIABQgVADgMAFIgMAFIgBABIgHAFIgLAIIgKAHQgEADgBADIABACQAAADAEABQAIAFAWAAIAvABIAPABIANACQATAGAaAYQAQAQgHAPQgDAJgKAHQgEAFgFAEIgCACIgIAGIgKAIQgFAEgIADQgIADgJACQggAHgmAGIiLARIgkAEQgRACgQAEQgKACgFAEIgOAFIgDADQgMAFgEAJQgCAFAAAIIgCAFIgEAFQgFAFgGACQgIAEgSABIgeABIgRAAIgXgBg");
	this.shape_549.setTransform(5.6,3.2);

	this.shape_550 = new cjs.Shape();
	this.shape_550.graphics.f("#D5FFFF").s().p("AEwDMIgEgBQgIAAgKgDIgVgFQgwgJgmgEQgUgBgWABIgPAAIguADIgPABIg8ACIg/ADIgGAAQgjACgiADIgKAAIgvACIgGAAQgUABgNgDQgSgCgVgHIgmgNIgpgPIgCgBQgRgGgFgIQgFgHADgHQACgHAFgFIABgCQASgSARgKIAGgDQgZgKgdgCQgcgBgcAHQgNADgfAMIgFABIgUAGQgJABgGgBQgMACgHgBIgTgEIgYgIIgNgEQg4gLgygMIhCgRQgVgGgMgIIgFgDQgOgMgBgQIAAgDQABgLAHgIQAFgFAHgEQAPgIAeABIAQAAQATAAAKgFQAGgCgBgDQABgDgFAAQgMgCgGgEIgCgBQgJgGgBgLQgBgJAIgLQAJgLANgEQAWgIAeAIQAhAJATACQANACAaAAQARAAAHgHQADgEABgHQAAgIADgDQAEgHALgDIAIgDIABAAIAOgFIAlgKQAjgHAsgIIAjgFIA6gJIAtgHIAIgBIAvgHIAAAAQAOgDAgAAIADAAQAUgBAOADQAJACAHADQAGACAFAEIADACIAMAEIAQAFQAMACARgDQArgFAsgJIArgIIAggCIAhgCIARgBIANAAQAJABAOAEQANACAWAAQCJAABCAIIACAAQASACAMADIAPAHIAGACIAMAEIAGAEIAFACIB1AQQBMAKAwAKQANAEAGAFQAFAFACALQABAKgBAEQgBAEgHADQgPAIgoAEIgIAAQgWADgOAFIgMAFIgBABIgHAFIgMAIIgJAHQgFADAAAEIAAABQABADADABQAKAFAWAAIAyABIAQABIANACQAVAHAbAYQARAQgGAQQgEAIgKAHIgJAKIgCACIgJAGIgKAIIgOAHIgRAFQggAHgmAGIiMARIglAFIghAFQgKADgGADIgPAGIgDACQgMAFgEAJQgCAFAAAIIgCAFIgEAGQgEAFgHACQgIADgSABIgfACIgogBg");
	this.shape_550.setTransform(5.8,3.3);

	this.shape_551 = new cjs.Shape();
	this.shape_551.graphics.f("#D5FFFF").s().p("AEyDOIgFAAIgRgEIgWgFQgvgKgogDQgTgCgWABIgQABIguACIgQABIg8ACQgpACgWACIgGAAQgjABgjAEIgKAAIgwACIgGAAQgUABgNgDQgSgCgVgGQgSgGgVgIIgpgPIgCgBQgRgHgGgHQgEgHADgIQACgHAFgGIACgBQASgTATgKIAHgDQgagKgdgCQgcgBgcAHQgNADggAMIgFACIgUAGQgJACgHgBQgMABgIAAIgUgEQgLgDgOgFIgOgEQg4gLgygMQgjgIgggJQgVgGgNgIIgEgDQgPgNAAgQIAAgDQAAgLAIgIQAEgFAIgFQAPgHAeABIARAAQASgBALgEQAFgCAAgDQAAgDgFgBQgMgCgHgEIgCgBQgJgGgCgLQgBgKAIgLQAJgLANgEQAWgIAfAIQAhAKATACQANABAbABQARAAAGgIQADgDABgIQABgIACgDQAEgHAMgDIAHgDIACAAIAOgFIAmgJQAjgIAsgIIAjgFIA7gJIAugHIAIgCIAvgHQAOgCAhgBIADAAQATAAAPACIAQAFIALAGIADACIAMAEIARAFQAMACARgCQAsgFAsgKIArgHIAhgCIAggCIASgBIANAAQAJABAPAEQAMACAXAAQCKgBBDAIIABAAQATACALAEIARAGIAGACQADACAJACIAHADIAEADIB3AQQBNAKAwALQAOAEAFAFQAGAFABALQABALgBAEQgBAEgIADQgQAIgqAEIgIAAQgXADgOAFIgNAFIgBABIgIAFIgMAIIgKAHQgEADgBAEIABABQABADAEABQAKAFAXAAIA0ABIASABIANACQAWAHAdAYQASARgHAQQgDAJgKAHIgJAJIgDACIgJAHIgLAHQgFAEgIADIgSAFQggAHgnAHIiNARIglAEIghAGQgLACgHAEIgPAFIgDACQgNAFgEAKQgBAFAAAIIgCAFIgEAGQgFAFgGACQgIAEgTABIgeABIgRAAIgYgBg");
	this.shape_551.setTransform(5.9,3.3);

	this.shape_552 = new cjs.Shape();
	this.shape_552.graphics.f("#D5FFFF").s().p("AE0DQIgFgBQgIAAgKgDIgVgFQgwgKgogEQgUgCgWABIgQAAIgvADIgPABIg9ACIhAADIgGAAIhHAGIgKAAIgwACIgGAAQgUABgNgCQgSgCgVgHQgTgFgVgIIgqgQIgBgBQgSgGgFgIQgEgHADgIQACgHAGgGIABgCQAUgTAUgLIAHgDQgagKgegBQgcgCgcAIQgNADggANIgGACIgTAFQgJACgHAAQgNACgIgBQgIgBgNgDQgMgCgOgFIgPgFQg4gLg0gMIhDgRQgVgGgNgHIgEgEQgPgMAAgRIgBgDQABgLAHgIQAFgGAHgEQAPgIAfABIARAAQATAAAKgFQAFgCAAgDQAAgDgFgBQgNgCgHgEIgCgBQgKgGgBgLQgCgLAIgLQAJgLANgFQAWgIAgAIQAhALATACQANABAbABQARAAAHgIQADgDABgIQAAgIACgDQAEgIAMgDIAIgDIABAAIAPgFIAmgJQAkgHAtgIIAjgGIA7gJIAvgHIAIgCIAvgHIABAAQANgCAhgBIADAAQAUAAAPACQAJACAHADQAHACAFAEIADACIAMAEIARAFQAMACASgCQArgFAtgKIAsgHIAhgDIAggBIASgBIANAAQAJABAPAEQAMACAYAAQCMgBBCAIIACAAQATACALADIARAGIAHACIANAFIAHADIAEACIB4ARQBOALAwALQAOADAGAGQAFAFABALQABALgBAEQgBAEgIADQgSAJgrADIgJABQgYACgPAFIgOAFIgBABIgIAFIgMAIIgKAHQgEADgBAEIABACQABADAEABQALAFAYAAIA3ABIASABQAJAAAFACQAYAGAeAZQASARgGARQgDAIgKAIIgKAJIgCACIgKAGQgFAEgGAEQgGAEgIADQgIADgKACQggAHgoAGQhGAKhIAIIglAFQgSACgQADQgLADgHADIgQAGIgDABQgNAGgEAJQgCAFABAIIgCAGIgEAGQgFAFgHACQgIADgSABIgfACIgSAAIgXgBg");
	this.shape_552.setTransform(6.1,3.4);

	this.shape_553 = new cjs.Shape();
	this.shape_553.graphics.f("#D5FFFF").s().p("AE1DSIgEgBIgSgDIgWgGQgwgKgpgEQgUgCgWABIgQAAIgvADIgQABIg9ACIhAADIgHAAIhHAGIgKAAIgwADIgHAAQgUABgNgCQgSgCgWgHQgTgGgVgIIgqgQIgBAAQgSgHgFgIQgEgHADgJQADgHAFgGIACgBQAUgUAWgLIAHgDQgagKgegCQgcgBgdAIQgNADggANIgGACIgTAGQgKACgHAAQgNACgIgBQgIAAgOgDIgcgIIgPgEQg5gLg0gMQgigIgigKQgVgFgNgIIgEgEQgPgMgBgRIAAgEQABgLAHgIQAEgGAIgEQAPgIAfABIARAAQATAAAKgFQAGgCgBgDQABgDgGgBQgNgCgIgFIgCAAQgKgHgCgLQgCgLAJgLQAIgLANgFQAWgIAgAIQAiAKAUADQAMACAbAAQASAAAHgIQACgDABgIQAAgJADgDQAEgHAMgDIAIgDIABgBIAPgEIAngJIBRgPIAkgGIA8gJIAugIIAJgCIAwgHQANgCAigBIADAAQAUAAAPACQAJACAHADIAMAFIAEACIAMAFQAKAEAHABQAMADASgDQAsgFAtgJQAggHAMgBIAhgDIAhgBIATgBIANAAQAIABAPAEQANACAXAAQCOAABDAHIACAAQASACAMADIASAGIAHACQADACAKACIAHADIAFADIB5ARQBPALAxALQANAEAGAFQAFAGACALQAAALgBAEQgCAEgIAEQgSAIguADIgJABQgZADgQAEIgOAGIgBABIgIAEIgNAIIgKAHQgEAEgBADIABACQABADAEABQALAGAagBIA5ABIATABQAKABAGABQAYAHAfAZQAUASgGAQQgDAJgKAIQgFAFgGAEIgCACIgKAGIgMAIQgGAEgIADIgSAFQghAHgnAGQhIAKhIAJIgmAEQgRACgQAEQgMACgIAEIgQAFIgEACQgNAFgEAJQgBAFAAAJIgBAFIgEAGQgFAFgHADQgIADgTABIgfACIgqgBg");
	this.shape_553.setTransform(6.2,3.5);

	this.shape_554 = new cjs.Shape();
	this.shape_554.graphics.f("#D5FFFF").s().p("AE3DTIgEAAIgTgEIgWgFQgwgLgpgEQgVgCgWABIgQAAIgvADIgRABIg9ACIhBADIgGAAIhIAGIgKAAIgxADIgGAAQgVABgOgCQgSgCgVgGQgTgGgWgIIgqgQIgCgBQgRgHgFgIQgEgIADgIQADgHAGgGIACgCQAVgUAXgLIAHgEQgagKgegCQgdgBgdAIQgNADggAOIgGACIgUAGQgJADgHAAQgOACgJAAQgIgBgOgDQgNgCgQgFIgQgFIhugXIhEgRQgXgGgMgIIgFgEQgPgMAAgRIgBgEQABgLAHgIQAFgGAHgFQAPgIAgABIARAAQATAAALgFQAFgCAAgDQAAgDgGgBQgOgDgIgEIgCgBQgLgGgCgMQgCgLAJgMQAIgLANgFQAXgIAgAIQAiALAUADQAMACAcAAQARAAAHgIQADgDAAgIQABgJACgDQAEgIAMgDIAJgDIABAAIAQgEIAngJIBSgQIAkgGIA8gJIAvgIIAJgCIAwgHQANgCAjgBIADAAQAUgBAPADIARAEQAHADAFADIADACIANAFQAJAEAIABQAMADASgDQAsgFAugJQAggHAMgCIAigCIAhgBIATgBIANAAIAYAFQAMACAYAAQCPAABDAGIACAAQATACAMADIASAGIAIACIANAFIAIADIAFACIB6ASQBQALAxALQANAEAGAGQAFAFACAMQAAAMgBADQgCAFgJADQgTAJgwADIgJAAQgaADgRAFIgPAFIgBABIgIAEIgNAIIgKAIQgFADAAAEIABACQABACAEACQAMAFAbAAIA8ABIAUAAIAQADQAaAGAgAaQAUASgFARQgDAJgLAIQgEAFgGAEIgDACIgLAGIgMAIIgOAGQgIADgKACQghAIgoAGIiRATIgmAFIgiAFQgMACgIAEIgRAFIgEACQgOAFgDAJQgCAFABAJIgCAGIgEAGQgFAFgGADQgJADgTABIgfABIgqgBg");
	this.shape_554.setTransform(6.4,3.6);

	this.shape_555 = new cjs.Shape();
	this.shape_555.graphics.f("#D5FFFF").s().p("AE5DVIgFgBQgIAAgKgDIgWgGQgwgLgrgDQgUgDgXABIgQAAIgwADIgQABIg+ACIhCADIgGAAIhIAGIgLAAIgxADIgGAAQgVACgOgCQgSgCgWgHQgTgFgVgIIgrgRIgCAAQgSgIgFgIQgEgHAEgJQADgIAGgFIACgCQAWgVAYgMIAIgCQgagMgfgBQgdgBgcAIQgNAEghANIgGACIgUAHQgKADgHAAQgOACgJAAQgJAAgPgDIgegHIgQgFIhvgYIhFgRQgXgFgMgIIgFgEQgPgNgBgRIAAgEQABgLAHgIQAEgHAIgEQAPgJAgACIARAAQAUgBAKgFQAGgCgBgDQAAgEgGAAQgPgDgIgEIgCgBQgLgHgDgLQgCgMAJgMQAIgLANgFQAXgJAgAJQAjALAUADQAMACAcAAQASAAAHgHQACgFABgIQAAgIACgDQAEgJAMgCIAKgEIABAAIAQgDIAogJIBSgQIAlgGIA9gKIAvgIIAIgCIAxgHIAAAAQANgCAjgBIADAAQAVAAAPACQAKACAHADIAMAFIAEACIAMAFQAKAEAIACQAMACASgCQAtgGAugJQAhgHAMgCIAhgCIAigBIATgBIANAAIAYAFQANADAYAAQCRgBBDAGIACAAQASACANADIATAFIAHADIAPAEIAIAEIAFACIB7ASQBRALAxAMQAOADAFAGQAFAGACAMQAAAMgBADQgCAFgJADQgVAKgxACIgKABQgbACgRAFIgQAGIgCABIgIAEIgNAIIgKAHQgFAEAAAEIABABQABADAEACQANAFAbgBIA/ABIAVABIARADQAbAGAiAaQAVATgFAQQgEAKgKAHIgLAKIgDACIgLAGIgMAIIgPAGQgIADgKACQghAIgpAHIiSATIgmAEIgjAFQgMADgJAEIgRAEIgEACQgOAFgEAJQgBAFABAKIgCAFIgEAHQgFAFgHADQgIADgTABIggABIgqgBg");
	this.shape_555.setTransform(6.5,3.7);

	this.shape_556 = new cjs.Shape();
	this.shape_556.graphics.f("#D5FFFF").s().p("AE6DXIgFAAIgSgEIgXgGQgwgLgrgEQgUgCgXAAIgQABIgxACIgQABIg/ACQgrACgXACIgGAAIhJAFIgKABIgyADIgGAAQgWABgNgBQgTgCgWgHQgTgFgWgJIgqgQIgCgBQgTgHgEgJQgEgHAEgJQADgIAHgGIABgCQAXgVAagMIAIgDQgagLgfgBQgegBgdAIQgMADgiAPIgFACIgVAHQgJADgIAAQgOADgKAAQgJAAgPgDQgOgDgSgFIgRgEQg6gMg1gMIhHgRQgWgGgNgIIgEgEQgQgMgBgSIAAgEQABgLAHgJQAEgGAIgEQAPgJAgABIARAAQAUAAALgFQAGgDgBgDQAAgDgGgBQgQgCgIgFIgDgBQgLgHgDgMQgCgLAIgNQAIgLAOgFQAXgJAhAJQAiALAUADQANACAcAAQASABAHgIQACgEABgIQAAgJACgEQAEgIAMgDIAKgDIACAAIAQgEIAogIIBTgQIAlgGIA9gKIAwgJIAJgBIAxgIQANgCAjgBIAEAAQAUAAAQADIARADQAHADAGADIADACIANAFQAKAFAHABQAMACATgCQAtgFAvgKQAhgHAMgBIAhgCIAigCIATgBIAOAAIAYAFQANADAYAAQCTgBBDAGIACAAQASACANADIAUAFIAIADIAPAEIAIADIAGACIB7ATQBSAMAxAMQAPADAFAGQAFAGABAMQABAMgCAEQgCAFgKADQgVAJgzADIgKABQgcACgSAFQgKACgHADIgCABIgIAEIgNAIIgLAIQgEADgBAEIABACQACADAEABQANAGAdgBIBBABIAWABIARACQAdAHAjAbQAWASgFARQgDAKgLAIQgEAFgHAEIgDACIgLAHIgNAHIgQAGIgSAFQghAIgpAHIiTATIgnAFIgjAFIgWAGIgSAFIgEACQgOAEgEAKQgBAFABAKIgCAFIgEAHQgFAFgHADQgIADgTABIghABIgOAAQgTAAgJgBg");
	this.shape_556.setTransform(6.7,3.8);

	this.shape_557 = new cjs.Shape();
	this.shape_557.graphics.f("#D5FFFF").s().p("AE7DZIgEgBIgTgDIgWgGQgwgMgsgEQgVgCgXAAIgQABIgxACIgRABIg/ACQgsACgWACIgHAAQgjACgmAEIgLAAIgyADIgGABQgWABgNgCQgTgCgWgGQgUgGgWgIIgrgRIgBgBQgTgHgFgJQgDgIAEgJQADgHAHgHIACgBQAYgWAbgMIAIgDQgbgMgfgBQgdgBgdAJQgNADgiAPIgGACIgUAHQgKADgIABQgOADgKAAQgKAAgQgDIgggHIgSgFIhxgYIhGgRQgXgGgNgIIgFgDQgPgNgBgSIAAgEQAAgLAHgJQAFgGAHgFQAPgJAhACIARAAQAVgBAKgFQAGgDgBgDQAAgDgGgBQgQgDgJgEIgDgBQgMgHgDgMQgCgMAIgNQAIgMAOgFQAXgJAhAJQAjAMAUADQANACAcABQATAAAGgIQADgEAAgJQAAgJACgDQAEgIANgEIAKgCIABgBIARgDIApgIIBUgQIAlgHIA+gKIAwgJIAJgBIAxgIIAAAAQANgCAkgBIADAAQAVAAAQACIARAEIANAGIAEACIAMAFQALAFAHABQAMADATgDQAtgFAwgKQAhgHAMgBIAigCIAigCIATgBIAOAAIAYAGQANACAZAAQCUgBBDAGIACAAQATACANADIAUAFIAJACIAPAFIAJADIAGACIB8ATQBTAMAxAMQAPAEAFAGQAFAGABAMQABAMgCAEQgDAFgJADQgXAJg1ADIgKABQgdACgTAFIgSAFIgBABIgJAEIgOAIIgKAIQgFADAAAEIABACQACADAEACQAOAFAeAAIBEAAIAWABIASACQAeAHAlAcQAXASgFASQgDAKgLAIQgFAFgHAEIgDACIgMAGIgNAHIgQAHIgSAFQghAIgpAGIiVAUIgnAFIgjAFIgXAGIgTAFIgEACQgPAEgDAKQgCAFABAKIgBAGIgEAGQgFAGgHACQgIAEgUABIghABIgrgBg");
	this.shape_557.setTransform(6.9,3.9);

	this.shape_558 = new cjs.Shape();
	this.shape_558.graphics.f("#D5FFFF").s().p("AE9DbIgFgBQgIAAgLgDIgWgGQgxgMgsgFQgVgBgXAAIgQAAIgyACIgRABIg/ACIhDAEIgHAAIhKAGIgKABIgzADIgGABQgWABgOgCQgTgBgWgHQgUgFgWgJIgrgRIgCgBQgTgHgEgJQgEgIAFgJQADgIAHgHIACgBQAZgXAcgMIAJgDQgbgMgfgBQgegBgeAJQgMAEgjAPIgFACIgVAHQgKADgIABQgOAEgLAAQgKAAgQgCIgigIIgTgFIhxgYIhHgRQgYgGgMgIIgFgEQgQgMgBgSIAAgFQAAgLAHgJQAFgHAHgEQAPgJAhABIASAAQAUAAALgFQAGgDgBgEQAAgDgGgBQgRgCgKgFIgCgBQgNgHgDgNQgDgLAJgNQAIgNAOgFQAXgJAhAJQAjAMAVADQAMADAdAAQATABAGgJQADgEAAgIQAAgKACgDQAEgIANgEIAKgCIACgBIARgDIApgIIBVgQIAlgGIA/gLIAwgJIAJgCQAfgFATgCQANgCAkgBIAEAAQAUgBAQADIASAEQAHACAGADIAEACIANAGQAKAEAHACQANACATgCQAugFAvgKIAugJIAigCIAjgCIATgBIANAAQAJABAQAFQANADAZAAQCWgBBDAGIACAAQATABAOADIAUAFIAJACIAQAEIAJAEIAGACIB+ATQBTANAyAMQAOAEAGAGQAFAGABAMQAAANgCAEQgDAFgKADQgXAJg3ADIgLABQgeACgUAFIgSAFIgBABIgJAEIgOAIIgKAIQgFADAAAEIABACQABADAFACQAPAGAegBIBHAAIAXABIATACQAfAHAmAcQAYATgFASQgDAKgKAIQgGAFgHAEIgDACIgMAHIgOAHIgQAGIgTAFQghAIgqAHIiVAUIgoAFIgjAFIgYAGIgUAFIgEABQgPAFgDAKQgCAFABAKIgBAGIgEAGQgFAGgHADQgIADgUABIghABIgrgBg");
	this.shape_558.setTransform(7.1,3.9);

	this.shape_559 = new cjs.Shape();
	this.shape_559.graphics.f("#D5FFFF").s().p("AE+DdIgEgBIgTgEIgXgGQgxgMgtgEQgVgCgXAAIgQAAIgyACIgRABIhAACIhEAEIgGAAIhLAGIgLABIgzADIgGABQgWABgOgBQgTgCgXgGQgTgGgXgJIgrgRIgCAAQgTgIgEgJQgEgIAFgKQADgHAIgHIACgCQAZgXAegMIAJgEQgbgLgggCQgegBgdAKQgNADgjAQIgFACIgVAIQgKADgIABQgPAEgLAAQgLABgRgDIgigIIgUgEQg7gMg3gNIhIgRQgYgGgMgIIgFgDQgQgNgBgSIgBgFQABgLAHgKQAEgGAIgFQAPgJAhABIASAAQAVAAAKgFQAGgDgBgEQAAgDgGgBQgSgCgKgFIgCgBQgNgHgDgNQgEgMAJgOQAIgMAOgFQAXgKAiAKQAjAMAVADQAMADAeAAQASABAHgJQADgEAAgJQgBgJACgEQAEgIANgEIALgCIACAAIARgEIAqgHIBWgQIAlgHIA/gLIAxgJIAJgCQAfgFATgCIAAAAQANgCAlgBIADAAQAVgBAQADIASADIAOAGIAEACIANAGQAKAEAHACQANACATgCQAvgFAvgKQAigIAMgBIAjgCIAjgCIATgBIAOAAQAIABAQAFQANADAZAAQCYgBBEAFIACAAQATACAOACIAVAFIAJADIARAEIAJADIAGACQAqAIBVAMQBUANAyAMQAPAEAFAGQAFAGABANQAAANgCAEQgDAFgKAEQgZAJg5ACIgLABQgfACgUAFIgTAFIgCABIgJAEIgOAIIgKAIQgFADAAAFIABACQABADAFABQAPAGAggBIBJABIAZAAIATADQAhAHAnAcQAYAUgEASQgDAKgLAIQgFAFgIAEIgDACIgNAHIgOAGIgQAGIgTAFQghAJgqAHIiXAUIgoAGIgkAFIgZAFIgUAFIgEACQgQAEgDAKQgBAFABAKIgBAGIgEAHQgGAGgGACQgJAEgUABIghABIgsgBg");
	this.shape_559.setTransform(7.2,4);

	this.shape_560 = new cjs.Shape();
	this.shape_560.graphics.f("#D5FFFF").s().p("AFADfIgEgBQgJgBgLgDIgXgGQgwgNgugEQgWgCgXAAIgQAAIgzACIgRABIhAACIhEAEIgHAAIhMAGIgKABIgzAEIgHAAQgWACgOgCQgTgBgXgHQgUgFgWgJIgsgRIgCgBQgTgIgFgJQgDgIAFgKQADgIAIgHIADgCQAagXAfgMIAJgEQgbgMgggBQgegBgeAJQgNAEgjAQIgFADIgVAIIgTAEQgPAEgMABQgKAAgSgCIgkgIIgUgFIhzgZIhJgRQgYgGgMgHIgGgEQgPgNgCgSIAAgFQAAgMAHgJQAFgHAHgFQAQgJAhACIASAAQAVgBALgFQAGgDgBgEQAAgDgHgBQgSgDgLgEIgCgBQgNgIgEgNQgEgMAJgOQAIgNAOgFQAXgJAjAJQAjANAVADQAMADAeAAQATABAGgJQADgEAAgJQAAgKACgDQADgJAOgDIALgDIACAAIARgDIArgIIBWgPIAmgHIBAgMIAxgJIAJgCQAfgFATgCQANgCAmgBIADAAQAVgBAQADIASADQAIACAGAEIAFACIAMAFQALAFAHACQANADATgDQAvgFAwgKIAugJIAjgCIAkgCIATgBIAOAAQAJABAQAFQANADAZAAQCZgBBEAFIACAAQATACAPACIAWAFIAJACIARAEIAKAEIAGACQAqAHBWANQBVANAyAMQAPAEAFAHQAFAGABANQAAANgCAEQgDAFgLAEQgaAJg6ADIgLAAQghADgVAEQgLACgIADIgCABIgKAEIgOAJQgGADgEAEQgGAEABAEIABACQABADAFACQAQAGAhgBIBMAAIAZABIAUACQAiAHApAdQAZAUgEASQgDALgLAIQgFAFgIAEIgDACIgOAHIgPAGIgQAGIgTAFQgiAIgqAIIiYAVIgoAFIgkAFIgaAGIgVAEIgFACQgPAEgDAKQgCAGACAKIgCAGIgEAHQgFAFgHADQgIAEgVABIghABIgPAAQgUAAgJgBg");
	this.shape_560.setTransform(7.4,4.1);

	this.shape_561 = new cjs.Shape();
	this.shape_561.graphics.f("#D5FFFF").s().p("AFCDgIgEAAQgJgBgLgDIgXgHQgxgNgugEQgXgCgWAAIgRAAIgzACIgRABIhBACQguACgXACIgHAAQgkACgoAEIgKABIg0AEIgHABQgWABgOgBQgTgCgYgGQgUgGgWgIIgtgSIgBgBQgUgHgEgKQgEgJAGgJQADgIAJgIIACgBQAcgYAfgNIAKgDQgbgNgggBQgfgBgeAKQgNAEgjAQIgGADIgVAIQgKAEgJABQgPAFgMAAQgLABgSgDIglgIIgVgEIh1gaIhJgRQgYgFgNgIIgFgEQgQgNgBgSIgBgFQABgMAGgJQAFgHAIgFQAPgKAiACIASAAQAVgBALgFQAGgDgBgEQAAgDgHgBQgTgDgLgFIgCgBQgOgHgEgOQgEgMAJgOQAIgNAOgFQAXgKAjAKQAkANAVADQAMADAeAAQAUABAGgJQADgEAAgJQgBgKACgEQAEgIANgEIAMgCIABgBIATgDIArgHIBXgQIAmgHIBAgMIAxgJIAJgCQAggFATgCQANgCAmgBIAEAAQAVgBAQADIATADIAOAFIAEACIANAGQALAFAHACQANADAUgDQAvgFAwgKQAjgIAMgBQANgCAWAAIAjgCIAUgBIAOAAQAJABAQAFQANADAaAAQCbgBBEAFIACAAQATABAOADIAXAEIAKADIASAEIAKADIAGACICBAVQBWANAyANQAPAEAFAGQAGAHAAANQAAANgDAFQgDAFgLADQgbAKg8ACIgLABQgiACgWAFQgLACgJADIgCABIgKAEQgIADgGAFIgLAHQgFAEAAAEIACADQABADAFABQARAGAiAAIBOAAIAaAAIAVADQAjAHAqAdQAbAUgFATQgCALgLAIQgGAFgIAEIgDACIgOAGIgPAHIgRAGIgTAFQgiAIgrAHIiZAWIgpAFIgkAFIgaAGIgWAEIgFACQgQAEgDAKQgBAGABAKIgBAGIgEAHQgFAGgHADQgJAEgUABIgiABQghAAgLgCg");
	this.shape_561.setTransform(7.5,4.2);

	this.shape_562 = new cjs.Shape();
	this.shape_562.graphics.f("#D5FFFF").s().p("AFDDjIgEgBQgJgBgLgDIgXgHQgxgNgvgFQgXgCgXAAIgRAAIgzACIgRABIhCACIhFAEIgHAAQgkACgpAFIgKABIg1AEIgGAAQgXACgNgBQgUgBgXgHQgVgFgXgJIgsgSIgCgBQgUgIgEgJQgDgJAFgKQAEgIAJgIIACgCQAdgYAhgNIAKgDQgcgNgggBQgfgBgeAKQgNAEgjARIgGADIgVAIIgUAGQgQAEgMABQgLABgTgDQgRgCgVgGIgWgFIh1gZIhKgRQgYgGgNgHIgFgEQgQgNgCgTIgBgFQABgMAGgJQAFgHAIgFQAPgKAiACIATAAQAVgBALgFQAGgDgBgEQgBgEgHgBQgTgCgLgFIgDgBQgOgIgEgOQgEgNAIgOQAJgNAOgGQAXgJAjAKQAlANAUAEQANACAeABQAUABAGgKQADgEAAgJQgBgKACgEQADgJAOgDIAMgDIACAAIASgDIAsgHQAogGAwgKIAmgHIBBgMIAygJIAJgCIAzgIQANgCAmgBIAEAAQAVAAARACIASADQAJACAGAEIAEACIANAGQALAFAIABQAMADAUgCQAwgFAxgLQAjgHAMgCQANgBAWgBIAkgBIATgBIAOAAQAJABARAFQANADAaAAQCdgBBEAEIACAAIAiAEIAXAEIAKACIATAFIAKADIAGACICDAWQBXANAyANQAPAEAFAGQAFAHABANQgBAOgCAEQgDAFgMAEQgcAKg+ACIgMABQgiACgXAEQgMACgJADIgCABIgKAEQgIAEgHAEQgGAEgEAEQgFAEAAAEIABADQACADAFABQASAGAiAAIBRAAIAbAAIAVADQAlAHAsAeQAbAUgEATQgDALgLAIQgGAFgIAEIgDACIgPAHIgPAGIgRAGIgTAFQgjAIgrAIIiaAWIgpAFIglAFIgbAGIgXAEIgFABQgQAFgDAKQgBAGACAKIgCAGIgEAHQgFAGgHADQgJAEgUABIgiABIgPAAQgVAAgJgBg");
	this.shape_562.setTransform(7.7,4.3);

	this.shape_563 = new cjs.Shape();
	this.shape_563.graphics.f("#D5FFFF").s().p("AFFDkIgFgBQgIAAgLgEIgYgGQgxgOgwgFQgWgCgYAAIgRAAIgzACIgSABIhCACIhGAEIgGAAQgkACgqAFIgLABIg0AEIgHABQgXABgOAAQgTgCgYgGQgUgGgXgJIgtgSIgCgBQgUgIgEgJQgEgJAGgKQAEgJAJgHIADgCQAdgZAigNIALgEQgcgMgggBQgggBgeAKQgMAEgkARIgGADIgWAJIgTAGQgRAEgMABQgMABgTgCQgRgDgXgFIgWgFIh2gaIhLgRQgYgFgNgIIgGgEQgQgNgCgTIAAgFQAAgMAHgKQAEgHAIgFQAQgKAiACIATAAQAVgBALgFQAGgDgBgEQAAgEgIgBQgUgDgLgFIgDgBQgOgIgFgNQgEgOAJgOQAIgNAOgGQAXgKAkAKQAlAOAUAEQANACAfABQATABAHgKQACgEAAgJQgBgLACgDQAEgJANgEIANgCIACAAIATgDIAsgHIBYgQIAngHIBBgNIAygJIAJgCIA0gIQANgCAngBIADAAQAWAAARACIATADQAIACAGADIAFACIANAHQALAFAIABQAMAEAUgDQAxgFAxgLIAvgJIAkgCIAkgBIAUgBIAOgBQAJACAQAFQANADAbAAQCegBBEAEIACAAIAjADIAYAEIAKADIATAEIALADIAGACQArAJBZAOQBYANAyANQAPAEAFAHQAFAGABAOQgBAOgCAEQgEAGgLADQgeAKg/ACIgNABQgjACgYAFQgMACgJADIgCABIgLAEQgIADgHAFIgKAHQgGAEABAFIABACQACADAFACQASAGAkgBIBUAAIAcABIAWACQAmAHAsAfQAcAUgDAUQgDALgLAIQgGAFgJAEIgDACIgPAHIgQAGIgRAGIgTAFQgjAIgsAIIibAWIgqAGIglAFIgcAFIgXAEIgFACQgRAEgDAKQgBAGACAKQAAAEgBADIgEAHQgFAGgIADQgIAEgVABIgiABQgiAAgLgCg");
	this.shape_563.setTransform(7.9,4.4);

	this.shape_564 = new cjs.Shape();
	this.shape_564.graphics.f("#D5FFFF").s().p("AFGDnIgEgBQgJgBgLgEIgYgGQgxgOgwgFQgXgCgXgBIgRAAIg1ACIgRABIhDADIhGADIgHAAQgkADgqAFIgLAAIg1AFIgGABQgYABgOAAQgUgCgXgGQgVgGgXgJIgtgSIgCgBQgUgIgEgKQgEgJAGgKQAFgJAJgHIADgCQAegZAjgOIALgEQgcgMgggBQgggCgfALQgMAEglASIgFACIgWAKIgUAGQgRAFgNABQgMABgTgCQgSgDgXgFIgXgFIh3gaIhLgRQgZgGgNgIIgGgDQgQgNgCgUIAAgEQAAgNAGgKQAFgHAIgFQAPgKAjACIATAAQAVgBALgGQAHgDgCgEQAAgDgHgBQgVgDgMgFIgDgBQgPgIgFgPQgEgNAJgPQAIgNAOgGQAYgKAjAKQAmAOAUAEQANADAfABQAUAAAGgJQADgEgBgKQAAgKABgEQAEgJAOgEIANgCIACAAIATgDIAtgHQApgGAwgKIAngHIBCgNIAygKIAJgCQAigGATgCQAMgBAogBIADAAQAWgBARACIATADQAIACAHAEIAFACIANAGQALAFAHACQANADAVgDQAwgEAygLIAvgJIAkgDIAlgBIAUgBIAOAAQAJABARAGQANACAaAAQCggBBFAEIACAAIAjADIAYAEIALADIATAEIALADIAHACQArAJBaAOQBYAOAzANQAPAEAGAHQAFAGAAAPQgBAOgDAEQgDAFgMAEQgfAKhBACIgNABQgkACgZAEQgMACgKADIgCABIgLAEQgIAEgHAEIgKAIQgGAEABAFIABACQACADAFACQATAGAlgBIBWAAIAdABIAXACQAnAHAuAfQAdAVgEAUQgCALgLAJQgGAFgJAEIgEACIgPAGIgRAGIgRAGIgUAFQgiAIgsAIIidAXIgqAGIglAFIgdAFIgYAEIgFABQgRAFgDAKQgBAGACAKIgBAHIgEAHQgGAGgHADQgIAEgWABIgiABIgugBg");
	this.shape_564.setTransform(8,4.4);

	this.shape_565 = new cjs.Shape();
	this.shape_565.graphics.f("#D5FFFF").s().p("AFHDoIgEgBQgJgBgLgDIgYgHQgxgOgxgFQgXgCgYgBIgRAAIg1ACIgRABIhDADQgwABgXACIgHAAQgkADgrAFIgLABIg1AEIgHABQgYACgNgBQgUgBgYgHQgVgFgYgJIgtgSIgCgBQgUgJgEgKQgDgJAGgLQAEgIAKgIIADgCQAfgaAlgNIALgEQgdgNgggBQgggBgfALQgMAEglASIgGADIgWAJIgUAHQgRAFgOACQgMABgUgDQgSgCgYgGIgYgFIh4gaIhMgRQgZgFgNgIIgFgEQgRgNgCgUIAAgEQAAgNAGgKQAFgIAIgFQAPgKAjACIATAAQAWgBALgFQAGgEgBgEQAAgEgIgBQgVgCgMgGIgDgBQgQgIgFgOQgEgOAIgPQAIgOAPgGQAXgKAlALQAlAOAVAEQAMADAgABQAUABAGgKQADgFgBgJQAAgLABgEQAEgJAOgEIANgCIACAAIAUgCIAtgHQApgGAxgKIAogIIBBgNIAzgKIAKgCQAigGASgCQANgBAogBIADAAQAXgBARACIATADIAPAFIAFACIANAHQALAFAIACQANADAUgDQAxgEAygLQAkgIAMgCQANgBAYgBIAkgBIAUgBIAOAAQAJABASAGQAMACAbAAQCiAABFADIACAAIAjADIAZAEIALACIAUAFIAMADIAHACQAqAIBbAPQBaAOAzANQAPAEAFAHQAFAHABAPQgBAOgDAEQgEAGgMAEQggAJhDADIgNAAQglACgaAFQgNACgKADIgCABIgLADQgJAEgHAEIgKAIQgFAEAAAFIABACQACAEAGABQAUAHAlgBIBZgBIAeABIAXACQApAIAvAfQAeAWgDAUQgDALgLAIQgGAFgJAEIgEACIgQAHIgRAGIgSAFIgTAFQgjAJgsAIIieAXIgrAGIglAFIgeAFIgZAEIgFABQgRAFgDAKQgBAGACAKIgBAHIgEAIQgGAGgHADQgIAEgWABIgjABQgiAAgMgCg");
	this.shape_565.setTransform(8.2,4.5);

	this.shape_566 = new cjs.Shape();
	this.shape_566.graphics.f("#D5FFFF").s().p("AFJDqIgEgBQgJgBgLgDIgZgHQgxgOgygGQgXgCgXgBIgSAAIg1ACIgSABIhDACIhIAEIgHAAQgkADgrAFIgLABIg2AEIgGABQgZACgNAAQgVgBgYgHQgVgFgXgKIgugSIgCgBQgUgIgEgLQgEgJAHgLQAFgJAKgIIADgCQAfgaAmgNIAMgEQgdgOgggBQghgBgfAMQgMAEglASIgGADIgWAKQgLAEgKADQgRAGgOABQgNABgUgCQgTgDgZgFIgYgFIh5gaIhNgRQgZgGgNgIIgGgEQgQgNgCgUIgBgFQAAgNAHgKQAEgHAIgGQAQgKAjACIATAAQAWAAALgGQAHgEgCgEQAAgEgIgBQgWgDgMgFIgDgBQgQgIgGgPQgEgOAIgPQAIgOAPgGQAYgLAkALQAmAPAVAEQAMADAgABQAVABAGgKQACgFAAgJQgBgLABgEQAEgKAOgEIAOgCIACAAIAUgCIAugGQAqgHAxgJIAngIIBDgNIAzgLIAJgCQAjgGATgCQAMgBApgBIADAAQAWgBASACIATADQAJACAHADIAFACIANAHQALAFAIACQANAEAVgDQAxgFAygLQAlgIALgCQAOgBAXgBIAlgBIAUgBIAPAAQAJABARAGQANADAbAAQCjgBBFADIACAAIAkADIAaADIALADIAVAEIALADIAIACQAqAJBcAPQBbAOAzANQAQAFAFAHQAFAHAAAOQgBAPgEAFQgDAFgNAEQghAKhFACIgNAAQgmACgaAFQgOACgKADIgCABIgMAEQgJADgHAFQgGADgEAFQgGADABAFIABADQACADAGACQAUAGAngBIBcAAIAeAAIAYADQAqAHAxAgQAfAWgEAUQgCALgLAJQgGAFgKAEIgEACIgQAHIgSAGIgSAFIgTAFQgjAJgtAIIifAXIgrAGIgmAFIgfAFIgZAFIgFABQgSAEgDAKQgBAGADALIgBAHIgEAHQgGAHgHADQgJADgWABIgjABIgPAAQgWAAgJgBg");
	this.shape_566.setTransform(8.4,4.6);

	this.shape_567 = new cjs.Shape();
	this.shape_567.graphics.f("#D5FFFF").s().p("Ar7DhQk8hdgBiEQABiCE8heQE9hdG+AAQG/AAE9BdQE8BeABCCQgBCEk8BdQk9Bem/AAQm+AAk9heg");
	this.shape_567.setTransform(10.4,4.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_470}]},355).to({state:[{t:this.shape_471}]},1).to({state:[{t:this.shape_472}]},1).to({state:[{t:this.shape_473}]},1).to({state:[{t:this.shape_474}]},1).to({state:[{t:this.shape_475}]},1).to({state:[{t:this.shape_476}]},1).to({state:[{t:this.shape_477}]},1).to({state:[{t:this.shape_478}]},1).to({state:[{t:this.shape_479}]},1).to({state:[{t:this.shape_480}]},1).to({state:[{t:this.shape_481}]},1).to({state:[{t:this.shape_482}]},1).to({state:[{t:this.shape_483}]},1).to({state:[{t:this.shape_484}]},1).to({state:[{t:this.shape_485}]},1).to({state:[{t:this.shape_486}]},1).to({state:[{t:this.shape_487}]},1).to({state:[{t:this.shape_488}]},1).to({state:[{t:this.shape_489}]},1).to({state:[{t:this.shape_490}]},1).to({state:[{t:this.shape_491}]},1).to({state:[{t:this.shape_492}]},1).to({state:[{t:this.shape_493}]},1).to({state:[{t:this.shape_494}]},1).to({state:[{t:this.shape_495}]},1).to({state:[{t:this.shape_496}]},1).to({state:[{t:this.shape_497}]},1).to({state:[{t:this.shape_498}]},1).to({state:[{t:this.shape_499}]},1).to({state:[{t:this.shape_500}]},1).to({state:[{t:this.shape_501}]},1).to({state:[{t:this.shape_502}]},1).to({state:[{t:this.shape_503}]},1).to({state:[{t:this.shape_504}]},1).to({state:[{t:this.shape_505}]},1).to({state:[{t:this.shape_506}]},1).to({state:[{t:this.shape_507}]},1).to({state:[{t:this.shape_508}]},1).to({state:[{t:this.shape_509}]},1).to({state:[{t:this.shape_510}]},1).to({state:[]},1).to({state:[{t:this.shape_511}]},63).to({state:[{t:this.shape_512}]},1).to({state:[{t:this.shape_513}]},1).to({state:[{t:this.shape_514}]},1).to({state:[{t:this.shape_515}]},1).to({state:[{t:this.shape_516}]},1).to({state:[{t:this.shape_517}]},1).to({state:[{t:this.shape_518}]},1).to({state:[{t:this.shape_519}]},1).to({state:[{t:this.shape_520}]},1).to({state:[{t:this.shape_521}]},1).to({state:[{t:this.shape_522}]},1).to({state:[{t:this.shape_523}]},1).to({state:[{t:this.shape_524}]},1).to({state:[{t:this.shape_525}]},1).to({state:[{t:this.shape_526}]},1).to({state:[{t:this.shape_527}]},1).to({state:[{t:this.shape_528}]},1).to({state:[{t:this.shape_529}]},1).to({state:[{t:this.shape_530}]},1).to({state:[{t:this.shape_531}]},1).to({state:[{t:this.shape_532}]},1).to({state:[{t:this.shape_533}]},1).to({state:[{t:this.shape_534}]},1).to({state:[{t:this.shape_535}]},1).to({state:[{t:this.shape_536}]},1).to({state:[{t:this.shape_537}]},1).to({state:[{t:this.shape_538}]},1).to({state:[{t:this.shape_539}]},1).to({state:[{t:this.shape_540}]},1).to({state:[{t:this.shape_541}]},1).to({state:[{t:this.shape_542}]},1).to({state:[{t:this.shape_543}]},1).to({state:[{t:this.shape_544}]},1).to({state:[{t:this.shape_545}]},1).to({state:[{t:this.shape_546}]},1).to({state:[{t:this.shape_547}]},1).to({state:[{t:this.shape_548}]},1).to({state:[{t:this.shape_549}]},1).to({state:[{t:this.shape_550}]},1).to({state:[{t:this.shape_551}]},1).to({state:[{t:this.shape_552}]},1).to({state:[{t:this.shape_553}]},1).to({state:[{t:this.shape_554}]},1).to({state:[{t:this.shape_555}]},1).to({state:[{t:this.shape_556}]},1).to({state:[{t:this.shape_557}]},1).to({state:[{t:this.shape_558}]},1).to({state:[{t:this.shape_559}]},1).to({state:[{t:this.shape_560}]},1).to({state:[{t:this.shape_561}]},1).to({state:[{t:this.shape_562}]},1).to({state:[{t:this.shape_563}]},1).to({state:[{t:this.shape_564}]},1).to({state:[{t:this.shape_565}]},1).to({state:[{t:this.shape_566}]},1).to({state:[{t:this.shape_470}]},1).to({state:[]},1).to({state:[{t:this.shape_567}]},40).to({state:[]},60).wait(73));

	// Layer 2
	this.shape_568 = new cjs.Shape();
	this.shape_568.graphics.f("rgba(160,252,250,0.188)").s().p("ApxEOIhDgPIirgyQhLgcg0gdIgdgSIgxgpQgYgZgKgaIgBgCIgBgDQgFgQAAgRQABh+EhhcIAhgKQEjhXGNgJIBigBQFkAAEUA6QBRARBKAWQCGAoBOAtIAoAbIAGAGQAcAWAQAYIADAHQAJAOAEAOQAFARAAAMQgBB+keBcIgkAMQkhBVmLAJIhnACQlfAAkSg4g");
	this.shape_568.setTransform(10.3,5.1);

	this.shape_569 = new cjs.Shape();
	this.shape_569.graphics.f("#D5FFFF").s().p("Ap2EWIhFgPIingxQhVgfg4ghIg2gmIgXgYQgWgZgIgcIAAgBIgBgCQgEgQAAgQQgBiEEphfIAigKQEkhYGQgJIBhgBQFlAAEUA6QBTARBKAXQCMApBQAxIArAdIABABIADACQAdAYAPAbIAEAGQAIAPAEAQIADAbQABCFkoBfIgjALQkjBXmPAJIhkABQljAAkTg6gAhilEQmNAJkjBXIghAKQkhBcgBB+QAAARAFAQIABADIABACQAKAaAYAZIAxApIAdASQA0AdBLAcICrAyIBDAPQESA4FfAAIBngCQGLgJEhhVIAkgMQEehcABh+QAAgMgFgRQgEgOgJgOIgDgHQgQgYgcgWIgGgGIgogbQhOgtiGgoQhKgWhRgRQkUg6lkAAg");
	this.shape_569.setTransform(10.3,5.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_569},{t:this.shape_568}]},99).wait(590));

	// Layer 1
	this.instance_27 = new lib.shape63("synched",0);
	this.instance_27.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_27).wait(689));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-108.8,-275.3,239.2,317.2);


// stage content:
(lib.Thermenontas_to_nero_v20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var _root = this;
		createjs.Touch.enable(stage);
		var where;
		var curModeDescription = "";
		var curState = 0;
		var curMode = 0;
		var isMatterChangeInProgress = false;
		
		var startingState=true;
		
		
		curStateDescription = "Κατάσταση σώματος: " + StateDescription(1);
			_root.curState_text.text=curStateDescription;
			_root.curMode.text=curModeDescription;
		
		_root.waterContainer.on("tick", function() {
		var tl = _root.waterContainer.timeline;
		var d = _root.waterContainer.timeline.duration;
			where = (tl.position)%d;
			if(where==160){where=0; matterChanged(2);_root.hot_btn.mouseEnabled = true;_root.cold_btn.mouseEnabled = true;};
			if(where==297){where=5; matterChanged(3);_root.hot_btn.mouseEnabled = true;_root.cold_btn.mouseEnabled = true;};
			if(where==458){where=0; matterChanged(2);_root.hot_btn.mouseEnabled = true;_root.cold_btn.mouseEnabled = true;};
			if(where==618){where=0; matterChanged(2);_root.hot_btn.mouseEnabled = true;_root.cold_btn.mouseEnabled = true;};
			if(where==688){where=0; matterChanged(1);_root.hot_btn.mouseEnabled = true;_root.cold_btn.mouseEnabled = true;};
			
		});
		
		
		_root.hot_btn.on("click", function() {
			_root.hot_btn.mouseEnabled = false;
			_root.cold_btn.mouseEnabled = false;
			if(where!=5){
			makeStateChange("heat");
		    _root.HCMachineI.visible=false;
			_root.HCMachineC.visible=false;
			_root.HCMachineH.visible=true;
			}
		});
		
		
		_root.hot_btn.on("pressup", function() {
			startingState = false;
		    if (!isMatterChangeInProgress)
		    {
				_root.HCMachineI.visible=true;
				_root.HCMachineC.visible=false;
				_root.HCMachineH.visible=false;
				
		    } // end if	
		});
		
		
		
		_root.cold_btn.on("click", function() {
			if (!startingState){
			_root.hot_btn.mouseEnabled = false;
			_root.cold_btn.mouseEnabled = false;
			makeStateChange("cool");
			_root.HCMachineI.visible=false;
			_root.HCMachineC.visible=true;
			_root.HCMachineH.visible=false;
			}
		});	
		
		
		
		function matterChanged(nCode)
		{
		    curState = nCode;
		    isMatterChangeInProgress = false;
		    curModeDescription = "";
		    _root.HCMachineI.visible=true;
			_root.HCMachineC.visible=false;
			_root.HCMachineH.visible=false;
		    curStateDescription = "Κατάσταση σώματος: " + StateDescription(nCode);
			_root.curState_text.text=curStateDescription;
			_root.curMode.text=curModeDescription;
		} // End of the function
		
		
		
		function StateDescription(nCode)
		{
		    var _loc1 = "";
		    switch (nCode)
		    {
		        case 1:
		        {
		            _loc1 = "Στερεό";
		            break;
		        } 
		        case 2:
		        {
		            _loc1 = "Υγρό";
		            break;
		        } 
		        case 3:
		        {
		            _loc1 = "Αέριο";
		            break;
		        } 
		        default:
		        {
		            _loc1 = "";
		            break;
		        } 
		    } // End of switch
		    return (_loc1);
		} // End of the function
		
		
		
		
		
		
		
		
		
		function makeStateChange(cool_or_heat)
		{
		    if (isMatterChangeInProgress)
		    {
		        return;
		    } // end if
			_root.HCMachineI.visible=false;
			_root.HCMachineC.visible=true;
			_root.HCMachineH.visible=false;
			
			console.log(curState)
		    var _loc1 = 0;
		    if (curState == 0 && cool_or_heat == "heat")
		    {
		        _loc1 = 1;
		    } // end if
		    if (curState == 1 && cool_or_heat == "heat")
		    {
		        _loc1 = 2;
		    } // end if
		    if (curState == 2 && cool_or_heat == "heat")
		    {
		        _loc1 = 3;
		    } // end if
		    if (curState == 2 && cool_or_heat == "cool")
		    {
		        _loc1 = 6;
		    } // end if
		    if (curState == 3 && cool_or_heat == "heat")
		    {
		        _loc1 = 4;
		    } // end if
		    if (curState == 3 && cool_or_heat == "cool")
		    {
		        _loc1 = 5;
		    } // end if
		    isMatterChangeInProgress = true;
		    switch (_loc1)
		    {
		        case 1:
		        {
		            curModeDescription = "Τήξη";
		            curStateDescription = "Κατάσταση σώματος: " + StateDescription(1) + " και " + StateDescription(2);
		            _root.waterContainer.gotoAndPlay("icecube_to_water");
		            curState = 2;
					_root.curState_text.text=curStateDescription;
					_root.curMode.text=curModeDescription;
		            break;
		        } 
		        case 2:
		        {
		            curModeDescription = "Τήξη";
		            curStateDescription = "Κατάσταση σώματος: " + StateDescription(1) + " και " + StateDescription(2);
		            _root.waterContainer.gotoAndPlay("ice_to_water");
		            curState = 2;
					_root.curState_text.text=curStateDescription;
					_root.curMode.text=curModeDescription;
		
		            break;
		        } 
		        case 3:
		        {
		            curModeDescription = "Εξάτμιση/Βρασμός";
		            curStateDescription = "Κατάσταση σώματος: " + StateDescription(2) + " και " + StateDescription(3);
		            _root.waterContainer.gotoAndPlay("water_to_steam");
		            curState = 3;
					_root.curState_text.text=curStateDescription;
					_root.curMode.text=curModeDescription;
		
		            break;
		        } 
		        case 4:
		        {
		            _root.waterContainer.gotoAndPlay("steam_explosion");
		            curStateDescription = "Κατάσταση σώματος: " + StateDescription(3);
		            curState = 3;
		            isMatterChangeInProgress = false;
					_root.curState_text.text=curStateDescription;
					_root.curMode.text=curModeDescription;
		
		            break;
		        } 
		        case 5:
		        {
		            curModeDescription = "Υγροποίηση";
		            curStateDescription = "Κατάσταση σώματος: " + StateDescription(3) + " και " + StateDescription(2);
		            _root.waterContainer.gotoAndPlay("steam_to_water");
		            curState = 2;
					_root.curState_text.text=curStateDescription;
					_root.curMode.text=curModeDescription;
		
		            break;
		        } 
		        case 6:
		        {
		            curModeDescription = "Πήξη";
		            curStateDescription = "Κατάσταση σώματος: " + StateDescription(2) + " και " + StateDescription(1);
		            _root.waterContainer.gotoAndPlay("water_to_ice");
		            curState = 1;
					_root.curState_text.text=curStateDescription;
					_root.curMode.text=curModeDescription;
		
		            break;
		        } 
		        default:
		        {
		            curModeDescription = "";
		            isMatterChangeInProgress = false;
								_root.curState_text.text=curStateDescription;
					_root.curMode.text=curModeDescription;
		
		            break;
		        } 
		    } // End of switch
		} // End of the function
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		_root.help_btn.addEventListener("click", function(evt) {
			_root.keimeno.visible=true;
				});
		_root.keimeno.xi.addEventListener("click", function(evt) {
			_root.keimeno.visible=false;
		});
		
		
		this.info_btn.addEventListener("click", fl_ClickToGoToWebPage);
		function fl_ClickToGoToWebPage() {
			window.open("credits/index.html", "_blank");
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// ?
	this.help_btn = new lib.dertg36copy();
	this.help_btn.name = "help_btn";
	this.help_btn.parent = this;
	this.help_btn.setTransform(1214.5,18.1,0.999,0.999);
	new cjs.ButtonHelper(this.help_btn, 0, 1, 2, false, new lib.dertg36copy(), 3);

	this.timeline.addTween(cjs.Tween.get(this.help_btn).wait(1));

	// i
	this.info_btn = new lib.dertg36();
	this.info_btn.name = "info_btn";
	this.info_btn.parent = this;
	this.info_btn.setTransform(1256.7,21.8,0.991,0.991,0,0,0,0.4,3.7);
	new cjs.ButtonHelper(this.info_btn, 0, 1, 2, false, new lib.dertg36(), 3);

	this.timeline.addTween(cjs.Tween.get(this.info_btn).wait(1));

	// help
	this.keimeno = new lib.Symbol27();
	this.keimeno.name = "keimeno";
	this.keimeno.parent = this;
	this.keimeno.setTransform(955.7,92.9,0.265,0.265,0,0,0,-1935.3,-166.3);
	this.keimeno.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.keimeno).wait(1));

	// CourseTitle
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgoBPQgQgSAAgfQAAgdAQgRQAQgRAYgBQAbAAAPASQAPAQAAAeQAAAfgQASQgPARgaAAQgZAAgPgRgAgXgCQgJALAAAVQAAAwAgAAQAQAAAJgOQAIgMAAgWQAAgtghAAQgOAAgJANgAgKg4IANgnIAZAAIgUAng");
	this.shape.setTransform(404.5,17.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag3BZIAAhmQAAgnAPgSQAPgRAZgBQAaABAPARQAPASAAAdQAAAcgPATQgPASgaAAQgVAAgMgKIAAA5gAgYg3QgIANAAAXIAAAhQALAJAQAAQASAAAKgMQAKgLAAgWQAAgWgJgMQgKgNgOAAQgPAAgJAOg");
	this.shape_1.setTransform(391.4,22.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgiA3QgNgKAAgQQAAgVAbgJQgLgDgGgHQgHgHAAgJQAAgQANgLQAMgKAVAAQASAAAWAKIgIASQgTgKgPAAQgJAAgFAFQgHAEAAAJQAAAIAIAFQAGAFAMAAIAQgBIAAARIgSgBQgMAAgHAGQgHAGAAAKQAAAKAHAFQAHAFAMAAQASAAAQgNIALARQgXAOgZAAQgVAAgNgKg");
	this.shape_2.setTransform(378.8,20.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgCBAIg2h/IAZAAIAfBVIAhhVIAYAAIg3B/g");
	this.shape_3.setTransform(367.1,20.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgoAwQgQgSAAgeQAAgcAQgSQAQgSAYAAQAbAAAPARQAPASAAAdQAAAfgQARQgPARgaAAQgZAAgPgRgAgXghQgJAMAAAVQAAAvAgAAQAQAAAJgNQAIgNAAgVQAAgughAAQgOAAgJANg");
	this.shape_4.setTransform(347.3,20.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgHA3QgJgJAAgQIAAhKIgfAAIAAgTIBfAAIAAATIgqAAIAABGQAAAKADAEQADAFAHAAQAGAAAHgDIADATQgKADgKAAQgPAAgHgJg");
	this.shape_5.setTransform(335.4,20.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgCBXIADgSQAGACAFAAQAIAAAEgEQAFgDAAgIQAAgHgFgEQgEgFgQgCQgZgEgOgPQgOgQgBgYQAAgfASgSQARgRAcgBQAUAAAPALIgKAQQgMgHgOgBQgRAAgKANQgLANAAAWQAAAhAnAHQAUAEAIAIQAKAJgBAPQABAPgMAJQgKAKgRAAQgIgBgGgBg");
	this.shape_6.setTransform(317.8,22.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgtAwQgPgRAAgeQABgcAQgTQAQgSAaAAQAQAAAOANQAEgIAHgCQAGgDANAAIAAANQgGACgDAEQgCAEAAAJIAAA+QAAAKADAFQADAFAHACIAAANQgRAAgGgEQgHgEgDgJQgNARgWAAQgYAAgOgRgAgaghQgKANAAAUQAAAWAKAMQAKAMAQAAQAOAAAMgPIAAhCQgLgKgNAAQgSAAgKAMg");
	this.shape_7.setTransform(305,20.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgHA3QgJgJAAgQIAAhKIgfAAIAAgTIBfAAIAAATIgqAAIAABGQAAAKADAEQADAFAHAAQAGAAAHgDIADATQgKADgKAAQgPAAgHgJg");
	this.shape_8.setTransform(292.6,20.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgCBAIg2h/IAZAAIAfBVIAhhVIAYAAIg3B/g");
	this.shape_9.setTransform(281.4,20.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgoAwQgQgSAAgeQAAgcAQgSQAQgSAYAAQAbAAAPARQAPASAAAdQAAAfgQARQgPARgaAAQgZAAgPgRgAgXghQgJAMAAAVQAAAvAgAAQAQAAAJgNQAIgNAAgVQAAgughAAQgOAAgJANg");
	this.shape_10.setTransform(268.8,20.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAfA/IgfgwIgfAwIgbAAIAvhAIgrg9IAaAAIAcAsIAdgsIAZAAIgsA8IAxBBg");
	this.shape_11.setTransform(256.2,20.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AglBSQgMgOAAgdIAAhGIAWAAIAABIQAAAlAbAAQAOAAAHgJQAHgIAAgTIAAhJIAWAAIAABGQAAA5gyAAQgZAAgMgOgAgKg4IALgnIAcAAIgVAng");
	this.shape_12.setTransform(243.5,17.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgKBXIAAgvQg8gEAAg7IAAg/IAXAAIAABAQAAAUAJALQAKAMATACIAAhtIAUAAIAABtQATgCAKgMQAJgLAAgUIAAhAIAWAAIAAA+QAAAcgPARQgPARgdACIAAAvg");
	this.shape_13.setTransform(228.2,23);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgSAcIAAhbIAVAAIAABYQAAATAQABIAAATQglAAAAgkg");
	this.shape_14.setTransform(209.4,20.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgtAwQgPgRAAgeQABgcAQgTQAQgSAaAAQAQAAAOANQAEgIAHgCQAGgDANAAIAAANQgGACgDAEQgCAEAAAJIAAA+QAAAKADAFQADAFAHACIAAANQgRAAgGgEQgHgEgDgJQgNARgWAAQgYAAgOgRgAgaghQgKANAAAUQAAAWAKAMQAKAMAQAAQAOAAAMgPIAAhCQgLgKgOAAQgRAAgKAMg");
	this.shape_15.setTransform(198.8,20.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAaA/Igng5IgSAVIAAAkIgWAAIAAh9IAWAAIAAA+IAyg+IAdAAIgvA1IA1BIg");
	this.shape_16.setTransform(185.8,20.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgCBXIADgSQAFACAHAAQAHAAAEgEQAFgDAAgIQAAgHgFgEQgEgFgQgCQgZgEgOgPQgOgQAAgYQAAgfARgSQARgRAcgBQAUAAAPALIgLAQQgLgHgOgBQgRAAgLANQgKANAAAWQAAAhAnAHQAUAEAJAIQAJAJAAAPQgBAPgKAJQgMAKgQAAQgJgBgFgBg");
	this.shape_17.setTransform(166.3,22.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgtAwQgOgRAAgeQgBgcARgTQAPgSAaAAQARAAAOANQAFgIAGgCQAHgDAMAAIAAANQgGACgDAEQgCAEAAAJIAAA+QAAAKADAFQADAFAGACIAAANQgPAAgHgEQgHgEgDgJQgNARgVAAQgZAAgOgRgAgaghQgKANAAAUQAAAWAKAMQALAMAPAAQAPAAAKgPIAAhCQgKgKgNAAQgSAAgKAMg");
	this.shape_18.setTransform(153.5,20.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgHA3QgJgJAAgQIAAhKIgfAAIAAgTIBfAAIAAATIgqAAIAABGQAAAKADAEQADAFAHAAQAGAAAHgDIADATQgKADgKAAQgPAAgHgJg");
	this.shape_19.setTransform(141.1,20.7);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgCBAIg2h/IAZAAIAfBVIAhhVIAYAAIg3B/g");
	this.shape_20.setTransform(129.9,20.7);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgoAwQgQgSAAgeQAAgcAQgSQAQgSAYAAQAbAAAPARQAPASAAAdQAAAfgQARQgPARgaAAQgZAAgPgRgAgXghQgJAMAAAVQAAAvAgAAQAQAAAJgNQAIgNAAgVQAAgughAAQgOAAgJANg");
	this.shape_21.setTransform(117.3,20.6);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgCBAIg2h/IAZAAIAfBVIAhhVIAYAAIg3B/g");
	this.shape_22.setTransform(104.8,20.7);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgTA8IAAhbIAWAAIAABYQAAATAQABIAAATQgmAAAAgkgAgTg4IANgnIAaAAIgUAng");
	this.shape_23.setTransform(96,17.5);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgtAwQgPgRAAgeQABgcAQgTQAQgSAZAAQARAAAOANQAFgIAGgCQAGgDANAAIAAANQgGACgDAEQgCAEAAAJIAAA+QAAAKADAFQADAFAGACIAAANQgPAAgHgEQgHgEgDgJQgNARgVAAQgZAAgOgRgAgaghQgKANAAAUQAAAWAKAMQALAMAPAAQAOAAAMgPIAAhCQgLgKgNAAQgSAAgKAMg");
	this.shape_24.setTransform(85.3,20.6);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgxBXIAAitIAWAAIAABJQAAAiAbAAQAKAAAHgFQAIgFACgHIAAhaIAXAAIAAB8IgXAAIAAgRQgEAJgJAFQgJAGgKAAQgNAAgJgFIAAAzg");
	this.shape_25.setTransform(71.7,23);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("Ag3BZIAAhmQAAgnAPgSQAPgRAZgBQAaABAPARQAPASAAAdQAAAcgPATQgPASgaAAQgVAAgMgKIAAA5gAgYg3QgIANAAAXIAAAhQALAJAQAAQASAAAKgMQAKgLAAgWQAAgWgJgMQgKgNgOAAQgPAAgJAOg");
	this.shape_26.setTransform(58.6,22.9);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgiA3QgNgKAAgQQAAgVAbgJQgKgDgHgHQgHgHABgJQAAgQALgLQAMgKAWAAQASAAAWAKIgIASQgTgKgPAAQgJAAgFAFQgHAEAAAJQAAAIAHAFQAHAFALAAIARgBIAAARIgSgBQgMAAgHAGQgHAGAAAKQAAAKAHAFQAHAFAMAAQASAAAQgNIALARQgWAOgZAAQgXAAgMgKg");
	this.shape_27.setTransform(46,20.6);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("Ag1BBQgTgZgBgpQAAgXAJgUQAIgUARgMQARgMAXAAQAUAAASAKQAQAKAKAVQAIAVABAZQgBApgUAZQgVAYggAAQgiAAgTgYgAgkgyQgNASABAfQgBAgANATQANASAXAAQAYAAANgRQAMgRAAgjQAAgfgMgSQgNgRgYAAQgXAAgNARgAghAIIAAgUIBDAAIAAAUg");
	this.shape_28.setTransform(32,18.3);

	this.instance = new lib.fasa();
	this.instance.parent = this;
	this.instance.setTransform(238.6,22.5,1,0.834,0,0,0,238.1,25.7);

	this.instance_1 = new lib.shadow("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(642.4,40.6,1,1.843,90,0,0,2.2,-347.2);
	this.instance_1.alpha = 0.43;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// magnetic-fields.svg
	this.curState_text = new cjs.Text("", "20px 'Roboto'", "#FFFFFF");
	this.curState_text.name = "curState_text";
	this.curState_text.lineHeight = 24;
	this.curState_text.lineWidth = 402;
	this.curState_text.parent = this;
	this.curState_text.setTransform(90.6,651.1);

	this.timeline.addTween(cjs.Tween.get(this.curState_text).wait(1));

	// Layer_1
	this.curMode = new cjs.Text("", "20px 'Roboto'", "#FFFFFF");
	this.curMode.name = "curMode";
	this.curMode.textAlign = "center";
	this.curMode.lineHeight = 24;
	this.curMode.lineWidth = 211;
	this.curMode.parent = this;
	this.curMode.setTransform(742.6,651.1);

	this.timeline.addTween(cjs.Tween.get(this.curMode).wait(1));

	// ssss
	this.waterContainer = new lib.sprite143();
	this.waterContainer.name = "waterContainer";
	this.waterContainer.parent = this;
	this.waterContainer.setTransform(540.7,487.4,1.06,1.06);

	this.timeline.addTween(cjs.Tween.get(this.waterContainer).wait(1));

	// Layer_4
	this.HCMachineC = new lib.sprite62copy5();
	this.HCMachineC.name = "HCMachineC";
	this.HCMachineC.parent = this;
	this.HCMachineC.setTransform(468,293.5,2.12,2.12);
	this.HCMachineC.visible = false;

	this.HCMachineH = new lib.sprite62copy2();
	this.HCMachineH.name = "HCMachineH";
	this.HCMachineH.parent = this;
	this.HCMachineH.setTransform(468,293.5,2.12,2.12);
	this.HCMachineH.visible = false;

	this.HCMachineI = new lib.sprite62copy3();
	this.HCMachineI.name = "HCMachineI";
	this.HCMachineI.parent = this;
	this.HCMachineI.setTransform(540.9,503.3,2.12,2.12);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.HCMachineI},{t:this.HCMachineH},{t:this.HCMachineC}]}).wait(1));

	// Layer_9
	this.cold_btn = new lib.button12copy();
	this.cold_btn.name = "cold_btn";
	this.cold_btn.parent = this;
	this.cold_btn.setTransform(275.1,500.3);
	new cjs.ButtonHelper(this.cold_btn, 0, 1, 2, false, new lib.button12copy(), 3);

	this.timeline.addTween(cjs.Tween.get(this.cold_btn).wait(1));

	// Layer_10
	this.hot_btn = new lib.button12();
	this.hot_btn.name = "hot_btn";
	this.hot_btn.parent = this;
	this.hot_btn.setTransform(818.3,500.4);
	new cjs.ButtonHelper(this.hot_btn, 0, 1, 2, false, new lib.button12(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hot_btn).wait(1));

	// Layer_11
	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#39454A").s().p("AgOA8QAKgNAAgNIAAgQIARAAIAAAOQAAAKgFAJQgFALgGAFgAgEgwQgDgDAAgFQAAgEADgEQADgDAFAAQAFAAADADQADAEAAAEQAAAFgDADQgDADgFAAQgFAAgDgDg");
	this.shape_29.setTransform(177.6,249.4);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#39454A").s().p("AAIBAIAGgKIABgIQAAgEgDgCQgDgDgHgCQgkgKgCgjIAAgJQAAgOAEgNQAGgMAJgHQAJgGAKAAQAPAAAKAKQAKAKAAATIgRAAQAAgMgEgGQgGgGgIgBQgJABgGAKQgGALAAARIAAAEQAAAZAYAJIAMAEQAHADAEAEQADAFAAAHQABAHgFAIQgFAJgFAFg");
	this.shape_30.setTransform(171,249.8);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#39454A").s().p("AgaAuQgKgIAAgPQAAgSAQgGQgHgDgEgGQgEgGAAgHQAAgPAKgIQAJgIAQAAQAPAAALAJQAKAJAAAOIgSAAQAAgHgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAHQAAAQASAAIAQAAIAAANIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJg");
	this.shape_31.setTransform(161.6,248);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#39454A").s().p("AgLBGQgEgHAAgOIAAhNIAQAAIAABPQAAALAJAAQAEAAACgBIAAAPQgFABgHAAQgJAAgGgHgAgNgrIAFghIAQAAIgKAhg");
	this.shape_32.setTransform(154.4,245.7);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#39454A").s().p("AgfAnQgLgPAAgYIAAgBQAAgXALgOQAKgPATAAIAtAAIAAAPIgWAAQAPAPAAAZIAAACQAAANgFAMQgFAMgJAGQgJAHgKAAQgTAAgKgPgAgTgcQgGAKAAASQAAASAGAKQAGALALAAQAJAAAGgKQAGgLAAgTQAAgRgGgKQgGgKgKAAQgKAAgGAKg");
	this.shape_33.setTransform(146.2,248.1);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_34.setTransform(136.3,248);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#39454A").s().p("AARA1IgegtIgIAAIAAAtIgRAAIAAhpIARAAIAAAtIAGAAIAfgtIAUAAIgkAzIAnA2g");
	this.shape_35.setTransform(126.5,248);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#39454A").s().p("AgLAuQgEgHAAgOIAAhNIAPAAIAABPQABALAIAAQAFAAACgBIAAAPQgFABgHAAQgJAAgGgHg");
	this.shape_36.setTransform(118.7,248.1);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#39454A").s().p("AgcA/QgLgOAAgaQAAgQAIgMQAHgMAMgEIAAAAQgIgEgEgHQgFgHAAgJQAAgNAJgIQAIgHAOAAQALAAALAFIAAAQQgFgDgGgBQgHgCgFAAQgFAAgEADQgDAEAAAGQAAALAQAHQASAHAIAOQAJAMAAATIAAAEQAAAXgLAOQgLAOgSAAQgRAAgLgOgAgPgDQgGAJAAAUQAAARAGAKQAGAKAJAAQALAAAGgKQAGgKAAgUQAAgNgHgKQgGgKgKgDQgJAAgGAKg");
	this.shape_37.setTransform(110.2,245.8);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_38.setTransform(100.6,248);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#39454A").s().p("AgKAuQgFgHgBgOIAAhNIAQAAIAABPQABALAIAAQAFAAADgBIAAAPQgGABgHAAQgJAAgFgHg");
	this.shape_39.setTransform(92.9,248.1);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#39454A").s().p("AgcA/QgLgOAAgaQAAgQAIgMQAHgMAMgEIAAAAQgIgEgEgHQgFgHAAgJQAAgNAJgIQAIgHAOAAQALAAALAFIAAAQQgFgDgGgBQgHgCgFAAQgFAAgEADQgDAEAAAGQAAALAQAHQASAHAIAOQAJAMAAATIAAAEQAAAXgLAOQgLAOgSAAQgRAAgLgOgAgPgDQgGAJAAAUQAAARAGAKQAGAKAJAAQALAAAGgKQAGgKAAgUQAAgNgHgKQgGgKgKgDQgJAAgGAKg");
	this.shape_40.setTransform(84.4,245.8);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#39454A").s().p("AAIBAIAGgKIABgIQAAgEgDgCQgDgDgHgCQgkgKgCgjIAAgJQAAgOAEgNQAGgMAJgHQAIgGALAAQAPAAALAKQAJAKAAATIgRAAQAAgMgEgGQgGgGgIgBQgJABgGAKQgGALAAARIAAAEQAAAZAYAJIAMAEQAIADADAEQAEAFgBAHQABAHgFAIQgFAJgFAFg");
	this.shape_41.setTransform(70.1,249.8);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#39454A").s().p("AgaBGQgKgIAAgPQAAgSAQgHQgHgDgEgGQgEgGAAgHQAAgOAKgIQAJgIAQAAQAPAAALAJQAKAJAAANIgSAAQAAgGgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAGQAAAQASAAIAQAAIAAAOIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJgAgGgtIAFghIAQAAIgLAhg");
	this.shape_42.setTransform(60.7,245.6);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#39454A").s().p("AgLAuQgEgHAAgOIAAhNIAPAAIAABPQABALAIAAQAFAAACgBIAAAPQgFABgHAAQgJAAgGgHg");
	this.shape_43.setTransform(53.5,248.1);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#39454A").s().p("AgcAqQgMgNAAgWIAAgLQAAgXALgNQALgOASAAQASAAALANQALANABAXIAAAKQAAAXgLANQgLAOgTAAQgRAAgLgNgAgQgeQgHAKAAAQIAAAJQAAAQAHAKQAGAJAKAAQAXAAAAghIAAgLQAAgQgGgKQgGgJgLAAQgKAAgGAJg");
	this.shape_44.setTransform(44.9,248);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#39454A").s().p("AATAuQgFgHAAgNIAAg/IgeAAIAABZIgRAAIAAhZIgNAAIAAgPIBZAAIAAAPIgMAAIAAA+QAAAHACADQACADAFAAQAFAAACgBIAAAPQgFABgHAAQgKAAgGgHg");
	this.shape_45.setTransform(34.7,248.1);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#39454A").s().p("AgaAuQgKgIAAgPQAAgSAQgGQgHgDgEgGQgEgGAAgHQAAgPAKgIQAJgIAQAAQAPAAALAJQAKAJAAAOIgSAAQAAgHgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAHQAAAQASAAIAQAAIAAANIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJg");
	this.shape_46.setTransform(349.6,224);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#39454A").s().p("AArBHIAAg4IABg2IglBuIgNAAIglhtIABA1IAAA4IgRAAIAAiNIAXAAIAkBzIAlhzIAXAAIAACNg");
	this.shape_47.setTransform(337.4,222.2);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#39454A").s().p("AgOA9QAKgNAAgOIAAgQIARAAIAAAOQAAAKgFAKQgFAJgGAGgAgEgwQgDgDAAgEQAAgGADgCQADgDAFgBQAFABADADQADACAAAGQAAAEgDADQgDADgFAAQgFAAgDgDg");
	this.shape_48.setTransform(323,225.4);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#39454A").s().p("AgcAqQgMgNAAgWIAAgLQAAgXALgNQALgOASAAQASAAALANQALANABAXIAAAKQAAAXgLANQgLAOgTAAQgRAAgLgNgAgQgeQgHAKAAAQIAAAJQAAAQAHAKQAGAJAKAAQAXAAAAghIAAgLQAAgQgGgKQgGgJgLAAQgKAAgGAJg");
	this.shape_49.setTransform(316.1,224);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#39454A").s().p("AgIAaIAAhAIgcAAIAAgPIBJAAIAAAPIgdAAIAAA/QAAANAHAAQAEAAAEgCIAEANQgHAFgJAAQgTAAAAgcg");
	this.shape_50.setTransform(306.5,224.1);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#39454A").s().p("AgaAuQgKgIAAgPQAAgSAQgGQgHgDgEgGQgEgGAAgHQAAgPAKgIQAJgIAQAAQAPAAALAJQAKAJAAAOIgSAAQAAgHgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAHQAAAQASAAIAQAAIAAANIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJg");
	this.shape_51.setTransform(297.2,224);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#39454A").s().p("AgbA5QgKgRAAgfIAAgSQAAgfAKgQQAKgQARAAQATAAAJAPQAKAQAAAeIAAATQAAAggKARQgKAQgSAAQgRAAgKgQgAgUAMQAAAVAFAMQAGANAJAAQAKAAAGgMQAFgMAAgWIAAgFIgpAAgAgPguQgFAMAAAWIAAAGIApAAIAAgGQAAgWgFgMQgGgMgKABQgJgBgGAMg");
	this.shape_52.setTransform(287.5,222.2);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#39454A").s().p("AgKBGQgGgHAAgOIAAhNIAQAAIAABPQABALAIAAQAFAAACgBIAAAPQgFABgHAAQgJAAgFgHgAgNgrIAFghIAQAAIgKAhg");
	this.shape_53.setTransform(280.1,221.7);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#39454A").s().p("AgIAaIAAhAIgcAAIAAgPIBJAAIAAAPIgdAAIAAA/QAAANAHAAQAEAAAEgCIAEANQgHAFgJAAQgTAAAAgcg");
	this.shape_54.setTransform(271.9,224.1);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#39454A").s().p("AgFA1IgghpIARAAIAUBOIAVhOIARAAIggBpg");
	this.shape_55.setTransform(263.1,224);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_56.setTransform(254.2,224);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#39454A").s().p("AgcAqQgMgNAAgWIAAgLQAAgXALgNQALgOASAAQASAAALANQALANABAXIAAAKQAAAXgLANQgLAOgTAAQgRAAgLgNgAgQgeQgHAKAAAQIAAAJQAAAQAHAKQAGAJAKAAQAXAAAAghIAAgLQAAgQgGgKQgGgJgLAAQgKAAgGAJg");
	this.shape_57.setTransform(239.3,224);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#39454A").s().p("AgIAaIAAhAIgcAAIAAgPIBJAAIAAAPIgdAAIAAA/QAAANAHAAQAEAAAEgCIAEANQgHAFgJAAQgTAAAAgcg");
	this.shape_58.setTransform(229.6,224.1);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#39454A").s().p("AgKAuQgFgHgBgOIAAhNIAQAAIAABPQABALAIAAQAFAAACgBIAAAPQgFABgHAAQgJAAgFgHg");
	this.shape_59.setTransform(218,224.1);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_60.setTransform(209.8,224);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#39454A").s().p("AARA1IgegtIgIAAIAAAtIgRAAIAAhpIARAAIAAAtIAGAAIAfgtIAUAAIgkAzIAnA2g");
	this.shape_61.setTransform(200.1,224);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#39454A").s().p("AAHBAIAHgKIABgIQAAgFgDgCQgDgCgGgBQglgKgCgkIAAgIQAAgPAFgMQAFgNAIgGQAJgHALAAQAPAAALAKQAJALAAARIgQAAQAAgLgGgGQgEgHgJAAQgJAAgGAMQgGAKAAASIAAACQAAAZAYAKIAMAEQAHACAEAFQADAFABAIQgBAGgEAIQgEAIgHAGg");
	this.shape_62.setTransform(185.4,225.8);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#39454A").s().p("AgLAuQgEgHAAgOIAAhNIAQAAIAABPQAAALAJAAQAEAAACgBIAAAPQgFABgHAAQgJAAgGgHg");
	this.shape_63.setTransform(178.2,224.1);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#39454A").s().p("AgaAuQgKgIAAgPQAAgSAQgGQgHgDgEgGQgEgGAAgHQAAgPAKgIQAJgIAQAAQAPAAALAJQAKAJAAAOIgSAAQAAgHgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAHQAAAQASAAIAQAAIAAANIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJg");
	this.shape_64.setTransform(170,224);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#39454A").s().p("AgFA1IgghpIARAAIAUBOIAVhOIARAAIggBpg");
	this.shape_65.setTransform(161,224);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#39454A").s().p("AARBAQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgaAJgPQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgEQgGAKAAAWQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgwQgGgPgMAAQgKAAgGALgAgFgtIAFghIAQAAIgLAhg");
	this.shape_66.setTransform(152.1,221.6);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#39454A").s().p("AARA1IgegtIgIAAIAAAtIgRAAIAAhpIARAAIAAAtIAGAAIAfgtIAUAAIgkAzIAnA2g");
	this.shape_67.setTransform(142.4,224);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_68.setTransform(127.8,224);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#39454A").s().p("AgFA1IgghpIARAAIAUBOIAVhOIARAAIggBpg");
	this.shape_69.setTransform(118.3,224);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#39454A").s().p("AAHBAIAHgKIABgIQAAgFgDgCQgDgCgGgBQglgKgCgkIAAgIQAAgPAFgMQAFgNAIgGQAKgHAKAAQAQAAAJAKQAKALAAARIgQAAQgBgLgFgGQgEgHgJAAQgJAAgGAMQgGAKAAASIAAACQAAAZAYAKIAMAEQAHACAEAFQADAFABAIQgBAGgEAIQgFAIgGAGg");
	this.shape_70.setTransform(104.7,225.8);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#39454A").s().p("AgLBGQgEgHgBgOIAAhNIAQAAIAABPQABALAIAAQAFAAACgBIAAAPQgFABgHAAQgJAAgGgHgAgNgrIAFghIAQAAIgKAhg");
	this.shape_71.setTransform(97.5,221.7);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#39454A").s().p("AgaAuQgKgIAAgPQAAgSAQgGQgHgDgEgGQgEgGAAgHQAAgPAKgIQAJgIAQAAQAPAAALAJQAKAJAAAOIgSAAQAAgHgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAHQAAAQASAAIAQAAIAAANIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJg");
	this.shape_72.setTransform(89.3,224);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#39454A").s().p("AglBKIAAhgQAAgPAFgMQAEgMAJgGQAJgGAKAAQARAAALAPQAKAPAAAcQAAAXgJANQgJAOgRABQgNAAgKgLIAAAxgAgOgvQgFAKgBARIAAAcQAGAMANAAQAKAAAGgJQAFgJABgTQgBgUgFgKQgGgMgJAAQgJAAgFAMg");
	this.shape_73.setTransform(79.8,226);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#39454A").s().p("AgcAqQgMgNAAgWIAAgLQAAgXALgNQALgOASAAQASAAALANQALANABAXIAAAKQAAAXgLANQgLAOgTAAQgRAAgLgNgAgQgeQgHAKAAAQIAAAJQAAAQAHAKQAGAJAKAAQAXAAAAghIAAgLQAAgQgGgKQgGgJgLAAQgKAAgGAJg");
	this.shape_74.setTransform(69.6,224);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#39454A").s().p("AATAuQgFgHAAgNIAAg/IgeAAIAABZIgRAAIAAhZIgNAAIAAgPIBZAAIAAAPIgMAAIAAA+QAAAHACADQACADAFAAQAFAAACgBIAAAPQgFABgHAAQgKAAgGgHg");
	this.shape_75.setTransform(59.4,224.1);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#39454A").s().p("AAqBHIAAg4IACg2IgmBuIgMAAIglhtIACA1IAAA4IgSAAIAAiNIAXAAIAkBzIAlhzIAXAAIAACNg");
	this.shape_76.setTransform(46.6,222.2);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#39454A").s().p("AgTAIIAAgPIAnAAIAAAPg");
	this.shape_77.setTransform(32,223.3);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#39454A").s().p("AgOA8QAKgMAAgOIAAgRIARAAIAAAPQAAAJgFALQgFAJgGAHgAgEgwQgDgDAAgFQAAgEADgEQADgCAFAAQAFAAADACQADAEAAAEQAAAFgDADQgDADgFAAQgFAAgDgDg");
	this.shape_78.setTransform(278.4,201.4);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#39454A").s().p("AAIA/IAGgJIABgIQAAgFgDgBQgDgDgHgCQgkgKgCgjIAAgIQAAgPAEgNQAGgMAJgGQAJgHAKAAQAPAAALAKQAJALAAARIgRAAQAAgLgEgGQgGgGgIAAQgJgBgGALQgGALAAARIAAADQAAAZAYAKIAMAEQAHADAEAEQADAFAAAHQABAHgFAIQgFAIgFAGg");
	this.shape_79.setTransform(271.8,201.8);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#39454A").s().p("AgaAuQgKgIAAgPQAAgSAQgGQgHgDgEgGQgEgGAAgHQAAgPAKgIQAJgIAQAAQAPAAALAJQAKAJAAAOIgSAAQAAgHgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAHQAAAQASAAIAQAAIAAANIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJg");
	this.shape_80.setTransform(262.4,200);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#39454A").s().p("AgLBGQgEgHAAgOIAAhNIAQAAIAABPQAAALAJAAQAEAAACgBIAAAPQgFABgHAAQgJAAgGgHgAgNgrIAFghIAQAAIgKAhg");
	this.shape_81.setTransform(255.2,197.7);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#39454A").s().p("AgfAnQgLgPAAgYIAAgBQAAgXALgOQAKgPATAAIAtAAIAAAPIgWAAQAPAPAAAZIAAACQAAANgFAMQgFAMgJAGQgJAHgKAAQgTAAgKgPgAgTgcQgGAKAAASQAAASAGAKQAGALALAAQAJAAAGgKQAGgLAAgTQAAgRgGgKQgGgKgKAAQgKAAgGAKg");
	this.shape_82.setTransform(247,200.1);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_83.setTransform(237.1,200);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#39454A").s().p("AARA1IgegtIgIAAIAAAtIgRAAIAAhpIARAAIAAAtIAGAAIAfgtIAUAAIgkAzIAnA2g");
	this.shape_84.setTransform(227.3,200);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#39454A").s().p("AgLAuQgEgHAAgOIAAhNIAPAAIAABPQABALAIAAQAFAAACgBIAAAPQgFABgHAAQgJAAgGgHg");
	this.shape_85.setTransform(219.5,200.1);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#39454A").s().p("AgcA/QgLgOAAgaQAAgQAIgMQAHgMAMgEIAAAAQgIgEgEgHQgFgHAAgJQAAgNAJgIQAIgHAOAAQALAAALAFIAAAQQgFgDgGgBQgHgCgFAAQgFAAgEADQgDAEAAAGQAAALAQAHQASAHAIAOQAJAMAAATIAAAEQAAAXgLAOQgLAOgSAAQgRAAgLgOgAgPgDQgGAJAAAUQAAARAGAKQAGAKAJAAQALAAAGgKQAGgKAAgUQAAgNgHgKQgGgKgKgDQgJAAgGAKg");
	this.shape_86.setTransform(211,197.8);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_87.setTransform(201.4,200);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#39454A").s().p("AgKAuQgFgHgBgOIAAhNIAQAAIAABPQABALAIAAQAFAAADgBIAAAPQgGABgHAAQgJAAgFgHg");
	this.shape_88.setTransform(193.7,200.1);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#39454A").s().p("AgcA/QgLgOAAgaQAAgQAIgMQAHgMAMgEIAAAAQgIgEgEgHQgFgHAAgJQAAgNAJgIQAIgHAOAAQALAAALAFIAAAQQgFgDgGgBQgHgCgFAAQgFAAgEADQgDAEAAAGQAAALAQAHQASAHAIAOQAJAMAAATIAAAEQAAAXgLAOQgLAOgSAAQgRAAgLgOgAgPgDQgGAJAAAUQAAARAGAKQAGAKAJAAQALAAAGgKQAGgKAAgUQAAgNgHgKQgGgKgKgDQgJAAgGAKg");
	this.shape_89.setTransform(185.2,197.8);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#39454A").s().p("AAIA/IAGgJIABgIQAAgFgDgBQgDgDgHgCQgkgKgCgjIAAgIQAAgPAEgNQAGgMAJgGQAIgHALAAQAPAAALAKQAJALAAARIgRAAQAAgLgEgGQgGgGgIAAQgJgBgGALQgGALAAARIAAADQAAAZAYAKIAMAEQAIADADAEQAEAFgBAHQABAHgFAIQgFAIgFAGg");
	this.shape_90.setTransform(170.9,201.8);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#39454A").s().p("AgaBGQgKgIAAgPQAAgSAQgHQgHgDgEgGQgEgGAAgHQAAgOAKgIQAJgIAQAAQAPAAALAJQAKAJAAANIgSAAQAAgGgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAGQAAAQASAAIAQAAIAAAOIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJgAgGgtIAFghIAQAAIgLAhg");
	this.shape_91.setTransform(161.5,197.6);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#39454A").s().p("AgLAuQgEgHAAgOIAAhNIAPAAIAABPQABALAIAAQAFAAACgBIAAAPQgFABgHAAQgJAAgGgHg");
	this.shape_92.setTransform(154.3,200.1);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#39454A").s().p("AgcAqQgMgNAAgWIAAgLQAAgXALgNQALgOASAAQASAAALANQALANABAXIAAAKQAAAXgLANQgLAOgTAAQgRAAgLgNgAgQgeQgHAKAAAQIAAAJQAAAQAHAKQAGAJAKAAQAXAAAAghIAAgLQAAgQgGgKQgGgJgLAAQgKAAgGAJg");
	this.shape_93.setTransform(145.7,200);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#39454A").s().p("AATAuQgFgHAAgNIAAg/IgeAAIAABZIgRAAIAAhZIgNAAIAAgPIBZAAIAAAPIgMAAIAAA+QAAAHACADQACADAFAAQAFAAACgBIAAAPQgFABgHAAQgKAAgGgHg");
	this.shape_94.setTransform(135.5,200.1);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#39454A").s().p("AgaAuQgKgIAAgPQAAgSAQgGQgHgDgEgGQgEgGAAgHQAAgPAKgIQAJgIAQAAQAPAAALAJQAKAJAAAOIgSAAQAAgHgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAHQAAAQASAAIAQAAIAAANIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJg");
	this.shape_95.setTransform(121,200);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#39454A").s().p("AArBHIAAg4IABg2IglBuIgNAAIglhuIABA2IAAA4IgRAAIAAiNIAXAAIAkBzIAlhzIAXAAIAACNg");
	this.shape_96.setTransform(108.8,198.2);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#39454A").s().p("AgOA8QAKgMAAgOIAAgRIARAAIAAAPQAAAJgFALQgFAJgGAHgAgEgwQgDgDAAgFQAAgEADgEQADgCAFAAQAFAAADACQADAEAAAEQAAAFgDADQgDADgFAAQgFAAgDgDg");
	this.shape_97.setTransform(94.4,201.4);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#39454A").s().p("AgcBCQgMgNAAgWIAAgMQAAgWALgNQALgOASAAQASAAALANQALANABAWIAAALQAAAXgLANQgLAOgTAAQgRAAgLgNgAgQgGQgHAJAAAQIAAAKQAAAQAHAKQAGAJAKAAQAXAAAAghIAAgMQAAgQgGgJQgGgJgLAAQgKAAgGAJgAgHgtIAGghIAPAAIgLAhg");
	this.shape_98.setTransform(87.5,197.6);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#39454A").s().p("AgjBJIAAiRIARAAIAAA+QAAAPAFAIQAEAHAIAAQAOAAAFgOIAAhOIARAAIAABoIgPAAIgBgJQgHALgMAAQgLABgHgHIAAAtg");
	this.shape_99.setTransform(77.6,202.1);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#39454A").s().p("AgIAaIAAhAIgcAAIAAgPIBJAAIAAAPIgdAAIAAA/QAAANAHAAQAEAAAEgCIAEANQgHAFgJAAQgTAAAAgcg");
	this.shape_100.setTransform(67.9,200.1);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_101.setTransform(58.7,200);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#39454A").s().p("AgaAuQgKgIAAgPQAAgSAQgGQgHgDgEgGQgEgGAAgHQAAgPAKgIQAJgIAQAAQAPAAALAJQAKAJAAAOIgSAAQAAgHgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAHQAAAQASAAIAQAAIAAANIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJg");
	this.shape_102.setTransform(44.2,200);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#39454A").s().p("AgfAnQgLgPAAgYIAAgBQAAgXALgOQAKgPATAAIAtAAIAAAPIgWAAQAPAPAAAZIAAACQAAANgFAMQgFAMgJAGQgJAHgKAAQgTAAgKgPgAgTgcQgGAKAAASQAAASAGAKQAGALALAAQAJAAAGgKQAGgLAAgTQAAgRgGgKQgGgKgKAAQgKAAgGAKg");
	this.shape_103.setTransform(34.8,200.1);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#39454A").s().p("AgcAqQgMgNAAgWIAAgLQAAgXALgNQALgOASAAQASAAALANQALANABAXIAAAKQAAAXgLANQgLAOgTAAQgRAAgLgNgAgQgeQgHAKAAAQIAAAJQAAAQAHAKQAGAJAKAAQAXAAAAghIAAgLQAAgQgGgKQgGgJgLAAQgKAAgGAJg");
	this.shape_104.setTransform(347.9,176);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#39454A").s().p("AgHBJIAAgwIgfhhIARAAIAWBKIAUhKIASAAIgeBiIAAAvg");
	this.shape_105.setTransform(338.5,178.1);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#39454A").s().p("AARBAQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgaAJgPQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgEQgGAKAAAWQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgwQgGgPgMAAQgKAAgGALgAgFgtIAFghIAQAAIgLAhg");
	this.shape_106.setTransform(329.4,173.6);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#39454A").s().p("AATAuQgFgHAAgNIAAg/IgeAAIAABZIgRAAIAAhZIgNAAIAAgPIBZAAIAAAPIgMAAIAAA+QAAAHACADQACADAFAAQAFAAACgBIAAAPQgFABgHAAQgKAAgGgHg");
	this.shape_107.setTransform(318.9,176.1);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#39454A").s().p("AgGA1IgfhpIASAAIATBOIAUhOIASAAIgfBpg");
	this.shape_108.setTransform(304.8,176);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#39454A").s().p("AgcAqQgMgNAAgWIAAgLQAAgXALgNQALgOASAAQASAAALANQALANABAXIAAAKQAAAXgLANQgLAOgTAAQgRAAgLgNgAgQgeQgHAKAAAQIAAAJQAAAQAHAKQAGAJAKAAQAXAAAAghIAAgLQAAgQgGgKQgGgJgLAAQgKAAgGAJg");
	this.shape_109.setTransform(295.5,176);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#39454A").s().p("AgIAaIAAhAIgcAAIAAgPIBJAAIAAAPIgdAAIAAA/QAAANAHAAQAEAAAEgCIAEANQgHAFgJAAQgTAAAAgcg");
	this.shape_110.setTransform(285.9,176.1);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#39454A").s().p("AAHBAIAHgKIABgIQAAgEgDgCQgDgDgHgCQgkgKgCgjIAAgJQAAgOAFgNQAEgMAJgHQAKgGAKAAQAPAAAKAKQAKAKAAATIgRAAQAAgMgEgGQgGgGgIgBQgJABgGAKQgGALAAARIAAAEQAAAZAYAJIAMAEQAIADADAEQAEAFAAAHQAAAHgFAIQgFAJgFAFg");
	this.shape_111.setTransform(272,177.8);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#39454A").s().p("AgKAuQgFgHgBgOIAAhNIAQAAIAABPQABALAIAAQAFAAACgBIAAAPQgFABgHAAQgJAAgFgHg");
	this.shape_112.setTransform(264.8,176.1);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#39454A").s().p("AgaAuQgKgIAAgPQAAgSAQgGQgHgDgEgGQgEgGAAgHQAAgPAKgIQAJgIAQAAQAPAAALAJQAKAJAAAOIgSAAQAAgHgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAHQAAAQASAAIAQAAIAAANIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJg");
	this.shape_113.setTransform(256.6,176);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#39454A").s().p("AgJBMIAAgtQgVgDgLgPQgLgOAAgaIAAgwIASAAIAAAvQAAAmAZAGIAAhbIAQAAIAABbQANgCAIgMQAHgKAAgRQAAgWgKgcIASAAQAKAXAAAbQAAAZgMAOQgMAPgWACIAAAtg");
	this.shape_114.setTransform(245.8,178.3);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#39454A").s().p("AgaBGQgKgIAAgPQAAgSAQgHQgHgDgEgGQgEgGAAgHQAAgOAKgIQAJgIAQAAQAPAAALAJQAKAJAAANIgSAAQAAgGgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAGQAAAQASAAIAQAAIAAAOIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJgAgGgtIAFghIAQAAIgLAhg");
	this.shape_115.setTransform(234.9,173.6);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#39454A").s().p("AglBKIAAhgQAAgPAEgMQAGgMAIgGQAJgGAKAAQASAAAJAPQALAPAAAcQAAAXgJANQgJAPgRAAQgOAAgIgLIAAAxgAgPgwQgEALAAAQIAAAdQAFANAOAAQAJAAAGgKQAGgJgBgSQABgVgGgLQgFgKgKgBQgJABgGAKg");
	this.shape_116.setTransform(225.4,178);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#39454A").s().p("AgIAaIAAhAIgcAAIAAgPIBJAAIAAAPIgdAAIAAA/QAAANAHAAQAEAAAEgCIAEANQgHAFgJAAQgTAAAAgcg");
	this.shape_117.setTransform(215.6,176.1);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_118.setTransform(206.4,176);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#39454A").s().p("AgIAaIAAhAIgcAAIAAgPIBJAAIAAAPIgdAAIAAA/QAAANAHAAQAEAAAEgCIAEANQgHAFgJAAQgTAAAAgcg");
	this.shape_119.setTransform(196.5,176.1);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#39454A").s().p("AgaAuQgKgIAAgPQAAgSAQgGQgHgDgEgGQgEgGAAgHQAAgPAKgIQAJgIAQAAQAPAAALAJQAKAJAAAOIgSAAQAAgHgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAHQAAAQASAAIAQAAIAAANIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJg");
	this.shape_120.setTransform(187.3,176);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#39454A").s().p("AgiBJIAAiRIARAAIAAA/QAAAOADAHQAFAIAIAAQAOAAAFgNIAAhPIASAAIAABoIgQAAIgBgKQgHANgMAAQgMAAgFgHIAAAtg");
	this.shape_121.setTransform(177.6,178.1);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_122.setTransform(163.4,176);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#39454A").s().p("AgFA1IgghpIARAAIAUBOIAVhOIARAAIggBpg");
	this.shape_123.setTransform(153.8,176);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#39454A").s().p("AAHBAIAHgKIABgIQAAgEgDgCQgDgDgGgCQglgKgCgjIAAgJQAAgOAFgNQAFgMAIgHQAKgGAKAAQAQAAAJAKQAKAKAAATIgQAAQgBgMgEgGQgFgGgJgBQgJABgGAKQgGALAAARIAAAEQAAAZAYAJIAMAEQAHADAEAEQADAFABAHQgBAHgEAIQgFAJgGAFg");
	this.shape_124.setTransform(140.2,177.8);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#39454A").s().p("AgLBGQgEgHgBgOIAAhNIAQAAIAABPQABALAIAAQAFAAACgBIAAAPQgFABgHAAQgJAAgGgHgAgNgrIAFghIAQAAIgKAhg");
	this.shape_125.setTransform(133,173.7);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#39454A").s().p("AgaAuQgKgIAAgPQAAgSAQgGQgHgDgEgGQgEgGAAgHQAAgPAKgIQAJgIAQAAQAPAAALAJQAKAJAAAOIgSAAQAAgHgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAHQAAAQASAAIAQAAIAAANIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJg");
	this.shape_126.setTransform(124.8,176);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#39454A").s().p("AglBKIAAhgQAAgPAFgMQAEgMAJgGQAJgGAKAAQARAAALAPQAKAPAAAcQAAAXgJANQgJAPgQAAQgOAAgKgLIAAAxgAgOgwQgFALgBAQIAAAdQAGANANAAQAKAAAGgKQAFgJABgSQgBgVgFgLQgGgKgJgBQgJABgFAKg");
	this.shape_127.setTransform(115.3,178);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#39454A").s().p("AgcAqQgMgNAAgWIAAgLQAAgXALgNQALgOASAAQASAAALANQALANABAXIAAAKQAAAXgLANQgLAOgTAAQgRAAgLgNgAgQgeQgHAKAAAQIAAAJQAAAQAHAKQAGAJAKAAQAXAAAAghIAAgLQAAgQgGgKQgGgJgLAAQgKAAgGAJg");
	this.shape_128.setTransform(105.1,176);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#39454A").s().p("AATAuQgFgHAAgNIAAg/IgeAAIAABZIgRAAIAAhZIgNAAIAAgPIBZAAIAAAPIgMAAIAAA+QAAAHACADQACADAFAAQAFAAACgBIAAAPQgFABgHAAQgKAAgGgHg");
	this.shape_129.setTransform(94.9,176.1);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#39454A").s().p("AgjBJIAAiRIARAAIAAA/QAAAOAFAHQAEAIAIAAQAOAAAFgNIAAhPIARAAIAABoIgPAAIgBgKQgHANgMAAQgLAAgHgHIAAAtg");
	this.shape_130.setTransform(84.8,178.1);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#39454A").s().p("AAIBAIAGgKIABgIQAAgEgDgCQgDgDgGgCQglgKgCgjIAAgJQAAgOAEgNQAFgMAKgHQAJgGAKAAQAQAAAKAKQAJAKAAATIgRAAQABgMgGgGQgEgGgJgBQgJABgGAKQgGALAAARIAAAEQAAAZAYAJIAMAEQAIADADAEQAEAFgBAHQABAHgFAIQgEAJgGAFg");
	this.shape_131.setTransform(70.4,177.8);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#39454A").s().p("AAAAfQgGAXgUAAQgPAAgJgPQgJgOAAgbQAAgcAMgXIASAAQgMAbgBAYQAAATAFALQAFALAHAAQAIAAAFgIQAEgIAAgQIAAgdIAQAAIAAAdQABAQAEAIQAEAIAJAAQAHAAAFgLQAEgLAAgTQgBgYgLgbIASAAQAMAXAAAcQAAAbgJAOQgJAPgPAAQgUAAgHgXg");
	this.shape_132.setTransform(58.6,176.1);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#39454A").s().p("AAcBHIAAh+Ig3AAIAAB+IgSAAIAAiNIBbAAIAACNg");
	this.shape_133.setTransform(45.2,174.2);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#39454A").s().p("AgTAIIAAgOIAnAAIAAAOg");
	this.shape_134.setTransform(32,175.3);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#39454A").s().p("AgHAIQgDgDAAgFQAAgDADgEQACgDAFAAQAGAAACADQADAEAAADQAAAFgDADQgCADgGAAQgFAAgCgDg");
	this.shape_135.setTransform(276.7,156.3);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#39454A").s().p("AAIBAIAGgKIABgIQAAgFgDgCQgDgCgHgBQgkgKgCgkIAAgIQAAgPAEgMQAGgNAJgGQAIgHALAAQAPAAALAKQAJALAAARIgRAAQAAgLgEgGQgGgHgIAAQgJAAgGAMQgGAKAAASIAAACQAAAZAYAKIAMAEQAIACADAFQAEAFgBAIQABAGgFAIQgFAIgFAGg");
	this.shape_136.setTransform(269.4,153.8);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#39454A").s().p("AATBKIAAhrQAAgOgEgFQgFgHgKAAQgMAAgFAPIAABOIgSAAIAAhpIAQAAIABAMQAKgOAOAAQAQAAAGAKQAIAJAAATIAABtg");
	this.shape_137.setTransform(259.7,154);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#39454A").s().p("AAKBTQAGgHABgDQACgEAAgEQAAgEgDgCQgDgCgKgDQgJgDgGgDQgWgKAAgdQAAgOAHgJQAHgKAMgEQgJgFgGgHQgGgHAAgKQAAgPALgJQALgJASAAQANAAAIADIgDAPQgKgEgIAAQgLAAgFAGQgGAFAAAIQAAAVAZAAIALAAIAAAPIgMAAQgOAAgIAIQgHAHAAAPQAAALAFAIQAFAIAJADIAIACQAMADAEADQAEACACAEQACAEAAAGQAAAGgEAIQgFAIgGAGg");
	this.shape_138.setTransform(250.6,152);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#39454A").s().p("AgbBDQgJgLAAgVIAAhAIARAAIAAA+QAAAeAQAAQAJAAAHgMQAGgNAAgRQAAgVgKgdIASAAQAKAXgBAbQAAAagLAPQgKAQgSAAQgQAAgIgLgAgJgsIAGghIAQAAIgMAhg");
	this.shape_139.setTransform(241.6,149.7);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#39454A").s().p("AgJBMIAAgtQgVgDgLgPQgLgOAAgaIAAgwIASAAIAAAvQAAAmAZAGIAAhbIAQAAIAABbQANgCAIgMQAHgKAAgRQAAgWgKgcIASAAQAKAXAAAbQAAAZgMAOQgMAPgWACIAAAtg");
	this.shape_140.setTransform(230.5,154.3);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#39454A").s().p("AgKAuQgGgHABgOIAAhNIAQAAIAABPQAAALAJAAQAEAAADgBIAAAPQgGABgHAAQgJAAgFgHg");
	this.shape_141.setTransform(217.2,152.1);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_142.setTransform(209.1,152);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#39454A").s().p("AARA1IgegtIgIAAIAAAtIgRAAIAAhpIARAAIAAAtIAGAAIAfgtIAUAAIgkAzIAnA2g");
	this.shape_143.setTransform(199.3,152);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#39454A").s().p("AAHBAIAHgKIABgIQAAgFgDgCQgDgCgHgBQgkgKgCgkIAAgIQAAgPAFgMQAEgNAJgGQAKgHAKAAQAPAAAKAKQAKALAAARIgRAAQAAgLgEgGQgFgHgJAAQgJAAgGAMQgGAKAAASIAAACQAAAZAYAKIAMAEQAIACADAFQAEAFAAAIQAAAGgFAIQgFAIgFAGg");
	this.shape_144.setTransform(184.7,153.8);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#39454A").s().p("AATBKIAAhrQAAgOgFgFQgDgHgLAAQgLAAgHAPIAABOIgRAAIAAhpIAPAAIABAMQAKgOAPAAQAPAAAIAKQAHAJAAATIAABtg");
	this.shape_145.setTransform(175,154);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#39454A").s().p("AgfAnQgLgPAAgYIAAgBQAAgXALgOQAKgPATAAIAtAAIAAAPIgWAAQAPAPAAAZIAAACQAAANgFAMQgFAMgJAGQgJAHgKAAQgTAAgKgPgAgTgcQgGAKAAASQAAASAGAKQAGALALAAQAJAAAGgKQAGgLAAgTQAAgRgGgKQgGgKgKAAQgKAAgGAKg");
	this.shape_146.setTransform(165.4,152.1);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#39454A").s().p("AgGA1IgfhpIASAAIATBOIAUhOIASAAIgfBpg");
	this.shape_147.setTransform(155.8,152);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_148.setTransform(146.9,152);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#39454A").s().p("AgiBJIAAiRIARAAIAAA+QAAAPADAIQAFAHAIAAQAOAAAFgNIAAhPIASAAIAABpIgQAAIgBgKQgHAMgMgBQgMAAgFgGIAAAtg");
	this.shape_149.setTransform(136.7,154.1);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#39454A").s().p("AglBKIAAhgQAAgPAEgMQAGgMAIgGQAJgGAKAAQASAAAJAPQALAPAAAcQAAAXgJANQgJAOgRABQgOAAgIgLIAAAxgAgPgvQgEAKAAARIAAAcQAFAMAOAAQAJAAAGgJQAGgJgBgTQABgUgGgKQgFgMgKAAQgJAAgGAMg");
	this.shape_150.setTransform(126.9,154);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#39454A").s().p("AgaBGQgKgIAAgPQAAgSAQgHQgHgDgEgGQgEgGAAgHQAAgOAKgIQAJgIAQAAQAPAAALAJQAKAJAAANIgSAAQAAgGgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAGQAAAQASAAIAQAAIAAAOIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJgAgGgtIAFghIAQAAIgLAhg");
	this.shape_151.setTransform(117,149.6);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#39454A").s().p("AgbA5QgKgRAAgfIAAgSQAAgfAKgQQAKgQARAAQATAAAJAPQAKAQAAAeIAAATQAAAggJARQgKAQgTAAQgRAAgKgQgAgUAMQAAAVAGAMQAFANAJAAQAKAAAFgMQAGgMAAgWIAAgFIgpAAgAgOguQgGAMAAAWIAAAGIApAAIAAgGQAAgWgGgMQgFgMgKABQgJgBgFAMg");
	this.shape_152.setTransform(107.3,150.2);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#39454A").s().p("AATBiIAAhrQAAgOgEgFQgFgHgKAAQgMAAgFAPIAABOIgSAAIAAhpIAQAAIABAMQAKgOAOAAQAQAAAGAKQAIAJAAATIAABtgAgGhBIAGggIAQAAIgMAgg");
	this.shape_153.setTransform(92.8,151.6);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#39454A").s().p("AgbArQgIgLAAgVIAAhAIARAAIAAA+QAAAeAPAAQAJAAAGgMQAHgNAAgQQAAgWgKgdIASAAQAJAXAAAcQABAZgLAPQgLAQgRAAQgRAAgIgLg");
	this.shape_154.setTransform(83.2,152.1);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#39454A").s().p("AgaAuQgKgIAAgPQAAgSAQgGQgHgDgEgGQgEgGAAgHQAAgPAKgIQAJgIAQAAQAPAAALAJQAKAJAAAOIgSAAQAAgHgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAHQAAAQASAAIAQAAIAAANIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJg");
	this.shape_155.setTransform(73.5,152);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#39454A").s().p("AARA1IgegtIgIAAIAAAtIgRAAIAAhpIARAAIAAAtIAGAAIAfgtIAUAAIgkAzIAnA2g");
	this.shape_156.setTransform(64.3,152);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#39454A").s().p("AgfAnQgLgPAAgYIAAgBQAAgXALgOQAKgPATAAIAtAAIAAAPIgWAAQAPAPAAAZIAAACQAAANgFAMQgFAMgJAGQgJAHgKAAQgTAAgKgPgAgTgcQgGAKAAASQAAASAGAKQAGALALAAQAJAAAGgKQAGgLAAgTQAAgRgGgKQgGgKgKAAQgKAAgGAKg");
	this.shape_157.setTransform(54.4,152.1);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#39454A").s().p("AgbArQgJgLAAgVIAAhAIARAAIAAA+QAAAeAQAAQAJAAAHgMQAGgNAAgQQAAgWgKgdIASAAQAKAXgBAcQAAAZgLAPQgKAQgSAAQgQAAgIgLg");
	this.shape_158.setTransform(44.5,152.1);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#39454A").s().p("AgfAnQgLgPAAgYIAAgBQAAgXALgOQAKgPATAAIAtAAIAAAPIgWAAQAPAPAAAZIAAACQAAANgFAMQgFAMgJAGQgJAHgKAAQgTAAgKgPgAgTgcQgGAKAAASQAAASAGAKQAGALALAAQAJAAAGgKQAGgLAAgTQAAgRgGgKQgGgKgKAAQgKAAgGAKg");
	this.shape_159.setTransform(34.8,152.1);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_160.setTransform(354.4,128);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#39454A").s().p("AgLAuQgEgHAAgOIAAhNIAQAAIAABPQAAALAJAAQAEAAACgBIAAAPQgFABgHAAQgJAAgGgHg");
	this.shape_161.setTransform(346.6,128.1);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#39454A").s().p("AgiBJIAAiRIARAAIAAA+QAAAPADAIQAEAHAJAAQAOAAAFgOIAAhOIASAAIAABoIgQAAIgBgJQgHALgMAAQgMABgFgHIAAAtg");
	this.shape_162.setTransform(338.2,130.1);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#39454A").s().p("AAHA/IAHgJIABgIQAAgFgDgBQgDgDgGgCQglgKgCgjIAAgIQAAgPAFgNQAFgMAIgGQAJgHALAAQAQAAAJAKQAKALAAARIgQAAQgBgLgEgGQgFgGgJAAQgJgBgGALQgGALAAARIAAADQAAAZAYAKIAMAEQAHADAEAEQADAFABAHQgBAHgEAIQgFAIgGAGg");
	this.shape_163.setTransform(323.8,129.8);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#39454A").s().p("AATBKIAAhrQAAgOgFgFQgEgGgJAAQgMgBgHAPIAABNIgRAAIAAhoIAPAAIABAMQAKgOAPAAQAPAAAIAJQAHAKAAATIAABtg");
	this.shape_164.setTransform(314.1,130);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#39454A").s().p("AgfAnQgLgPAAgYIAAgBQAAgXALgOQAKgPATAAIAtAAIAAAPIgWAAQAPAPAAAZIAAACQAAANgFAMQgFAMgJAGQgJAHgKAAQgTAAgKgPgAgTgcQgGAKAAASQAAASAGAKQAGALALAAQAJAAAGgKQAGgLAAgTQAAgRgGgKQgGgKgKAAQgKAAgGAKg");
	this.shape_165.setTransform(304.5,128.1);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#39454A").s().p("AgKBGQgFgHgBgOIAAhNIAQAAIAABPQABALAIAAQAFAAADgBIAAAPQgGABgHAAQgJAAgFgHgAgNgrIAFghIAQAAIgKAhg");
	this.shape_166.setTransform(296.7,125.7);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#39454A").s().p("AATAuQgFgHAAgNIAAg/IgeAAIAABZIgRAAIAAhZIgNAAIAAgPIBZAAIAAAPIgMAAIAAA+QAAAHACADQACADAFAAQAFAAACgBIAAAPQgFABgHAAQgKAAgGgHg");
	this.shape_167.setTransform(288,128.1);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f("#39454A").s().p("AglBHIAAiNIBKAAIAAAPIg5AAIAAAuIAyAAIAAAOIgyAAIAAAzIA6AAIAAAPg");
	this.shape_168.setTransform(278.2,126.2);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#39454A").s().p("AgHAIQgDgDAAgFQAAgDADgEQACgDAFAAQAGAAACADQADAEAAADQAAAFgDADQgCADgGAAQgFAAgCgDg");
	this.shape_169.setTransform(265.6,132.3);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f("#39454A").s().p("AgbArQgJgLAAgVIAAhAIARAAIAAA+QAAAeAQAAQAJAAAHgMQAGgNAAgQQAAgWgKgdIASAAQAJAXAAAcQABAZgMAPQgKAQgRAAQgRAAgIgLg");
	this.shape_170.setTransform(258.5,128.1);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("#39454A").s().p("AgcAqQgMgNAAgWIAAgLQAAgXALgNQALgOASAAQASAAALANQALANABAXIAAAKQAAAXgLANQgLAOgTAAQgRAAgLgNgAgQgeQgHAKAAAQIAAAJQAAAQAHAKQAGAJAKAAQAXAAAAghIAAgLQAAgQgGgKQgGgJgLAAQgKAAgGAJg");
	this.shape_171.setTransform(248.4,128);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f("#39454A").s().p("AgIBJIAAgwIgehhIASAAIAUBKIAVhKIASAAIgfBiIAAAvg");
	this.shape_172.setTransform(239,130.1);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("#39454A").s().p("AARBAQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgaAJgPQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgEQgGAKAAAWQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgwQgGgPgMAAQgKAAgGALgAgFgtIAFghIAQAAIgLAhg");
	this.shape_173.setTransform(229.9,125.6);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f("#39454A").s().p("AATAuQgFgHAAgNIAAg/IgeAAIAABZIgRAAIAAhZIgNAAIAAgPIBZAAIAAAPIgMAAIAAA+QAAAHACADQACADAFAAQAFAAACgBIAAAPQgFABgHAAQgKAAgGgHg");
	this.shape_174.setTransform(219.4,128.1);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f("#39454A").s().p("AgLAuQgEgHAAgOIAAhNIAQAAIAABPQAAALAJAAQAEAAACgBIAAAPQgFABgHAAQgJAAgGgHg");
	this.shape_175.setTransform(207.1,128.1);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f("#39454A").s().p("AgIAaIAAhAIgcAAIAAgPIBJAAIAAAPIgdAAIAAA/QAAANAHAAQAEAAAEgCIAEANQgHAFgJAAQgTAAAAgcg");
	this.shape_176.setTransform(199,128.1);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_177.setTransform(189.8,128);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f("#39454A").s().p("AgiBJIAAiRIAQAAIAAA+QABAPAEAIQADAHAJAAQAOAAAFgOIAAhOIARAAIAABoIgPAAIgBgJQgHALgMAAQgLABgHgHIAAAtg");
	this.shape_178.setTransform(179.6,130.1);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f("#39454A").s().p("AgiBJIAAiRIARAAIAAA+QAAAPADAIQAFAHAIAAQANAAAGgOIAAhOIASAAIAABoIgQAAIgBgJQgHALgMAAQgMABgFgHIAAAtg");
	this.shape_179.setTransform(169.6,130.1);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f("#39454A").s().p("AgcAqQgMgNAAgWIAAgLQAAgXALgNQALgOASAAQASAAALANQALANABAXIAAAKQAAAXgLANQgLAOgTAAQgRAAgLgNgAgQgeQgHAKAAAQIAAAJQAAAQAHAKQAGAJAKAAQAXAAAAghIAAgLQAAgQgGgKQgGgJgLAAQgKAAgGAJg");
	this.shape_180.setTransform(159.6,128);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f("#39454A").s().p("AARA1IgegtIgIAAIAAAtIgRAAIAAhpIARAAIAAAtIAGAAIAfgtIAUAAIgkAzIAnA2g");
	this.shape_181.setTransform(150.1,128);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_182.setTransform(135.5,128);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f("#39454A").s().p("AgGA1IgfhpIASAAIATBOIAUhOIASAAIgfBpg");
	this.shape_183.setTransform(126,128);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f("#39454A").s().p("AgaBGQgKgIAAgPQAAgSAQgHQgHgDgEgGQgEgGAAgHQAAgOAKgIQAJgIAQAAQAPAAALAJQAKAJAAANIgSAAQAAgGgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAGQAAAQASAAIAQAAIAAAOIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJgAgGgtIAFghIAQAAIgLAhg");
	this.shape_184.setTransform(117,125.6);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f("#39454A").s().p("AgaAuQgKgIAAgPQAAgSAQgGQgHgDgEgGQgEgGAAgHQAAgPAKgIQAJgIAQAAQAPAAALAJQAKAJAAAOIgSAAQAAgHgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAHQAAAQASAAIAQAAIAAANIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJg");
	this.shape_185.setTransform(103,128);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f("#39454A").s().p("AgiBJIAAiRIARAAIAAA+QAAAPADAIQAEAHAJAAQAOAAAFgOIAAhOIASAAIAABoIgQAAIgBgJQgHALgMAAQgMABgFgHIAAAtg");
	this.shape_186.setTransform(93.4,130.1);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f("#39454A").s().p("AgcAqQgMgNAAgWIAAgLQAAgXALgNQALgOASAAQASAAALANQALANABAXIAAAKQAAAXgLANQgLAOgTAAQgRAAgLgNgAgQgeQgHAKAAAQIAAAJQAAAQAHAKQAGAJAKAAQAXAAAAghIAAgLQAAgQgGgKQgGgJgLAAQgKAAgGAJg");
	this.shape_187.setTransform(78.7,128);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f("#39454A").s().p("AgLBGQgEgHAAgOIAAhNIAQAAIAABPQAAALAJAAQAEAAACgBIAAAPQgFABgHAAQgJAAgGgHgAgNgrIAFghIAQAAIgKAhg");
	this.shape_188.setTransform(71.2,125.7);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f("#39454A").s().p("AgaAuQgKgIAAgPQAAgSAQgGQgHgDgEgGQgEgGAAgHQAAgPAKgIQAJgIAQAAQAPAAALAJQAKAJAAAOIgSAAQAAgHgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAHQAAAQASAAIAQAAIAAANIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJg");
	this.shape_189.setTransform(63,128);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f("#39454A").s().p("AAVBGQgGgFgFgNIgLghIgVA2IgSAAIAfhMIgNgmQgGgSgJAAIgFABIAAgOIAJgCQAPAAAHATIALAeIASgvIARAAIgcBGIARAuQAFAOAGAAIACAAIAGAAIgEAPQgBABAAAAQgBAAAAAAQgBABgBAAQAAAAgBAAQgIAAgFgFg");
	this.shape_190.setTransform(54.4,130.1);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f("#39454A").s().p("AgcAqQgMgNAAgWIAAgLQAAgXALgNQALgOASAAQASAAALANQALANABAXIAAAKQAAAXgLANQgLAOgTAAQgRAAgLgNgAgQgeQgHAKAAAQIAAAJQAAAQAHAKQAGAJAKAAQAXAAAAghIAAgLQAAgQgGgKQgGgJgLAAQgKAAgGAJg");
	this.shape_191.setTransform(44.5,128);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f("#39454A").s().p("AgcA/QgLgOAAgaQAAgQAIgMQAHgMAMgEIAAAAQgIgEgEgHQgFgHAAgJQAAgNAJgIQAIgHAOAAQALAAALAFIAAAQQgFgDgGgBQgHgCgFAAQgFAAgEADQgDAEAAAGQAAALAQAHQASAHAIAOQAJAMAAATIAAAEQAAAXgLAOQgLAOgSAAQgRAAgLgOgAgPgDQgGAJAAAUQAAARAGAKQAGAKAJAAQALAAAGgKQAGgKAAgUQAAgNgHgKQgGgKgKgDQgJAAgGAKg");
	this.shape_192.setTransform(34.5,125.8);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f("#39454A").s().p("AgcBCQgMgNAAgWIAAgMQAAgWALgNQALgOASAAQASAAALANQALANABAWIAAALQAAAXgLANQgLAOgTAAQgRAAgLgNgAgQgGQgHAJAAAQIAAAKQAAAQAHAKQAGAJAKAAQAXAAAAghIAAgMQAAgQgGgJQgGgJgLAAQgKAAgGAJgAgHgtIAGghIAPAAIgLAhg");
	this.shape_193.setTransform(327,101.6);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f("#39454A").s().p("AgIAaIAAhAIgcAAIAAgPIBJAAIAAAPIgdAAIAAA/QAAANAHAAQAEAAAEgCIAEANQgHAFgJAAQgTAAAAgcg");
	this.shape_194.setTransform(317.3,104.1);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f("#39454A").s().p("AgfAnQgLgPAAgYIAAgBQAAgXALgOQAKgPATAAIAtAAIAAAPIgWAAQAPAPAAAZIAAACQAAANgFAMQgFAMgJAGQgJAHgKAAQgTAAgKgPgAgTgcQgGAKAAASQAAASAGAKQAGALALAAQAJAAAGgKQAGgLAAgTQAAgRgGgKQgGgKgKAAQgKAAgGAKg");
	this.shape_195.setTransform(308.1,104.1);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f("#39454A").s().p("AgKAuQgGgHAAgOIAAhNIAQAAIAABPQABALAIAAQAFAAACgBIAAAPQgFABgHAAQgJAAgFgHg");
	this.shape_196.setTransform(300.3,104.1);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f("#39454A").s().p("AgaAuQgKgIAAgPQAAgSAQgGQgHgDgEgGQgEgGAAgHQAAgPAKgIQAJgIAQAAQAPAAALAJQAKAJAAAOIgSAAQAAgHgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAHQAAAQASAAIAQAAIAAANIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJg");
	this.shape_197.setTransform(292.1,104);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f("#39454A").s().p("AAYBHQgEgEgDgKIgSg5IgWBJIgTAAIAghiIgIgYQgCgGgDgCQgCgCgCAAIgFAAIAAgOIAJgBQAIAAAFAEQAFAEACAJIAjBrIAEAHQAAABABAAQAAABABAAQAAAAABAAQAAAAABAAIADAAIAAAPIgGABQgJAAgEgEg");
	this.shape_198.setTransform(282.5,102);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f("#39454A").s().p("AARA1IgegtIgIAAIAAAtIgRAAIAAhpIARAAIAAAtIAGAAIAfgtIAUAAIgkAzIAnA2g");
	this.shape_199.setTransform(273.2,104);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_200.setTransform(258.7,104);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.f("#39454A").s().p("AgFA1IgghpIASAAIATBOIAVhOIARAAIggBpg");
	this.shape_201.setTransform(249.1,104);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.f("#39454A").s().p("AgaBGQgKgIAAgPQAAgSAQgHQgHgDgEgGQgEgGAAgHQAAgOAKgIQAJgIAQAAQAPAAALAJQAKAJAAANIgSAAQAAgGgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAGQAAAQASAAIAQAAIAAAOIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJgAgGgtIAFghIAQAAIgLAhg");
	this.shape_202.setTransform(240.2,101.6);

	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.f("#39454A").s().p("AAIBAIAGgKIABgIQAAgEgDgCQgDgDgHgCQgkgKgCgjIAAgJQAAgOAEgNQAFgMAKgHQAJgGAKAAQAQAAAKAKQAJAKAAATIgRAAQABgMgGgGQgEgGgJgBQgJABgGAKQgGALAAARIAAAEQAAAZAYAJIAMAEQAIADADAEQAEAFgBAHQABAHgFAIQgEAJgGAFg");
	this.shape_203.setTransform(226.1,105.8);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.f("#39454A").s().p("AgLAuQgEgHAAgOIAAhNIAQAAIAABPQAAALAJAAQAEAAADgBIAAAPQgGABgHAAQgJAAgGgHg");
	this.shape_204.setTransform(218.9,104.1);

	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.f("#39454A").s().p("AgaAuQgKgIAAgPQAAgSAQgGQgHgDgEgGQgEgGAAgHQAAgPAKgIQAJgIAQAAQAPAAALAJQAKAJAAAOIgSAAQAAgHgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAHQAAAQASAAIAQAAIAAANIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJg");
	this.shape_205.setTransform(210.7,104);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.f("#39454A").s().p("AglBKIAAhgQAAgPAEgMQAGgMAIgGQAJgGAKAAQASAAAJAPQALAPAAAdQAAAWgJANQgJAPgRAAQgOAAgIgLIAAAxgAgPgwQgEALAAAQIAAAdQAFANAOAAQAJAAAGgKQAGgJgBgSQABgVgGgLQgFgKgKgBQgJABgGAKg");
	this.shape_206.setTransform(201.2,106);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.f("#39454A").s().p("AgmBbIAAiOQAAgKAFgJQAFgJAJgGQAIgFAKAAQAPAAAKALQAKAKAAARQAAAJgEAIQgEAHgIAFQALAEAEAKQAGAJAAAMQAAAUgKALQgLAMgQAAQgNAAgJgIIAAAsgAgPhEQgFAHAAALIAABQQAGAKAOAAQAKAAAGgHQAGgIAAgNQAAgLgGgHQgFgJgHAAIgMAAIAAgPIAHAAQAIAAAGgFQAEgGAAgLQAAgKgFgHQgGgGgHAAQgIAAgGAHg");
	this.shape_207.setTransform(191.1,104);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_208.setTransform(176.5,104);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.f("#39454A").s().p("AgbA4QgKgQAAgfIAAgSQAAgeAKgQQAJgRASAAQASAAAKAQQAKAQAAAdIAAATQAAAggKAQQgJARgTAAQgRAAgKgRgAgUALQAAAWAFAMQAGANAJAAQAKAAAGgMQAFgMAAgXIAAgDIgpAAgAgPgtQgFALAAAXIAAAFIApAAIAAgFQAAgXgFgLQgGgMgKAAQgJAAgGAMg");
	this.shape_209.setTransform(166.2,102.2);

	this.shape_210 = new cjs.Shape();
	this.shape_210.graphics.f("#39454A").s().p("AgcAqQgMgNAAgWIAAgLQAAgXALgNQALgOASAAQASAAALANQALANABAXIAAAKQAAAXgLANQgLAOgTAAQgRAAgLgNgAgQgeQgHAKAAAQIAAAJQAAAQAHAKQAGAJAKAAQAXAAAAghIAAgLQAAgQgGgKQgGgJgLAAQgKAAgGAJg");
	this.shape_210.setTransform(151.6,104);

	this.shape_211 = new cjs.Shape();
	this.shape_211.graphics.f("#39454A").s().p("AgLAuQgEgHAAgOIAAhNIAQAAIAABPQAAALAJAAQAEAAACgBIAAAPQgFABgHAAQgJAAgGgHg");
	this.shape_211.setTransform(144.1,104.1);

	this.shape_212 = new cjs.Shape();
	this.shape_212.graphics.f("#39454A").s().p("AglBKIAAhgQAAgPAFgMQAEgMAJgGQAIgGALAAQASAAAJAPQALAPAAAdQAAAWgJANQgKAPgPAAQgOAAgKgLIAAAxgAgOgwQgGALAAAQIAAAdQAHANAMAAQAKAAAGgKQAGgJAAgSQAAgVgGgLQgFgKgKgBQgJABgFAKg");
	this.shape_212.setTransform(135.8,106);

	this.shape_213 = new cjs.Shape();
	this.shape_213.graphics.f("#39454A").s().p("AATBiIAAhrQAAgNgFgGQgEgGgJgBQgMABgGAPIAABMIgSAAIAAhoIAPAAIABAMQALgOAOAAQAPAAAIAKQAHAJAAAUIAABsgAgGhAIAFghIAQAAIgLAhg");
	this.shape_213.setTransform(125.7,103.6);

	this.shape_214 = new cjs.Shape();
	this.shape_214.graphics.f("#39454A").s().p("AgIAaIAAhAIgcAAIAAgPIBJAAIAAAPIgdAAIAAA/QAAANAHAAQAEAAAEgCIAEANQgHAFgJAAQgTAAAAgcg");
	this.shape_214.setTransform(116.1,104.1);

	this.shape_215 = new cjs.Shape();
	this.shape_215.graphics.f("#39454A").s().p("AgfAnQgLgPAAgYIAAgBQAAgXALgOQAKgPATAAIAtAAIAAAPIgWAAQAPAPAAAZIAAACQAAANgFAMQgFAMgJAGQgJAHgKAAQgTAAgKgPgAgTgcQgGAKAAASQAAASAGAKQAGALALAAQAJAAAGgKQAGgLAAgTQAAgRgGgKQgGgKgKAAQgKAAgGAKg");
	this.shape_215.setTransform(106.9,104.1);

	this.shape_216 = new cjs.Shape();
	this.shape_216.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_216.setTransform(96.9,104);

	this.shape_217 = new cjs.Shape();
	this.shape_217.graphics.f("#39454A").s().p("AgHBJIAAgwIgfhhIASAAIAUBKIAVhKIASAAIgeBiIAAAvg");
	this.shape_217.setTransform(87.3,106.1);

	this.shape_218 = new cjs.Shape();
	this.shape_218.graphics.f("#39454A").s().p("AglBKIAAhgQAAgPAFgMQAEgMAJgGQAJgGAKAAQARAAALAPQAKAPAAAdQAAAWgJANQgJAPgRAAQgNAAgKgLIAAAxgAgOgwQgFALgBAQIAAAdQAHANAMAAQAKAAAGgKQAFgJABgSQgBgVgFgLQgGgKgJgBQgJABgFAKg");
	this.shape_218.setTransform(78,106);

	this.shape_219 = new cjs.Shape();
	this.shape_219.graphics.f("#39454A").s().p("AgaAuQgKgIAAgPQAAgSAQgGQgHgDgEgGQgEgGAAgHQAAgPAKgIQAJgIAQAAQAPAAALAJQAKAJAAAOIgSAAQAAgHgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAHQAAAQASAAIAQAAIAAANIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJg");
	this.shape_219.setTransform(68.1,104);

	this.shape_220 = new cjs.Shape();
	this.shape_220.graphics.f("#39454A").s().p("AgcAqQgMgNAAgWIAAgLQAAgXALgNQALgOASAAQASAAALANQALANABAXIAAAKQAAAXgLANQgLAOgTAAQgRAAgLgNgAgQgeQgHAKAAAQIAAAJQAAAQAHAKQAGAJAKAAQAXAAAAghIAAgLQAAgQgGgKQgGgJgLAAQgKAAgGAJg");
	this.shape_220.setTransform(53.8,104);

	this.shape_221 = new cjs.Shape();
	this.shape_221.graphics.f("#39454A").s().p("AgIAaIAAhAIgcAAIAAgPIBJAAIAAAPIgdAAIAAA/QAAANAHAAQAEAAAEgCIAEANQgHAFgJAAQgTAAAAgcg");
	this.shape_221.setTransform(44.1,104.1);

	this.shape_222 = new cjs.Shape();
	this.shape_222.graphics.f("#39454A").s().p("AgpBHIAAgOIAmg5Igmg4IAAgOIBPAAIAAAPIg6AAIAkA3IAAABIglA2IA/AAIAAAQg");
	this.shape_222.setTransform(34.5,102.2);

	this.shape_223 = new cjs.Shape();
	this.shape_223.graphics.f("#39454A").s().p("AgKBEQgEgFAAgGQAAgHAEgEQAEgEAGAAQAHAAAEAEQAEAEAAAHQAAAGgEAFQgEAEgHAAQgGAAgEgEgAgKAbIgEhiIAdAAIgDBig");
	this.shape_223.setTransform(355.4,78.3);

	this.shape_224 = new cjs.Shape();
	this.shape_224.graphics.f("#39454A").s().p("AgfApQgLgOAAgYIAAgFQAAgZALgNQAMgOATAAQAUAAALAOQAMANAAAZIAAAFQAAAZgMANQgLAOgUAAQgTAAgMgOgAgKgYQgEAHAAAPIAAAFQAAAdAOAAQAOAAABgYIAAgKQAAgPgEgHQgEgHgHAAQgGAAgEAHg");
	this.shape_224.setTransform(347.8,80);

	this.shape_225 = new cjs.Shape();
	this.shape_225.graphics.f("#39454A").s().p("AgUAWIAAhKIAbAAIgBBHQAAAGACADQACACAFAAIAGgBIAAAWQgHACgIAAQgaAAAAgfg");
	this.shape_225.setTransform(339.9,80.1);

	this.shape_226 = new cjs.Shape();
	this.shape_226.graphics.f("#39454A").s().p("AgoBKIAAhfQAAgZALgNQAMgOASAAQATAAAKAPQALAOAAAcQAAAXgJAOQgJAOgQABQgMAAgHgKIAAAwgAgJgqQgDAIAAAQIAAAYQAEAHAIgBQANAAABgaIAAgEQAAgQgEgIQgEgIgGAAQgGAAgDAIg");
	this.shape_226.setTransform(331.7,82);

	this.shape_227 = new cjs.Shape();
	this.shape_227.graphics.f("#39454A").s().p("AAMBjIAAhsQAAgRgLABQgHAAgFAHIAABMIgcAAIAAhoIAaAAIABAMQAKgPANAAQAdAAAAApIAABrgAgJg/IAGgiIAZAAIgPAig");
	this.shape_227.setTransform(321.6,79.5);

	this.shape_228 = new cjs.Shape();
	this.shape_228.graphics.f("#39454A").s().p("AgGAtQgIgJAAgRIAAgxIgaAAIAAgXIBRAAIAAAXIgcAAIAAAyQAAAGABACQACADADAAQAEAAAEgCIADAWQgHADgKAAQgNAAgGgJg");
	this.shape_228.setTransform(312.1,80.1);

	this.shape_229 = new cjs.Shape();
	this.shape_229.graphics.f("#39454A").s().p("AghAnQgLgOAAgZIAAgBQAAgYALgOQALgOAVAAIAuAAIAAAXIgVAAQAOAOAAAUQAAAXgLANQgLAOgRAAQgUAAgMgPgAgRgDIAAADQABAfAPAAQALAAAAgZIABgHQAAgPgEgHQgDgHgFAAQgPAAgBAbg");
	this.shape_229.setTransform(302.6,80.1);

	this.shape_230 = new cjs.Shape();
	this.shape_230.graphics.f("#39454A").s().p("AANAoQgJAPgNAAQgQAAgJgOQgKgOAAgaQAAgZAKgPQAJgPAQAAQAMAAAHANIADgLIAXAAIAABIQAAALAGAAIABAAIABAVQgEADgGAAQgPAAgGgPgAgMgXQgEAIAAASQAAAPAEAHQADAHAIAAQAGAAAEgHIAAgwQgEgIgGAAQgIAAgDAIg");
	this.shape_230.setTransform(292.7,80);

	this.shape_231 = new cjs.Shape();
	this.shape_231.graphics.f("#39454A").s().p("AgNBJIAAgrIgchmIAcAAIANBBIAOhBIAcAAIgcBnIAAAqg");
	this.shape_231.setTransform(283,82.1);

	this.shape_232 = new cjs.Shape();
	this.shape_232.graphics.f("#39454A").s().p("AgoBKIAAhfQAAgZALgNQAMgOASAAQATAAAKAPQALAOAAAcQAAAXgJAOQgJAOgQABQgMAAgHgKIAAAwgAgJgqQgDAIAAAQIAAAYQAEAHAIgBQANAAABgaIAAgEQAAgQgEgIQgEgIgGAAQgGAAgDAIg");
	this.shape_232.setTransform(273.6,82);

	this.shape_233 = new cjs.Shape();
	this.shape_233.graphics.f("#39454A").s().p("AgcAuQgMgJAAgOQAAgSARgGQgHgDgEgGQgEgGAAgHQAAgOALgJQALgIASAAQAQAAALAJQAKAJAAAPIgbAAQAAgGgDgCQgEgDgFAAQgEAAgEADQgDADAAAFQAAAFADADQAEADAEAAIAQAAIAAASIgQAAQgMAAAAANQAAAFADAEQAEADAFAAQAGAAAEgDQADgDAAgFIAcAAQAAAPgLAJQgLAJgRAAQgSAAgMgJg");
	this.shape_233.setTransform(263.7,80);

	this.shape_234 = new cjs.Shape();
	this.shape_234.graphics.f("#39454A").s().p("AgfBCQgLgOAAgYIAAgHQAAgXALgOQAMgNATAAQAUAAALANQAMAOAAAXIAAAHQAAAYgMAOQgLANgUAAQgTAAgMgNgAgKAAQgEAHAAAOIAAAHQAAAcAOAAQAOAAABgXIAAgMQAAgOgEgHQgEgGgHAAQgGAAgEAGgAgKgsIAHgiIAZAAIgQAig");
	this.shape_234.setTransform(249.1,77.6);

	this.shape_235 = new cjs.Shape();
	this.shape_235.graphics.f("#39454A").s().p("AAJA1IgRgnIgIAAIAAAnIgbAAIAAhpIAbAAIAAAoIAGAAIATgoIAiAAIgdAyIAeA3g");
	this.shape_235.setTransform(239.3,80);

	this.shape_236 = new cjs.Shape();
	this.shape_236.graphics.f("#39454A").s().p("AgUAWIAAhKIAbAAIgBBHQAAAGACADQACACAFAAIAGgBIAAAWQgHACgIAAQgaAAAAgfg");
	this.shape_236.setTransform(230.8,80.1);

	this.shape_237 = new cjs.Shape();
	this.shape_237.graphics.f("#39454A").s().p("AgMA1IgdhpIAdAAIAMBCIANhCIAdAAIgdBpg");
	this.shape_237.setTransform(222.9,80);

	this.shape_238 = new cjs.Shape();
	this.shape_238.graphics.f("#39454A").s().p("AgfApQgLgOAAgYIAAgFQAAgZALgNQAMgOATAAQAUAAALAOQAMANAAAZIAAAFQAAAZgMANQgLAOgUAAQgTAAgMgOgAgKgYQgEAHAAAPIAAAFQAAAdAOAAQAOAAABgYIAAgKQAAgPgEgHQgEgHgHAAQgGAAgEAHg");
	this.shape_238.setTransform(213.5,80);

	this.shape_239 = new cjs.Shape();
	this.shape_239.graphics.f("#39454A").s().p("AAJA1IgRgnIgIAAIAAAnIgbAAIAAhpIAbAAIAAAoIAGAAIATgoIAiAAIgdAyIAeA3g");
	this.shape_239.setTransform(203.7,80);

	this.shape_240 = new cjs.Shape();
	this.shape_240.graphics.f("#39454A").s().p("AgUAWIAAhKIAbAAIgBBHQAAAGACADQACACAFAAIAGgBIAAAWQgHACgIAAQgaAAAAgfg");
	this.shape_240.setTransform(195.2,80.1);

	this.shape_241 = new cjs.Shape();
	this.shape_241.graphics.f("#39454A").s().p("AgcAuQgMgJAAgOQAAgSARgGQgHgDgEgGQgEgGAAgHQAAgOALgJQALgIASAAQAQAAALAJQAKAJAAAPIgbAAQAAgGgDgCQgEgDgFAAQgEAAgEADQgDADAAAFQAAAFADADQAEADAEAAIAQAAIAAASIgQAAQgMAAAAANQAAAFADAEQAEADAFAAQAGAAAEgDQADgDAAgFIAcAAQAAAPgLAJQgLAJgRAAQgSAAgMgJg");
	this.shape_241.setTransform(187.1,80);

	this.shape_242 = new cjs.Shape();
	this.shape_242.graphics.f("#39454A").s().p("AgfApQgLgOAAgYIAAgFQAAgZALgNQAMgOATAAQAUAAALAOQAMANAAAZIAAAFQAAAZgMANQgLAOgUAAQgTAAgMgOgAgKgYQgEAHAAAPIAAAFQAAAdAOAAQAOAAABgYIAAgKQAAgPgEgHQgEgHgHAAQgGAAgEAHg");
	this.shape_242.setTransform(172.5,80);

	this.shape_243 = new cjs.Shape();
	this.shape_243.graphics.f("#39454A").s().p("AgGAtQgIgJABgRIAAgxIgbAAIAAgXIBRAAIAAAXIgcAAIAAAyQAAAGABACQACADADAAQADAAAFgCIADAWQgHADgKAAQgNAAgGgJg");
	this.shape_243.setTransform(162.9,80.1);

	this.shape_244 = new cjs.Shape();
	this.shape_244.graphics.f("#39454A").s().p("AghAnQgLgOAAgZIAAgBQAAgYALgOQALgOAVAAIAuAAIAAAXIgVAAQAOAOAAAUQABAXgMANQgLAOgRAAQgUAAgMgPgAgRgDIAAADQABAfAPAAQALAAAAgZIABgHQAAgPgDgHQgEgHgFAAQgPAAgBAbg");
	this.shape_244.setTransform(153.4,80.1);

	this.shape_245 = new cjs.Shape();
	this.shape_245.graphics.f("#39454A").s().p("AgdArQgJgLAAgUIAAhBIAbAAIAAA/QAAAVAIAAQAGAAAEgKQAFgKAAgOQgBgXgHgbIAaAAQAJAWAAAcQAAAbgLAPQgLAPgTAAQgSAAgJgLg");
	this.shape_245.setTransform(138.9,80.1);

	this.shape_246 = new cjs.Shape();
	this.shape_246.graphics.f("#39454A").s().p("AgfApQgLgOAAgYIAAgFQAAgZALgNQAMgOATAAQAUAAALAOQAMANAAAZIAAAFQAAAZgMANQgLAOgUAAQgTAAgMgOgAgKgYQgEAHAAAPIAAAFQAAAdAOAAQAOAAABgYIAAgKQAAgPgEgHQgEgHgHAAQgGAAgEAHg");
	this.shape_246.setTransform(129,80);

	this.shape_247 = new cjs.Shape();
	this.shape_247.graphics.f("#39454A").s().p("AghAnQgLgOAAgZIAAgBQAAgYALgOQALgOAVAAIAuAAIAAAXIgVAAQAOAOAAAUQABAXgLANQgMAOgRAAQgUAAgMgPgAgQgDIAAADQgBAfAQAAQAKAAACgZIAAgHQAAgPgDgHQgEgHgFAAQgPAAAAAbg");
	this.shape_247.setTransform(119.1,80.1);

	this.shape_248 = new cjs.Shape();
	this.shape_248.graphics.f("#39454A").s().p("AgUAvIAAhLIAbAAIgBBIQAAAGACACQACACAFAAIAGAAIAAAVQgHADgIAAQgaAAAAgfgAgPgrIAHgiIAZAAIgQAig");
	this.shape_248.setTransform(111,77.6);

	this.shape_249 = new cjs.Shape();
	this.shape_249.graphics.f("#39454A").s().p("AgGAtQgIgJABgRIAAgxIgbAAIAAgXIBRAAIAAAXIgcAAIAAAyQAAAGABACQACADADAAQAEAAAEgCIADAWQgHADgKAAQgNAAgGgJg");
	this.shape_249.setTransform(103.1,80.1);

	this.shape_250 = new cjs.Shape();
	this.shape_250.graphics.f("#39454A").s().p("AANAoQgJAPgNAAQgQAAgJgOQgKgOAAgaQAAgZAKgPQAJgPAQAAQAMAAAHANIADgLIAXAAIAABIQAAALAGAAIABAAIABAVQgEADgGAAQgPAAgGgPgAgMgXQgEAIAAASQAAAPAEAHQADAHAIAAQAGAAAEgHIAAgwQgEgIgGAAQgIAAgDAIg");
	this.shape_250.setTransform(93.8,80);

	this.shape_251 = new cjs.Shape();
	this.shape_251.graphics.f("#39454A").s().p("AgoBJIAAiRIAbAAIAAA9QAAALAEAGQACAFAHAAQAJABAEgJIAAhLIAcAAIAABpIgaAAIAAgGQgHAIgIAAQgHgBgGgDIAAAqg");
	this.shape_251.setTransform(83,82.1);

	this.shape_252 = new cjs.Shape();
	this.shape_252.graphics.f("#39454A").s().p("AANAoQgJAPgNAAQgPAAgKgOQgKgOABgaQgBgZAKgPQAKgPAPAAQAMAAAIANIACgLIAYAAIAABIQAAALAEAAIABAAIACAVQgEADgHAAQgPAAgFgPgAgMgXQgEAIABASQgBAPAEAHQAEAHAGAAQAHAAAEgHIAAgwQgEgIgGAAQgIAAgDAIg");
	this.shape_252.setTransform(72.9,80);

	this.shape_253 = new cjs.Shape();
	this.shape_253.graphics.f("#39454A").s().p("AgoBKIAAhfQAAgZALgNQAMgOASAAQATAAAKAPQALAOAAAcQAAAXgJAOQgJAOgQABQgMAAgHgKIAAAwgAgJgqQgDAIAAAQIAAAYQAEAHAIgBQANAAABgaIAAgEQAAgQgEgIQgEgIgGAAQgGAAgDAIg");
	this.shape_253.setTransform(62.9,82);

	this.shape_254 = new cjs.Shape();
	this.shape_254.graphics.f("#39454A").s().p("AgUAWIAAhKIAbAAIgBBHQAAAGACADQACACAFAAIAGgBIAAAWQgHACgIAAQgaAAAAgfg");
	this.shape_254.setTransform(54.9,80.1);

	this.shape_255 = new cjs.Shape();
	this.shape_255.graphics.f("#39454A").s().p("AgcAuQgMgJAAgOQAAgSARgGQgHgDgEgGQgEgGAAgHQAAgOALgJQALgIASAAQAQAAALAJQAKAJAAAPIgbAAQAAgGgDgCQgEgDgFAAQgEAAgEADQgDADAAAFQAAAFADADQAEADAEAAIAQAAIAAASIgQAAQgMAAAAANQAAAFADAEQAEADAFAAQAGAAAEgDQADgDAAgFIAcAAQAAAPgLAJQgLAJgRAAQgSAAgMgJg");
	this.shape_255.setTransform(46.8,80);

	this.shape_256 = new cjs.Shape();
	this.shape_256.graphics.f("#39454A").s().p("AAVBHIAAh2IgpAAIAAB2IgdAAIAAiNIBjAAIAACNg");
	this.shape_256.setTransform(35.6,78.2);

	this.shape_257 = new cjs.Shape();
	this.shape_257.graphics.f("#39454A").s().p("AgHAIQgDgDAAgFQAAgDADgEQACgDAFAAQAGAAACADQADAEAAADQAAAFgDADQgCADgGAAQgFAAgCgDg");
	this.shape_257.setTransform(1177.6,527.6);

	this.shape_258 = new cjs.Shape();
	this.shape_258.graphics.f("#39454A").s().p("AgVBcQAMgMAHgYQAHgYAAgdIAAgDQAAglgLgdQgHgQgIgJIADgLQALAHAJARQAUAiAAAtQAAArgTAiQgKASgLAHg");
	this.shape_258.setTransform(1171.5,522.9);

	this.shape_259 = new cjs.Shape();
	this.shape_259.graphics.f("#39454A").s().p("AgcAqQgMgNAAgWIAAgLQAAgXALgNQALgOASAAQASAAALANQALANABAXIAAAKQAAAXgLANQgLAOgTAAQgRAAgLgNgAgQgeQgHAKAAAQIAAAJQAAAQAHAKQAGAJAKAAQAXAAAAghIAAgLQAAgQgGgKQgGgJgLAAQgKAAgGAJg");
	this.shape_259.setTransform(1163.7,523.3);

	this.shape_260 = new cjs.Shape();
	this.shape_260.graphics.f("#39454A").s().p("AgLAuQgEgHAAgOIAAhNIAQAAIAABPQAAALAJAAQAEAAACgBIAAAPQgFABgHAAQgJAAgGgHg");
	this.shape_260.setTransform(1156.2,523.4);

	this.shape_261 = new cjs.Shape();
	this.shape_261.graphics.f("#39454A").s().p("AglBKIAAhgQAAgQAFgLQAEgMAJgGQAIgGALAAQASAAAJAPQALAPAAAdQAAAWgJANQgKAPgPAAQgOAAgKgLIAAAxgAgOgwQgGALAAAQIAAAcQAHANAMABQAKAAAGgJQAGgKAAgSQAAgVgGgLQgGgLgJAAQgJAAgFALg");
	this.shape_261.setTransform(1147.9,525.3);

	this.shape_262 = new cjs.Shape();
	this.shape_262.graphics.f("#39454A").s().p("AgaBGQgKgIAAgPQAAgSAQgHQgHgDgEgGQgEgGAAgHQAAgOAKgIQAJgIAQAAQAPAAALAJQAKAJAAANIgSAAQAAgGgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAGQAAAQASAAIAQAAIAAAOIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJgAgGgtIAFghIAQAAIgLAhg");
	this.shape_262.setTransform(1138,520.9);

	this.shape_263 = new cjs.Shape();
	this.shape_263.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_263.setTransform(1128.7,523.3);

	this.shape_264 = new cjs.Shape();
	this.shape_264.graphics.f("#39454A").s().p("AABBTQgXgjAAgwQAAgZAIgXQAGgWAMgRQAIgKAHgFIADAMQgLALgIAXQgGAWgBAcIAAAHQAAAiAIAaQAIAUAKALIgDALQgJgGgJgOg");
	this.shape_264.setTransform(1120.6,522.9);

	this.shape_265 = new cjs.Shape();
	this.shape_265.graphics.f("#39454A").s().p("AAIA/IAGgJIABgIQAAgEgDgCQgDgDgHgCQgkgJgCgkIAAgJQAAgOAEgNQAGgLAJgIQAIgGALAAQAQAAAKAKQAJAKAAATIgRAAQAAgMgEgGQgGgGgIgBQgJAAgGALQgGALAAARIAAAEQAAAYAYAKIAMAEQAIADADAEQAEAFgBAHQABAHgFAIQgFAIgFAGg");
	this.shape_265.setTransform(1107.8,525.1);

	this.shape_266 = new cjs.Shape();
	this.shape_266.graphics.f("#39454A").s().p("AgcBCQgMgNAAgWIAAgMQAAgWALgNQALgOASAAQASAAALANQALANABAWIAAALQAAAXgLANQgLAOgTAAQgRAAgLgNgAgQgGQgHAJAAAQIAAAKQAAAQAHAKQAGAJAKAAQAXAAAAghIAAgMQAAgQgGgJQgGgJgLAAQgKAAgGAJgAgHgtIAGghIAPAAIgLAhg");
	this.shape_266.setTransform(1098,520.9);

	this.shape_267 = new cjs.Shape();
	this.shape_267.graphics.f("#39454A").s().p("AgiBJIAAiRIARAAIAAA/QAAAOADAHQAFAIAIAAQANAAAGgOIAAhOIASAAIAABoIgQAAIgBgKQgHANgMAAQgMAAgFgHIAAAtg");
	this.shape_267.setTransform(1088.1,525.4);

	this.shape_268 = new cjs.Shape();
	this.shape_268.graphics.f("#39454A").s().p("AgIAaIAAhAIgcAAIAAgPIBJAAIAAAPIgdAAIAAA/QAAANAHAAQAEAAAEgCIAEANQgHAFgJAAQgTAAAAgcg");
	this.shape_268.setTransform(1078.4,523.4);

	this.shape_269 = new cjs.Shape();
	this.shape_269.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_269.setTransform(1069.2,523.3);

	this.shape_270 = new cjs.Shape();
	this.shape_270.graphics.f("#39454A").s().p("AgFA1IgghpIASAAIATBOIAUhOIASAAIggBpg");
	this.shape_270.setTransform(1055.1,523.3);

	this.shape_271 = new cjs.Shape();
	this.shape_271.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_271.setTransform(1046.2,523.3);

	this.shape_272 = new cjs.Shape();
	this.shape_272.graphics.f("#39454A").s().p("AgfAnQgLgPAAgYIAAgBQAAgXALgOQAKgPATAAIAtAAIAAAPIgWAAQAPAPAAAZIAAACQAAANgFAMQgFAMgJAGQgJAHgKAAQgTAAgKgPgAgTgcQgGAKAAASQAAASAGAKQAGALALAAQAJAAAGgKQAGgLAAgTQAAgRgGgKQgGgKgKAAQgKAAgGAKg");
	this.shape_272.setTransform(1036.3,523.4);

	this.shape_273 = new cjs.Shape();
	this.shape_273.graphics.f("#39454A").s().p("AgLAuQgEgHAAgOIAAhNIAQAAIAABPQAAALAIAAQAFAAACgBIAAAPQgFABgHAAQgJAAgGgHg");
	this.shape_273.setTransform(1260,499.4);

	this.shape_274 = new cjs.Shape();
	this.shape_274.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_274.setTransform(1251.9,499.3);

	this.shape_275 = new cjs.Shape();
	this.shape_275.graphics.f("#39454A").s().p("AARA1IgegtIgIAAIAAAtIgRAAIAAhpIARAAIAAAtIAGAAIAfgtIAUAAIgkAzIAnA2g");
	this.shape_275.setTransform(1242.1,499.3);

	this.shape_276 = new cjs.Shape();
	this.shape_276.graphics.f("#39454A").s().p("AgVBcQAMgMAHgYQAHgYAAgdIAAgDQAAglgLgdQgHgQgIgJIADgLQALAHAJARQAUAiAAAtQAAArgTAiQgKASgLAHg");
	this.shape_276.setTransform(1228.6,498.9);

	this.shape_277 = new cjs.Shape();
	this.shape_277.graphics.f("#39454A").s().p("AgcBCQgMgNAAgWIAAgMQAAgWALgNQALgOASAAQASAAALANQALANABAWIAAALQAAAXgLANQgLAOgTAAQgRAAgLgNgAgQgGQgHAJAAAQIAAAKQAAAQAHAKQAGAJAKAAQAXAAAAghIAAgMQAAgQgGgJQgGgJgLAAQgKAAgGAJgAgHgtIAGghIAPAAIgLAhg");
	this.shape_277.setTransform(1220.8,496.9);

	this.shape_278 = new cjs.Shape();
	this.shape_278.graphics.f("#39454A").s().p("AglBKIAAhgQAAgPAEgMQAGgMAIgGQAJgGAKAAQARAAAKAPQALAPAAAcQAAAXgJANQgJAOgRABQgOAAgIgLIAAAxgAgPgvQgEAKAAARIAAAcQAFANAOgBQAJABAGgKQAGgJgBgTQABgUgGgKQgFgMgKAAQgJAAgGAMg");
	this.shape_278.setTransform(1211,501.3);

	this.shape_279 = new cjs.Shape();
	this.shape_279.graphics.f("#39454A").s().p("AgIBJIAAgwIgehhIASAAIAVBKIAUhKIASAAIgeBiIAAAvg");
	this.shape_279.setTransform(1201.5,501.4);

	this.shape_280 = new cjs.Shape();
	this.shape_280.graphics.f("#39454A").s().p("AgbArQgIgLAAgVIAAhAIARAAIAAA+QAAAeAPAAQAJAAAGgMQAHgNAAgQQAAgWgKgdIASAAQAKAXAAAcQgBAZgKAPQgLAQgSAAQgPAAgJgLg");
	this.shape_280.setTransform(1192.4,499.4);

	this.shape_281 = new cjs.Shape();
	this.shape_281.graphics.f("#39454A").s().p("AAABTQgWgjABgwQAAgZAGgXQAIgWALgRQAIgKAHgFIAEAMQgNALgHAXQgHAWAAAcIAAAHQAAAiAJAaQAHAUALALIgEALQgJgGgKgOg");
	this.shape_281.setTransform(1184.6,498.9);

	this.shape_282 = new cjs.Shape();
	this.shape_282.graphics.f("#39454A").s().p("AgcBCQgMgNAAgWIAAgMQAAgWALgNQALgOASAAQASAAALANQALANABAWIAAALQAAAXgLANQgLAOgTAAQgRAAgLgNgAgQgGQgHAJAAAQIAAAKQAAAQAHAKQAGAJAKAAQAXAAAAghIAAgMQAAgQgGgJQgGgJgLAAQgKAAgGAJgAgHgtIAGghIAPAAIgLAhg");
	this.shape_282.setTransform(1171.4,496.9);

	this.shape_283 = new cjs.Shape();
	this.shape_283.graphics.f("#39454A").s().p("AglBKIAAhgQAAgPAEgMQAGgMAIgGQAJgGAKAAQARAAAKAPQALAPAAAcQAAAXgJANQgJAOgRABQgNAAgJgLIAAAxgAgPgvQgEAKAAARIAAAcQAFANANgBQAKABAGgKQAGgJgBgTQABgUgGgKQgGgMgJAAQgJAAgGAMg");
	this.shape_283.setTransform(1161.6,501.3);

	this.shape_284 = new cjs.Shape();
	this.shape_284.graphics.f("#39454A").s().p("AgaAuQgKgIAAgPQAAgSAQgGQgHgDgEgGQgEgGAAgHQAAgPAKgIQAJgIAQAAQAPAAALAJQAKAJAAAOIgSAAQAAgHgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAHQAAAQASAAIAQAAIAAANIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJg");
	this.shape_284.setTransform(1151.8,499.3);

	this.shape_285 = new cjs.Shape();
	this.shape_285.graphics.f("#39454A").s().p("AgGA1IgfhpIARAAIAVBOIAThOIASAAIggBpg");
	this.shape_285.setTransform(1142.8,499.3);

	this.shape_286 = new cjs.Shape();
	this.shape_286.graphics.f("#39454A").s().p("AgFA1IgghpIARAAIAVBOIAUhOIARAAIggBpg");
	this.shape_286.setTransform(1129.6,499.3);

	this.shape_287 = new cjs.Shape();
	this.shape_287.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_287.setTransform(1120.7,499.3);

	this.shape_288 = new cjs.Shape();
	this.shape_288.graphics.f("#39454A").s().p("AgfAnQgLgPAAgYIAAgBQAAgXALgOQAKgPATAAIAtAAIAAAPIgWAAQAPAPAAAZIAAACQAAANgFAMQgFAMgJAGQgJAHgKAAQgTAAgKgPgAgTgcQgGAKAAASQAAASAGAKQAGALALAAQAJAAAGgKQAGgLAAgTQAAgRgGgKQgGgKgKAAQgKAAgGAKg");
	this.shape_288.setTransform(1110.8,499.4);

	this.shape_289 = new cjs.Shape();
	this.shape_289.graphics.f("#39454A").s().p("AgMASQAIgNABgNIAAgQIARAAIAAAPQAAAJgFAJQgFAKgGAGg");
	this.shape_289.setTransform(1098.6,505);

	this.shape_290 = new cjs.Shape();
	this.shape_290.graphics.f("#39454A").s().p("AgVBcQAMgMAHgYQAHgYAAgdIAAgDQAAglgLgdQgHgQgIgJIADgLQALAHAJARQAUAiAAAtQAAArgTAiQgKASgLAHg");
	this.shape_290.setTransform(1093.4,498.9);

	this.shape_291 = new cjs.Shape();
	this.shape_291.graphics.f("#39454A").s().p("AgcBCQgMgNAAgWIAAgMQAAgWALgNQALgOASAAQASAAALANQALANABAWIAAALQAAAXgLANQgLAOgTAAQgRAAgLgNgAgQgGQgHAJAAAQIAAAKQAAAQAHAKQAGAJAKAAQAXAAAAghIAAgMQAAgQgGgJQgGgJgLAAQgKAAgGAJgAgHgtIAGghIAPAAIgLAhg");
	this.shape_291.setTransform(1085.6,496.9);

	this.shape_292 = new cjs.Shape();
	this.shape_292.graphics.f("#39454A").s().p("AgaAuQgKgIAAgPQAAgSAQgGQgHgDgEgGQgEgGAAgHQAAgPAKgIQAJgIAQAAQAPAAALAJQAKAJAAAOIgSAAQAAgHgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAHQAAAQASAAIAQAAIAAANIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJg");
	this.shape_292.setTransform(1075.9,499.3);

	this.shape_293 = new cjs.Shape();
	this.shape_293.graphics.f("#39454A").s().p("AglBKIAAhgQAAgPAEgMQAFgMAJgGQAIgGALAAQASAAAKAPQAKAPAAAcQAAAXgJANQgKAOgQABQgOAAgIgLIAAAxgAgPgvQgEAKAAARIAAAcQAFANAOgBQAJABAGgKQAFgJAAgTQAAgUgFgKQgFgMgKAAQgJAAgGAMg");
	this.shape_293.setTransform(1066.4,501.3);

	this.shape_294 = new cjs.Shape();
	this.shape_294.graphics.f("#39454A").s().p("AgaAuQgKgIAAgPQAAgSAQgGQgHgDgEgGQgEgGAAgHQAAgPAKgIQAJgIAQAAQAPAAALAJQAKAJAAAOIgSAAQAAgHgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAHQAAAQASAAIAQAAIAAANIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJg");
	this.shape_294.setTransform(1056.5,499.3);

	this.shape_295 = new cjs.Shape();
	this.shape_295.graphics.f("#39454A").s().p("AgIAaIAAhAIgcAAIAAgPIBJAAIAAAPIgdAAIAAA/QAAANAHAAQAEAAAEgCIAEANQgHAFgJAAQgTAAAAgcg");
	this.shape_295.setTransform(1047.2,499.4);

	this.shape_296 = new cjs.Shape();
	this.shape_296.graphics.f("#39454A").s().p("AgfAnQgLgPAAgYIAAgBQAAgXALgOQAKgPATAAIAtAAIAAAPIgWAAQAPAPAAAZIAAACQAAANgFAMQgFAMgJAGQgJAHgKAAQgTAAgKgPgAgTgcQgGAKAAASQAAASAGAKQAGALALAAQAJAAAGgKQAGgLAAgTQAAgRgGgKQgGgKgKAAQgKAAgGAKg");
	this.shape_296.setTransform(1038,499.4);

	this.shape_297 = new cjs.Shape();
	this.shape_297.graphics.f("#39454A").s().p("AAABTQgVgjAAgwQgBgZAIgXQAGgWAMgRQAIgKAHgFIAEAMQgMALgIAXQgGAWgBAcIAAAHQAAAiAJAaQAHAUALALIgEALQgJgGgKgOg");
	this.shape_297.setTransform(1029.9,498.9);

	this.shape_298 = new cjs.Shape();
	this.shape_298.graphics.f("#39454A").s().p("AAHA/IAHgJIABgIQAAgEgDgDQgDgCgHgBQgkgLgCgjIAAgIQAAgPAFgMQAEgNAJgGQAKgHAKAAQAPAAAKAKQAKAKAAASIgRAAQAAgLgEgGQgGgHgIABQgJAAgGALQgGAKAAARIAAADQAAAZAYAKIAMAEQAIADADAEQAEAFAAAIQAAAGgFAIQgFAJgGAFg");
	this.shape_298.setTransform(1254.3,477.1);

	this.shape_299 = new cjs.Shape();
	this.shape_299.graphics.f("#39454A").s().p("AgcAqQgMgNAAgWIAAgLQAAgXALgNQALgOASAAQASAAALANQALANABAXIAAAKQAAAXgLANQgLAOgTAAQgRAAgLgNgAgQgeQgHAKAAAQIAAAJQAAAQAHAKQAGAJAKAAQAXAAAAghIAAgLQAAgQgGgKQgGgJgLAAQgKAAgGAJg");
	this.shape_299.setTransform(1244.6,475.3);

	this.shape_300 = new cjs.Shape();
	this.shape_300.graphics.f("#39454A").s().p("AgIBJIAAgwIgehhIARAAIAVBKIAWhKIARAAIgfBiIAAAvg");
	this.shape_300.setTransform(1235.2,477.4);

	this.shape_301 = new cjs.Shape();
	this.shape_301.graphics.f("#39454A").s().p("AARBAQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgaAJgPQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgEQgGAKAAAWQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgwQgGgPgMAAQgKAAgGALgAgFgtIAFghIAQAAIgLAhg");
	this.shape_301.setTransform(1226,472.9);

	this.shape_302 = new cjs.Shape();
	this.shape_302.graphics.f("#39454A").s().p("AATAuQgFgHAAgNIAAg/IgeAAIAABZIgRAAIAAhZIgNAAIAAgPIBZAAIAAAPIgMAAIAAA+QAAAHACADQACADAFAAQAFAAACgBIAAAPQgFABgHAAQgKAAgGgHg");
	this.shape_302.setTransform(1215.6,475.4);

	this.shape_303 = new cjs.Shape();
	this.shape_303.graphics.f("#39454A").s().p("AgGA1IgfhpIASAAIATBOIAUhOIASAAIgfBpg");
	this.shape_303.setTransform(1201.5,475.3);

	this.shape_304 = new cjs.Shape();
	this.shape_304.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_304.setTransform(1192.6,475.3);

	this.shape_305 = new cjs.Shape();
	this.shape_305.graphics.f("#39454A").s().p("AgfAnQgLgPAAgYIAAgBQAAgXALgOQAKgPATAAIAtAAIAAAPIgWAAQAPAPAAAZIAAACQAAANgFAMQgFAMgJAGQgJAHgKAAQgTAAgKgPgAgTgcQgGAKAAASQAAASAGAKQAGALALAAQAJAAAGgKQAGgLAAgTQAAgRgGgKQgGgKgKAAQgKAAgGAKg");
	this.shape_305.setTransform(1182.7,475.4);

	this.shape_306 = new cjs.Shape();
	this.shape_306.graphics.f("#39454A").s().p("AgLAuQgEgHgBgOIAAhNIAQAAIAABPQABALAIAAQAFAAACgBIAAAPQgFABgHAAQgJAAgGgHg");
	this.shape_306.setTransform(1170.3,475.4);

	this.shape_307 = new cjs.Shape();
	this.shape_307.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_307.setTransform(1162.1,475.3);

	this.shape_308 = new cjs.Shape();
	this.shape_308.graphics.f("#39454A").s().p("AgIAaIAAhAIgcAAIAAgPIBJAAIAAAPIgdAAIAAA/QAAANAHAAQAEAAAEgCIAEANQgHAFgJAAQgTAAAAgcg");
	this.shape_308.setTransform(1152.2,475.4);

	this.shape_309 = new cjs.Shape();
	this.shape_309.graphics.f("#39454A").s().p("AgaAuQgKgIAAgPQAAgSAQgGQgHgDgEgGQgEgGAAgHQAAgPAKgIQAJgIAQAAQAPAAALAJQAKAJAAAOIgSAAQAAgHgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAHQAAAQASAAIAQAAIAAANIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJg");
	this.shape_309.setTransform(1143,475.3);

	this.shape_310 = new cjs.Shape();
	this.shape_310.graphics.f("#39454A").s().p("AAHBRQAIgJAAgIQAAgHgNgEIgFgCQgOgEgGgIQgFgIAAgQQAAgNAGgPQAHgQAKgOIAWgfIgzAAIAAgPIBFAAIAAAMIgbApQgLASgEALQgEAKAAAMQAAAJACAFQADAEAFADIASAGQAIADADAEQAEAEAAAIQgBAHgFAIQgEAIgGAGg");
	this.shape_310.setTransform(1133.7,475.4);

	this.shape_311 = new cjs.Shape();
	this.shape_311.graphics.f("#39454A").s().p("AgKBGQgGgHAAgOIAAhNIAQAAIAABPQABALAIAAQAFAAADgBIAAAPQgGABgHAAQgJAAgFgHgAgNgrIAFghIAQAAIgKAhg");
	this.shape_311.setTransform(1126.5,473);

	this.shape_312 = new cjs.Shape();
	this.shape_312.graphics.f("#39454A").s().p("AgFA1IgghpIARAAIAVBOIAUhOIARAAIggBpg");
	this.shape_312.setTransform(1118.7,475.3);

	this.shape_313 = new cjs.Shape();
	this.shape_313.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_313.setTransform(1109.8,475.3);

	this.shape_314 = new cjs.Shape();
	this.shape_314.graphics.f("#39454A").s().p("AgIBMIAAgtQgVgDgMgOQgLgOAAgYQAAgjAUgQIAKANQgMAMgBAaQAAAQAHAKQAHAMANACIAAhFQAAgKAFgGQAFgGAKAAQALAAAKAHQAJAGAGANQAFAMAAAOQAAAXgLAOQgMAOgWADIAAAtgAAIg0IAABEQANgDAIgKQAHgKAAgQQAAgRgHgKQgGgKgLAAQgEAAAAAIg");
	this.shape_314.setTransform(1098.4,477.7);

	this.shape_315 = new cjs.Shape();
	this.shape_315.graphics.f("#39454A").s().p("AgjBJIAAiRIASAAIAAA+QAAAPADAIQAFAHAIAAQANAAAGgOIAAhOIARAAIAABpIgPAAIgBgKQgHAMgMgBQgLAAgGgGIAAAtg");
	this.shape_315.setTransform(1087.3,477.4);

	this.shape_316 = new cjs.Shape();
	this.shape_316.graphics.f("#39454A").s().p("AgaAuQgKgIAAgPQAAgSAQgGQgHgDgEgGQgEgGAAgHQAAgPAKgIQAJgIAQAAQAPAAALAJQAKAJAAAOIgSAAQAAgHgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAHQAAAQASAAIAQAAIAAANIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJg");
	this.shape_316.setTransform(1077.6,475.3);

	this.shape_317 = new cjs.Shape();
	this.shape_317.graphics.f("#39454A").s().p("AgMASQAIgNABgNIAAgQIARAAIAAAOQgBAKgEAJQgFAKgHAGg");
	this.shape_317.setTransform(1066,481);

	this.shape_318 = new cjs.Shape();
	this.shape_318.graphics.f("#39454A").s().p("AgcBCQgMgNAAgWIAAgMQAAgWALgNQALgOASAAQASAAALANQALANABAWIAAALQAAAXgLANQgLAOgTAAQgRAAgLgNgAgQgGQgHAJAAAQIAAAKQAAAQAHAKQAGAJAKAAQAXAAAAghIAAgMQAAgQgGgJQgGgJgLAAQgKAAgGAJgAgHgtIAGghIAPAAIgLAhg");
	this.shape_318.setTransform(1059.3,472.9);

	this.shape_319 = new cjs.Shape();
	this.shape_319.graphics.f("#39454A").s().p("AglBKIAAhgQAAgPAEgMQAGgLAIgHQAJgGAKAAQARAAAKAPQALAPAAAdQAAAWgJAOQgJAOgRgBQgOAAgIgKIAAAxgAgPgvQgEAKAAARIAAAbQAFAOAOAAQAJgBAGgIQAGgKgBgTQABgTgGgLQgFgLgKAAQgJAAgGALg");
	this.shape_319.setTransform(1049.5,477.3);

	this.shape_320 = new cjs.Shape();
	this.shape_320.graphics.f("#39454A").s().p("AgaAuQgKgIAAgPQAAgSAQgGQgHgDgEgGQgEgGAAgHQAAgPAKgIQAJgIAQAAQAPAAALAJQAKAJAAAOIgSAAQAAgHgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAHQAAAQASAAIAQAAIAAANIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJg");
	this.shape_320.setTransform(1039.6,475.3);

	this.shape_321 = new cjs.Shape();
	this.shape_321.graphics.f("#39454A").s().p("AgFA1IgghpIARAAIAVBOIAUhOIARAAIggBpg");
	this.shape_321.setTransform(1030.6,475.3);

	this.shape_322 = new cjs.Shape();
	this.shape_322.graphics.f("#39454A").s().p("AgcAqQgMgNAAgWIAAgLQAAgXALgNQALgOASAAQASAAALANQALANABAXIAAAKQAAAXgLANQgLAOgTAAQgRAAgLgNgAgQgeQgHAKAAAQIAAAJQAAAQAHAKQAGAJAKAAQAXAAAAghIAAgLQAAgQgGgKQgGgJgLAAQgKAAgGAJg");
	this.shape_322.setTransform(1232.3,451.3);

	this.shape_323 = new cjs.Shape();
	this.shape_323.graphics.f("#39454A").s().p("AgIAaIAAhAIgcAAIAAgPIBJAAIAAAPIgdAAIAAA/QAAANAHAAQAEAAAEgCIAEANQgHAFgJAAQgTAAAAgcg");
	this.shape_323.setTransform(1222.7,451.4);

	this.shape_324 = new cjs.Shape();
	this.shape_324.graphics.f("#39454A").s().p("AgMASQAIgNABgMIAAgRIARAAIAAAPQgBAJgEAJQgFAKgGAGg");
	this.shape_324.setTransform(1211.2,457);

	this.shape_325 = new cjs.Shape();
	this.shape_325.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_325.setTransform(1204.9,451.3);

	this.shape_326 = new cjs.Shape();
	this.shape_326.graphics.f("#39454A").s().p("AgiBJIAAiRIARAAIAAA/QAAAOADAHQAFAIAIAAQANAAAGgOIAAhOIASAAIAABoIgQAAIgBgKQgHANgMAAQgMAAgFgHIAAAtg");
	this.shape_326.setTransform(1194.7,453.4);

	this.shape_327 = new cjs.Shape();
	this.shape_327.graphics.f("#39454A").s().p("AAAA3QgGAXgTAAQgRAAgIgPQgJgOAAgcQABgbAKgXIATAAQgMAbgBAXQABAUAEALQAFALAHAAQAIAAAEgIQAFgIAAgQIAAgeIARAAIAAAeQAAAQAEAIQAEAIAJAAQAHAAAFgLQAEgLAAgUQgBgXgLgbIASAAQAMAXAAAbQAAAcgJAOQgJAPgPAAQgUAAgHgXgAgGgsIAGghIAQAAIgMAhg");
	this.shape_327.setTransform(1182.6,449);

	this.shape_328 = new cjs.Shape();
	this.shape_328.graphics.f("#39454A").s().p("AgfAnQgLgPAAgYIAAgBQAAgXALgOQAKgPATAAIAtAAIAAAPIgWAAQAPAPAAAZIAAACQAAANgFAMQgFAMgJAGQgJAHgKAAQgTAAgKgPgAgTgcQgGAKAAASQAAASAGAKQAGALALAAQAJAAAGgKQAGgLAAgTQAAgRgGgKQgGgKgKAAQgKAAgGAKg");
	this.shape_328.setTransform(1170.8,451.4);

	this.shape_329 = new cjs.Shape();
	this.shape_329.graphics.f("#39454A").s().p("AAHA/IAHgJIABgIQAAgEgDgCQgDgDgGgCQglgJgCgkIAAgJQAAgOAFgNQAEgLAKgIQAIgGALAAQAPAAALAKQAJAKAAATIgQAAQAAgMgGgGQgEgGgJgBQgJAAgGALQgGALAAARIAAAEQAAAYAYAKIAMAEQAHADAEAEQADAFAAAHQAAAHgEAIQgEAIgHAGg");
	this.shape_329.setTransform(1156.2,453.1);

	this.shape_330 = new cjs.Shape();
	this.shape_330.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_330.setTransform(1146.8,451.3);

	this.shape_331 = new cjs.Shape();
	this.shape_331.graphics.f("#39454A").s().p("AgjBJIAAiRIARAAIAAA/QAAAOAFAHQADAIAJAAQANAAAGgOIAAhOIARAAIAABoIgPAAIgBgKQgHANgMAAQgLAAgHgHIAAAtg");
	this.shape_331.setTransform(1136.6,453.4);

	this.shape_332 = new cjs.Shape();
	this.shape_332.graphics.f("#39454A").s().p("AgcBCQgMgNAAgWIAAgMQAAgWALgNQALgOASAAQASAAALANQALANABAWIAAALQAAAXgLANQgLAOgTAAQgRAAgLgNgAgQgGQgHAJAAAQIAAAKQAAAQAHAKQAGAJAKAAQAXAAAAghIAAgMQAAgQgGgJQgGgJgLAAQgKAAgGAJgAgHgtIAGghIAPAAIgLAhg");
	this.shape_332.setTransform(1122,448.9);

	this.shape_333 = new cjs.Shape();
	this.shape_333.graphics.f("#39454A").s().p("AgjBJIAAiRIASAAIAAA/QAAAOADAHQAFAIAIAAQANAAAGgOIAAhOIARAAIAABoIgPAAIgBgKQgHANgMAAQgLAAgGgHIAAAtg");
	this.shape_333.setTransform(1112,453.4);

	this.shape_334 = new cjs.Shape();
	this.shape_334.graphics.f("#39454A").s().p("AgLAuQgEgHAAgOIAAhNIAQAAIAABPQAAALAJAAQAEAAADgBIAAAPQgGABgHAAQgJAAgGgHg");
	this.shape_334.setTransform(1104.5,451.4);

	this.shape_335 = new cjs.Shape();
	this.shape_335.graphics.f("#39454A").s().p("AglBKIAAhgQAAgQAFgLQAEgMAJgGQAIgGALAAQARAAAKAPQALAPAAAdQAAAWgJANQgKAPgPAAQgOAAgKgLIAAAxgAgOgwQgGALAAAQIAAAcQAHANAMABQAKAAAGgJQAFgKABgSQgBgVgFgLQgGgLgJAAQgJAAgFALg");
	this.shape_335.setTransform(1096.2,453.3);

	this.shape_336 = new cjs.Shape();
	this.shape_336.graphics.f("#39454A").s().p("AAAA3QgGAXgTAAQgRAAgIgPQgJgOAAgcQABgbAKgXIASAAQgKAbgCAXQABAUAEALQAEALAIAAQAIAAAEgIQAFgIAAgQIAAgeIARAAIAAAeQgBAQAFAIQAEAIAJAAQAHAAAFgLQAEgLAAgUQgBgXgLgbIASAAQALAXAAAbQABAcgJAOQgJAPgPAAQgUAAgHgXgAgGgsIAGghIAPAAIgLAhg");
	this.shape_336.setTransform(1083.9,449);

	this.shape_337 = new cjs.Shape();
	this.shape_337.graphics.f("#39454A").s().p("AgGA1IgfhpIASAAIATBOIAUhOIASAAIgfBpg");
	this.shape_337.setTransform(1072.5,451.3);

	this.shape_338 = new cjs.Shape();
	this.shape_338.graphics.f("#39454A").s().p("AgIBJIAAgwIgehhIASAAIAUBKIAVhKIASAAIgfBiIAAAvg");
	this.shape_338.setTransform(1063.9,453.4);

	this.shape_339 = new cjs.Shape();
	this.shape_339.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_339.setTransform(1050.1,451.3);

	this.shape_340 = new cjs.Shape();
	this.shape_340.graphics.f("#39454A").s().p("AgGA1IgfhpIASAAIATBOIAUhOIASAAIgfBpg");
	this.shape_340.setTransform(1040.6,451.3);

	this.shape_341 = new cjs.Shape();
	this.shape_341.graphics.f("#39454A").s().p("AgVBOIAAiNIBLAAIAAAPIg5AAIAAAuIAyAAIAAAPIgyAAIAAAxIA6AAIAAAQgAg2gsIAFghIASAAIgMAhg");
	this.shape_341.setTransform(1030.1,448.8);

	this.shape_342 = new cjs.Shape();
	this.shape_342.graphics.f("#39454A").s().p("AgdBEQgJgLAAgUIAAhBIAbAAIAABAQAAAUAIAAQAGAAAEgKQAFgKAAgPQgBgWgHgbIAaAAQAJAWAAAbQAAAcgLAPQgLAPgTAAQgSAAgJgLgAgKgsIAHgiIAZAAIgQAig");
	this.shape_342.setTransform(1103.4,424.9);

	this.shape_343 = new cjs.Shape();
	this.shape_343.graphics.f("#39454A").s().p("AgfApQgLgOAAgYIAAgFQAAgZALgNQAMgOATAAQAUAAALAOQAMANAAAZIAAAFQAAAZgMANQgLAOgUAAQgTAAgMgOgAgKgYQgEAHAAAPIAAAFQAAAdAOAAQAOAAABgYIAAgKQAAgPgEgHQgEgHgHAAQgGAAgEAHg");
	this.shape_343.setTransform(1093.4,427.3);

	this.shape_344 = new cjs.Shape();
	this.shape_344.graphics.f("#39454A").s().p("AgoBKIAAhfQAAgZALgNQAMgOASAAQATAAAKAPQALAOAAAcQAAAXgJAOQgJAOgQABQgMAAgHgKIAAAwgAgJgqQgDAIAAAQIAAAYQAEAHAIgBQANAAABgaIAAgDQAAgRgEgIQgEgIgGAAQgGAAgDAIg");
	this.shape_344.setTransform(1083.6,429.3);

	this.shape_345 = new cjs.Shape();
	this.shape_345.graphics.f("#39454A").s().p("AgcAuQgMgJAAgOQAAgSARgGQgHgDgEgGQgEgGAAgHQAAgOALgJQALgIASAAQAQAAALAJQAKAJAAAPIgbAAQAAgGgDgCQgEgDgFAAQgEAAgEADQgDADAAAFQAAAFADADQAEADAEAAIAQAAIAAASIgQAAQgMAAAAANQAAAFADAEQAEADAFAAQAGAAAEgDQADgDAAgFIAcAAQAAAPgLAJQgLAJgRAAQgSAAgMgJg");
	this.shape_345.setTransform(1073.8,427.3);

	this.shape_346 = new cjs.Shape();
	this.shape_346.graphics.f("#39454A").s().p("AgMA1IgdhpIAdAAIAMBCIANhCIAdAAIgdBpg");
	this.shape_346.setTransform(1064.2,427.3);

	this.shape_347 = new cjs.Shape();
	this.shape_347.graphics.f("#39454A").s().p("AgdArQgJgLAAgUIAAhBIAbAAIAAA/QAAAVAIAAQAGAAAEgKQAFgKAAgOQgBgXgHgbIAaAAQAJAWAAAcQAAAbgLAPQgLAPgTAAQgSAAgJgLg");
	this.shape_347.setTransform(1050.5,427.4);

	this.shape_348 = new cjs.Shape();
	this.shape_348.graphics.f("#39454A").s().p("AgfApQgLgOAAgYIAAgFQAAgZALgNQAMgOATAAQAUAAALAOQAMANAAAZIAAAFQAAAZgMANQgLAOgUAAQgTAAgMgOgAgKgYQgEAHAAAPIAAAFQAAAdAOAAQAOAAABgYIAAgKQAAgPgEgHQgEgHgHAAQgGAAgEAHg");
	this.shape_348.setTransform(1040.5,427.3);

	this.shape_349 = new cjs.Shape();
	this.shape_349.graphics.f("#39454A").s().p("AgGAtQgIgJABgRIAAgxIgbAAIAAgXIBRAAIAAAXIgcAAIAAAyQAAAGABACQACADADAAQADAAAFgCIADAWQgHADgKAAQgNAAgGgJg");
	this.shape_349.setTransform(1031,427.4);

	this.shape_350 = new cjs.Shape();
	this.shape_350.graphics.f("#39454A").s().p("AgBA9QAGgJAAgIQAAgGgHgDQgSgGgKgMQgIgLgBgTIAAgFQAAgYAMgOQALgPASAAQARAAAKALQALALgBAUIgZAAQAAgTgMAAQgLAAgCAZIAAAIQAAAMAEAGQAEAGAJAEQANAEAEADQAFAEACADQACAFAAAGQAAAJgFAJQgHAKgIAGg");
	this.shape_350.setTransform(1126.1,405.1);

	this.shape_351 = new cjs.Shape();
	this.shape_351.graphics.f("#39454A").s().p("AgUAWIAAhKIAbAAIgBBHQAAAGACADQACACAFAAIAGgBIAAAWQgHACgIAAQgaAAAAgfg");
	this.shape_351.setTransform(1118.7,403.4);

	this.shape_352 = new cjs.Shape();
	this.shape_352.graphics.f("#39454A").s().p("AgcAuQgMgJAAgOQAAgSARgGQgHgDgEgGQgEgGAAgHQAAgOALgJQALgIASAAQAQAAALAJQAKAJAAAPIgbAAQAAgGgDgCQgEgDgFAAQgEAAgEADQgDADAAAFQAAAFADADQAEADAEAAIAQAAIAAASIgQAAQgMAAAAANQAAAFADAEQAEADAFAAQAGAAAEgDQADgDAAgFIAcAAQAAAPgLAJQgLAJgRAAQgSAAgMgJg");
	this.shape_352.setTransform(1110.6,403.3);

	this.shape_353 = new cjs.Shape();
	this.shape_353.graphics.f("#39454A").s().p("AghAnQgLgOAAgZIAAgBQAAgYALgOQALgOAVAAIAuAAIAAAXIgVAAQAOAOAAAUQAAAXgKANQgMAOgRAAQgUAAgMgPgAgQgDIAAADQAAAfAPAAQAKAAABgZIABgHQAAgPgDgHQgEgHgFAAQgPAAAAAbg");
	this.shape_353.setTransform(1100.7,403.4);

	this.shape_354 = new cjs.Shape();
	this.shape_354.graphics.f("#39454A").s().p("AAMBAQgHAPgNAAQgRAAgJgOQgKgOAAgaQAAgZAKgOQAJgPARAAQALAAAHAMIACgKIAZAAIAABHQgBAMAGAAIABgBIACAWQgFACgGAAQgQAAgGgPgAgMABQgDAIgBASQABAPADAHQADAHAIAAQAGAAAEgGIAAgyQgEgGgGAAQgHAAgEAHgAgIgsIAHgiIAYAAIgPAig");
	this.shape_354.setTransform(1090.8,400.9);

	this.shape_355 = new cjs.Shape();
	this.shape_355.graphics.f("#39454A").s().p("AgGAtQgIgJAAgRIAAgxIgaAAIAAgXIBRAAIAAAXIgcAAIAAAyQAAAGABACQACADADAAQADAAAFgCIADAWQgHADgKAAQgNAAgGgJg");
	this.shape_355.setTransform(1081,403.4);

	this.shape_356 = new cjs.Shape();
	this.shape_356.graphics.f("#39454A").s().p("AghAnQgLgOAAgZIAAgBQAAgYALgOQALgOAVAAIAuAAIAAAXIgVAAQAOAOAAAUQAAAXgLANQgLAOgRAAQgUAAgMgPgAgRgDIAAADQABAfAPAAQALAAAAgZIABgHQAAgPgDgHQgEgHgFAAQgPAAgBAbg");
	this.shape_356.setTransform(1071.5,403.4);

	this.shape_357 = new cjs.Shape();
	this.shape_357.graphics.f("#39454A").s().p("AAMAoQgHAPgNAAQgRAAgJgOQgKgOAAgaQAAgZAKgPQAJgPARAAQALAAAHANIACgLIAYAAIAABIQAAALAGAAIABAAIABAVQgEADgGAAQgPAAgHgPgAgMgXQgEAIAAASQAAAPAEAHQADAHAIAAQAGAAAEgHIAAgwQgEgIgGAAQgIAAgDAIg");
	this.shape_357.setTransform(1061.6,403.3);

	this.shape_358 = new cjs.Shape();
	this.shape_358.graphics.f("#39454A").s().p("AgGAtQgIgJAAgRIAAgxIgaAAIAAgXIBRAAIAAAXIgcAAIAAAyQAAAGABACQACADADAAQAEAAAEgCIACAWQgGADgKAAQgNAAgGgJg");
	this.shape_358.setTransform(1051.9,403.4);

	this.shape_359 = new cjs.Shape();
	this.shape_359.graphics.f("#39454A").s().p("AANAoQgJAPgNAAQgPAAgKgOQgKgOAAgaQAAgZAKgPQAKgPAPAAQAMAAAIANIACgLIAXAAIAABIQABALAEAAIABAAIACAVQgEADgHAAQgPAAgFgPgAgMgXQgDAIAAASQAAAPADAHQAEAHAGAAQAHAAAEgHIAAgwQgEgIgGAAQgHAAgEAIg");
	this.shape_359.setTransform(1042.6,403.3);

	this.shape_360 = new cjs.Shape();
	this.shape_360.graphics.f("#39454A").s().p("AAQBHIgZg3IgMAOIAAApIgcAAIAAiNIAcAAIAAA+IAJgPIAagvIAjAAIgoA/IApBOg");
	this.shape_360.setTransform(1032.5,401.5);

	this.shape_361 = new cjs.Shape();
	this.shape_361.graphics.f("#39454A").s().p("AgHAIQgDgDAAgFQAAgDADgEQACgDAFAAQAGAAACADQADAEAAADQAAAFgDADQgCADgGAAQgFAAgCgDg");
	this.shape_361.setTransform(1216.4,359.6);

	this.shape_362 = new cjs.Shape();
	this.shape_362.graphics.f("#39454A").s().p("AAIBAIAGgKIABgIQAAgFgDgCQgDgCgHgBQgkgKgCgkIAAgIQAAgPAEgMQAGgMAJgIQAIgGALAAQAPAAAKAKQAKALAAARIgRAAQAAgLgEgGQgGgHgIAAQgJAAgGAMQgGAKAAASIAAACQAAAaAYAJIAMAEQAHACAEAFQADAFAAAIQABAGgFAIQgFAIgFAGg");
	this.shape_362.setTransform(1209.1,357.1);

	this.shape_363 = new cjs.Shape();
	this.shape_363.graphics.f("#39454A").s().p("AATBKIAAhrQAAgNgEgGQgFgHgKAAQgMAAgGAPIAABOIgRAAIAAhpIAQAAIAAAMQALgOAOAAQAPAAAHAKQAIAJAAATIAABtg");
	this.shape_363.setTransform(1199.4,357.3);

	this.shape_364 = new cjs.Shape();
	this.shape_364.graphics.f("#39454A").s().p("AAKBTQAGgHABgDQACgEAAgEQAAgEgDgCQgDgCgKgDQgJgDgGgDQgWgKAAgdQAAgOAHgJQAHgKAMgEQgJgFgGgHQgGgHAAgKQAAgPALgJQALgJASAAQANAAAIADIgDAPQgKgEgIAAQgLAAgFAGQgGAFAAAIQAAAVAZAAIALAAIAAAPIgMAAQgOAAgIAIQgHAHAAAPQAAALAFAIQAFAIAJADIAIACQAMADAEADQAEACACAEQACAEAAAGQAAAGgEAIQgFAIgGAGg");
	this.shape_364.setTransform(1190.3,355.3);

	this.shape_365 = new cjs.Shape();
	this.shape_365.graphics.f("#39454A").s().p("AATBiIAAhrQAAgNgEgGQgFgHgKAAQgMAAgFAPIAABOIgSAAIAAhpIAQAAIABAMQAKgOAOAAQAPAAAHAKQAIAJAAATIAABtgAgGhBIAGggIAQAAIgMAgg");
	this.shape_365.setTransform(1180.9,354.9);

	this.shape_366 = new cjs.Shape();
	this.shape_366.graphics.f("#39454A").s().p("AATAuQgFgHAAgNIAAg/IgeAAIAABZIgRAAIAAhZIgNAAIAAgPIBZAAIAAAPIgMAAIAAA+QAAAHACADQACADAFAAQAFAAACgBIAAAPQgFABgHAAQgKAAgGgHg");
	this.shape_366.setTransform(1170.7,355.4);

	this.shape_367 = new cjs.Shape();
	this.shape_367.graphics.f("#39454A").s().p("AgLAuQgEgHAAgOIAAhNIAQAAIAABPQAAALAJAAQAEAAACgBIAAAPQgFABgHAAQgJAAgGgHg");
	this.shape_367.setTransform(1158.4,355.4);

	this.shape_368 = new cjs.Shape();
	this.shape_368.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_368.setTransform(1150.3,355.3);

	this.shape_369 = new cjs.Shape();
	this.shape_369.graphics.f("#39454A").s().p("AARA1IgegtIgIAAIAAAtIgRAAIAAhpIARAAIAAAtIAGAAIAfgtIAUAAIgkAzIAnA2g");
	this.shape_369.setTransform(1140.5,355.3);

	this.shape_370 = new cjs.Shape();
	this.shape_370.graphics.f("#39454A").s().p("AAIBAIAGgKIABgIQAAgFgDgCQgDgCgHgBQgkgKgCgkIAAgIQAAgPAEgMQAGgMAJgIQAIgGALAAQAPAAAKAKQAKALAAARIgRAAQAAgLgEgGQgGgHgIAAQgJAAgGAMQgGAKAAASIAAACQAAAaAYAJIAMAEQAHACAEAFQADAFAAAIQABAGgFAIQgFAIgFAGg");
	this.shape_370.setTransform(1125.9,357.1);

	this.shape_371 = new cjs.Shape();
	this.shape_371.graphics.f("#39454A").s().p("AATBKIAAhrQAAgNgEgGQgFgHgKAAQgMAAgGAPIAABOIgRAAIAAhpIAQAAIAAAMQALgOAOAAQAPAAAHAKQAIAJAAATIAABtg");
	this.shape_371.setTransform(1116.2,357.3);

	this.shape_372 = new cjs.Shape();
	this.shape_372.graphics.f("#39454A").s().p("AgfAnQgLgPAAgYIAAgBQAAgXALgOQAKgPATAAIAtAAIAAAPIgWAAQAPAPAAAZIAAACQAAANgFAMQgFAMgJAGQgJAHgKAAQgTAAgKgPgAgTgcQgGAKAAASQAAASAGAKQAGALALAAQAJAAAGgKQAGgLAAgTQAAgRgGgKQgGgKgKAAQgKAAgGAKg");
	this.shape_372.setTransform(1106.6,355.4);

	this.shape_373 = new cjs.Shape();
	this.shape_373.graphics.f("#39454A").s().p("AATBKIAAhrQAAgNgEgGQgFgHgKAAQgMAAgFAPIAABOIgSAAIAAhpIAQAAIABAMQAKgOAOAAQAPAAAHAKQAIAJAAATIAABtg");
	this.shape_373.setTransform(1096.3,357.3);

	this.shape_374 = new cjs.Shape();
	this.shape_374.graphics.f("#39454A").s().p("AgKBGQgFgHgBgOIAAhNIAQAAIAABPQABALAIAAQAFAAACgBIAAAPQgFABgHAAQgJAAgFgHgAgNgrIAFghIAQAAIgKAhg");
	this.shape_374.setTransform(1088.8,353);

	this.shape_375 = new cjs.Shape();
	this.shape_375.graphics.f("#39454A").s().p("AgcAqQgMgNAAgWIAAgLQAAgXALgNQALgOASAAQASAAALANQALANABAXIAAAKQAAAXgLANQgLAOgTAAQgRAAgLgNgAgQgeQgHAKAAAQIAAAJQAAAQAHAKQAGAJAKAAQAXAAAAghIAAgLQAAgQgGgKQgGgJgLAAQgKAAgGAJg");
	this.shape_375.setTransform(1080.3,355.3);

	this.shape_376 = new cjs.Shape();
	this.shape_376.graphics.f("#39454A").s().p("AATAuQgFgHAAgNIAAg/IgeAAIAABZIgRAAIAAhZIgNAAIAAgPIBZAAIAAAPIgMAAIAAA+QAAAHACADQACADAFAAQAFAAACgBIAAAPQgFABgHAAQgKAAgGgHg");
	this.shape_376.setTransform(1070.1,355.4);

	this.shape_377 = new cjs.Shape();
	this.shape_377.graphics.f("#39454A").s().p("AgcAqQgMgNAAgWIAAgLQAAgXALgNQALgOASAAQASAAALANQALANABAXIAAAKQAAAXgLANQgLAOgTAAQgRAAgLgNgAgQgeQgHAKAAAQIAAAJQAAAQAHAKQAGAJAKAAQAXAAAAghIAAgLQAAgQgGgKQgGgJgLAAQgKAAgGAJg");
	this.shape_377.setTransform(1059.8,355.3);

	this.shape_378 = new cjs.Shape();
	this.shape_378.graphics.f("#39454A").s().p("AglBKIAAhgQAAgPAEgMQAGgMAIgGQAJgGAKAAQARAAAKAPQALAPAAAcQAAAXgJANQgJAOgRABQgNAAgJgLIAAAxgAgPgvQgEAKAAARIAAAcQAFANANgBQAKABAGgKQAFgJAAgTQAAgUgFgKQgGgMgJAAQgJAAgGAMg");
	this.shape_378.setTransform(1050,357.3);

	this.shape_379 = new cjs.Shape();
	this.shape_379.graphics.f("#39454A").s().p("AgIBJIAAgwIgehhIASAAIAUBKIAVhKIASAAIgfBiIAAAvg");
	this.shape_379.setTransform(1040.5,357.4);

	this.shape_380 = new cjs.Shape();
	this.shape_380.graphics.f("#39454A").s().p("AgbArQgIgLAAgVIAAhAIARAAIAAA+QAAAeAPAAQAJAAAGgMQAHgNAAgQQAAgWgKgdIASAAQAJAXABAcQAAAZgLAPQgLAQgRAAQgRAAgIgLg");
	this.shape_380.setTransform(1031.4,355.4);

	this.shape_381 = new cjs.Shape();
	this.shape_381.graphics.f("#39454A").s().p("AgMASQAIgNABgNIAAgQIARAAIAAAOQgBAKgEAJQgFAKgGAGg");
	this.shape_381.setTransform(1188.7,337);

	this.shape_382 = new cjs.Shape();
	this.shape_382.graphics.f("#39454A").s().p("AgbBDQgIgLAAgVIAAhAIARAAIAAA+QAAAeAPAAQAJAAAGgMQAHgNAAgRQAAgVgKgdIASAAQAKAXAAAbQgBAagKAPQgLAQgSAAQgPAAgJgLgAgJgsIAFghIAQAAIgLAhg");
	this.shape_382.setTransform(1182.5,329);

	this.shape_383 = new cjs.Shape();
	this.shape_383.graphics.f("#39454A").s().p("AgcAqQgMgNAAgWIAAgLQAAgXALgNQALgOASAAQASAAALANQALANABAXIAAAKQAAAXgLANQgLAOgTAAQgRAAgLgNgAgQgeQgHAKAAAQIAAAJQAAAQAHAKQAGAJAKAAQAXAAAAghIAAgLQAAgQgGgKQgGgJgLAAQgKAAgGAJg");
	this.shape_383.setTransform(1172.4,331.3);

	this.shape_384 = new cjs.Shape();
	this.shape_384.graphics.f("#39454A").s().p("AgiBJIAAiRIAQAAIAAA+QAAAPAEAIQAEAHAJAAQAOAAAFgOIAAhOIASAAIAABpIgQAAIgBgKQgHAMgMgBQgMAAgGgGIAAAtg");
	this.shape_384.setTransform(1162.5,333.4);

	this.shape_385 = new cjs.Shape();
	this.shape_385.graphics.f("#39454A").s().p("AgfAnQgLgPAAgYIAAgBQAAgXALgOQAKgPATAAIAtAAIAAAPIgWAAQAPAPAAAZIAAACQAAANgFAMQgFAMgJAGQgJAHgKAAQgTAAgKgPgAgTgcQgGAKAAASQAAASAGAKQAGALALAAQAJAAAGgKQAGgLAAgTQAAgRgGgKQgGgKgKAAQgKAAgGAKg");
	this.shape_385.setTransform(1152.8,331.4);

	this.shape_386 = new cjs.Shape();
	this.shape_386.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_386.setTransform(1142.9,331.3);

	this.shape_387 = new cjs.Shape();
	this.shape_387.graphics.f("#39454A").s().p("AglBKIAAhgQAAgPAEgMQAGgLAIgHQAJgGAKAAQARAAAKAPQALAPAAAdQAAAWgJAOQgKAOgPgBQgPAAgIgKIAAAxgAgPgvQgEAKAAARIAAAbQAFAOAOAAQAJgBAGgIQAGgKgBgTQABgTgGgLQgGgLgJAAQgJAAgGALg");
	this.shape_387.setTransform(1132.8,333.3);

	this.shape_388 = new cjs.Shape();
	this.shape_388.graphics.f("#39454A").s().p("AgmBbIAAiOQAAgKAFgJQAFgJAJgGQAIgFAKAAQAPAAAKALQAKAKAAARQAAAJgEAIQgEAHgIAFQALAEAEAKQAGAJAAAMQAAAUgKALQgLAMgQAAQgNAAgKgIIAAAsgAgPhEQgFAHgBALIAABQQAHAKAOAAQAKAAAGgHQAGgIAAgNQAAgLgGgHQgFgJgHAAIgMAAIAAgPIAHAAQAIAAAGgFQAEgGAAgLQAAgKgFgHQgGgGgHAAQgIAAgGAHg");
	this.shape_388.setTransform(1122.7,331.3);

	this.shape_389 = new cjs.Shape();
	this.shape_389.graphics.f("#39454A").s().p("AgMASQAIgNABgNIAAgQIARAAIAAAOQgBAKgEAJQgFAKgGAGg");
	this.shape_389.setTransform(1110.4,337);

	this.shape_390 = new cjs.Shape();
	this.shape_390.graphics.f("#39454A").s().p("AAIA/IAGgJIABgIQAAgEgDgDQgDgCgHgBQgkgLgCgjIAAgIQAAgPAFgMQAEgNAJgGQAKgHAKAAQAPAAAKAKQAKAKAAASIgRAAQAAgLgEgGQgGgHgIABQgJAAgGALQgGAKAAARIAAADQAAAZAYAKIAMAEQAHACAEAFQAEAFAAAIQAAAGgFAIQgFAJgFAFg");
	this.shape_390.setTransform(1104,333.1);

	this.shape_391 = new cjs.Shape();
	this.shape_391.graphics.f("#39454A").s().p("AATBKIAAhrQAAgOgFgFQgDgHgLABQgLAAgHAOIAABOIgRAAIAAhpIAPAAIABAMQAKgOAPAAQAPAAAIAJQAHAKAAATIAABtg");
	this.shape_391.setTransform(1094.3,333.3);

	this.shape_392 = new cjs.Shape();
	this.shape_392.graphics.f("#39454A").s().p("AgfAnQgLgPAAgYIAAgBQAAgXALgOQAKgPATAAIAtAAIAAAPIgWAAQAPAPAAAZIAAACQAAANgFAMQgFAMgJAGQgJAHgKAAQgTAAgKgPgAgTgcQgGAKAAASQAAASAGAKQAGALALAAQAJAAAGgKQAGgLAAgTQAAgRgGgKQgGgKgKAAQgKAAgGAKg");
	this.shape_392.setTransform(1084.7,331.4);

	this.shape_393 = new cjs.Shape();
	this.shape_393.graphics.f("#39454A").s().p("AgKAuQgGgHAAgOIAAhNIAQAAIAABPQABALAIAAQAFAAADgBIAAAPQgGABgHAAQgJAAgFgHg");
	this.shape_393.setTransform(1076.9,331.4);

	this.shape_394 = new cjs.Shape();
	this.shape_394.graphics.f("#39454A").s().p("AgjBJIAAiRIARAAIAAA+QAAAPAFAIQAEAHAIAAQANAAAGgOIAAhOIARAAIAABpIgPAAIgBgKQgHAMgMgBQgLAAgHgGIAAAtg");
	this.shape_394.setTransform(1068.5,333.4);

	this.shape_395 = new cjs.Shape();
	this.shape_395.graphics.f("#39454A").s().p("AgIAaIAAhAIgcAAIAAgPIBJAAIAAAPIgdAAIAAA/QAAANAHAAQAEAAAEgCIAEANQgHAFgJAAQgTAAAAgcg");
	this.shape_395.setTransform(1058.8,331.4);

	this.shape_396 = new cjs.Shape();
	this.shape_396.graphics.f("#39454A").s().p("AARBAQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgaAJgPQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgEQgGAKAAAWQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgwQgGgPgMAAQgKAAgGALgAgFgtIAFghIAQAAIgLAhg");
	this.shape_396.setTransform(1049.6,328.9);

	this.shape_397 = new cjs.Shape();
	this.shape_397.graphics.f("#39454A").s().p("AAKBTQAGgHABgDQACgEAAgEQAAgEgDgCQgDgCgKgDQgJgDgGgDQgWgKAAgdQAAgOAHgJQAHgKAMgEQgJgFgGgHQgGgHAAgKQAAgPALgJQALgJASAAQANAAAIADIgDAPQgKgEgIAAQgLAAgFAGQgGAFAAAIQAAAVAZAAIALAAIAAAPIgMAAQgOAAgIAIQgHAHAAAPQAAALAFAIQAFAIAJADIAIACQAMADAEADQAEACACAEQACAEAAAGQAAAGgEAIQgFAIgGAGg");
	this.shape_397.setTransform(1040.2,331.3);

	this.shape_398 = new cjs.Shape();
	this.shape_398.graphics.f("#39454A").s().p("AgaAuQgKgIAAgPQAAgSAQgGQgHgDgEgGQgEgGAAgHQAAgPAKgIQAJgIAQAAQAPAAALAJQAKAJAAAOIgSAAQAAgHgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAHQAAAQASAAIAQAAIAAANIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJg");
	this.shape_398.setTransform(1031.1,331.3);

	this.shape_399 = new cjs.Shape();
	this.shape_399.graphics.f("#39454A").s().p("AgNASQAKgNAAgMIAAgRIAQAAIAAAPQABAJgFAJQgFAKgHAGg");
	this.shape_399.setTransform(1176.1,313);

	this.shape_400 = new cjs.Shape();
	this.shape_400.graphics.f("#39454A").s().p("AAHA/IAHgJIABgIQAAgEgDgCQgDgDgGgCQglgJgCgkIAAgJQAAgOAFgNQAEgLAKgIQAIgGALAAQAPAAALAKQAJAKAAATIgQAAQAAgMgGgGQgEgGgJgBQgJAAgGALQgGALAAARIAAAEQAAAYAYAKIAMAEQAHADAEAEQADAFAAAHQAAAHgEAIQgEAIgHAGg");
	this.shape_400.setTransform(1169.7,309.1);

	this.shape_401 = new cjs.Shape();
	this.shape_401.graphics.f("#39454A").s().p("AATBKIAAhrQAAgNgFgGQgDgGgKgBQgNABgFAPIAABMIgSAAIAAhoIAQAAIABAMQAJgOAPAAQAPAAAHAJQAIAKAAAUIAABsg");
	this.shape_401.setTransform(1160,309.3);

	this.shape_402 = new cjs.Shape();
	this.shape_402.graphics.f("#39454A").s().p("AAKBTQAGgHABgDQACgEAAgEQAAgEgDgCQgDgCgKgDQgJgDgGgDQgWgKAAgdQAAgOAHgJQAHgKAMgEQgJgFgGgHQgGgHAAgKQAAgPALgJQALgJASAAQANAAAIADIgDAPQgKgEgIAAQgLAAgFAGQgGAFAAAIQAAAVAZAAIALAAIAAAPIgMAAQgOAAgIAIQgHAHAAAPQAAALAFAIQAFAIAJADIAIACQAMADAEADQAEACACAEQACAEAAAGQAAAGgEAIQgFAIgGAGg");
	this.shape_402.setTransform(1150.8,307.3);

	this.shape_403 = new cjs.Shape();
	this.shape_403.graphics.f("#39454A").s().p("AATBiIAAhrQAAgNgFgGQgDgGgKgBQgNABgFAPIAABMIgSAAIAAhoIAPAAIABAMQALgOAOAAQAPAAAIAJQAHAKAAAUIAABsgAgGhAIAGghIAPAAIgLAhg");
	this.shape_403.setTransform(1141.4,306.9);

	this.shape_404 = new cjs.Shape();
	this.shape_404.graphics.f("#39454A").s().p("AgIAaIAAhAIgcAAIAAgPIBJAAIAAAPIgdAAIAAA/QAAANAHAAQAEAAAEgCIAEANQgHAFgJAAQgTAAAAgcg");
	this.shape_404.setTransform(1131.8,307.4);

	this.shape_405 = new cjs.Shape();
	this.shape_405.graphics.f("#39454A").s().p("AAHA/IAHgJIABgIQAAgEgDgCQgDgDgGgCQglgJgCgkIAAgJQAAgOAFgNQAEgLAKgIQAIgGALAAQAPAAALAKQAJAKAAATIgQAAQAAgMgGgGQgEgGgJgBQgJAAgGALQgGALAAARIAAAEQAAAYAYAKIAMAEQAHADAEAEQADAFAAAHQAAAHgEAIQgEAIgHAGg");
	this.shape_405.setTransform(1117.9,309.1);

	this.shape_406 = new cjs.Shape();
	this.shape_406.graphics.f("#39454A").s().p("AgaAuQgKgIAAgPQAAgSAQgGQgHgDgEgGQgEgGAAgHQAAgPAKgIQAJgIAQAAQAPAAALAJQAKAJAAAOIgSAAQAAgHgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAHQAAAQASAAIAQAAIAAANIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJg");
	this.shape_406.setTransform(1108.5,307.3);

	this.shape_407 = new cjs.Shape();
	this.shape_407.graphics.f("#39454A").s().p("AgKBGQgGgHAAgOIAAhNIAQAAIAABPQABALAIAAQAFAAACgBIAAAPQgFABgHAAQgJAAgFgHgAgNgrIAFghIAQAAIgKAhg");
	this.shape_407.setTransform(1101.3,305);

	this.shape_408 = new cjs.Shape();
	this.shape_408.graphics.f("#39454A").s().p("AgfAnQgLgPAAgYIAAgBQAAgXALgOQAKgPATAAIAtAAIAAAPIgWAAQAPAPAAAZIAAACQAAANgFAMQgFAMgJAGQgJAHgKAAQgTAAgKgPgAgTgcQgGAKAAASQAAASAGAKQAGALALAAQAJAAAGgKQAGgLAAgTQAAgRgGgKQgGgKgKAAQgKAAgGAKg");
	this.shape_408.setTransform(1093.2,307.4);

	this.shape_409 = new cjs.Shape();
	this.shape_409.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_409.setTransform(1083.2,307.3);

	this.shape_410 = new cjs.Shape();
	this.shape_410.graphics.f("#39454A").s().p("AARA1IgegtIgIAAIAAAtIgRAAIAAhpIARAAIAAAtIAGAAIAfgtIAUAAIgkAzIAnA2g");
	this.shape_410.setTransform(1073.5,307.3);

	this.shape_411 = new cjs.Shape();
	this.shape_411.graphics.f("#39454A").s().p("AgKAuQgGgHAAgOIAAhNIAQAAIAABPQABALAIAAQAFAAADgBIAAAPQgGABgHAAQgJAAgFgHg");
	this.shape_411.setTransform(1065.7,307.4);

	this.shape_412 = new cjs.Shape();
	this.shape_412.graphics.f("#39454A").s().p("AgcA/QgLgOAAgaQAAgQAIgMQAHgMAMgEIAAAAQgIgEgEgHQgFgHAAgJQAAgNAJgIQAIgHAOAAQALAAALAFIAAAQQgFgDgGgBQgHgCgFAAQgFAAgEADQgDAEAAAGQAAALAQAHQASAHAIAOQAJAMAAATIAAAEQAAAXgLAOQgLAOgSAAQgRAAgLgOgAgPgDQgGAJAAAUQAAARAGAKQAGAKAJAAQALAAAGgKQAGgKAAgUQAAgNgHgKQgGgKgKgDQgJAAgGAKg");
	this.shape_412.setTransform(1057.2,305.1);

	this.shape_413 = new cjs.Shape();
	this.shape_413.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_413.setTransform(1047.6,307.3);

	this.shape_414 = new cjs.Shape();
	this.shape_414.graphics.f("#39454A").s().p("AgKAuQgGgHABgOIAAhNIAQAAIAABPQAAALAJAAQAEAAADgBIAAAPQgGABgHAAQgJAAgFgHg");
	this.shape_414.setTransform(1039.8,307.4);

	this.shape_415 = new cjs.Shape();
	this.shape_415.graphics.f("#39454A").s().p("AgcA/QgLgOAAgaQAAgQAIgMQAHgMAMgEIAAAAQgIgEgEgHQgFgHAAgJQAAgNAJgIQAIgHAOAAQALAAALAFIAAAQQgFgDgGgBQgHgCgFAAQgFAAgEADQgDAEAAAGQAAALAQAHQASAHAIAOQAJAMAAATIAAAEQAAAXgLAOQgLAOgSAAQgRAAgLgOgAgPgDQgGAJAAAUQAAARAGAKQAGAKAJAAQALAAAGgKQAGgKAAgUQAAgNgHgKQgGgKgKgDQgJAAgGAKg");
	this.shape_415.setTransform(1031.3,305.1);

	this.shape_416 = new cjs.Shape();
	this.shape_416.graphics.f("#39454A").s().p("AAHBAIAHgKIABgIQAAgFgDgCQgDgCgGgBQglgKgCgkIAAgIQAAgPAFgMQAFgMAIgIQAKgGAKAAQAQAAAJAKQAKALAAARIgQAAQgBgLgFgGQgEgHgJAAQgJAAgGAMQgGAKAAASIAAACQAAAaAYAJIAMAEQAIACADAFQADAFABAIQgBAGgEAIQgFAIgGAGg");
	this.shape_416.setTransform(1231,285.1);

	this.shape_417 = new cjs.Shape();
	this.shape_417.graphics.f("#39454A").s().p("AgKAuQgFgHgBgOIAAhNIAQAAIAABPQABALAIAAQAFAAACgBIAAAPQgFABgHAAQgJAAgFgHg");
	this.shape_417.setTransform(1223.8,283.4);

	this.shape_418 = new cjs.Shape();
	this.shape_418.graphics.f("#39454A").s().p("AgIAaIAAhAIgcAAIAAgPIBJAAIAAAPIgdAAIAAA/QAAANAHAAQAEAAAEgCIAEANQgHAFgJAAQgTAAAAgcg");
	this.shape_418.setTransform(1215.7,283.4);

	this.shape_419 = new cjs.Shape();
	this.shape_419.graphics.f("#39454A").s().p("AgaAuQgKgIAAgPQAAgSAQgGQgHgDgEgGQgEgGAAgHQAAgPAKgIQAJgIAQAAQAPAAALAJQAKAJAAAOIgSAAQAAgHgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAHQAAAQASAAIAQAAIAAANIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJg");
	this.shape_419.setTransform(1201.8,283.3);

	this.shape_420 = new cjs.Shape();
	this.shape_420.graphics.f("#39454A").s().p("AgiBJIAAiRIARAAIAAA/QAAAOADAHQAEAIAJAAQAOAAAFgNIAAhPIARAAIAABpIgPAAIgBgKQgHALgMABQgMgBgFgGIAAAtg");
	this.shape_420.setTransform(1192.2,285.4);

	this.shape_421 = new cjs.Shape();
	this.shape_421.graphics.f("#39454A").s().p("AATBKIAAhrQAAgNgFgGQgDgHgLAAQgLAAgHAPIAABOIgRAAIAAhpIAPAAIABAMQAKgOAPAAQAPAAAIAKQAHAJAAATIAABtg");
	this.shape_421.setTransform(1177.6,285.3);

	this.shape_422 = new cjs.Shape();
	this.shape_422.graphics.f("#39454A").s().p("AgfAnQgLgPAAgYIAAgBQAAgXALgOQAKgPATAAIAtAAIAAAPIgWAAQAPAPAAAZIAAACQAAANgFAMQgFAMgJAGQgJAHgKAAQgTAAgKgPgAgTgcQgGAKAAASQAAASAGAKQAGALALAAQAJAAAGgKQAGgLAAgTQAAgRgGgKQgGgKgKAAQgKAAgGAKg");
	this.shape_422.setTransform(1168,283.4);

	this.shape_423 = new cjs.Shape();
	this.shape_423.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_423.setTransform(1158,283.3);

	this.shape_424 = new cjs.Shape();
	this.shape_424.graphics.f("#39454A").s().p("AgIAaIAAhAIgcAAIAAgPIBJAAIAAAPIgdAAIAAA/QAAANAHAAQAEAAAEgCIAEANQgHAFgJAAQgTAAAAgcg");
	this.shape_424.setTransform(1148.1,283.4);

	this.shape_425 = new cjs.Shape();
	this.shape_425.graphics.f("#39454A").s().p("AgfAnQgLgPAAgYIAAgBQAAgXALgOQAKgPATAAIAtAAIAAAPIgWAAQAPAPAAAZIAAACQAAANgFAMQgFAMgJAGQgJAHgKAAQgTAAgKgPgAgTgcQgGAKAAASQAAASAGAKQAGALALAAQAJAAAGgKQAGgLAAgTQAAgRgGgKQgGgKgKAAQgKAAgGAKg");
	this.shape_425.setTransform(1138.9,283.4);

	this.shape_426 = new cjs.Shape();
	this.shape_426.graphics.f("#39454A").s().p("AARBAQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgaAJgPQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgEQgGAKAAAWQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgwQgGgPgMAAQgKAAgGALgAgFgtIAFghIAQAAIgLAhg");
	this.shape_426.setTransform(1129,280.9);

	this.shape_427 = new cjs.Shape();
	this.shape_427.graphics.f("#39454A").s().p("AgIAaIAAhAIgcAAIAAgPIBJAAIAAAPIgdAAIAAA/QAAANAHAAQAEAAAEgCIAEANQgHAFgJAAQgTAAAAgcg");
	this.shape_427.setTransform(1119.1,283.4);

	this.shape_428 = new cjs.Shape();
	this.shape_428.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_428.setTransform(1109.9,283.3);

	this.shape_429 = new cjs.Shape();
	this.shape_429.graphics.f("#39454A").s().p("AARA1IgegtIgIAAIAAAtIgRAAIAAhpIARAAIAAAtIAGAAIAfgtIAUAAIgkAzIAnA2g");
	this.shape_429.setTransform(1100.1,283.3);

	this.shape_430 = new cjs.Shape();
	this.shape_430.graphics.f("#39454A").s().p("AgKAuQgGgHAAgOIAAhNIAQAAIAABPQABALAIAAQAFAAADgBIAAAPQgGABgHAAQgJAAgFgHg");
	this.shape_430.setTransform(1087.7,283.4);

	this.shape_431 = new cjs.Shape();
	this.shape_431.graphics.f("#39454A").s().p("AgaAuQgKgIAAgPQAAgSAQgGQgHgDgEgGQgEgGAAgHQAAgPAKgIQAJgIAQAAQAPAAALAJQAKAJAAAOIgSAAQAAgHgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAHQAAAQASAAIAQAAIAAANIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJg");
	this.shape_431.setTransform(1079.5,283.3);

	this.shape_432 = new cjs.Shape();
	this.shape_432.graphics.f("#39454A").s().p("AAIBRQAHgJAAgIQAAgHgNgEIgFgCQgOgEgGgIQgFgIAAgQQAAgNAGgPQAHgQAKgOIAWgfIgzAAIAAgPIBFAAIAAAMIgbApQgMASgDALQgEAKAAAMQAAAJACAFQADAEAFADIASAGQAIADADAEQAEAEAAAIQgBAHgFAIQgEAIgFAGg");
	this.shape_432.setTransform(1070.3,283.4);

	this.shape_433 = new cjs.Shape();
	this.shape_433.graphics.f("#39454A").s().p("AARBAQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgaAJgPQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgEQgGAKAAAWQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgwQgGgPgMAAQgKAAgGALgAgFgtIAFghIAQAAIgLAhg");
	this.shape_433.setTransform(1060.9,280.9);

	this.shape_434 = new cjs.Shape();
	this.shape_434.graphics.f("#39454A").s().p("AAYBHQgEgEgDgKIgSg5IgWBJIgTAAIAghiIgIgYQgDgGgCgCQgCgCgCAAIgFAAIAAgOIAJgBQAIAAAFAEQAFAEACAJIAjBrIAEAHQAAABABAAQAAAAABABQAAAAABAAQAAAAABAAIADAAIAAAPIgHABQgIAAgEgEg");
	this.shape_434.setTransform(1050.7,281.3);

	this.shape_435 = new cjs.Shape();
	this.shape_435.graphics.f("#39454A").s().p("AAYBHQgEgEgDgKIgSg5IgVBJIgUAAIAghiIgJgYQgBgGgCgCQgDgCgCAAIgEAAIAAgOIAIgBQAIAAAFAEQAFAEADAJIAjBrIACAHQABABABAAQAAAAABABQAAAAABAAQAAAAABAAIADAAIAAAPIgHABQgIAAgEgEg");
	this.shape_435.setTransform(1041,281.3);

	this.shape_436 = new cjs.Shape();
	this.shape_436.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_436.setTransform(1031.6,283.3);

	this.shape_437 = new cjs.Shape();
	this.shape_437.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_437.setTransform(1203,259.3);

	this.shape_438 = new cjs.Shape();
	this.shape_438.graphics.f("#39454A").s().p("AgjBJIAAiRIARAAIAAA+QAAAPAFAIQADAHAJAAQANAAAGgOIAAhOIARAAIAABpIgPAAIgBgKQgHAMgMgBQgLAAgHgGIAAAtg");
	this.shape_438.setTransform(1192.8,261.4);

	this.shape_439 = new cjs.Shape();
	this.shape_439.graphics.f("#39454A").s().p("AAAA3QgGAXgUAAQgPAAgJgPQgJgOABgcQAAgbALgXIASAAQgLAbgCAXQAAAUAFALQAFALAHAAQAIAAAFgIQAEgIAAgQIAAgeIAQAAIAAAeQAAAQAFAIQAEAIAIAAQAJAAAEgLQAEgLAAgUQgBgXgKgbIASAAQAKAXABAbQAAAcgJAOQgJAPgQAAQgTAAgHgXgAgGgsIAFghIARAAIgLAhg");
	this.shape_439.setTransform(1180.6,257);

	this.shape_440 = new cjs.Shape();
	this.shape_440.graphics.f("#39454A").s().p("AgfAnQgLgPAAgYIAAgBQAAgXALgOQAKgPATAAIAtAAIAAAPIgWAAQAPAPAAAZIAAACQAAANgFAMQgFAMgJAGQgJAHgKAAQgTAAgKgPgAgTgcQgGAKAAASQAAASAGAKQAGALALAAQAJAAAGgKQAGgLAAgTQAAgRgGgKQgGgKgKAAQgKAAgGAKg");
	this.shape_440.setTransform(1168.9,259.4);

	this.shape_441 = new cjs.Shape();
	this.shape_441.graphics.f("#39454A").s().p("AgcAqQgMgNAAgWIAAgLQAAgXALgNQALgOASAAQASAAALANQALANABAXIAAAKQAAAXgLANQgLAOgTAAQgRAAgLgNgAgQgeQgHAKAAAQIAAAJQAAAQAHAKQAGAJAKAAQAXAAAAghIAAgLQAAgQgGgKQgGgJgLAAQgKAAgGAJg");
	this.shape_441.setTransform(1153.9,259.3);

	this.shape_442 = new cjs.Shape();
	this.shape_442.graphics.f("#39454A").s().p("AgIAaIAAhAIgcAAIAAgPIBJAAIAAAPIgdAAIAAA/QAAANAHAAQAEAAAEgCIAEANQgHAFgJAAQgTAAAAgcg");
	this.shape_442.setTransform(1144.3,259.4);

	this.shape_443 = new cjs.Shape();
	this.shape_443.graphics.f("#39454A").s().p("AgMASQAIgNABgNIAAgQIARAAIAAAOQAAAKgFAJQgFAKgGAGg");
	this.shape_443.setTransform(1132.8,265);

	this.shape_444 = new cjs.Shape();
	this.shape_444.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_444.setTransform(1126.5,259.3);

	this.shape_445 = new cjs.Shape();
	this.shape_445.graphics.f("#39454A").s().p("AgKBGQgGgHAAgOIAAhNIAQAAIAABPQABALAIAAQAFAAADgBIAAAPQgGABgHAAQgJAAgFgHgAgNgrIAFghIAQAAIgKAhg");
	this.shape_445.setTransform(1118.8,257);

	this.shape_446 = new cjs.Shape();
	this.shape_446.graphics.f("#39454A").s().p("AgfAnQgLgPAAgYIAAgBQAAgXALgOQAKgPATAAIAtAAIAAAPIgWAAQAPAPAAAZIAAACQAAANgFAMQgFAMgJAGQgJAHgKAAQgTAAgKgPgAgTgcQgGAKAAASQAAASAGAKQAGALALAAQAJAAAGgKQAGgLAAgTQAAgRgGgKQgGgKgKAAQgKAAgGAKg");
	this.shape_446.setTransform(1110.6,259.4);

	this.shape_447 = new cjs.Shape();
	this.shape_447.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_447.setTransform(1100.7,259.3);

	this.shape_448 = new cjs.Shape();
	this.shape_448.graphics.f("#39454A").s().p("AglBKIAAhgQAAgPAFgMQAFgLAIgHQAIgGALAAQASAAAJAPQALAPAAAdQAAAWgJAOQgKAOgPgBQgPAAgJgKIAAAxgAgOgvQgGAKAAARIAAAbQAGAOANAAQAKgBAGgIQAGgKAAgTQAAgTgGgLQgGgLgJAAQgJAAgFALg");
	this.shape_448.setTransform(1090.6,261.3);

	this.shape_449 = new cjs.Shape();
	this.shape_449.graphics.f("#39454A").s().p("AARA1IgegtIgIAAIAAAtIgRAAIAAhpIARAAIAAAtIAGAAIAfgtIAUAAIgkAzIAnA2g");
	this.shape_449.setTransform(1081,259.3);

	this.shape_450 = new cjs.Shape();
	this.shape_450.graphics.f("#39454A").s().p("AgcAqQgMgNAAgWIAAgLQAAgXALgNQALgOASAAQASAAALANQALANABAXIAAAKQAAAXgLANQgLAOgTAAQgRAAgLgNgAgQgeQgHAKAAAQIAAAJQAAAQAHAKQAGAJAKAAQAXAAAAghIAAgLQAAgQgGgKQgGgJgLAAQgKAAgGAJg");
	this.shape_450.setTransform(1070.6,259.3);

	this.shape_451 = new cjs.Shape();
	this.shape_451.graphics.f("#39454A").s().p("AgjBJIAAiRIARAAIAAA+QABAPAEAIQADAHAJAAQAOAAAFgOIAAhOIARAAIAABpIgPAAIgBgKQgHAMgMgBQgLAAgHgGIAAAtg");
	this.shape_451.setTransform(1060.7,261.4);

	this.shape_452 = new cjs.Shape();
	this.shape_452.graphics.f("#39454A").s().p("AglBKIAAhgQAAgPAFgMQAEgLAJgHQAIgGALAAQARAAALAPQAKAPAAAdQAAAWgJAOQgJAOgRgBQgNAAgKgKIAAAxgAgOgvQgGAKAAARIAAAbQAGAOANAAQAKgBAGgIQAFgKABgTQgBgTgFgLQgGgLgJAAQgJAAgFALg");
	this.shape_452.setTransform(1050.9,261.3);

	this.shape_453 = new cjs.Shape();
	this.shape_453.graphics.f("#39454A").s().p("AgaAuQgKgIAAgPQAAgSAQgGQgHgDgEgGQgEgGAAgHQAAgPAKgIQAJgIAQAAQAPAAALAJQAKAJAAAOIgSAAQAAgHgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAHQAAAQASAAIAQAAIAAANIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJg");
	this.shape_453.setTransform(1041,259.3);

	this.shape_454 = new cjs.Shape();
	this.shape_454.graphics.f("#39454A").s().p("AgbA5QgKgRAAgfIAAgRQAAgfAKgRQAJgQASAAQASAAAKAPQAKAQAAAeIAAAUQAAAfgJARQgLAQgSAAQgRAAgKgQgAgUAMQAAAVAGANQAFAMAJAAQAKAAAFgMQAGgMAAgWIAAgFIgpAAgAgOguQgGAMAAAWIAAAGIApAAIAAgGQAAgWgGgMQgFgLgKgBQgJABgFALg");
	this.shape_454.setTransform(1031.3,257.5);

	this.shape_455 = new cjs.Shape();
	this.shape_455.graphics.f("#39454A").s().p("AATBKIAAhrQAAgNgFgGQgEgGgJAAQgMAAgHAPIAABMIgRAAIAAhoIAPAAIABAMQALgOAOAAQAPAAAIAJQAHAKAAAUIAABsg");
	this.shape_455.setTransform(1214.2,237.3);

	this.shape_456 = new cjs.Shape();
	this.shape_456.graphics.f("#39454A").s().p("AAYBHQgEgEgEgKIgSg5IgVBJIgTAAIAfhiIgIgYQgCgGgCgCQgBgCgEAAIgEAAIAAgOIAJgBQAIAAAFAEQAFAEACAJIAjBrIADAHQABABABAAQAAABABAAQAAAAABAAQAAAAABAAIADAAIAAAPIgGABQgJAAgEgEg");
	this.shape_456.setTransform(1204.3,233.3);

	this.shape_457 = new cjs.Shape();
	this.shape_457.graphics.f("#39454A").s().p("AATBKIAAhrQAAgNgEgGQgFgGgKAAQgMAAgGAPIAABMIgRAAIAAhoIAPAAIABAMQAKgOAPAAQAQAAAGAJQAIAKAAAUIAABsg");
	this.shape_457.setTransform(1194.6,237.3);

	this.shape_458 = new cjs.Shape();
	this.shape_458.graphics.f("#39454A").s().p("AAYBHQgEgEgEgKIgRg5IgVBJIgUAAIAfhiIgIgYQgBgGgCgCQgDgCgDAAIgDAAIAAgOIAIgBQAIAAAFAEQAFAEADAJIAjBrIACAHQABABABAAQAAABABAAQAAAAABAAQAAAAABAAIADAAIAAAPIgHABQgIAAgEgEg");
	this.shape_458.setTransform(1184.7,233.3);

	this.shape_459 = new cjs.Shape();
	this.shape_459.graphics.f("#39454A").s().p("AAYBHQgEgEgEgKIgSg5IgUBJIgUAAIAfhiIgIgYQgCgGgBgCQgCgCgEAAIgDAAIAAgOIAIgBQAIAAAFAEQAFAEACAJIAjBrIADAHQABABABAAQAAABABAAQAAAAABAAQAAAAABAAIADAAIAAAPIgHABQgIAAgEgEg");
	this.shape_459.setTransform(1175,233.3);

	this.shape_460 = new cjs.Shape();
	this.shape_460.graphics.f("#39454A").s().p("AARBAQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgaAJgPQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgEQgGAKAAAWQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgwQgGgPgMAAQgKAAgGALgAgFgtIAFghIAQAAIgLAhg");
	this.shape_460.setTransform(1165.6,232.9);

	this.shape_461 = new cjs.Shape();
	this.shape_461.graphics.f("#39454A").s().p("AgIAaIAAhAIgcAAIAAgPIBJAAIAAAPIgdAAIAAA/QAAANAHAAQAEAAAEgCIAEANQgHAFgJAAQgTAAAAgcg");
	this.shape_461.setTransform(1155.7,235.4);

	this.shape_462 = new cjs.Shape();
	this.shape_462.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_462.setTransform(1146.5,235.3);

	this.shape_463 = new cjs.Shape();
	this.shape_463.graphics.f("#39454A").s().p("AARA1IgegtIgIAAIAAAtIgRAAIAAhpIARAAIAAAtIAGAAIAfgtIAUAAIgkAzIAnA2g");
	this.shape_463.setTransform(1136.7,235.3);

	this.shape_464 = new cjs.Shape();
	this.shape_464.graphics.f("#39454A").s().p("AgaAuQgKgIAAgPQAAgSAQgGQgHgDgEgGQgEgGAAgHQAAgPAKgIQAJgIAQAAQAPAAALAJQAKAJAAAOIgSAAQAAgHgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAHQAAAQASAAIAQAAIAAANIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJg");
	this.shape_464.setTransform(1122.1,235.3);

	this.shape_465 = new cjs.Shape();
	this.shape_465.graphics.f("#39454A").s().p("AgfAnQgLgPAAgYIAAgBQAAgXALgOQAKgPATAAIAtAAIAAAPIgWAAQAPAPAAAZIAAACQAAANgFAMQgFAMgJAGQgJAHgKAAQgTAAgKgPgAgTgcQgGAKAAASQAAASAGAKQAGALALAAQAJAAAGgKQAGgLAAgTQAAgRgGgKQgGgKgKAAQgKAAgGAKg");
	this.shape_465.setTransform(1112.8,235.4);

	this.shape_466 = new cjs.Shape();
	this.shape_466.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_466.setTransform(1098.2,235.3);

	this.shape_467 = new cjs.Shape();
	this.shape_467.graphics.f("#39454A").s().p("AgjBJIAAiRIARAAIAAA/QAAAOAFAHQADAIAJAAQANAAAGgOIAAhOIARAAIAABoIgPAAIgBgKQgHANgMAAQgLAAgHgHIAAAtg");
	this.shape_467.setTransform(1088,237.4);

	this.shape_468 = new cjs.Shape();
	this.shape_468.graphics.f("#39454A").s().p("AAAA3QgGAXgUAAQgPAAgJgPQgIgOAAgcQgBgbAMgXIARAAQgLAbAAAXQgBAUAFALQAEALAJAAQAHAAAFgIQAEgIAAgQIAAgeIAQAAIAAAeQAAAQAFAIQAFAIAHAAQAJAAAEgLQAEgLAAgUQAAgXgLgbIASAAQALAXgBAbQAAAcgIAOQgJAPgQAAQgTAAgHgXgAgFgsIAEghIAQAAIgKAhg");
	this.shape_468.setTransform(1075.9,233);

	this.shape_469 = new cjs.Shape();
	this.shape_469.graphics.f("#39454A").s().p("AgfAnQgLgPAAgYIAAgBQAAgXALgOQAKgPATAAIAtAAIAAAPIgWAAQAPAPAAAZIAAACQAAANgFAMQgFAMgJAGQgJAHgKAAQgTAAgKgPgAgTgcQgGAKAAASQAAASAGAKQAGALALAAQAJAAAGgKQAGgLAAgTQAAgRgGgKQgGgKgKAAQgKAAgGAKg");
	this.shape_469.setTransform(1064.1,235.4);

	this.shape_470 = new cjs.Shape();
	this.shape_470.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_470.setTransform(1049.6,235.3);

	this.shape_471 = new cjs.Shape();
	this.shape_471.graphics.f("#39454A").s().p("AgGA1IgfhpIASAAIATBOIAUhOIASAAIgfBpg");
	this.shape_471.setTransform(1040,235.3);

	this.shape_472 = new cjs.Shape();
	this.shape_472.graphics.f("#39454A").s().p("AgaBGQgKgIAAgPQAAgSAQgHQgHgDgEgGQgEgGAAgHQAAgOAKgIQAJgIAQAAQAPAAALAJQAKAJAAANIgSAAQAAgGgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAGQAAAQASAAIAQAAIAAAOIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJgAgGgtIAFghIAQAAIgLAhg");
	this.shape_472.setTransform(1031.1,232.9);

	this.shape_473 = new cjs.Shape();
	this.shape_473.graphics.f("#39454A").s().p("AAIBAIAGgKIABgIQAAgFgDgCQgDgCgHgBQgkgKgCgkIAAgIQAAgPAEgMQAFgMAKgIQAJgGAKAAQAPAAAKAKQAKALAAARIgRAAQAAgLgEgGQgGgHgIAAQgJAAgGAMQgGAKAAASIAAACQAAAaAYAJIAMAEQAHACAEAFQAEAFAAAIQAAAGgFAIQgFAIgFAGg");
	this.shape_473.setTransform(1231.3,213.1);

	this.shape_474 = new cjs.Shape();
	this.shape_474.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_474.setTransform(1221.9,211.3);

	this.shape_475 = new cjs.Shape();
	this.shape_475.graphics.f("#39454A").s().p("AgIAaIAAhAIgcAAIAAgPIBJAAIAAAPIgdAAIAAA/QAAANAHAAQAEAAAEgCIAEANQgHAFgJAAQgTAAAAgcg");
	this.shape_475.setTransform(1212,211.4);

	this.shape_476 = new cjs.Shape();
	this.shape_476.graphics.f("#39454A").s().p("AgGA1IgfhpIARAAIAVBOIAThOIASAAIgfBpg");
	this.shape_476.setTransform(1203.2,211.3);

	this.shape_477 = new cjs.Shape();
	this.shape_477.graphics.f("#39454A").s().p("AgcAqQgMgNAAgWIAAgLQAAgXALgNQALgOASAAQASAAALANQALANABAXIAAAKQAAAXgLANQgLAOgTAAQgRAAgLgNgAgQgeQgHAKAAAQIAAAJQAAAQAHAKQAGAJAKAAQAXAAAAghIAAgLQAAgQgGgKQgGgJgLAAQgKAAgGAJg");
	this.shape_477.setTransform(1193.9,211.3);

	this.shape_478 = new cjs.Shape();
	this.shape_478.graphics.f("#39454A").s().p("AAUBGQgFgFgFgNIgKghIgWA2IgTAAIAghMIgNgmQgGgSgJAAIgGABIAAgOIAJgCQAQAAAHATIALAeIASgvIARAAIgcBGIARAuQAFAOAGAAIACAAIAHAAIgGAPQAAABAAAAQgBAAAAAAQgBABgBAAQAAAAgBAAQgIAAgGgFg");
	this.shape_478.setTransform(1184.9,213.4);

	this.shape_479 = new cjs.Shape();
	this.shape_479.graphics.f("#39454A").s().p("AgbBDQgIgLgBgVIAAhAIASAAIAAA+QAAAeAPAAQAJAAAGgMQAHgNAAgRQAAgVgKgdIASAAQAJAXAAAbQABAagLAPQgLAQgRAAQgRAAgIgLgAgJgsIAGghIAPAAIgLAhg");
	this.shape_479.setTransform(1175.5,209);

	this.shape_480 = new cjs.Shape();
	this.shape_480.graphics.f("#39454A").s().p("AgJBMIAAgtQgVgDgLgPQgLgOAAgaIAAgwIASAAIAAAvQAAAmAZAGIAAhbIAQAAIAABbQANgCAIgMQAHgKAAgRQAAgWgKgcIASAAQAKAXAAAbQAAAZgMAOQgMAPgWACIAAAtg");
	this.shape_480.setTransform(1164.4,213.6);

	this.shape_481 = new cjs.Shape();
	this.shape_481.graphics.f("#39454A").s().p("AATBiIAAhrQAAgNgFgGQgEgHgJAAQgNAAgFAQIAABNIgSAAIAAhpIAPAAIACAMQAJgOAPAAQAPAAAIAKQAHAJAAATIAABtgAgGhAIAFghIAQAAIgLAhg");
	this.shape_481.setTransform(1148.6,210.9);

	this.shape_482 = new cjs.Shape();
	this.shape_482.graphics.f("#39454A").s().p("AAIBAIAGgKIABgIQAAgFgDgCQgDgCgHgBQgkgKgCgkIAAgIQAAgPAEgMQAGgMAJgIQAIgGALAAQAPAAALAKQAJALAAARIgRAAQABgLgGgGQgFgHgIAAQgJAAgGAMQgGAKAAASIAAACQAAAaAYAJIAMAEQAIACADAFQAEAFgBAIQABAGgFAIQgFAIgFAGg");
	this.shape_482.setTransform(1134.3,213.1);

	this.shape_483 = new cjs.Shape();
	this.shape_483.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_483.setTransform(1125,211.3);

	this.shape_484 = new cjs.Shape();
	this.shape_484.graphics.f("#39454A").s().p("AgIAaIAAhAIgcAAIAAgPIBJAAIAAAPIgdAAIAAA/QAAANAHAAQAEAAAEgCIAEANQgHAFgJAAQgTAAAAgcg");
	this.shape_484.setTransform(1115.1,211.4);

	this.shape_485 = new cjs.Shape();
	this.shape_485.graphics.f("#39454A").s().p("AgFA1IgghpIARAAIAVBOIAUhOIARAAIggBpg");
	this.shape_485.setTransform(1106.2,211.3);

	this.shape_486 = new cjs.Shape();
	this.shape_486.graphics.f("#39454A").s().p("AgcAqQgMgNAAgWIAAgLQAAgXALgNQALgOASAAQASAAALANQALANABAXIAAAKQAAAXgLANQgLAOgTAAQgRAAgLgNgAgQgeQgHAKAAAQIAAAJQAAAQAHAKQAGAJAKAAQAXAAAAghIAAgLQAAgQgGgKQgGgJgLAAQgKAAgGAJg");
	this.shape_486.setTransform(1096.9,211.3);

	this.shape_487 = new cjs.Shape();
	this.shape_487.graphics.f("#39454A").s().p("AgGA1IgfhpIASAAIAUBOIAThOIASAAIgfBpg");
	this.shape_487.setTransform(1087.6,211.3);

	this.shape_488 = new cjs.Shape();
	this.shape_488.graphics.f("#39454A").s().p("AgKBGQgGgHAAgOIAAhNIARAAIAABPQAAALAIAAQAFAAADgBIAAAPQgGABgHAAQgJAAgFgHgAgNgrIAFghIAQAAIgKAhg");
	this.shape_488.setTransform(1080.9,209);

	this.shape_489 = new cjs.Shape();
	this.shape_489.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_489.setTransform(1072.7,211.3);

	this.shape_490 = new cjs.Shape();
	this.shape_490.graphics.f("#39454A").s().p("AgjBJIAAiRIASAAIAAA/QAAAOADAHQAFAIAIAAQANAAAGgNIAAhPIARAAIAABpIgPAAIgBgKQgHALgMABQgLgBgGgGIAAAtg");
	this.shape_490.setTransform(1062.5,213.4);

	this.shape_491 = new cjs.Shape();
	this.shape_491.graphics.f("#39454A").s().p("AglBKIAAhgQAAgPAEgMQAGgMAIgGQAJgGAKAAQARAAAKAPQALAPAAAcQAAAXgJANQgKAOgPABQgPAAgIgLIAAAxgAgPgvQgEAKAAARIAAAcQAFANANgBQAKABAGgKQAFgJAAgTQAAgUgFgKQgGgMgJAAQgJAAgGAMg");
	this.shape_491.setTransform(1052.7,213.3);

	this.shape_492 = new cjs.Shape();
	this.shape_492.graphics.f("#39454A").s().p("AgaAuQgKgIAAgPQAAgSAQgGQgHgDgEgGQgEgGAAgHQAAgPAKgIQAJgIAQAAQAPAAALAJQAKAJAAAOIgSAAQAAgHgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAHQAAAQASAAIAQAAIAAANIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJg");
	this.shape_492.setTransform(1042.9,211.3);

	this.shape_493 = new cjs.Shape();
	this.shape_493.graphics.f("#39454A").s().p("AgYBBQgLgJgGgPQgGgQgBgTIAAgJQAAgVAHgPQAFgQAMgJQAKgIAOAAQAOAAALAIQAMAIAFAQQAHAPAAAVIAAAJQAAAUgHAQQgFAPgMAJQgLAIgOAAQgNAAgLgIgAgVgrQgJAOAAAYIAAAKQAAAYAJAOQAHAOAOAAQAPAAAIgOQAIgNAAgZIAAgIQAAgagIgOQgIgNgPAAQgNAAgIANgAgSAGIAAgNIAoAAIAAANg");
	this.shape_493.setTransform(1032.2,209.5);

	this.shape_494 = new cjs.Shape();
	this.shape_494.graphics.f("#39454A").s().p("AgHAIQgDgDAAgFQAAgDADgEQACgDAFAAQAGAAACADQADAEAAADQAAAFgDADQgCADgGAAQgFAAgCgDg");
	this.shape_494.setTransform(1147.3,191.6);

	this.shape_495 = new cjs.Shape();
	this.shape_495.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_495.setTransform(1140.1,187.3);

	this.shape_496 = new cjs.Shape();
	this.shape_496.graphics.f("#39454A").s().p("AgKAuQgFgHgBgOIAAhNIAQAAIAABPQABALAIAAQAFAAADgBIAAAPQgGABgHAAQgJAAgFgHg");
	this.shape_496.setTransform(1132.4,187.4);

	this.shape_497 = new cjs.Shape();
	this.shape_497.graphics.f("#39454A").s().p("AglBKIAAhgQAAgQAEgLQAFgLAJgHQAJgGAKAAQASAAAJAPQALAPAAAdQAAAWgJAOQgKAOgQgBQgOAAgIgKIAAAxgAgPgvQgEAKAAARIAAAbQAFAOAOAAQAJgBAGgIQAFgKAAgTQAAgTgFgLQgFgLgKAAQgJAAgGALg");
	this.shape_497.setTransform(1124.1,189.3);

	this.shape_498 = new cjs.Shape();
	this.shape_498.graphics.f("#39454A").s().p("AgaBGQgKgIAAgPQAAgSAQgHQgHgDgEgGQgEgGAAgHQAAgOAKgIQAJgIAQAAQAPAAALAJQAKAJAAANIgSAAQAAgGgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAGQAAAQASAAIAQAAIAAAOIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJgAgGgtIAFghIAQAAIgLAhg");
	this.shape_498.setTransform(1114.2,184.9);

	this.shape_499 = new cjs.Shape();
	this.shape_499.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_499.setTransform(1104.9,187.3);

	this.shape_500 = new cjs.Shape();
	this.shape_500.graphics.f("#39454A").s().p("AgLAuQgFgHAAgOIAAhNIAQAAIAABPQABALAIAAQAFAAACgBIAAAPQgFABgHAAQgJAAgGgHg");
	this.shape_500.setTransform(1092.5,187.4);

	this.shape_501 = new cjs.Shape();
	this.shape_501.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_501.setTransform(1084.4,187.3);

	this.shape_502 = new cjs.Shape();
	this.shape_502.graphics.f("#39454A").s().p("AARA1IgegtIgIAAIAAAtIgRAAIAAhpIARAAIAAAtIAGAAIAfgtIAUAAIgkAzIAnA2g");
	this.shape_502.setTransform(1074.6,187.3);

	this.shape_503 = new cjs.Shape();
	this.shape_503.graphics.f("#39454A").s().p("AARBAQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgaAJgPQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgEQgGAKAAAWQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgwQgGgPgMAAQgKAAgGALgAgFgtIAFghIAQAAIgLAhg");
	this.shape_503.setTransform(1060.1,184.9);

	this.shape_504 = new cjs.Shape();
	this.shape_504.graphics.f("#39454A").s().p("AglBKIAAhgQAAgQAEgLQAGgLAIgHQAJgGAKAAQARAAAKAPQALAPAAAdQAAAWgJAOQgJAOgRgBQgNAAgJgKIAAAxgAgPgvQgEAKAAARIAAAbQAFAOANAAQAKgBAGgIQAFgKAAgTQAAgTgFgLQgGgLgJAAQgJAAgGALg");
	this.shape_504.setTransform(1050,189.3);

	this.shape_505 = new cjs.Shape();
	this.shape_505.graphics.f("#39454A").s().p("AgIBJIAAgwIgehhIASAAIAUBKIAVhKIASAAIgfBiIAAAvg");
	this.shape_505.setTransform(1040.5,189.4);

	this.shape_506 = new cjs.Shape();
	this.shape_506.graphics.f("#39454A").s().p("AgbArQgIgLAAgVIAAhAIARAAIAAA+QAAAeAPAAQAJAAAGgMQAHgNAAgQQAAgWgKgdIASAAQAJAXABAcQAAAZgLAPQgLAQgRAAQgRAAgIgLg");
	this.shape_506.setTransform(1031.4,187.4);

	this.shape_507 = new cjs.Shape();
	this.shape_507.graphics.f("#39454A").s().p("AgMASQAIgNABgMIAAgRIARAAIAAAPQgBAJgEAJQgFAKgGAGg");
	this.shape_507.setTransform(1246.3,169);

	this.shape_508 = new cjs.Shape();
	this.shape_508.graphics.f("#39454A").s().p("AARBAQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgaAJgPQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgEQgGAKAAAWQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgwQgGgPgMAAQgKAAgGALgAgFgtIAFghIAQAAIgLAhg");
	this.shape_508.setTransform(1240,160.9);

	this.shape_509 = new cjs.Shape();
	this.shape_509.graphics.f("#39454A").s().p("AgaAuQgKgIAAgPQAAgSAQgGQgHgDgEgGQgEgGAAgHQAAgPAKgIQAJgIAQAAQAPAAALAJQAKAJAAAOIgSAAQAAgHgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAHQAAAQASAAIAQAAIAAANIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJg");
	this.shape_509.setTransform(1230.1,163.3);

	this.shape_510 = new cjs.Shape();
	this.shape_510.graphics.f("#39454A").s().p("AglBKIAAhgQAAgQAEgLQAGgMAIgGQAJgGAKAAQARAAAKAPQALAPAAAdQAAAWgJANQgKAPgPAAQgPAAgIgLIAAAxgAgPgwQgEALAAAQIAAAcQAFANAOABQAJAAAGgJQAGgKgBgSQABgVgGgLQgGgLgJABQgJgBgGALg");
	this.shape_510.setTransform(1220.6,165.3);

	this.shape_511 = new cjs.Shape();
	this.shape_511.graphics.f("#39454A").s().p("AgaAuQgKgIAAgPQAAgSAQgGQgHgDgEgGQgEgGAAgHQAAgPAKgIQAJgIAQAAQAPAAALAJQAKAJAAAOIgSAAQAAgHgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAHQAAAQASAAIAQAAIAAANIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJg");
	this.shape_511.setTransform(1210.7,163.3);

	this.shape_512 = new cjs.Shape();
	this.shape_512.graphics.f("#39454A").s().p("AgIAaIAAhAIgcAAIAAgPIBJAAIAAAPIgdAAIAAA/QAAANAHAAQAEAAAEgCIAEANQgHAFgJAAQgTAAAAgcg");
	this.shape_512.setTransform(1201.4,163.4);

	this.shape_513 = new cjs.Shape();
	this.shape_513.graphics.f("#39454A").s().p("AgfAnQgLgPAAgYIAAgBQAAgXALgOQAKgPATAAIAtAAIAAAPIgWAAQAPAPAAAZIAAACQAAANgFAMQgFAMgJAGQgJAHgKAAQgTAAgKgPgAgTgcQgGAKAAASQAAASAGAKQAGALALAAQAJAAAGgKQAGgLAAgTQAAgRgGgKQgGgKgKAAQgKAAgGAKg");
	this.shape_513.setTransform(1192.2,163.4);

	this.shape_514 = new cjs.Shape();
	this.shape_514.graphics.f("#39454A").s().p("AgHAzQgDgDAAgFQAAgEADgEQACgDAFAAQAFAAADADQADAEAAAEQAAAFgDADQgDADgFAAQgFAAgCgDgAgHgiQgDgDAAgFQAAgFADgDQACgDAFAAQAGAAACADQADADAAAFQAAAFgDADQgCADgGAAQgFAAgCgDg");
	this.shape_514.setTransform(1180.1,163.3);

	this.shape_515 = new cjs.Shape();
	this.shape_515.graphics.f("#39454A").s().p("AAHA/IAHgJIABgIQAAgEgDgCQgDgDgHgCQgkgJgCgkIAAgJQAAgOAEgNQAFgLAJgIQAKgGAKAAQAPAAAKAKQAKAKAAATIgRAAQAAgMgEgGQgGgGgIAAQgJgBgGALQgGALAAARIAAAEQAAAYAYAKIAMAEQAHADAEAEQAEAFAAAHQAAAHgFAIQgFAIgFAGg");
	this.shape_515.setTransform(1172.9,165.1);

	this.shape_516 = new cjs.Shape();
	this.shape_516.graphics.f("#39454A").s().p("AgKAuQgGgHAAgOIAAhNIAQAAIAABPQABALAIAAQAFAAACgBIAAAPQgFABgHAAQgJAAgFgHg");
	this.shape_516.setTransform(1165.7,163.4);

	this.shape_517 = new cjs.Shape();
	this.shape_517.graphics.f("#39454A").s().p("AgaAuQgKgIAAgPQAAgSAQgGQgHgDgEgGQgEgGAAgHQAAgPAKgIQAJgIAQAAQAPAAALAJQAKAJAAAOIgSAAQAAgHgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAHQAAAQASAAIAQAAIAAANIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJg");
	this.shape_517.setTransform(1157.5,163.3);

	this.shape_518 = new cjs.Shape();
	this.shape_518.graphics.f("#39454A").s().p("AgfAnQgLgPAAgYIAAgBQAAgXALgOQAKgPATAAIAtAAIAAAPIgWAAQAPAPAAAZIAAACQAAANgFAMQgFAMgJAGQgJAHgKAAQgTAAgKgPgAgTgcQgGAKAAASQAAASAGAKQAGALALAAQAJAAAGgKQAGgLAAgTQAAgRgGgKQgGgKgKAAQgKAAgGAKg");
	this.shape_518.setTransform(1148.1,163.4);

	this.shape_519 = new cjs.Shape();
	this.shape_519.graphics.f("#39454A").s().p("AARBAQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgaAJgPQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgEQgGAKAAAWQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgwQgGgPgMAAQgKAAgGALgAgFgtIAFghIAQAAIgLAhg");
	this.shape_519.setTransform(1138.2,160.9);

	this.shape_520 = new cjs.Shape();
	this.shape_520.graphics.f("#39454A").s().p("AgIAaIAAhAIgcAAIAAgPIBJAAIAAAPIgdAAIAAA/QAAANAHAAQAEAAAEgCIAEANQgHAFgJAAQgTAAAAgcg");
	this.shape_520.setTransform(1128.3,163.4);

	this.shape_521 = new cjs.Shape();
	this.shape_521.graphics.f("#39454A").s().p("AgfAnQgLgPAAgYIAAgBQAAgXALgOQAKgPATAAIAtAAIAAAPIgWAAQAPAPAAAZIAAACQAAANgFAMQgFAMgJAGQgJAHgKAAQgTAAgKgPgAgTgcQgGAKAAASQAAASAGAKQAGALALAAQAJAAAGgKQAGgLAAgTQAAgRgGgKQgGgKgKAAQgKAAgGAKg");
	this.shape_521.setTransform(1119.1,163.4);

	this.shape_522 = new cjs.Shape();
	this.shape_522.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_522.setTransform(1109.1,163.3);

	this.shape_523 = new cjs.Shape();
	this.shape_523.graphics.f("#39454A").s().p("AgIAaIAAhAIgcAAIAAgPIBJAAIAAAPIgdAAIAAA/QAAANAHAAQAEAAAEgCIAEANQgHAFgJAAQgTAAAAgcg");
	this.shape_523.setTransform(1099.2,163.4);

	this.shape_524 = new cjs.Shape();
	this.shape_524.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_524.setTransform(1090,163.3);

	this.shape_525 = new cjs.Shape();
	this.shape_525.graphics.f("#39454A").s().p("AARA1IgegtIgIAAIAAAtIgRAAIAAhpIARAAIAAAtIAGAAIAfgtIAUAAIgkAzIAnA2g");
	this.shape_525.setTransform(1080.3,163.3);

	this.shape_526 = new cjs.Shape();
	this.shape_526.graphics.f("#39454A").s().p("AAHA/IAHgJIABgIQAAgEgDgCQgDgDgGgCQglgJgCgkIAAgJQAAgOAFgNQAFgLAIgIQAJgGALAAQAQAAAJAKQAKAKAAATIgQAAQAAgMgGgGQgEgGgJAAQgJgBgGALQgGALAAARIAAAEQAAAYAYAKIAMAEQAHADAEAEQADAFABAHQgBAHgEAIQgEAIgHAGg");
	this.shape_526.setTransform(1065.6,165.1);

	this.shape_527 = new cjs.Shape();
	this.shape_527.graphics.f("#39454A").s().p("AgLAuQgEgHAAgOIAAhNIAPAAIAABPQABALAIAAQAFAAACgBIAAAPQgFABgHAAQgJAAgGgHg");
	this.shape_527.setTransform(1058.4,163.4);

	this.shape_528 = new cjs.Shape();
	this.shape_528.graphics.f("#39454A").s().p("AgaAuQgKgIAAgPQAAgSAQgGQgHgDgEgGQgEgGAAgHQAAgPAKgIQAJgIAQAAQAPAAALAJQAKAJAAAOIgSAAQAAgHgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAHQAAAQASAAIAQAAIAAANIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJg");
	this.shape_528.setTransform(1050.2,163.3);

	this.shape_529 = new cjs.Shape();
	this.shape_529.graphics.f("#39454A").s().p("AglBKIAAhgQAAgQAEgLQAFgMAJgGQAIgGALAAQASAAAKAPQAKAPAAAdQAAAWgJANQgKAPgQAAQgOAAgIgLIAAAxgAgPgwQgEALAAAQIAAAcQAFANAOABQAJAAAGgJQAFgKAAgSQAAgVgFgLQgFgLgKABQgJgBgGALg");
	this.shape_529.setTransform(1040.7,165.3);

	this.shape_530 = new cjs.Shape();
	this.shape_530.graphics.f("#39454A").s().p("AgIAaIAAhAIgcAAIAAgPIBJAAIAAAPIgdAAIAAA/QAAANAHAAQAEAAAEgCIAEANQgHAFgJAAQgTAAAAgcg");
	this.shape_530.setTransform(1030.9,163.4);

	this.shape_531 = new cjs.Shape();
	this.shape_531.graphics.f("#39454A").s().p("AgaAuQgKgIAAgPQAAgSAQgGQgHgDgEgGQgEgGAAgHQAAgPAKgIQAJgIAQAAQAPAAALAJQAKAJAAAOIgSAAQAAgHgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAHQAAAQASAAIAQAAIAAANIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJg");
	this.shape_531.setTransform(1247,139.3);

	this.shape_532 = new cjs.Shape();
	this.shape_532.graphics.f("#39454A").s().p("AgfAnQgLgPAAgYIAAgBQAAgXALgOQAKgPATAAIAtAAIAAAPIgWAAQAPAPAAAZIAAACQAAANgFAMQgFAMgJAGQgJAHgKAAQgTAAgKgPgAgTgcQgGAKAAASQAAASAGAKQAGALALAAQAJAAAGgKQAGgLAAgTQAAgRgGgKQgGgKgKAAQgKAAgGAKg");
	this.shape_532.setTransform(1237.7,139.4);

	this.shape_533 = new cjs.Shape();
	this.shape_533.graphics.f("#39454A").s().p("AgaAuQgKgIAAgPQAAgSAQgGQgHgDgEgGQgEgGAAgHQAAgPAKgIQAJgIAQAAQAPAAALAJQAKAJAAAOIgSAAQAAgHgFgFQgFgFgIAAQgIAAgFAEQgFAFAAAHQAAAQASAAIAQAAIAAANIgRAAQgSAAAAARQAAAHAFAFQAGAFAIAAQAIAAAGgFQAGgGAAgHIARAAQAAAPgKAJQgLAJgQAAQgQAAgKgJg");
	this.shape_533.setTransform(1223.1,139.3);

	this.shape_534 = new cjs.Shape();
	this.shape_534.graphics.f("#39454A").s().p("AgiBJIAAiRIARAAIAAA/QAAAOADAHQAEAIAJAAQAOAAAFgNIAAhPIASAAIAABpIgQAAIgBgKQgHALgMABQgMgBgFgGIAAAtg");
	this.shape_534.setTransform(1213.4,141.4);

	this.shape_535 = new cjs.Shape();
	this.shape_535.graphics.f("#39454A").s().p("AgbArQgIgLAAgVIAAhAIARAAIAAA+QAAAeAPAAQAJAAAGgMQAHgNAAgQQAAgWgKgdIASAAQAJAXAAAcQABAZgLAPQgLAQgRAAQgRAAgIgLg");
	this.shape_535.setTransform(1203.8,139.4);

	this.shape_536 = new cjs.Shape();
	this.shape_536.graphics.f("#39454A").s().p("AgcAqQgMgNAAgWIAAgLQAAgXALgNQALgOASAAQASAAALANQALANABAXIAAAKQAAAXgLANQgLAOgTAAQgRAAgLgNgAgQgeQgHAKAAAQIAAAJQAAAQAHAKQAGAJAKAAQAXAAAAghIAAgLQAAgQgGgKQgGgJgLAAQgKAAgGAJg");
	this.shape_536.setTransform(1193.8,139.3);

	this.shape_537 = new cjs.Shape();
	this.shape_537.graphics.f("#39454A").s().p("AARA1IgegtIgIAAIAAAtIgRAAIAAhpIARAAIAAAtIAGAAIAfgtIAUAAIgkAzIAnA2g");
	this.shape_537.setTransform(1184.3,139.3);

	this.shape_538 = new cjs.Shape();
	this.shape_538.graphics.f("#39454A").s().p("AgfAnQgLgPAAgYIAAgBQAAgXALgOQAKgPATAAIAtAAIAAAPIgWAAQAPAPAAAZIAAACQAAANgFAMQgFAMgJAGQgJAHgKAAQgTAAgKgPgAgTgcQgGAKAAASQAAASAGAKQAGALALAAQAJAAAGgKQAGgLAAgTQAAgRgGgKQgGgKgKAAQgKAAgGAKg");
	this.shape_538.setTransform(1174.3,139.4);

	this.shape_539 = new cjs.Shape();
	this.shape_539.graphics.f("#39454A").s().p("AgLBGQgEgHAAgOIAAhNIAQAAIAABPQAAALAJAAQAEAAACgBIAAAPQgFABgHAAQgJAAgGgHgAgNgrIAFghIAQAAIgKAhg");
	this.shape_539.setTransform(1166.5,137);

	this.shape_540 = new cjs.Shape();
	this.shape_540.graphics.f("#39454A").s().p("AglBKIAAhgQAAgPAFgMQAEgMAJgGQAIgGALAAQASAAAJAPQALAPAAAcQAAAXgJANQgKAOgPABQgOAAgKgLIAAAxgAgOgvQgGAKAAARIAAAcQAHANAMgBQAKABAGgKQAGgJAAgTQAAgUgGgKQgFgMgKAAQgJAAgFAMg");
	this.shape_540.setTransform(1158.2,141.3);

	this.shape_541 = new cjs.Shape();
	this.shape_541.graphics.f("#39454A").s().p("AgmBbIAAiOQAAgKAFgJQAFgJAJgGQAJgFAJAAQAQAAAJALQAKAKAAARQAAAJgEAIQgEAHgHAFQAJAEAFAKQAGAJAAAMQAAAUgKALQgKAMgRAAQgNAAgKgIIAAAsgAgPhEQgGAHAAALIAABQQAIAKANAAQAKAAAGgHQAGgIAAgNQAAgLgGgHQgEgJgIAAIgLAAIAAgPIAGAAQAJAAAEgFQAFgGAAgLQAAgKgFgHQgFgGgIAAQgIAAgGAHg");
	this.shape_541.setTransform(1148.1,139.3);

	this.shape_542 = new cjs.Shape();
	this.shape_542.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_542.setTransform(1133.5,139.3);

	this.shape_543 = new cjs.Shape();
	this.shape_543.graphics.f("#39454A").s().p("AgIAaIAAhAIgcAAIAAgPIBJAAIAAAPIgdAAIAAA/QAAANAHAAQAEAAAEgCIAEANQgHAFgJAAQgTAAAAgcg");
	this.shape_543.setTransform(1123.6,139.4);

	this.shape_544 = new cjs.Shape();
	this.shape_544.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_544.setTransform(1109.8,139.3);

	this.shape_545 = new cjs.Shape();
	this.shape_545.graphics.f("#39454A").s().p("AgIAaIAAhAIgcAAIAAgPIBJAAIAAAPIgdAAIAAA/QAAANAHAAQAEAAAEgCIAEANQgHAFgJAAQgTAAAAgcg");
	this.shape_545.setTransform(1099.9,139.4);

	this.shape_546 = new cjs.Shape();
	this.shape_546.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_546.setTransform(1090.7,139.3);

	this.shape_547 = new cjs.Shape();
	this.shape_547.graphics.f("#39454A").s().p("AgiBJIAAiRIAQAAIAAA/QABAOAEAHQADAIAJAAQAOAAAFgNIAAhPIARAAIAABpIgPAAIgBgKQgHALgMABQgLgBgHgGIAAAtg");
	this.shape_547.setTransform(1080.5,141.4);

	this.shape_548 = new cjs.Shape();
	this.shape_548.graphics.f("#39454A").s().p("AAAA3QgGAXgTAAQgRAAgIgPQgIgOAAgcQgBgbALgXIASAAQgLAbAAAXQgBAUAFALQAEALAJAAQAHAAAEgIQAFgIAAgQIAAgeIAQAAIAAAeQAAAQAFAIQAFAIAHAAQAJAAAEgLQAEgLAAgUQAAgXgLgbIASAAQALAXgBAbQAAAcgIAOQgJAPgQAAQgTAAgHgXgAgFgsIAEghIAQAAIgKAhg");
	this.shape_548.setTransform(1068.3,137);

	this.shape_549 = new cjs.Shape();
	this.shape_549.graphics.f("#39454A").s().p("AgfAnQgLgPAAgYIAAgBQAAgXALgOQAKgPATAAIAtAAIAAAPIgWAAQAPAPAAAZIAAACQAAANgFAMQgFAMgJAGQgJAHgKAAQgTAAgKgPgAgTgcQgGAKAAASQAAASAGAKQAGALALAAQAJAAAGgKQAGgLAAgTQAAgRgGgKQgGgKgKAAQgKAAgGAKg");
	this.shape_549.setTransform(1056.6,139.4);

	this.shape_550 = new cjs.Shape();
	this.shape_550.graphics.f("#39454A").s().p("AARAoQgJAPgPAAQgQAAgKgOQgJgOAAgZQAAgZAJgQQAKgPAQAAQAPAAAJAOIABgMIAPAAIAABNQAAAOAFAAIADgBIACANQgEAEgHAAQgMAAgDgPgAgTgcQgGALAAAVQAAASAGAJQAGAJAKAAQAMAAAGgQIAAgvQgGgQgMAAQgKAAgGALg");
	this.shape_550.setTransform(1042,139.3);

	this.shape_551 = new cjs.Shape();
	this.shape_551.graphics.f("#39454A").s().p("AgIBHIAAh+IglAAIAAgPIBbAAIAAAPIglAAIAAB+g");
	this.shape_551.setTransform(1031.6,137.5);

	this.shape_552 = new cjs.Shape();
	this.shape_552.graphics.f("#39454A").s().p("AgMA1IgdhpIAdAAIAMBCIANhCIAdAAIgdBpg");
	this.shape_552.setTransform(1136.2,115.3);

	this.shape_553 = new cjs.Shape();
	this.shape_553.graphics.f("#39454A").s().p("AAAAiQgHAUgTAAQgSAAgJgOQgKgOAAgdQAAgcANgWIAaAAQgKAagBAZQAAAhAKAAQAMAAAAgdIAAggIAcAAIAAAgQgBAdAMAAQAEAAADgJQACgJAAgPQAAgZgKgaIAaAAQAMAWAAAcQAAAdgJAOQgKAOgSAAQgSAAgIgUg");
	this.shape_553.setTransform(1124.7,115.4);

	this.shape_554 = new cjs.Shape();
	this.shape_554.graphics.f("#39454A").s().p("AgHAtQgGgJAAgRIAAgxIgbAAIAAgXIBRAAIAAAXIgcAAIAAAyQAAAGACACQABADADAAQADAAAFgCIACAWQgGADgKAAQgNAAgHgJg");
	this.shape_554.setTransform(1113,115.4);

	this.shape_555 = new cjs.Shape();
	this.shape_555.graphics.f("#39454A").s().p("AAMBAQgHAPgNAAQgQAAgKgOQgJgOAAgaQAAgZAJgOQAKgPAQAAQALAAAHAMIACgKIAZAAIAABHQAAAMAEAAIABgBIADAWQgFACgGAAQgQAAgGgPgAgMABQgDAIgBASQABAPADAHQADAHAHAAQAHAAAEgGIAAgyQgEgGgGAAQgHAAgEAHgAgIgsIAHgiIAYAAIgPAig");
	this.shape_555.setTransform(1103.7,112.9);

	this.shape_556 = new cjs.Shape();
	this.shape_556.graphics.f("#39454A").s().p("AgoBJIAAiRIAcAAIAAA8QAAAMACAGQADAFAHABQAJAAAFgJIAAhLIAbAAIAABoIgaAAIAAgFQgHAIgJgBQgGABgFgEIAAAqg");
	this.shape_556.setTransform(1093,117.4);

	this.shape_557 = new cjs.Shape();
	this.shape_557.graphics.f("#39454A").s().p("AAAAiQgIAUgSAAQgRAAgKgOQgJgOAAgdQgBgcANgWIAaAAQgKAagBAZQAAAhAKAAQALAAAAgdIAAggIAdAAIAAAgQAAAdALAAQAEAAADgJQACgJAAgPQAAgZgKgaIAaAAQAMAWAAAcQAAAdgJAOQgKAOgRAAQgTAAgIgUg");
	this.shape_557.setTransform(1080.5,115.4);

	this.shape_558 = new cjs.Shape();
	this.shape_558.graphics.f("#39454A").s().p("AggAnQgMgOAAgZIAAgBQAAgYAMgOQALgOATAAIAvAAIAAAXIgVAAQAPAOgBAUQABAXgLANQgMAOgSAAQgTAAgLgPgAgQgDIAAADQgBAfAPAAQAMAAABgZIAAgHQAAgPgDgHQgEgHgGAAQgOAAAAAbg");
	this.shape_558.setTransform(1068.5,115.4);

	this.shape_559 = new cjs.Shape();
	this.shape_559.graphics.f("#39454A").s().p("AgMA1IgdhpIAdAAIAMBCIANhCIAdAAIgdBpg");
	this.shape_559.setTransform(1054.2,115.3);

	this.shape_560 = new cjs.Shape();
	this.shape_560.graphics.f("#39454A").s().p("AAAAiQgIAUgRAAQgTAAgJgOQgKgOAAgdQAAgcANgWIAaAAQgKAaAAAZQAAAhAKAAQAKAAABgdIAAggIAbAAIAAAgQAAAdALAAQAFAAADgJQACgJAAgPQAAgZgKgaIAaAAQANAWAAAcQAAAdgKAOQgJAOgTAAQgRAAgJgUg");
	this.shape_560.setTransform(1042.7,115.4);

	this.shape_561 = new cjs.Shape();
	this.shape_561.graphics.f("#39454A").s().p("AgGAtQgIgJABgRIAAgxIgbAAIAAgXIBRAAIAAAXIgcAAIAAAyQAAAGABACQACADADAAQADAAAFgCIADAWQgHADgKAAQgNAAgGgJg");
	this.shape_561.setTransform(1031,115.4);

	this.shape_562 = new cjs.Shape();
	this.shape_562.graphics.f("#39454A").s().p("AgBA9QAGgJAAgIQAAgGgHgDQgSgGgKgMQgIgLgBgTIAAgFQAAgYAMgPQALgOASAAQARAAAKALQALALgBAUIgZAAQAAgTgMAAQgLAAgCAaIAAAHQAAANAEAFQAEAHAJADQANAEAEAEQAFACACAEQACAFAAAHQAAAHgFALQgHAJgIAGg");
	this.shape_562.setTransform(1126.1,93.1);

	this.shape_563 = new cjs.Shape();
	this.shape_563.graphics.f("#39454A").s().p("AgUAWIAAhKIAbAAIgBBHQAAAGACADQACACAFAAIAGgBIAAAWQgHACgIAAQgaAAAAgfg");
	this.shape_563.setTransform(1118.7,91.4);

	this.shape_564 = new cjs.Shape();
	this.shape_564.graphics.f("#39454A").s().p("AgcAuQgMgJAAgOQAAgSARgGQgHgDgEgGQgEgGAAgHQAAgOALgJQALgIASAAQAQAAALAJQAKAJAAAPIgbAAQAAgGgDgCQgEgDgFAAQgEAAgEADQgDADAAAFQAAAFADADQAEADAEAAIAQAAIAAASIgQAAQgMAAAAANQAAAFADAEQAEADAFAAQAGAAAEgDQADgDAAgFIAcAAQAAAPgLAJQgLAJgRAAQgSAAgMgJg");
	this.shape_564.setTransform(1110.6,91.3);

	this.shape_565 = new cjs.Shape();
	this.shape_565.graphics.f("#39454A").s().p("AghAnQgLgOAAgZIAAgBQAAgYALgOQALgOAVAAIAuAAIAAAXIgVAAQAOAOAAAUQAAAXgKANQgMAOgRAAQgUAAgMgPgAgQgDIAAADQAAAfAPAAQAKAAABgZIABgHQAAgPgDgHQgEgHgFAAQgPAAAAAbg");
	this.shape_565.setTransform(1100.7,91.4);

	this.shape_566 = new cjs.Shape();
	this.shape_566.graphics.f("#39454A").s().p("AAMBAQgHAPgNAAQgRAAgJgOQgKgOAAgaQAAgZAKgOQAJgPARAAQALAAAHAMIACgKIAZAAIAABHQgBAMAGAAIABgBIACAWQgFACgGAAQgQAAgGgPgAgMABQgDAIgBASQABAPADAHQADAHAIAAQAGAAAEgGIAAgyQgEgGgGAAQgHAAgEAHgAgIgsIAHgiIAYAAIgPAig");
	this.shape_566.setTransform(1090.8,88.9);

	this.shape_567 = new cjs.Shape();
	this.shape_567.graphics.f("#39454A").s().p("AgGAtQgIgJAAgRIAAgxIgaAAIAAgXIBRAAIAAAXIgcAAIAAAyQAAAGABACQACADADAAQADAAAFgCIADAWQgHADgKAAQgNAAgGgJg");
	this.shape_567.setTransform(1081,91.4);

	this.shape_568 = new cjs.Shape();
	this.shape_568.graphics.f("#39454A").s().p("AghAnQgLgOAAgZIAAgBQAAgYALgOQALgOAVAAIAuAAIAAAXIgVAAQAOAOAAAUQAAAXgLANQgLAOgRAAQgUAAgMgPgAgRgDIAAADQABAfAPAAQALAAAAgZIABgHQAAgPgDgHQgEgHgFAAQgPAAgBAbg");
	this.shape_568.setTransform(1071.5,91.4);

	this.shape_569 = new cjs.Shape();
	this.shape_569.graphics.f("#39454A").s().p("AAMAoQgHAPgNAAQgRAAgJgOQgKgOAAgaQAAgZAKgPQAJgPARAAQALAAAHANIACgLIAYAAIAABIQAAALAGAAIABAAIABAVQgEADgGAAQgPAAgHgPgAgMgXQgEAIAAASQAAAPAEAHQADAHAIAAQAGAAAEgHIAAgwQgEgIgGAAQgIAAgDAIg");
	this.shape_569.setTransform(1061.6,91.3);

	this.shape_570 = new cjs.Shape();
	this.shape_570.graphics.f("#39454A").s().p("AgGAtQgIgJAAgRIAAgxIgaAAIAAgXIBRAAIAAAXIgcAAIAAAyQAAAGABACQACADADAAQAEAAAEgCIACAWQgGADgKAAQgNAAgGgJg");
	this.shape_570.setTransform(1051.9,91.4);

	this.shape_571 = new cjs.Shape();
	this.shape_571.graphics.f("#39454A").s().p("AANAoQgJAPgNAAQgPAAgKgOQgKgOAAgaQAAgZAKgPQAKgPAPAAQAMAAAIANIACgLIAXAAIAABIQABALAEAAIABAAIACAVQgEADgHAAQgPAAgFgPgAgMgXQgDAIAAASQAAAPADAHQAEAHAGAAQAHAAAEgHIAAgwQgEgIgGAAQgHAAgEAIg");
	this.shape_571.setTransform(1042.6,91.3);

	this.shape_572 = new cjs.Shape();
	this.shape_572.graphics.f("#39454A").s().p("AAQBHIgZg3IgMAOIAAApIgcAAIAAiNIAcAAIAAA+IAJgQIAaguIAjAAIgoA/IApBOg");
	this.shape_572.setTransform(1032.5,89.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_572},{t:this.shape_571},{t:this.shape_570},{t:this.shape_569},{t:this.shape_568},{t:this.shape_567},{t:this.shape_566},{t:this.shape_565},{t:this.shape_564},{t:this.shape_563},{t:this.shape_562},{t:this.shape_561},{t:this.shape_560},{t:this.shape_559},{t:this.shape_558},{t:this.shape_557},{t:this.shape_556},{t:this.shape_555},{t:this.shape_554},{t:this.shape_553},{t:this.shape_552},{t:this.shape_551},{t:this.shape_550},{t:this.shape_549},{t:this.shape_548},{t:this.shape_547},{t:this.shape_546},{t:this.shape_545},{t:this.shape_544},{t:this.shape_543},{t:this.shape_542},{t:this.shape_541},{t:this.shape_540},{t:this.shape_539},{t:this.shape_538},{t:this.shape_537},{t:this.shape_536},{t:this.shape_535},{t:this.shape_534},{t:this.shape_533},{t:this.shape_532},{t:this.shape_531},{t:this.shape_530},{t:this.shape_529},{t:this.shape_528},{t:this.shape_527},{t:this.shape_526},{t:this.shape_525},{t:this.shape_524},{t:this.shape_523},{t:this.shape_522},{t:this.shape_521},{t:this.shape_520},{t:this.shape_519},{t:this.shape_518},{t:this.shape_517},{t:this.shape_516},{t:this.shape_515},{t:this.shape_514},{t:this.shape_513},{t:this.shape_512},{t:this.shape_511},{t:this.shape_510},{t:this.shape_509},{t:this.shape_508},{t:this.shape_507},{t:this.shape_506},{t:this.shape_505},{t:this.shape_504},{t:this.shape_503},{t:this.shape_502},{t:this.shape_501},{t:this.shape_500},{t:this.shape_499},{t:this.shape_498},{t:this.shape_497},{t:this.shape_496},{t:this.shape_495},{t:this.shape_494},{t:this.shape_493},{t:this.shape_492},{t:this.shape_491},{t:this.shape_490},{t:this.shape_489},{t:this.shape_488},{t:this.shape_487},{t:this.shape_486},{t:this.shape_485},{t:this.shape_484},{t:this.shape_483},{t:this.shape_482},{t:this.shape_481},{t:this.shape_480},{t:this.shape_479},{t:this.shape_478},{t:this.shape_477},{t:this.shape_476},{t:this.shape_475},{t:this.shape_474},{t:this.shape_473},{t:this.shape_472},{t:this.shape_471},{t:this.shape_470},{t:this.shape_469},{t:this.shape_468},{t:this.shape_467},{t:this.shape_466},{t:this.shape_465},{t:this.shape_464},{t:this.shape_463},{t:this.shape_462},{t:this.shape_461},{t:this.shape_460},{t:this.shape_459},{t:this.shape_458},{t:this.shape_457},{t:this.shape_456},{t:this.shape_455},{t:this.shape_454},{t:this.shape_453},{t:this.shape_452},{t:this.shape_451},{t:this.shape_450},{t:this.shape_449},{t:this.shape_448},{t:this.shape_447},{t:this.shape_446},{t:this.shape_445},{t:this.shape_444},{t:this.shape_443},{t:this.shape_442},{t:this.shape_441},{t:this.shape_440},{t:this.shape_439},{t:this.shape_438},{t:this.shape_437},{t:this.shape_436},{t:this.shape_435},{t:this.shape_434},{t:this.shape_433},{t:this.shape_432},{t:this.shape_431},{t:this.shape_430},{t:this.shape_429},{t:this.shape_428},{t:this.shape_427},{t:this.shape_426},{t:this.shape_425},{t:this.shape_424},{t:this.shape_423},{t:this.shape_422},{t:this.shape_421},{t:this.shape_420},{t:this.shape_419},{t:this.shape_418},{t:this.shape_417},{t:this.shape_416},{t:this.shape_415},{t:this.shape_414},{t:this.shape_413},{t:this.shape_412},{t:this.shape_411},{t:this.shape_410},{t:this.shape_409},{t:this.shape_408},{t:this.shape_407},{t:this.shape_406},{t:this.shape_405},{t:this.shape_404},{t:this.shape_403},{t:this.shape_402},{t:this.shape_401},{t:this.shape_400},{t:this.shape_399},{t:this.shape_398},{t:this.shape_397},{t:this.shape_396},{t:this.shape_395},{t:this.shape_394},{t:this.shape_393},{t:this.shape_392},{t:this.shape_391},{t:this.shape_390},{t:this.shape_389},{t:this.shape_388},{t:this.shape_387},{t:this.shape_386},{t:this.shape_385},{t:this.shape_384},{t:this.shape_383},{t:this.shape_382},{t:this.shape_381},{t:this.shape_380},{t:this.shape_379},{t:this.shape_378},{t:this.shape_377},{t:this.shape_376},{t:this.shape_375},{t:this.shape_374},{t:this.shape_373},{t:this.shape_372},{t:this.shape_371},{t:this.shape_370},{t:this.shape_369},{t:this.shape_368},{t:this.shape_367},{t:this.shape_366},{t:this.shape_365},{t:this.shape_364},{t:this.shape_363},{t:this.shape_362},{t:this.shape_361},{t:this.shape_360},{t:this.shape_359},{t:this.shape_358},{t:this.shape_357},{t:this.shape_356},{t:this.shape_355},{t:this.shape_354},{t:this.shape_353},{t:this.shape_352},{t:this.shape_351},{t:this.shape_350},{t:this.shape_349},{t:this.shape_348},{t:this.shape_347},{t:this.shape_346},{t:this.shape_345},{t:this.shape_344},{t:this.shape_343},{t:this.shape_342},{t:this.shape_341},{t:this.shape_340},{t:this.shape_339},{t:this.shape_338},{t:this.shape_337},{t:this.shape_336},{t:this.shape_335},{t:this.shape_334},{t:this.shape_333},{t:this.shape_332},{t:this.shape_331},{t:this.shape_330},{t:this.shape_329},{t:this.shape_328},{t:this.shape_327},{t:this.shape_326},{t:this.shape_325},{t:this.shape_324},{t:this.shape_323},{t:this.shape_322},{t:this.shape_321},{t:this.shape_320},{t:this.shape_319},{t:this.shape_318},{t:this.shape_317},{t:this.shape_316},{t:this.shape_315},{t:this.shape_314},{t:this.shape_313},{t:this.shape_312},{t:this.shape_311},{t:this.shape_310},{t:this.shape_309},{t:this.shape_308},{t:this.shape_307},{t:this.shape_306},{t:this.shape_305},{t:this.shape_304},{t:this.shape_303},{t:this.shape_302},{t:this.shape_301},{t:this.shape_300},{t:this.shape_299},{t:this.shape_298},{t:this.shape_297},{t:this.shape_296},{t:this.shape_295},{t:this.shape_294},{t:this.shape_293},{t:this.shape_292},{t:this.shape_291},{t:this.shape_290},{t:this.shape_289},{t:this.shape_288},{t:this.shape_287},{t:this.shape_286},{t:this.shape_285},{t:this.shape_284},{t:this.shape_283},{t:this.shape_282},{t:this.shape_281},{t:this.shape_280},{t:this.shape_279},{t:this.shape_278},{t:this.shape_277},{t:this.shape_276},{t:this.shape_275},{t:this.shape_274},{t:this.shape_273},{t:this.shape_272},{t:this.shape_271},{t:this.shape_270},{t:this.shape_269},{t:this.shape_268},{t:this.shape_267},{t:this.shape_266},{t:this.shape_265},{t:this.shape_264},{t:this.shape_263},{t:this.shape_262},{t:this.shape_261},{t:this.shape_260},{t:this.shape_259},{t:this.shape_258},{t:this.shape_257},{t:this.shape_256},{t:this.shape_255},{t:this.shape_254},{t:this.shape_253},{t:this.shape_252},{t:this.shape_251},{t:this.shape_250},{t:this.shape_249},{t:this.shape_248},{t:this.shape_247},{t:this.shape_246},{t:this.shape_245},{t:this.shape_244},{t:this.shape_243},{t:this.shape_242},{t:this.shape_241},{t:this.shape_240},{t:this.shape_239},{t:this.shape_238},{t:this.shape_237},{t:this.shape_236},{t:this.shape_235},{t:this.shape_234},{t:this.shape_233},{t:this.shape_232},{t:this.shape_231},{t:this.shape_230},{t:this.shape_229},{t:this.shape_228},{t:this.shape_227},{t:this.shape_226},{t:this.shape_225},{t:this.shape_224},{t:this.shape_223},{t:this.shape_222},{t:this.shape_221},{t:this.shape_220},{t:this.shape_219},{t:this.shape_218},{t:this.shape_217},{t:this.shape_216},{t:this.shape_215},{t:this.shape_214},{t:this.shape_213},{t:this.shape_212},{t:this.shape_211},{t:this.shape_210},{t:this.shape_209},{t:this.shape_208},{t:this.shape_207},{t:this.shape_206},{t:this.shape_205},{t:this.shape_204},{t:this.shape_203},{t:this.shape_202},{t:this.shape_201},{t:this.shape_200},{t:this.shape_199},{t:this.shape_198},{t:this.shape_197},{t:this.shape_196},{t:this.shape_195},{t:this.shape_194},{t:this.shape_193},{t:this.shape_192},{t:this.shape_191},{t:this.shape_190},{t:this.shape_189},{t:this.shape_188},{t:this.shape_187},{t:this.shape_186},{t:this.shape_185},{t:this.shape_184},{t:this.shape_183},{t:this.shape_182},{t:this.shape_181},{t:this.shape_180},{t:this.shape_179},{t:this.shape_178},{t:this.shape_177},{t:this.shape_176},{t:this.shape_175},{t:this.shape_174},{t:this.shape_173},{t:this.shape_172},{t:this.shape_171},{t:this.shape_170},{t:this.shape_169},{t:this.shape_168},{t:this.shape_167},{t:this.shape_166},{t:this.shape_165},{t:this.shape_164},{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29}]}).wait(1));

	// Layer_2
	this.shape_573 = new cjs.Shape();
	this.shape_573.graphics.f("rgba(55,53,53,0.078)").s().p("EgjJATBMAi5gIdIAK6JIhHkKQAAhQBNhHIAAgQIAAgGIAAgzIAAgFQAgh+EdhaQFAhlHEAAQHGAAFBBlQFBBngBCPIAAA8QBDBBAABLIgGAqIgLAgIg+DpIAMdlIgBAQQAAgDgBgCQgHBOhWBDQgNBegNhIMgh4AKdQloAZkrAAQ23AAgWpRg");
	this.shape_573.setTransform(645.1,357.6);

	this.timeline.addTween(cjs.Tween.get(this.shape_573).wait(1));

	// background
	this.instance_2 = new lib.Symbol7();
	this.instance_2.parent = this;
	this.instance_2.setTransform(532.8,667.1,1.005,1.15,0,0,0,640.4,-46.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// movingparts
	this.instance_3 = new lib.gridandgrey("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(245.8,346.1,1,0.99,0,0,0,345.6,-378.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(637.7,360.3,1284.9,721);
// library properties:
lib.properties = {
	id: '3B147A20CC43444AB8DF8C7FC37D8C1F',
	width: 1280,
	height: 720,
	fps: 30,
	color: "#BDBEA7",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['3B147A20CC43444AB8DF8C7FC37D8C1F'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;
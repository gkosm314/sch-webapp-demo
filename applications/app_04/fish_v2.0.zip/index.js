(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"index_atlas_", frames: [[0,0,1826,1027],[0,1029,409,539],[1272,1029,40,35],[411,1029,511,294],[924,1029,346,202]]}
];


// symbols:



(lib.background3 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap1 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap2 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap3 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.orange_fish2 = function() {
	this.spriteSheet = ss["index_atlas_"];
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Symbol9copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.instance = new lib.orange_fish2();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.485,1.485);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol9copy3, new cjs.Rectangle(0,0,513.7,299.9), null);


(lib.Symbol9copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.instance = new lib.orange_fish2();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.485,1.485);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol9copy2, new cjs.Rectangle(0,0,513.7,299.9), null);


(lib.Symbol8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AL/k1IjHAAIg7AAIlZAAIhfAAItDAAQizAAAACyIAAA9IAADKQAACyCzAAINDAAIBfAAIFZAAIA7AAIDHAAQCzAAAAiyIAAjKIAAg9QAAiyizAAg");
	this.shape.setTransform(94.6,31);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(231,231,231,0.6)").s().p("AI4E2Ig7AAIlZAAIhfAAItDAAQizAAAAiyIAAjKIAAg9QAAiyCzAAINDAAIBfAAIFZAAIA7AAIDHAAQCzAAAACyIAAA9IAADKQAACyizAAg");
	this.shape_1.setTransform(94.6,31);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol8, new cjs.Rectangle(-1,-1,191.2,64), null);


(lib.Symbol5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(0.8).p("AnzhEIAACJAH0hEIAACJAGPhEIAACJADFhEIAACJABghEIAACJAEqhEIAACJAjIhEIAACJAmShEIAACJAkuhEIAACJAhjhEIAACJAABhEIAACJ");
	this.shape.setTransform(50,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(0.5).p("AFegfIAAA/AHCgfIAAA/AD6gfIAAA/AgwgfIAAA/ACVgfIAAA/AAwgfIAAA/AnBgfIAAA/AldgfIAAA/Aj4gfIAAA/AiUgfIAAA/");
	this.shape_1.setTransform(50.1,3.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol5, new cjs.Rectangle(-1,-7.9,102,15.8), null);


(lib.Symbol4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(253,191,68,0.176)","#E77014"],[0,0.804],-60.6,0,60.7,0).s().p("ApeBnIAAjNIS9AAIAADNg");
	this.shape.setTransform(-2.1,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol4, new cjs.Rectangle(-62.8,-10.2,121.4,20.6), null);


(lib.cloneLine = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FEFDFB").ss(1,1,1).p("ArUrUIWpAAIAAWpI2pAAg");
	this.shape.setTransform(72.5,72.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(72,198,187,0.176)").s().p("ArULVIAA2pIWpAAIAAWpg");
	this.shape_1.setTransform(72.5,72.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.cloneLine, new cjs.Rectangle(-1,-1,147,147), null);


(lib.Line = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FEFDFB").ss(1,1,1).p("ArUrUIWpAAIAAWpI2pAAg");
	this.shape.setTransform(72.5,72.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(245,54,61,0.176)").s().p("ArULVIAA2pIWpAAIAAWpg");
	this.shape_1.setTransform(72.5,72.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Line, new cjs.Rectangle(-1,-1,147,147), null);


(lib.Graph = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FEFDFB").ss(1,1,1).p("ArUrUIWpAAIAAWpI2pAAg");
	this.shape.setTransform(72.5,72.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Graph, new cjs.Rectangle(-1,-1,147,147), null);


(lib.plus_buttoncopy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FDFEFA").s().p("AigF9QhKggg6g4Qg4g6gghKQghhNABhUQgBhTAhhNQAghKA4g6QA6g4BKggQBNghBTABQBUgBBNAhQBKAgA6A4QA4A6AgBKQAhBNgBBTQABBUghBNQgfBKg6A6Qg5A4hKAgQhNAhhUgBQhTABhNghgAiVljQhFAeg2A1Qg1A2geBFQgeBIAABNQAABOAeBIQAeBFA1A2QA2A1BFAdQBIAfBNAAQBOAABIgfQBFgdA2g1QA1g2AdhFQAfhIAAhOQAAhNgfhIQgdhGg1g1Qg1g1hGgeQhIgehOAAQhNAAhIAegAgJDLQgEgEAAgGIAAizIizAAQgGAAgEgEQgEgEAAgGQAAgEAEgFQAEgEAGAAICzAAIAAizQAAgGAEgEQAEgEAFAAQAFAAAFAEQAEAEAAAGIAACzICzAAQAGAAAEAEQADAFAAAEQAAAGgDAEQgEAEgGAAIizAAIAACzQAAAGgEAEQgFADgFAAQgFAAgEgDg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#C0CA33").s().p("AiAExQg7gagugtQgtgugag7Qgag9AAhEQAAhCAag+QAag7AtguQAugtA7gaQA9gaBDAAQBDAAA+AaQA7AaAuAtQAtAuAaA7QAaA+AABCQAABEgaA9QgaA7gtAuQguAtg7AaQg+AahDAAQhDAAg9gagAjKgJQgEAFAAAEQAAAGAEAEQAEAEAGAAICzAAIAACzQAAAGAEAEQAEADAFAAQAFAAAFgDQAEgEAAgGIAAizICzAAQAGAAAEgEQADgEAAgGQAAgEgDgFQgEgEgGAAIizAAIAAizQAAgGgEgEQgFgEgFAAQgFAAgEAEQgEAEAAAGIAACzIizAAQgGAAgEAEg");

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#C0CA33").s().p("AigF9QhKggg6g4Qg4g6gghKQghhNABhUQgBhTAhhNQAghKA4g6QA6g4BKggQBNghBTABQBUgBBNAhQBKAgA6A4QA4A6AgBKQAhBNgBBTQABBUghBNQgfBKg6A6Qg5A4hKAgQhNAhhUgBQhTABhNghgAiVljQhFAeg2A1Qg1A2geBFQgeBIAABNQAABOAeBIQAeBFA1A2QA2A1BFAdQBIAfBNAAQBOAABIgfQBFgdA2g1QA1g2AdhFQAfhIAAhOQAAhNgfhIQgdhGg1g1Qg1g1hGgeQhIgehOAAQhNAAhIAegAiAExQg7gagugtQgtgugag7Qgag9AAhEQAAhCAag+QAag7AtguQAugtA7gaQA9gaBDAAQBDAAA+AaQA7AaAuAtQAtAuAaA7QAaA+AABCQAABEgaA9QgaA7gtAuQguAtg7AaQg+AahDAAQhDAAg9gagAjKgJQgEAFAAAEQAAAGAEAEQAEAEAGAAICzAAIAACzQAAAGAEAEQAEADAFAAQAFAAAFgDQAEgEAAgGIAAizICzAAQAGAAAEgEQADgEAAgGQAAgEgDgFQgEgEgGAAIizAAIAAizQAAgGgEgEQgFgEgFAAQgFAAgEAEQgEAEAAAGIAACzIizAAQgGAAgEAEg");

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgIDLQgFgEAAgGIAAizIizAAQgFAAgEgEQgFgEAAgGQAAgEAFgEQAEgFAFAAICzAAIAAizQAAgFAFgEQADgFAFAAQAGAAAEAFQAEAEAAAFIAACzICzAAQAGAAAEAFQAEAEAAAEQAAAGgEAEQgEAEgGAAIizAAIAACzQAAAGgEAEQgEAEgGAAQgFAAgDgEg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_3},{t:this.shape_2}]},2).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-41.3,-41.3,82.7,82.7);


(lib.image = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap1();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.207,0.207);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.image, new cjs.Rectangle(0,0,84.7,111.6), null);


(lib.help_text_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3F3F3F").s().p("AgcAbQgLgKAAgRQAAgPALgLQAMgLAQAAQARAAAMALQALALAAAPQAAARgLAKQgMALgRAAQgRAAgLgLg");
	this.shape.setTransform(709.9,296);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#3F3F3F").s().p("AhVCqQgbgbAAgzIAAijIBHAAIAAChQAAAyAeAAQAXAAAPgYQAQgaAAgkQgBg5gYhEIBDAAQAcA4AABFQAABDggAmQgfAmg6AAQgzAAgagbgAgchwIAShUIA/AAIgoBUg");
	this.shape_1.setTransform(689.6,280.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#3F3F3F").s().p("AhaBlQgigmAAg+IAAgDQAAgnAPgeQAPggAdgQQAcgRAlAAQA1AAAiAhQAiAgAEA5IAAARQAAA8giAmQgiAkg5AAQg4AAgigkgAgng7QgPAUAAAqQAAAlAPAUQAOAUAZAAQAaAAAOgUQAPgUAAgqQAAgkgPgVQgOgUgaAAQgZAAgOAUg");
	this.shape_2.setTransform(661.4,286.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#3F3F3F").s().p("Ag6A6IAAi+IBGAAIgBC0QAAAPAGAGQAGAHAQAAQALAAAJgCIAAA1QgTAGgXAAQhKAAgBhLg");
	this.shape_3.setTransform(639.7,286.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#3F3F3F").s().p("Ah2C5IAAjvQAAg7AhgkQAhgjA2AAQA2AAAgAlQAfAlAABDIAAADQAAA7gcAjQgcAjguAAQgnAAgZgeIAAB+gAgjhrQgMAUAAAmIAAA6QAOAXAgAAQAXAAANgTQANgRAAgqQAAgngNgVQgNgVgXAAQgVAAgNAUg");
	this.shape_4.setTransform(616.8,291.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#3F3F3F").s().p("AAoBgQgYApgrAAQguAAgbggQgcghgCg3IAAgPQAAg/AbglQAcgmAwAAQAnAAAYAkIAFgfIA9AAIAAC1QABAdARAAIAFgBIAGA1QgMAGgSAAQgtAAgQgpgAgug6QgOAVAAAsQAABJAyAAQAcAAAOgXIAAhuQgOgagbAAQgYAAgNAVg");
	this.shape_5.setTransform(589,286.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#3F3F3F").s().p("AglC+IAAhxQg/gIgigkQgigkgBg/IAAh7IBHAAIAAB4QABBJA8AOIAAjPIBGAAIAADQQBCgOAAhMQAAg0gahCIBBAAQAfA1AABBQABBBgkAmQgkAmhBAHIAABxg");
	this.shape_6.setTransform(555.5,292.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#3F3F3F").s().p("AhVBrQgbgbAAgyIAAikIBHAAIAAChQAAAzAegBQAXABAPgZQAQgZAAgkQgBg6gYhEIBDAAQAcA4AABGQAABCggAmQgfAmg6AAQgzAAgagbg");
	this.shape_7.setTransform(511.2,286.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#3F3F3F").s().p("AhaBlQgigmAAg+IAAgDQAAgnAPgeQAPggAdgQQAcgRAlAAQA1AAAiAhQAiAgAEA5IAAARQAAA8giAmQgiAkg5AAQg4AAgigkgAgng7QgPAUAAAqQAAAlAPAUQAOAUAZAAQAaAAAOgUQAPgUAAgqQAAgkgPgVQgOgUgaAAQgZAAgOAUg");
	this.shape_8.setTransform(483,286.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#3F3F3F").s().p("AgQByQgVgVAAgrIAAh/IhRAAIAAg5IDtAAIAAA5IhWAAIAAB/QAAAOAEAGQAFAHAMAAQAMAAANgEIAHA1QgVAIgZAAQglAAgTgUg");
	this.shape_9.setTransform(455.8,286.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#3F3F3F").s().p("AAsC5IAAkPQgBgpgnAAQgeAAgRAWIAAC9IhGAAIAAkHIBBAAIACAgQAeglAuAAQBSAAACBfIAAESg");
	this.shape_10.setTransform(416.3,291.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#3F3F3F").s().p("AhhBiQgjglAAg+IAAgDQABg6AhgkQAigkA6AAICLAAIAAA5Ig+AAQAqAjAAA0QAAA4ghAiQghAjg2gBQg5AAghgkgAgug6QgPATAAAnQAAAmAPAUQANATAaAAQAXAAANgTQANgUABgqQAAgjgOgSQgNgUgXAAQgZAAgOATg");
	this.shape_11.setTransform(388.4,286.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#3F3F3F").s().p("AhUCwQgigWAAgkQAAgsAygRQgVgJgMgOQgMgQAAgRQAAgjAfgUQAggVA2AAQAxAAAfAXQAfAWAAAjIhGAAQAAgMgNgHQgMgIgUAAQgTABgMAHQgMAJAAAMQAAANALAHQALAIAVAAIAuAAIAAAvIguAAQgwAAAAAfQAAAOAOAJQANAJAVAAQAWAAANgIQAOgJAAgNIBGAAQAAAlggAXQghAXgyAAQg2AAgigWgAgZhxIAShUIA/AAIgoBUg");
	this.shape_12.setTransform(360,280.2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#3F3F3F").s().p("AhXCQQgfgngBhIIAAg+QAAhJAfgoQAfgoA5AAQA4AAAgAnQAfAmABBIIAAA+QAABKgfAoQgfAog6AAQg4AAgfgngAgwAnQgBBXAxAAQAuAAADhKIABgaIhiAAgAgwgzIAAAYIBiAAIAAgMQAAgrgNgVQgMgWgZAAQgtAAgDBKg");
	this.shape_13.setTransform(331,281.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#3F3F3F").s().p("AAsC5IAAkPQgBgpgnAAQgeAAgRAWIAAC9IhGAAIAAkHIBBAAIACAgQAeglAuAAQBTAAABBfIAAESg");
	this.shape_14.setTransform(289.7,291.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#3F3F3F").s().p("AgQByQgVgVAAgrIAAh/IhSAAIAAg5IDuAAIAAA5IhXAAIAAB/QABAOAFAGQAEAHANAAQALAAAMgEIAIA1QgVAIgZAAQgkAAgUgUg");
	this.shape_15.setTransform(262.6,286.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#3F3F3F").s().p("Ag6A6IAAi+IBGAAIgBC0QAAAPAGAGQAGAHAQAAQALAAAJgCIAAA1QgTAGgXAAQhKAAgBhLg");
	this.shape_16.setTransform(229.5,286.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#3F3F3F").s().p("AAoBgQgYApgrAAQguAAgbggQgcghgCg3IAAgPQAAg/AbglQAcgmAwAAQAnAAAYAkIAFgfIA9AAIAAC1QABAdARAAIAFgBIAGA1QgMAGgSAAQgtAAgQgpgAgug6QgOAVAAAsQAABJAyAAQAcAAAOgXIAAhuQgOgagbAAQgYAAgNAVg");
	this.shape_17.setTransform(207,286.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#3F3F3F").s().p("AAkCEIg/hiIgcAAIAABiIhHAAIAAkHIBHAAIAABjIAVAAIBEhjIBZAAIhdB/IBhCIg");
	this.shape_18.setTransform(178.5,286.3);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#3F3F3F").s().p("AgqA4IAJgRQAQgeABgcIAAg3IA7AAIgBAyQAAAZgNAcQgOAbgUASg");
	this.shape_19.setTransform(842.2,241);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#3F3F3F").s().p("AAsD2IAAkPQgBgpgnAAQgeAAgRAWIAAC9IhGAAIAAkHIBBAAIACAgQAeglAuAAQBTAAABBfIAAESgAgZihIAShUIA/AAIgoBUg");
	this.shape_20.setTransform(823,225);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#3F3F3F").s().p("AgQByQgVgVAAgsIAAh+IhSAAIAAg4IDvAAIAAA4IhYAAIAAB+QABAPAFAHQAEAGANAAQALAAAMgEIAIA2QgVAHgZABQgkgBgUgUg");
	this.shape_21.setTransform(795.8,226.6);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#3F3F3F").s().p("AAsC5IAAkPQgBgpgnAAQgeAAgRAWIAAC9IhGAAIAAkHIBBAAIACAgQAeglAuAAQBSAAACBfIAAESg");
	this.shape_22.setTransform(768.7,231.1);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#3F3F3F").s().p("Ah2C5IAAjvQAAg7AhgkQAhgjA2AAQA2AAAgAlQAfAlAABDIAAADQAAA7gcAjQgcAjguAAQgnAAgZgeIAAB+gAgjhrQgMAUAAAmIAAA6QAOAXAgAAQAXAAANgTQANgRAAgqQAAgngNgVQgNgVgXAAQgVAAgNAUg");
	this.shape_23.setTransform(741,231.1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#3F3F3F").s().p("AAsC5IAAkPQgBgpgnAAQgeAAgRAWIAAC9IhHAAIAAkHIBCAAIADAgQAdglAtAAQBTAAADBfIAAESg");
	this.shape_24.setTransform(712.3,231.1);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#3F3F3F").s().p("AgQByQgVgVAAgsIAAh+IhRAAIAAg4IDuAAIAAA4IhXAAIAAB+QAAAPAEAHQAFAGAMAAQAMAAAMgEIAIA2QgVAHgZABQgkgBgUgUg");
	this.shape_25.setTransform(685.2,226.6);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#3F3F3F").s().p("AAoBhQgYAogrAAQguAAgbggQgcghgCg3IAAgPQAAg/AbglQAcgmAwAAQAnAAAYAlIAFggIA9AAIAAC1QABAdARAAIAFgBIAGA1QgMAGgSAAQgtAAgQgogAgug6QgOAVAAAsQAABJAyAAQAcAAAOgYIAAhtQgOgagbAAQgYAAgNAVg");
	this.shape_26.setTransform(658.9,226.3);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#3F3F3F").s().p("Ah2C5IAAjvQAAg7AhgkQAhgjA2AAQA2AAAgAlQAfAlAABDIAAADQAAA7gcAjQgcAjguAAQgnAAgZgeIAAB+gAgjhrQgMAUAAAmIAAA6QAOAXAgAAQAXAAANgTQANgRAAgqQAAgngNgVQgNgVgXAAQgVAAgNAUg");
	this.shape_27.setTransform(630.4,231.1);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#3F3F3F").s().p("AAoBhQgYAogrAAQguAAgbggQgcghgCg3IAAgPQAAg/AbglQAcgmAwAAQAnAAAYAlIAFggIA9AAIAAC1QABAdARAAIAFgBIAGA1QgMAGgSAAQgtAAgQgogAgug6QgOAVAAAsQAABJAyAAQAcAAAOgYIAAhtQgOgagbAAQgYAAgNAVg");
	this.shape_28.setTransform(602.6,226.3);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#3F3F3F").s().p("AAgA6IAAiIIhDAAIAADRIhGAAIAAjRIgsAAIAAg2IElAAIAAA2IgqAAIAAB+QAAAPAGAGQAFAHAQAAQALAAAKgCIAAA1QgTAGgYAAQhKAAgBhLg");
	this.shape_29.setTransform(571.7,226.4);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#3F3F3F").s().p("AhVBsQgbgcAAgzIAAiiIBHAAIAACgQAAAyAeAAQAXAAAPgYQAQgaAAgiQgBg7gYhDIBDAAQAcA3AABHQAABBggAmQgfAng6AAQgzAAgagbg");
	this.shape_30.setTransform(529.8,226.6);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#3F3F3F").s().p("AhaBkQgiglAAg/IAAgBQAAgoAPgeQAPgfAdgRQAcgRAlAAQA1AAAiAgQAiAiAEA3IAAARQAAA9giAlQgiAlg5AAQg4AAgiglgAgng7QgPAUAAApQAAAmAPAUQAOAUAZAAQAaAAAOgUQAPgTAAgrQAAglgPgUQgOgUgaAAQgZAAgOAUg");
	this.shape_31.setTransform(501.6,226.3);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#3F3F3F").s().p("AgQByQgVgVAAgsIAAh+IhSAAIAAg4IDvAAIAAA4IhYAAIAAB+QAAAPAGAHQAEAGANAAQALAAAMgEIAIA2QgVAHgZABQgkgBgUgUg");
	this.shape_32.setTransform(474.4,226.6);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#3F3F3F").s().p("AAsC5IAAkPQgBgpgnAAQgeAAgRAWIAAC9IhHAAIAAkHIBCAAIACAgQAeglAtAAQBUAAACBfIAAESg");
	this.shape_33.setTransform(434.9,231.1);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#3F3F3F").s().p("AhhBiQgiglgBg+IAAgDQAAg7AjgjQAhgjA6AAICKAAIAAA4Ig9AAQAqAjAAA0QAAA4ghAiQghAjg1AAQg5AAgiglgAgvg6QgOASAAAoQAAAmAOATQAOAVAbgBQAXABAMgVQANgTAAgrQAAgigNgTQgNgTgXAAQgaAAgOATg");
	this.shape_34.setTransform(407,226.6);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#3F3F3F").s().p("AhUCwQgigWAAgkQAAgtAygQQgVgJgMgOQgMgPAAgSQAAgjAfgVQAggUA2AAQAxAAAfAXQAfAWAAAjIhGAAQAAgLgNgIQgMgIgUABQgTAAgMAIQgMAHAAANQAAAMALAIQALAHAVAAIAuAAIAAAvIguAAQgwABAAAfQAAANAOAKQANAJAVAAQAWAAANgJQAOgIAAgNIBGAAQAAAlggAXQghAXgyAAQg2AAgigWgAgZhwIAShVIA/AAIgoBVg");
	this.shape_35.setTransform(378.6,220.2);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#3F3F3F").s().p("AhXCQQgfgngBhIIAAg+QAAhJAfgoQAfgoA5AAQA4AAAgAnQAfAmABBIIAAA+QAABKgfAoQgfAog6AAQg4AAgfgngAgxAnQABBXAwAAQAuAAADhKIAAgaIhiAAgAgxgzIAAAYIBiAAIAAgMQAAgrgMgVQgMgWgZAAQgtAAgEBKg");
	this.shape_36.setTransform(349.6,221.7);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#3F3F3F").s().p("AAsC5IAAkPQgBgpgnAAQgeAAgRAWIAAC9IhHAAIAAkHIBCAAIADAgQAdglAtAAQBTAAADBfIAAESg");
	this.shape_37.setTransform(308.3,231.1);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#3F3F3F").s().p("AgQByQgVgVAAgsIAAh+IhSAAIAAg4IDvAAIAAA4IhYAAIAAB+QAAAPAGAHQAFAGALAAQAMAAAMgEIAIA2QgVAHgZABQgkgBgUgUg");
	this.shape_38.setTransform(281.2,226.6);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#3F3F3F").s().p("AgqA4IAJgRQAQgeABgcIAAg3IA7AAIgBAyQAAAZgNAcQgOAbgUASg");
	this.shape_39.setTransform(248.6,241);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#3F3F3F").s().p("Ah2C0IAAgwIBzh7QAYgZALgTQALgTAAgRQAAgYgMgOQgMgNgVAAQgYAAgOAQQgOARAAAbIhGAAQAAghAPgbQAQgbAcgPQAcgPAkAAQA2AAAfAaQAeAbAAAwQAAAagOAbQgNAbgiAkIhQBVICYAAIAAA5g");
	this.shape_40.setTransform(229.1,221.5);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#3F3F3F").s().p("AAsCGIAAioQAAgWgKgKQgKgKgXAAQgdAAgPAZIAAC5IhGAAIAAkGIBDAAIABAeQAdgkAuAAQArABAUAYQAUAZABAxIAACpg");
	this.shape_41.setTransform(200.8,226.1);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#3F3F3F").s().p("Ag6A6IAAi+IBGAAIgBC0QAAAPAGAGQAGAHAQAAQALAAAJgCIAAA1QgTAGgXAAQhKAAgBhLg");
	this.shape_42.setTransform(166.8,226.4);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#3F3F3F").s().p("AAoBhQgYAogrAAQguAAgbggQgcghgCg3IAAgPQAAg/AbglQAcgmAwAAQAnAAAYAlIAFggIA9AAIAAC1QABAdARAAIAFgBIAGA1QgMAGgSAAQgtAAgQgogAgug6QgOAVAAAsQAABJAyAAQAcAAAOgYIAAhtQgOgagbAAQgYAAgNAVg");
	this.shape_43.setTransform(144.3,226.3);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#3F3F3F").s().p("AAkCEIg/hhIgcAAIAABhIhHAAIAAkHIBHAAIAABjIAVAAIBEhjIBZAAIhdB/IBhCIg");
	this.shape_44.setTransform(115.7,226.3);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#3F3F3F").s().p("AAHCyIAAkPIhTAaIAAg5ICSg1IAHAAIAAFjg");
	this.shape_45.setTransform(70.5,221.7);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#3F3F3F").s().p("AArCGIAAioQABgWgKgKQgKgKgWAAQgdAAgPAZIAAC5IhHAAIAAkGIBCAAIADAeQAcgkAvAAQAqABAUAYQAVAZAAAxIAACpg");
	this.shape_46.setTransform(44.7,226.1);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#3F3F3F").s().p("AgqA3IAJgQQAQgdABgdIAAg2IA7AAIgBAwQAAAbgNAbQgOAcgUARg");
	this.shape_47.setTransform(742.9,181);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#3F3F3F").s().p("AghCEIhZkHIBKAAIAwCxIAxixIBKAAIhZEHg");
	this.shape_48.setTransform(725.1,166.3);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#3F3F3F").s().p("AAgB5QgUgNgMgaQgLAagUANQgUAOgbgBQg0ABgbglQgbgkAAhGQAAhGAkg4IBDAAQgfBCgCA8QAAAqALAVQAKAXASAAQAnAAAAhHIAAhSIBJAAIAABSQAABHAnAAQATgBAKgWQAKgXAAgoQgCg8gghCIBEAAQAkA4AABGQAABGgbAkQgbAlg0gBQgbABgUgOg");
	this.shape_49.setTransform(692,166.6);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#3F3F3F").s().p("AhhBiQgjgkABg/IAAgDQAAg7AhgjQAigkA6AAICLAAIAAA5Ig/AAQArAjAAA0QAAA4ghAiQghAig2AAQg5ABghglgAgug6QgPASAAAoQAAAmAPATQANAVAaAAQAYAAANgVQAMgTABgrQAAgigOgSQgNgUgXAAQgaAAgNATg");
	this.shape_50.setTransform(657.7,166.6);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#3F3F3F").s().p("AhUCwQgigWAAgjQAAgtAygRQgVgJgMgPQgMgPAAgRQAAgjAfgVQAggUA2AAQAxAAAfAXQAfAXAAAiIhGAAQAAgLgNgIQgMgHgUgBQgTAAgMAJQgMAHAAAMQAAANALAIQALAIAVgBIAuAAIAAAwIguAAQgwAAAAAfQAAANAOAKQANAJAVAAQAWAAANgIQAOgJAAgNIBGAAQAAAmggAWQghAXgyAAQg2AAgigWgAgZhwIAShVIA/AAIgoBVg");
	this.shape_51.setTransform(629.3,160.2);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#3F3F3F").s().p("Ah1C3IAAltIBHAAIAACYQAAAeAKAPQAKAOAYAAQAjAAAOgaIAAi5IBHAAIAAEHIhCAAIgCgQQgWAVgfAAQgaAAgRgLIAABsg");
	this.shape_52.setTransform(599.4,171.4);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#3F3F3F").s().p("AhaBkQgigkAAhAIAAgBQAAgoAPgfQAPgeAdgRQAcgRAlAAQA1AAAiAhQAiAgAEA5IAAARQAAA9giAkQgiAlg5AAQg4AAgiglgAgng7QgPAUAAAqQAAAlAPAUQAOAUAZAAQAaAAAOgUQAPgTAAgrQAAgkgPgVQgOgUgaAAQgZAAgOAUg");
	this.shape_53.setTransform(557.7,166.3);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#3F3F3F").s().p("AhVCqQgbgbAAgzIAAijIBHAAIAAChQAAAyAeAAQAXAAAPgYQAQgaAAgkQgBg5gYhEIBDAAQAcA4AABFQAABDggAmQgfAmg6AAQgzAAgagbgAgchwIAShUIA/AAIgoBUg");
	this.shape_54.setTransform(530.3,160.3);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#3F3F3F").s().p("AhaCfQgjgkAAg8IAAgDQAAgnAXgdQAVgfAigJIgBgBQgugXAAgqQAAgmAbgVQAbgUAtAAQAZAAAXAGIAQAEIAAA3QgkgLgWAAQgRAAgLAGQgKAGAAALQAAATAmAOQAnAOAZAUQAaAVANAaQAMAZgBAmQABA8gjAlQgiAlg5gBQg3AAgjgjgAgmgCQgQAUAAAoQAAAmAPAUQAPAWAYAAQAZAAAQgWQAOgUAAgrQAAgbgQgWQgPgVgYgFQgYgBgOAVg");
	this.shape_55.setTransform(502.3,160.6);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#3F3F3F").s().p("AggCEIhakHIBKAAIAwCxIAxixIBKAAIhaEHg");
	this.shape_56.setTransform(463,166.3);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#3F3F3F").s().p("AAgB5QgUgNgMgaQgLAagUANQgUAOgbgBQg0ABgbglQgbgkAAhGQAAhGAkg4IBDAAQgfBCgCA8QAAAqALAVQAKAXASAAQAnAAAAhHIAAhSIBJAAIAABSQAABHAnAAQATgBAKgWQAKgXAAgoQgCg8gghCIBEAAQAkA4AABGQAABGgbAkQgbAlg0gBQgbABgUgOg");
	this.shape_57.setTransform(429.9,166.6);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#3F3F3F").s().p("AgQByQgVgVAAgrIAAh/IhSAAIAAg5IDvAAIAAA5IhXAAIAAB/QAAAOAEAHQAFAGAMAAQAMAAANgEIAHA1QgVAJgZgBQgkABgUgVg");
	this.shape_58.setTransform(396.3,166.6);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#3F3F3F").s().p("AAACYQAWgYAAgRQAAgRgZgGQg6gPgageQgbgeAAgwIAAgLQAAgnAPgeQAPgfAcgRQAbgQAkAAQAxAAAeAcQAdAcAAAvIhCAAQgBgVgKgNQgMgMgTAAQgXAAgOATQgNATgBAmIAAAHQAAAfAOAPQAOARAhAJQAhAJAOAIQANAHAIALQAGAMABARQAAATgQAZQgRAYgXAPg");
	this.shape_59.setTransform(358.1,170.6);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#3F3F3F").s().p("AAsC5IAAkPQgBgpgnAAQgeAAgRAWIAAC9IhGAAIAAkHIBBAAIADAgQAdglAtAAQBTAAACBfIAAESg");
	this.shape_60.setTransform(331,171.1);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#3F3F3F").s().p("AhhBiQgjgkABg/IAAgDQAAg7AhgjQAigkA6AAICLAAIAAA5Ig/AAQArAjAAA0QAAA4ghAiQghAig2AAQg5ABghglgAgug6QgPASAAAoQAAAmAPATQANAVAaAAQAYAAANgVQAMgTABgrQgBgigNgSQgNgUgXAAQgaAAgNATg");
	this.shape_61.setTransform(303.1,166.6);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#3F3F3F").s().p("AAoBgQgYApgrAAQguAAgbggQgcgggCg4IAAgPQAAhAAbglQAcglAwAAQAnAAAYAkIAFgfIA9AAIAAC1QABAdARAAIAFgBIAGA1QgMAGgSAAQgtAAgQgpgAgug6QgOAVAAAsQAABJAyAAQAcAAAOgXIAAhvQgOgZgbAAQgYAAgNAVg");
	this.shape_62.setTransform(275,166.3);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#3F3F3F").s().p("ABACzQgRgMgKgcIgphzIg2CiIhMAAIBdkAIgRgpQgFgNgIgEQgHgFgMAAIgOABIgBg1QARgFAWAAQAwAAARAoIBmECIAEAIQAIASANAAIAFAAIAEAAIAAA3QgKACgQAAQgbAAgSgMg");
	this.shape_63.setTransform(246.4,160.9);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#3F3F3F").s().p("AhXCQQgfgngBhIIAAg+QAAhJAfgoQAfgoA5AAQA4AAAgAnQAfAmABBIIAAA+QAABKgfAoQgfAog6AAQg4AAgfgngAgwAnQAABXAwAAQAuAAADhKIABgaIhiAAgAgwgzIAAAYIBiAAIAAgMQAAgrgNgVQgMgWgZAAQgtAAgDBKg");
	this.shape_64.setTransform(218,161.7);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#3F3F3F").s().p("AAoCdQgYApgrAAQguAAgbggQgcgggCg4IAAgPQAAhAAbglQAcglAwAAQAnAAAYAkIAFgfIA9AAIAAC1QABAdARAAIAFgBIAGA1QgMAGgSAAQgtAAgQgpgAguACQgOAVAAAtQAABJAyAAQAcAAAOgXIAAhwQgOgYgbAAQgYAAgNAUgAgXhwIAShVIA/AAIgoBVg");
	this.shape_65.setTransform(190,160.2);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#3F3F3F").s().p("Ag6A6IAAi+IBGAAIgBC0QAAAPAGAGQAGAHAQAAQALAAAJgCIAAA1QgTAGgXAAQhKAAgBhLg");
	this.shape_66.setTransform(167.5,166.4);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#3F3F3F").s().p("AhZCfQgkgkABg8IAAgDQAAgnAVgdQAXgfAggJIAAgBQgugXAAgqQAAgmAbgVQAbgUAtAAQAZAAAXAGIAQAEIAAA3QgkgLgWAAQgRAAgKAGQgLAGAAALQAAATAmAOQAmAOAaAUQAaAVAMAaQANAZAAAmQgBA8ghAlQgjAlg4gBQg4AAgigjgAgngCQgPAUAAAoQAAAmAPAUQAPAWAZAAQAZAAAOgWQAPgUAAgrQAAgbgQgWQgOgVgYgFQgZgBgPAVg");
	this.shape_67.setTransform(144.2,160.6);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#3F3F3F").s().p("AAACYQAXgYgBgRQAAgRgZgGQg5gPgbgeQgagegBgwIAAgLQAAgnAPgeQAPgfAcgRQAbgQAkAAQAyAAAdAcQAdAcAAAvIhDAAQAAgVgLgNQgKgMgUAAQgYAAgMATQgOATgBAmIAAAHQABAfAOAPQAOARAgAJQAiAJANAIQAOAHAGALQAIAMAAARQAAATgRAZQgQAYgXAPg");
	this.shape_68.setTransform(829,110.6);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#3F3F3F").s().p("AhUBzQgigWAAgkQAAgsAygQQgVgJgMgOQgMgQAAgRQAAgkAfgUQAggVA2AAQAxAAAfAXQAfAWAAAkIhGAAQAAgNgNgHQgMgIgUAAQgTABgMAHQgMAJAAANQAAANALAHQALAIAVAAIAuAAIAAAuIguAAQgwAAAAAfQAAAOAOAJQANAJAVAAQAWAAANgJQAOgIAAgNIBGAAQAAAlggAXQghAXgyAAQg2AAgigWg");
	this.shape_69.setTransform(802.3,106.3);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#3F3F3F").s().p("AgQByQgVgVAAgrIAAh/IhRAAIAAg5IDtAAIAAA5IhWAAIAAB/QAAAOAEAGQAGAHALAAQAMAAANgEIAHA1QgVAIgZAAQglAAgTgUg");
	this.shape_70.setTransform(775.1,106.6);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#3F3F3F").s().p("AAkCEIg/hiIgcAAIAABiIhHAAIAAkHIBHAAIAABjIAVAAIBEhjIBZAAIhdB/IBhCIg");
	this.shape_71.setTransform(748.4,106.3);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#3F3F3F").s().p("Ag6B3IAAi/IBGAAIgBC1QAAAPAGAGQAGAHAQAAQALAAAJgDIAAA2QgTAGgXAAQhKAAgBhLgAgthtIAShUIA/AAIgnBUg");
	this.shape_72.setTransform(725,100.4);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#3F3F3F").s().p("AhUBzQgigWAAgkQAAgsAygQQgVgJgMgOQgMgQAAgRQAAgkAfgUQAggVA2AAQAxAAAfAXQAfAWAAAkIhGAAQAAgNgNgHQgMgIgUAAQgTABgMAHQgMAJAAANQAAANALAHQALAIAVAAIAuAAIAAAuIguAAQgwAAAAAfQAAAOAOAJQANAJAVAAQAWAAANgJQAOgIAAgNIBGAAQAAAlggAXQghAXgyAAQg2AAgigWg");
	this.shape_73.setTransform(702.1,106.3);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#3F3F3F").s().p("AhaCfQgigjgBg9IAAgDQAAgnAXgdQAVgfAigJIgBgBQgugYAAgpQAAgmAbgVQAbgUAtgBQAZABAWAGIARAEIAAA3QgkgMgVAAQgSABgLAGQgKAGAAALQAAAUAmANQAnANAaAVQAZAVANAaQALAZAAAnQABA7gjAlQgiAkg5AAQg3ABgjgkgAgmgCQgQAUAAAoQAAAlAPAWQAPAUAYAAQAaAAAPgUQAOgWAAgpQAAgcgPgWQgPgWgZgFQgYAAgOAVg");
	this.shape_74.setTransform(673.9,100.6);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#3F3F3F").s().p("AAACYQAXgYgBgRQAAgRgZgGQg5gPgbgeQgagegBgwIAAgLQAAgnAPgeQAOgfAdgRQAbgQAkAAQAyAAAdAcQAdAcAAAvIhDAAQAAgVgLgNQgLgMgTAAQgYAAgMATQgOATgBAmIAAAHQABAfAOAPQAOARAgAJQAiAJANAIQAOAHAGALQAIAMAAARQAAATgRAZQgQAYgXAPg");
	this.shape_75.setTransform(634.6,110.6);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#3F3F3F").s().p("AhVBrQgbgbAAgyIAAikIBHAAIAAChQAAAzAegBQAXABAPgZQAQgZAAgkQgBg6gYhEIBDAAQAcA4AABGQAABCggAmQgfAmg6AAQgzAAgagbg");
	this.shape_76.setTransform(608.3,106.6);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#3F3F3F").s().p("AhaBlQgigmAAg+IAAgDQAAgnAPgeQAPggAdgQQAcgRAlAAQA1AAAiAgQAiAhAEA5IAAARQAAA8giAmQgiAkg5AAQg4AAgigkgAgng7QgPAUAAAqQAAAlAPAUQAOAUAZAAQAaAAAOgUQAPgUAAgqQAAgkgPgVQgOgUgaAAQgZAAgOAUg");
	this.shape_77.setTransform(580.1,106.3);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#3F3F3F").s().p("AgQByQgVgVAAgrIAAh/IhRAAIAAg5IDtAAIAAA5IhXAAIAAB/QABAOAEAGQAFAHANAAQALAAANgEIAHA1QgVAIgZAAQglAAgTgUg");
	this.shape_78.setTransform(552.9,106.6);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#3F3F3F").s().p("AAACYQAXgYgBgRQAAgRgZgGQg5gPgbgeQgagegBgwIAAgLQAAgnAPgeQAOgfAdgRQAbgQAkAAQAyAAAdAcQAdAcAAAvIhDAAQAAgVgLgNQgKgMgUAAQgYAAgMATQgOATgBAmIAAAHQABAfAOAPQAOARAgAJQAiAJANAIQAOAHAGALQAIAMAAARQAAATgRAZQgQAYgXAPg");
	this.shape_79.setTransform(514.8,110.6);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#3F3F3F").s().p("Ag6A6IAAi+IBGAAIgBC0QAAAPAGAGQAGAHAQAAQALAAAJgCIAAA1QgTAGgXAAQhKAAgBhLg");
	this.shape_80.setTransform(494.1,106.4);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#3F3F3F").s().p("AhUBzQgigWAAgkQAAgsAygQQgVgJgMgOQgMgQAAgRQAAgkAfgUQAggVA2AAQAxAAAfAXQAfAWAAAkIhGAAQAAgNgNgHQgMgIgUAAQgTABgMAHQgMAJAAANQAAANALAHQALAIAVAAIAuAAIAAAuIguAAQgwAAAAAfQAAAOAOAJQANAJAVAAQAWAAANgJQAOgIAAgNIBGAAQAAAlggAXQghAXgyAAQg2AAgigWg");
	this.shape_81.setTransform(471.3,106.3);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#3F3F3F").s().p("AATDJQAXgYAAgRQAAgRgcgHIgOgEIgvgQQgUgIgPgLQgOgMgIgRQgHgSAAgbQAAgiATgXQATgXAjgMQg0gTAAgtQAAgsAfgZQAggZA0AAQAXAAAPADQAQACAUAHIgLA3QgWgGgLgBQgKgCgMAAQgcAAgMAKQgNAJAAAPQAAAlA5AAIAjAAIAAA6IgiAAQhPAAAAA8QAAArA7AOIAkAJIASAGQApAQgBAlQAAATgQAYQgRAYgXAQg");
	this.shape_82.setTransform(444.3,106.3);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#3F3F3F").s().p("AAoCdQgYApgrAAQguAAgbggQgcghgCg3IAAgPQAAg/AbglQAcgmAwAAQAnAAAYAkIAFgfIA9AAIAAC1QABAdARAAIAFgBIAGA1QgMAGgSAAQgtAAgQgpgAguACQgOAVAAAtQAABJAyAAQAcAAAOgXIAAhvQgOgZgbAAQgYAAgNAUgAgXhxIAShUIA/AAIgoBUg");
	this.shape_83.setTransform(417.3,100.2);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#3F3F3F").s().p("ABACzQgRgMgKgcIgphyIg2CiIhMAAIBdkCIgRgoQgFgMgIgFQgHgFgMAAIgOAAIgBg0QARgFAWAAQAwAAARAoIBmEBIAEAJQAIASANAAIAFAAIAEAAIAAA3QgKACgQAAQgbAAgSgMg");
	this.shape_84.setTransform(388.7,100.9);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#3F3F3F").s().p("ABACzQgRgMgKgcIgphyIg2CiIhMAAIBdkCIgRgoQgFgMgIgFQgHgFgMAAIgOAAIgBg0QARgFAWAAQAwAAARAoIBmEBIAEAJQAIASANAAIAFAAIAEAAIAAA3QgKACgQAAQgbAAgSgMg");
	this.shape_85.setTransform(361.3,100.9);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#3F3F3F").s().p("AAoBgQgYApgrAAQguAAgbggQgcghgCg3IAAgPQAAg/AbglQAcgmAwAAQAnAAAYAkIAFgfIA9AAIAAC1QABAdARAAIAFgBIAGA1QgMAGgSAAQgtAAgQgpgAgug6QgOAVAAAsQAABJAyAAQAcAAAOgXIAAhuQgOgagbAAQgYAAgNAVg");
	this.shape_86.setTransform(334.4,106.3);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#3F3F3F").s().p("AAoBgQgYApgrAAQguAAgbggQgcghgCg3IAAgPQAAg/AbglQAcgmAwAAQAnAAAYAkIAFgfIA9AAIAAC1QABAdARAAIAFgBIAGA1QgMAGgSAAQgtAAgQgpgAgug6QgOAVAAAsQAABJAyAAQAcAAAOgXIAAhuQgOgagbAAQgYAAgNAVg");
	this.shape_87.setTransform(293.8,106.3);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#3F3F3F").s().p("AggCEIhakHIBKAAIAwCxIAxixIBKAAIhaEHg");
	this.shape_88.setTransform(266.2,106.3);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#3F3F3F").s().p("AAACYQAWgYAAgRQAAgRgZgGQg5gPgbgeQgagegBgwIAAgLQAAgnAPgeQAOgfAcgRQAcgQAkAAQAyAAAdAcQAdAcAAAvIhDAAQABgVgMgNQgKgMgUAAQgYAAgNATQgNATAAAmIAAAHQgBAfAOAPQAPARAgAJQAiAJANAIQAOAHAGALQAIAMAAARQAAATgRAZQgQAYgWAPg");
	this.shape_89.setTransform(228.5,110.6);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#3F3F3F").s().p("Ag6B3IAAi/IBGAAIgBC1QAAAPAGAGQAGAHAQAAQALAAAJgDIAAA2QgTAGgXAAQhKAAgBhLgAgthtIAShUIA/AAIgnBUg");
	this.shape_90.setTransform(207.8,100.4);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#3F3F3F").s().p("AhUBzQgigWAAgkQAAgsAygQQgVgJgMgOQgMgQAAgRQAAgkAfgUQAggVA2AAQAxAAAfAXQAfAWAAAkIhGAAQAAgNgNgHQgMgIgUAAQgTABgMAHQgMAJAAANQAAANALAHQALAIAVAAIAuAAIAAAuIguAAQgwAAAAAfQAAAOAOAJQANAJAVAAQAWAAANgJQAOgIAAgNIBGAAQAAAlggAXQghAXgyAAQg2AAgigWg");
	this.shape_91.setTransform(185,106.3);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#3F3F3F").s().p("Ah2C5IAAjvQAAg7AhgkQAhgjA2AAQA2AAAgAlQAfAlAABDIAAADQAAA7gcAjQgcAjguAAQgnAAgZgeIAAB+gAgjhrQgMAUAAAmIAAA6QAOAXAgAAQAXAAANgTQANgRAAgqQAAgngNgVQgNgVgXAAQgVAAgNAUg");
	this.shape_92.setTransform(157.2,111.1);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#3F3F3F").s().p("AhaBlQgigmAAg+IAAgDQAAgnAPgeQAPggAdgQQAcgRAlAAQA1AAAiAgQAiAhAEA5IAAARQAAA8giAmQgiAkg5AAQg4AAgigkgAgng7QgPAUAAAqQAAAlAPAUQAOAUAZAAQAaAAAOgUQAPgUAAgqQAAgkgPgVQgOgUgaAAQgZAAgOAUg");
	this.shape_93.setTransform(128.4,106.3);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#3F3F3F").s().p("AAgA6IAAiIIhDAAIAADRIhGAAIAAjRIgsAAIAAg2IElAAIAAA2IgqAAIAAB+QAAAPAGAGQAFAHAQAAQALAAAKgCIAAA1QgTAGgYAAQhKAAgBhLg");
	this.shape_94.setTransform(98.3,106.4);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#3F3F3F").s().p("AByCyIAAhhIAHinIhgEIIgxAAIhgkIIAHCnIAABhIhJAAIAAljIBgAAIBaEBIBbkBIBgAAIAAFjg");
	this.shape_95.setTransform(60.2,101.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.help_text_1, new cjs.Rectangle(22.4,70,835.2,304), null);


(lib.shape125 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AgEHqIgCgEIACgEIAEgBIAFABIACAEIgCAEIgFABgAgEHJIgCgDIACgFIAEgBIAFABIACAFIgCADQgCACgDAAgAgEGpIgCgEIACgEIAEgBIAFABIACAEIgCAEQgCACgDAAgAgEGIIgCgDIACgFIAEgBIAFABIACAFIgCADIgFACgAgEFoIgCgEIACgDIAEgCIAFACIACADIgCAEIgFACgAgEFIIgCgEIACgEIAEgBIAFABIACAEIgCAEQgCABgDAAgAgEEnIgCgDIACgFIAEgBIAFABIACAFIgCADQgCACgDAAgAgEEHIgCgEIACgEIAEgBIAFABIACAEIgCAEIgFACgAgEDmIgCgDIACgEIAEgCIAFACIACAEIgCADIgFACgAgEDGIgCgEIACgDIAEgCIAFACIACADIgCAEQgCACgDAAgAgECmIgCgEIACgEIAEgBIAFABIACAEIgCAEQgCABgDAAgAgECFIgCgDIACgFIAEgBIAFABIACAFIgCADIgFACgAgEBlIgCgEIACgDIAEgCIAFACIACADIgCAEIgFACgAgEBEIgCgDIACgEIAEgCIAFACIACAEIgCADQgCACgDAAgAgEAkIgCgEIACgDIAEgCIAFACIACADIgCAEQgCACgDAAgAgEAEIgCgEIACgDIAEgBIAFABIACADIgCAEIgFABgAgEgcIgCgDIACgEIAEgCIAFACIACAEIgCADIgFACgAgEg8IgCgEIACgDIAEgCIAFACIACADIgCAEQgCACgDAAgAgEhdIgCgDIACgEIAEgCIAFACIACAEIgCADQgCACgDAAgAgEh8IgCgFIACgDIAEgBIAFABIACADIgCAFIgFABgAgEidIgCgDIACgFIAEgBIAFABIACAFIgCADIgFABgAgEi+IgCgDIACgEIAEgCIAFACIACAEIgCADQgCACgDABgAgEjeIgCgEIACgDIAEgCIAFACIACADIgCAEQgCACgDAAgAgEj+IgCgEIACgEIAEgBIAFABIACAEIgCAEIgFABgAgEkeIgCgEIACgEIAEgBIAFABIACAEIgCAEIgFABgAgEk/IgCgDIACgFIAEgBIAFABIACAFIgCADQgCACgDAAgAgElgIgCgDIACgEIAEgCIAFACIACAEIgCADQgCACgDABgAgEl/IgCgFIACgDIAEgBIAFABIACADIgCAFIgFABgAgEmgIgCgDIACgFIAEgBIAFABIACAFIgCADIgFABgAgEnAIgCgEIACgEIAEgBIAFABIACAEIgCAEQgCACgDAAgAgEnhIgCgDIACgFIAEgBIAFABIACAFIgCADQgCACgDAAg");
	this.shape.setTransform(0,-48.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.7,-97.7,1.5,98.2);


(lib.fasa = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FFC447","#FFC447","#DE4F00"],[0,0.016,1],-240.2,-106.9,272.2,163.4).s().p("Ehj/ADlIAAnJMDH/AAAIAAHJg");
	this.shape.setTransform(640,22.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.fasa, new cjs.Rectangle(0,0,1280,45.7), null);


(lib.Symbol88copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhZDVQgqgSgfggQgggggSgpQgSgrAAgvQAAguASgrQASgqAggfQAfghAqgRQArgSAuAAQAvAAArASQAqARAfAhQAgAfASAqQASArAAAuQAAAvgSArQgSApggAgQgfAggqASQgrASgvAAQguAAgrgSgAhIisQgiAOgaAaQgaAagOAiQgPAjAAAlQAAAmAPAjQAOAiAaAaQAaAaAiAOQAjAPAlAAQAmAAAjgPQAigOAagaQAagaAOgiQAPgjAAgmQAAglgPgjQgOgigagaQgagagigOQgjgPgmAAQglAAgjAPgAgQB/QgIgGAAgNQAAgLAHgIQAIgIALAAQALAAAHAIQAIAIAAALQAAANgIAGQgIAIgKAAQgKAAgIgIgAgPA7QgGgGAAgLQAAgPAEgMQAFgKAIgIIATgTIARgPIAIgLQAEgHAAgHQAAgOgLgKQgKgKgSAAQgSAAgJAKQgJAKgHATQgGAUgQAAQgKAAgHgHQgHgHAAgIQAAgRALgRQALgRAUgMQAVgLAaAAQAbAAATAJQAUAKAKAQQALARAAATQAAAPgGALQgGALgJAJQgIAIgWASIgJAKIgGAIIgCAHIgEAMQgDASgRAAQgJAAgGgGg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol88copy2, new cjs.Rectangle(-23.1,-23.1,46.3,46.3), null);


(lib.Symbol88copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FBB940").s().p("AhZDVQgqgSgfggQgggggSgpQgSgrAAgvQAAguASgrQASgqAggfQAfghAqgRQArgSAuAAQAvAAArASQAqARAfAhQAgAfASAqQASArAAAuQAAAvgSArQgSApggAgQgfAggqASQgrASgvAAQguAAgrgSgAhIisQgiAOgaAaQgaAagOAiQgPAjAAAlQAAAmAPAjQAOAiAaAaQAaAaAiAOQAjAPAlAAQAmAAAjgPQAigOAagaQAagaAOgiQAPgjAAgmQAAglgPgjQgOgigagaQgagagigOQgjgPgmAAQglAAgjAPgAgQB/QgIgGAAgNQAAgLAHgIQAIgIALAAQALAAAHAIQAIAIAAALQAAANgIAGQgIAIgKAAQgKAAgIgIgAgPA7QgGgGAAgLQAAgPAEgMQAFgKAIgIIATgTIARgPIAIgLQAEgHAAgHQAAgOgLgKQgKgKgSAAQgSAAgJAKQgJAKgHATQgGAUgQAAQgKAAgHgHQgHgHAAgIQAAgRALgRQALgRAUgMQAVgLAaAAQAbAAATAJQAUAKAKAQQALARAAATQAAAPgGALQgGALgJAJQgIAIgWASIgJAKIgGAIIgCAHIgEAMQgDASgRAAQgJAAgGgGg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol88copy, new cjs.Rectangle(-23.1,-23.1,46.3,46.3), null);


(lib.Symbol9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.157)").s().p("Ai+C/QhQhPAAhwQAAhvBQhPQBPhQBvAAQBwAABPBQQBQBPgBBvQABBwhQBPQhPBQhwgBQhvABhPhQg");
	this.shape.setTransform(27.1,27.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol9, new cjs.Rectangle(0,0,54.1,54.1), null);


(lib.Symbol7copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Bitmap2();
	this.instance.parent = this;
	this.instance.setTransform(-20,4.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,0,1).p("ABngeIhnhDIhmBDIAACAIDNAAg");
	this.shape.setTransform(0,9.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.749)").s().p("AhmBiIAAiAIBmhDIBnBDIAACAg");
	this.shape_1.setTransform(0,9.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-20,-1,40,40.7);


(lib.Symbol7copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,0,1).p("ABngeIhnhDIhmBDIAACAIDNAAg");
	this.shape.setTransform(0,9.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.749)").s().p("AhmBiIAAiAIBmhDIBnBDIAACAg");
	this.shape_1.setTransform(0,9.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap2();
	this.instance.parent = this;
	this.instance.setTransform(-20,4.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#D7D7D7").ss(0.1,0,0,3).p("AAACWIAAkr");
	this.shape_2.setTransform(-20,25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-21,-1,41.1,42);


(lib.Symbol6copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgjAgIAjhAIAkBAg");
	this.shape.setTransform(0,3.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.6,0,7.3,6.5);


(lib.Symbol6copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgjAgIAjhAIAkBAg");
	this.shape.setTransform(0,3.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.6,0,7.3,6.5);


(lib.Symbol5_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(0.8).p("AnzhEIAACJAH0hEIAACJAGPhEIAACJADFhEIAACJABghEIAACJAEqhEIAACJAjIhEIAACJAmShEIAACJAkuhEIAACJAhjhEIAACJAABhEIAACJ");
	this.shape_2.setTransform(50,0);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(0.5).p("AFegfIAAA/AHCgfIAAA/AD6gfIAAA/AgwgfIAAA/ACVgfIAAA/AAwgfIAAA/AnBgfIAAA/AldgfIAAA/Aj4gfIAAA/AiUgfIAAA/");
	this.shape_3.setTransform(50.1,3.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol5_1, new cjs.Rectangle(-1,-7.9,102,15.8), null);


(lib.Symbol4_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(254,192,69,0.176)","#E77014"],[0,0.804],-60.6,0,60.7,0).s().p("ApeBnIAAjNIS9AAIAADNg");
	this.shape_1.setTransform(-2.1,0);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol4_1, new cjs.Rectangle(-62.8,-10.2,121.4,20.6), null);


(lib.Symbol2copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(1,1,1).p("AL/k1IjHAAIg7AAIlZAAIhfAAItDAAQizAAAACyIAAA9IAADKQAACyCzAAINDAAIBfAAIFZAAIA7AAIDHAAQCzAAAAiyIAAjKIAAg9QAAiyizAAg");
	this.shape_2.setTransform(11.4,0);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(231,231,231,0.6)").s().p("AI4E2Ig7AAIlZAAIhfAAItDAAQizAAAAizIAAjJIAAg8QAAizCzAAINDAAIBfAAIFZAAIA7AAIDHAAQCzAAAACzIAAA8IAADJQAACzizAAg");
	this.shape_3.setTransform(11.4,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol2copy, new cjs.Rectangle(-84.2,-32,191.2,64), null);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").ss(1,1,1).p("AL/k1IjHAAIg7AAIlZAAIhfAAItDAAQizAAAACyIAAA9IAADKQAACyCzAAINDAAIBfAAIFZAAIA7AAIDHAAQCzAAAAiyIAAjKIAAg9QAAiyizAAg");
	this.shape_1.setTransform(11.4,0);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(231,231,231,0.6)").s().p("AI4E2Ig7AAIlZAAIhfAAItDAAQizAAAAizIAAjJIAAg8QAAizCzAAINDAAIBfAAIFZAAIA7AAIDHAAQCzAAAACzIAAA8IAADJQAACzizAAg");
	this.shape_2.setTransform(11.4,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol2, new cjs.Rectangle(-84.2,-32,191.2,64), null);


(lib.dertg36 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgDCcQhBgCgsguQgtgvAChAQAChBAvgrQAugtBAABQBBADAsAuQAsAugBBBQgDBAgtAtQgtAqg+AAIgEAAgAhWhaQgnAjgBA1QgBA0AlAmQAjAlA0ACQA0ABAngkQAlgkABg0QABg1gjglQgkgmg1gBIgDAAQgyAAgkAjgAglBMIAcgCIABgyIAAglIghgBIABgeIA+ACIgBAxIAABBIAhACIACAcIheAEgAgDg2QgNAAgIgIQgGgIABgNQAAgMAHgJQAHgHAMABQAMAAAIAHQAGAJAAAMQAAAFgDAGQgBAFgEAFIgIAGIgHABIgDAAg");
	this.shape.setTransform(0.2,0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.161)").s().p("AgCB/Qg1gCgjglQglgmACg0QABg1AmgkQAmgkAzACQA2ABAkAmQAjAlgBA0QgBA1gmAkQglAjgzAAIgCAAgAgogOIAgAAIAAAmIAAAyIgcABIgBAeIBegDIgCgcIghgCIgBhCIABgwIg+gCgAgWhoQgHAIAAAMQgBANAHAJQAHAHANAAQAFABAFgCIAIgFQAEgFACgFQACgGABgGQAAgMgHgIQgIgHgLgBIgCAAQgLAAgHAHg");
	this.shape_1.setTransform(0.1,0.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FBB940").s().p("AgDCcQhBgCgsguQgtgvAChAQAChBAvgrQAugtBAABQBBADAsAuQAsAugBBBQgDBAgtAtQgtAqg+AAIgEAAgAhWhaQgnAjgBA1QgBA0AlAmQAjAlA0ACQA0ABAngkQAlgkABg0QABg1gjglQgkgmg1gBIgDAAQgyAAgkAjgAglBMIAcgCIABgyIAAglIghgBIABgeIA+ACIgBAxIAABBIAhACIACAcIheAEgAgDg2QgNAAgIgIQgGgIABgNQAAgMAHgJQAHgHAMABQAMAAAIAHQAGAJAAAMQAAAFgDAGQgBAFgEAFIgIAGIgHABIgDAAg");
	this.shape_2.setTransform(0.2,0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_1},{t:this.shape_2}]},2).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-15.4,-15.5,31.2,31.2);


(lib.shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#000000","rgba(0,0,0,0)"],[0,1],-4.1,0,3.8,0).s().p("EgAnA2RMAAAhshIBPAAMAAABshg");
	this.shape.setTransform(4,-347.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-694.5,8,694.5);


(lib.Symbol11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.close = new lib.plus_buttoncopy2();
	this.close.name = "close";
	this.close.parent = this;
	this.close.setTransform(690.1,180,0.859,0.859,-45,0,0,0.3,0.4);
	new cjs.ButtonHelper(this.close, 0, 1, 2, false, new lib.plus_buttoncopy2(), 3);

	this.timeline.addTween(cjs.Tween.get(this.close).wait(1));

	// Layer_1
	this.help_text_inside = new lib.help_text_1();
	this.help_text_inside.name = "help_text_inside";
	this.help_text_inside.parent = this;
	this.help_text_inside.setTransform(496.1,284.6,0.52,0.52,0,0,0,444.9,177.1);

	this.timeline.addTween(cjs.Tween.get(this.help_text_inside).wait(1));

	// Layer_3
	this.instance = new lib.Bitmap3();
	this.instance.parent = this;
	this.instance.setTransform(235.6,135.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol11, new cjs.Rectangle(235.6,129.7,511,300.1), null);


(lib.Symbol10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(1));

	// Layer_1
	this.help_text = new lib.Symbol11();
	this.help_text.name = "help_text";
	this.help_text.parent = this;
	this.help_text.setTransform(1338.1,1099.5,0.744,0.744,0,0,0,491.2,282.9);

	this.timeline.addTween(cjs.Tween.get(this.help_text).wait(1).to({x:880.1},28,cjs.Ease.sineInOut).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1148,985.5,380,223.3);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.eyes = new lib.image();
	this.eyes.name = "eyes";
	this.eyes.parent = this;
	this.eyes.setTransform(-0.6,0,1,1,0,0,0,42.4,55.8);

	this.timeline.addTween(cjs.Tween.get(this.eyes).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol1, new cjs.Rectangle(-43,-55.8,84.7,111.6), null);


(lib.sprite126 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.shape125("synched",0);
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.sprite126, new cjs.Rectangle(-0.7,-97.7,1.5,98.2), null);


(lib.Symbol13copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol88copy2();
	this.instance.parent = this;

	this.instance_1 = new lib.Symbol88copy();
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},2).wait(2));

	// Layer_2
	this.instance_2 = new lib.Symbol9();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-0.2,-0.2,0.81,0.81,0,0,0,27,27.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(4));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-23.1,-23.1,46.3,46.3);


(lib.Symbol1copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol5_1();
	this.instance.parent = this;
	this.instance.setTransform(49.9,-0.2,1,1,0,0,0,50,0);

	this.instance_1 = new lib.Symbol4_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(52.1,0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol1copy, new cjs.Rectangle(-10.7,-10,121.4,20.6), null);


(lib.Symbol1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol5();
	this.instance.parent = this;
	this.instance.setTransform(49.9,-0.2,1,1,0,0,0,50,0);

	this.instance_1 = new lib.Symbol4();
	this.instance_1.parent = this;
	this.instance_1.setTransform(52.1,0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol1_1, new cjs.Rectangle(-10.7,-10,121.4,20.6), null);


(lib.ss2copy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol6copy2();
	this.instance.parent = this;
	this.instance.setTransform(6.9,13,1,1,0,0,0,0,3.3);
	new cjs.ButtonHelper(this.instance, 0, 1, 1);

	this.instance_1 = new lib.Symbol7copy2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(6.9,13.9);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ss2copy2, new cjs.Rectangle(-13.1,9.7,40,43.8), null);


(lib.ss2copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol6copy();
	this.instance.parent = this;
	this.instance.setTransform(6.9,13,1,1,0,0,0,0,3.3);
	new cjs.ButtonHelper(this.instance, 0, 1, 1);

	this.instance_1 = new lib.Symbol7copy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(6.9,28,1,1,0,0,0,0,14.1);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ss2copy, new cjs.Rectangle(-14.2,9.7,41.1,45.2), null);


(lib.ss1copy5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ss2copy();
	this.instance.parent = this;
	this.instance.setTransform(-8.4,14.9,0.725,0.725,0,0,180,18.3,33.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ss1copy5, new cjs.Rectangle(-14.6,-2.2,29.1,32), null);


(lib.ss1copy3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ss2copy2();
	this.instance.parent = this;
	this.instance.setTransform(-8.4,14.9,0.725,0.725,0,0,180,18.3,33.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ss1copy3, new cjs.Rectangle(-14.6,-2.2,29,31.8), null);


(lib.heading2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.help_btn = new lib.Symbol13copy2();
	this.help_btn.name = "help_btn";
	this.help_btn.parent = this;
	this.help_btn.setTransform(1209.8,18.6,0.706,0.706);
	new cjs.ButtonHelper(this.help_btn, 0, 1, 2, false, new lib.Symbol13copy2(), 3);

	this.info_btn = new lib.dertg36();
	this.info_btn.name = "info_btn";
	this.info_btn.parent = this;
	this.info_btn.setTransform(1251.2,23,1.05,1.05,0,0,0,0.5,3.8);
	new cjs.ButtonHelper(this.info_btn, 0, 1, 2, false, new lib.dertg36(), 3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.info_btn},{t:this.help_btn}]}).wait(1));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AtIB5IAHggQALAEAHAAQAIgBAFgDQAGgDAAgHQAAgFgFgEQgFgDgNgDQgfgGgOgQQgOgPAAgVQAAgSAKgTQALgRATgLQAUgKAYAAQAVAAAQAFIgIAfQgOgFgNAAQgXAAgPANQgQANAAARQAAALAJAHQAIAGAVAGQAZAGALAKQALALAAARQAAAUgPAMQgPALgZAAIgYgBgEAiXAB3IAAh4IgBgYQgCgIgFgFQgGgEgIAAQgKAAgIAFQgHAGgCAKQgDAJAAASIAAA+IgjAAIAAiHIAhAAIAAAUQASgWAaAAQAQAAALAGQALAHAEAKQAEALAAAUIAACGgAYsB3IAAgwQgZgCgOgJQgPgJgFgNQgGgNAAgZIAAhDIAkAAIAABDQAAAQACAHQADAIAHAGQAHAFAKAAIAAhtIAkAAIAABtQALgBAHgEQAGgGADgIQACgHAAgQIAAhDIAkAAIAABDQAAAZgFANQgGAMgOAKQgOAJgaACIAAAwgAOWB3IAAh4IgBgYQgBgIgGgFQgFgEgJAAQgKAAgHAFQgIAGgCAKQgCAJAAASIAAA+IgkAAIAAiHIAhAAIAAAUQASgWAbAAQAQAAAKAGQALAHAEAKQAEALAAAUIAACGgAGVB3IAAi6IAjAAIAAA+QAAAQACAKQACAJAGAHQAGAFAJAAQAJAAAHgGQAHgGABgJQACgJAAgQIAAg/IAkAAIAACHIghAAIAAgRQgKAUgRgBQgSABgJgUIAABEgAkDB3IAAgwQgegEgSgUQgRgVAAgbQAAghASgTQAPgQAdAAIgIAfQgJADgEAKQgFAKAAAMQAAAOAHANQAHAMAPAFIAAg4QAAgWADgLQADgJAJgHQAJgFAPAAQAUAAAOAKQAOAJAHARQAHAPAAAQQAAAagRAUQgRAVgfAGIAAAwgAjdglQgCAFAAAVIAAA2QAcgMAAgmQAAgNgFgLQgGgKgIABQgEAAgDADgAnMB3IAAh4IgBgYQgCgIgFgFQgGgEgIAAQgKAAgIAFQgHAGgCAKQgDAJAAASIAAA+IgjAAIAAiHIAhAAIAAAUQASgWAaAAQAQAAALAGQALAHAEAKQAEALAAAUIAACGgAeZAzQgTgTAAgfQAAgfASgTQATgVAhABQAJAAANACIBGAAIAAAeIghAAQAKARAAAUQAAAdgTAVQgUAUgfAAQgfABgTgUgAezgeQgJAMAAASQAAATAJAMQAKALAOgBQAOAAAKgKQAJgLAAgUQAAgSgJgLQgJgLgPAAQgOgBgKALgAcOAqQgMAcgfAAQgZABgQgUQgQgTAAgdQAAgQAGgVQAGgUAHgNIAiAAQgQAkAAAjQAAAVAHAIQAIAKAKgBQAHABAFgFQAFgEACgGQABgHAAgNIAAgoIAkAAIAAAoQAAANABAGQACAGAFAFQAGAFAHgBQAKAAAHgJQAIgJAAgVQAAgOgFgUQgEgTgIgRIAiAAQAHANAGAUQAGAVAAAQQAAAegQASQgPAUgagBQgfAAgMgcgAVuA9QgPgIgGgPQgFgPAAgaIAAhAIAjAAIAABFQAAAZAHAHQAHAHALAAQANAAAGgIQAGgJAAgWIAAhFIAkAAIAABAQAAAagGAQQgGAOgOAJQgPAJgTgBQgVAAgOgJgAQuAxQgQgXAAgdQAAgbAQgUQAPgTAcAAQAcAAAQAaIAIgYIAfAAQgIAQgEAWQgFAXAAAJQAAALAEATQAEATAHAQIgeAAIgCgIIgFgPQgPAZgdAAQgbABgQgWgARLgeQgIALAAAUQAAASAIAMQAIALAMAAQAMAAAIgKQAIgKAAgVQAAgUgIgMQgJgKgLAAQgMAAgIALgAI6A7QgPgLAAgRQAAgXAYgKQgTgKAAgTQAAgQAMgLQAMgLAbAAQAdAAAUANIgVAXQgNgHgNAAQgIAAgFADQgEAEAAAEQAAAOAhAAIAAAbQgWAAgHADQgIAEAAAJQAAAGAFAFQAGADAHAAQAOAAASgMIAYAXQgeARgcAAQgXAAgPgLgAEQA+QgRgIgJgQQgIgRAAgWQAAgSAIgQQAJgRAQgIQAQgJAUAAQAfgBATAVQAUATAAAeQAAAfgUATQgUAVgegBQgSABgRgJgAEcgeQgKALAAATQAAAUAKALQAJAKAOAAQAOAAAKgKQAJgLAAgUQAAgTgJgLQgKgLgOABQgOgBgJALgAh7AxQgPgXAAgdQAAgbAPgUQAQgTAcAAQAbAAARAaIAHgYIAeAAQgGAQgFAWQgFAXAAAJQAAALAFATQAEATAGAQIgdAAIgDgIIgEgPQgQAZgdAAQgbABgQgWgAhegeQgIALAAAUQAAASAIAMQAIALANAAQAMAAAIgKQAHgKAAgVQAAgUgIgMQgIgKgMAAQgMAAgIALgAv/AxQgPgXAAgdQAAgbAPgUQAQgTAcAAQAbAAARAaIAHgYIAfAAQgHAQgFAWQgFAXAAAJQAAALAFATQAEATAHAQIgeAAIgDgIIgEgPQgQAZgdAAQgbABgQgWgAvigeQgIALAAAUQAAASAIAMQAIALANAAQAMAAAIgKQAHgKAAgVQAAgUgIgMQgIgKgMAAQgMAAgIALgA2KAqQgMAcgfAAQgaABgQgUQgPgTAAgdQAAgQAGgVQAGgUAHgNIAiAAQgRAkAAAjQAAAVAIAIQAHAKAKgBQAHABAGgFQAFgEABgGQACgHAAgNIAAgoIAjAAIAAAoQAAANACAGQABAGAGAFQAFAFAHgBQALAAAHgJQAHgJAAgVQAAgOgEgUQgFgTgIgRIAiAAQAIANAGAUQAGAVAAAQQAAAegQASQgQAUgagBQgeAAgMgcgA7PA7QgPgLAAgRQAAgXAYgKQgTgKAAgTQAAgQAMgLQAMgLAbAAQAdAAAUANIgVAXQgNgHgNAAQgIAAgFADQgEAEAAAEQAAAOAhAAIAAAbQgWAAgHADQgIAEAAAJQAAAGAFAFQAGADAHAAQAOAAASgMIAYAXQgeARgcAAQgXAAgPgLgA/bA7QgPgLAAgRQAAgXAYgKQgTgKAAgTQAAgQAMgLQAMgLAbAAQAdAAAUANIgVAXQgNgHgNAAQgIAAgFADQgEAEAAAEQAAAOAhAAIAAAbQgWAAgHADQgIAEAAAJQAAAGAFAFQAGADAHAAQAOAAASgMIAYAXQgeARgcAAQgXAAgPgLgATsBEIg2iHIAlAAIAhBbIAEgLIADgLIAahFIAlAAIg2CHgALUBEIg2iHIAmAAIAgBbIAEgLIAEgLIAZhFIAlAAIg1CHgACKBEIg2iHIAmAAIAgBbIAEgLIAEgLIAZhFIAlAAIg1CHgAAdBEIAAiHIAkAAIAACHgAqABEIAAhpIgjAAIAAgeIBoAAIAAAeIghAAIAABpgAxjBEIAAhpIgjAAIAAgeIBoAAIAAAeIghAAIAABpgAzlBEIg2iHIAlAAIAhBbIAEgLIADgLIAahFIAlAAIg2CHgA5DBEIAAhpIgjAAIAAgeIBoAAIAAAeIghAAIAABpgA8PBEIgXg+IgLgdIgKAcIgXA/IgkAAIAziGIgTg0IAjAAIBJC6gEggpABEIAAiSIglCSIgkAAIgliSIAACSIgjAAIAAi6IA4AAIAiB+IAih+IA4AAIAAC6gAV9hTIARgmIAoAAIgjAmgAEfhTIASgmIAoAAIgjAmgA2mhTIARgmIAoAAIgjAmg");
	this.shape.setTransform(250.5,21.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.instance = new lib.fasa();
	this.instance.parent = this;
	this.instance.setTransform(238.1,21.5,1,0.834,0,0,0,238.1,25.7);

	this.instance_1 = new lib.shadow("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(639.9,40.6,1,1.843,90,0,0,2.2,-347.2);
	this.instance_1.alpha = 0.43;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.heading2, new cjs.Rectangle(0,0,1280,46.4), null);


(lib.Symbol17copy4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.n2_text = new cjs.Text("", "15px 'Roboto'");
	this.n2_text.name = "n2_text";
	this.n2_text.lineHeight = 18;
	this.n2_text.lineWidth = 64;
	this.n2_text.parent = this;
	this.n2_text.setTransform(43.6,-35.3);

	this.lever = new lib.ss1copy3();
	this.lever.name = "lever";
	this.lever.parent = this;
	this.lever.setTransform(15,0,1,1,0,180,0);

	this.instance = new lib.Symbol1copy();
	this.instance.parent = this;

	this.defract_2 = new cjs.Text(" ", "15px 'Roboto'");
	this.defract_2.name = "defract_2";
	this.defract_2.textAlign = "center";
	this.defract_2.lineHeight = 18;
	this.defract_2.lineWidth = 34;
	this.defract_2.parent = this;
	this.defract_2.setTransform(21.6,-36.3);

	this.instance_1 = new lib.Symbol2copy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(37.7,-8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.defract_2},{t:this.instance},{t:this.lever},{t:this.n2_text}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol17copy4, new cjs.Rectangle(-46,-39.5,190.1,63), null);


(lib.Symbol17copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.n1_text = new cjs.Text("", "15px 'Roboto'");
	this.n1_text.name = "n1_text";
	this.n1_text.lineHeight = 18;
	this.n1_text.lineWidth = 57;
	this.n1_text.parent = this;
	this.n1_text.setTransform(50.9,-35.8);

	this.lever = new lib.ss1copy5();
	this.lever.name = "lever";
	this.lever.parent = this;
	this.lever.setTransform(0.1,0,1,1,0,180,0);

	this.instance = new lib.Symbol1_1();
	this.instance.parent = this;

	this.defract_1 = new cjs.Text("", "15px 'Roboto'");
	this.defract_1.name = "defract_1";
	this.defract_1.textAlign = "center";
	this.defract_1.lineHeight = 18;
	this.defract_1.lineWidth = 31;
	this.defract_1.parent = this;
	this.defract_1.setTransform(30.3,-36.2);

	this.instance_1 = new lib.Symbol2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(37.7,-8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.defract_1},{t:this.instance},{t:this.lever},{t:this.n1_text}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol17copy, new cjs.Rectangle(-46,-39.5,190.1,63), null);


// stage content:
(lib.index = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		_root = this;
		
		createjs.Touch.enable(stage);
		
		var index1 = 1;
		var index2 = 1.300000;
		
		
		_root.value1_slider.n1_text.text = index1;
		_root.value2_slider.n2_text.text = index2;
		
		var N = 2;
		var diktis1 = String.fromCharCode(8321);
		var diktis2 = String.fromCharCode(8322);
		var moires = String.fromCharCode(186);
		var proto_kommati1 = new createjs.Shape();
		var Line_mc = new lib.Line();
		var cloneLine_mc = new lib.cloneLine();
		var proto_kommati2 = new createjs.Shape();
		
		var X0;
		var Y0 = 352;
		var X1;
		var Y1;
		var X2;
		var Y2;
		
		_root.value1_slider.defract_1.text = "n" + diktis1 + " =";
		
		_root.value2_slider.defract_2.text = "n" + diktis2 + " =";
		
		//HELP 
		_root.help.help_text.close.on("click", function(){
			_root.help.gotoAndStop(0);
			});
			
		_root.heading.help_btn.on("click", function(){
			_root.help.gotoAndPlay(1);
			});	
			
		_root.heading.info_btn.on("click", function(){
			window.open("credits/index.html", "_blank");
			});		
		
		onLoad();
		
		function onLoad()
		{
		    drawBestPath();
		    drawClone();
			xLine();
		}
		_root.point1_mc.on("pressmove", function(evt) {
			_root.addChildAt(_root.point1_mc,_root.getNumChildren()-1);
			onPressFunc1(evt);
			onMouseMoveFuncFunc(evt);
		});
		_root.point1_mc.on("pressup", function(evt) {
			onReleaseFunc(); 
		});
		
		_root.point2_mc.on("pressmove", function(evt) {
			onPressFunc2(evt);
			onMouseMoveFuncFunc(evt);
		});
		_root.point2_mc.on("pressup", function(evt) {
			onReleaseFunc(); 
		});
		
		
		///////////////   SLIDERS1   /////////////////////////////////////////////////
		var Arxislider1=0;
		var Telosslider1=100;
		var slider1Width = Math.abs(Telosslider1-Arxislider1);
		var ArxikiThesiTouLeverOnTheRuller1=0;
		var ArxiMonadon1=0;
		var TelosMonadon1=100;
		
		_root.value1_slider.lever.x = ArxikiThesiTouLeverOnTheRuller1;
		this.value1_slider.lever.cursor = "pointer";
		this.value1_slider.lever.on("mousedown", function (e) {
			var global = _root.value1_slider.localToGlobal(this.x, this.y);
			this.offset = {'x' : global.x - e.stageX, 'y' : global.y - e.stageY};
			onPressSlider();	
		});
		
		this.value2_slider.lever.on("mousedown", function (e) {
			var global = _root.value2_slider.localToGlobal(this.x, this.y);
			this.offset = {'x' : global.x - e.stageX, 'y' : global.y - e.stageY};
			onPressSlider();
		});
		
		//TOUCHSTART
		this.value1_slider.lever.on("touchstart", function (e) {
			var global = _root.value1_slider.localToGlobal(this.x, this.y);
			this.offset = {'x' : global.x - e.stageX, 'y' : global.y - e.stageY};
			onPressSlider();	
		});
		
		this.value2_slider.lever.on("touchstart", function (e) {
			var global = _root.value2_slider.localToGlobal(this.x, this.y);
			this.offset = {'x' : global.x - e.stageX, 'y' : global.y - e.stageY};
			onPressSlider();
		});
		
		
		this.value1_slider.lever.on("pressmove", function (e) {
			force_pressed=true;
			var local = _root.value1_slider.globalToLocal(e.stageX + this.offset.x, e.stageY + this.offset.y);
		    this.x = local.x;
			if (this.x < 0) {this.x = 0};
			if (this.x > 100) {this.x = 100};
			n1 = this.x;
			index1 = 1 + n1 / 100;
		    index1 = parseFloat(index1.toFixed(4));
			_root.value1_slider.n1_text.text = index1;
			onMouseMoveFuncSlider();
			//kaneStatikousYpologismous();
		});
		
		this.value2_slider.lever.on("pressmove", function (e) {
			force_pressed=true;
			var local = _root.value2_slider.globalToLocal(e.stageX + this.offset.x, e.stageY + this.offset.y);
			this.x = local.x;
			if (this.x < 0) {this.x = 0};
			if (this.x > 100) {this.x = 100};
			n2 = this.x;
		    index2 = 1 + n2 / 100;	
			index2 = parseFloat(index2.toFixed(4));
			_root.value2_slider.n2_text.text = index2;
			onMouseMoveFuncSlider();
			//kaneStatikousYpologismous();
		});
		
		function onPressFunc1(evt)
		{
			var p = evt.currentTarget.parent.globalToLocal(evt.stageX, evt.stageY);
			//evt.currentTarget.x = p.x;	
			if(p.x < 30)
				p.x = 30;
			else if (p.x > 1250)
				p.x = 1250;
			else 
				evt.currentTarget.x = p.x;
			
			if(p.y > 322)
				p.y = 322;
			else if (p.y < 80)
				p.y = 80;	
			else 
				evt.currentTarget.y = p.y;	
		} // End of the function
		
		function onPressFunc2(evt)
		{
			var p = evt.currentTarget.parent.globalToLocal(evt.stageX, evt.stageY);
			if(p.x < 50)
				p.x = 50;
			else if (p.x > 1200)
				p.x = 1200;
			else 
				evt.currentTarget.x = p.x;
			
			if(p.y < 352)
				p.y = 352;
			else if (p.y > 650)
				p.y = 650;
			else 
				evt.currentTarget.y = p.y;	
		} // End of the function
		
		function onMouseMoveFuncFunc(evt)
		{
		    var _loc5 = this.name;
		    var _loc4 = parseInt(_loc5.slice(5, 6));
			var _loc3 = _root.globalToLocal(evt.stageX);
			var _loc2 = _root.globalToLocal(evt.stageY);
			
		    if (_loc4 == 1)
		    {
		        if (_loc2 > 180)
		        {
		            _loc2 = 180;
		        } // end if
		    } // end if
		    if (_loc4 == 2)
		    {
		        if (_loc2 < 220)
		        {
		            _loc2 = 220;
		        } // end if
		    } // end if
		    if (_loc3 >= 500)
		    {
		        _loc3 = 500;
		    } // end if
		    if (_loc3 <= 20)
		    {
		        _loc3 = 20;
		    } // end if
		    if (_loc2 < 10)
		    {
		        _loc2 = 10;
		    } // end if
		    if (_loc2 > 380)
		    {
		        _loc2 = 380;
		    } // end if
		    this._x = _loc3;
		    this._y = _loc2;
		    drawBestPath();
		    drawClone();
		    stage.update();
		} // End of the function
		
		function onReleaseFunc()
		{
		    delete this.onMouseMove;
		} // End of the function
		
		function drawClone()
		{
		    var _loc2 = (Y1 - Y0) / (X1 - X0);
		    if (isFinite(_loc2))
		    {
		        var _loc4 = Y1 - _loc2 * X1;
		        var _loc1 = _loc2 * X2 + _loc4;
		        
		    } // end if
		    _root.point2Clone_mc.x = X2;
		    _root.point2Clone_mc.y = _loc1;
		    var _loc3 = Math.atan2(Y1 - Y0, X1 - X0) * 180 / 3.141593;
		    if (_loc3 <= -90)
		    {
		        _root.point1_mc.eyes.scaleX = -1;
		        _root.point1_mc.rotation = _loc3 + 180;
		    }
		    else
		    {
		        _root.point1_mc.eyes.scaleX = 1;
		        _root.point1_mc.rotation = _loc3;
		    } // end else if
		    _root.verticalLine_mc.x = X2;
		    _root.verticalLine_mc.y = Math.max(Y2, _loc1);	
			_root.verticalLine_mc.scaleY = (Math.max(Y2, _loc1) - Y0)/_root.verticalLine_mc.nominalBounds.height;
			proto_kommati2.graphics.clear();
			proto_kommati2.graphics.beginStroke("grey", 100)
			.moveTo(_root.point1_mc.x, _root.point1_mc.y)
			//.moveTo(X0, Y0)
		    .lineTo(X2, _loc1)
			.endFill()	
			stage.addChild(proto_kommati2);	
		} // End of the function
		
		function xLine()
		{
		    var _loc1 = (Y2 - Y1) / (X2 - X1);
		    if (isFinite(_loc1))
		    {
		        var _loc3 = Y1 - _loc1 * X1;
		        var _loc2 = (Y0 - _loc3) / _loc1;
		    }
		    else
		    {
		        _loc2 = X1;
		    } // end else if
			return (_loc2);
		} // End of the function
		
		function clearGraph()
		{
			proto_kommati1.graphics.clear();
		} // End of the function
		
		function drawBestPath()
		{
		    X1 = _root.point1_mc.x;
		    Y1 = _root.point1_mc.y;
		    X2 = _root.point2_mc.x;
		    Y2 = _root.point2_mc.y;
		    clearGraph();
		    var _loc4 = Math.min(X1, X2);
		    var _loc5 = Math.max(X1, X2);
		    var _loc3 = 99999;
		    var _loc2;
		    X0 = _loc4;
		    var _loc1;
		    for (var _loc1 = _loc4; _loc1 <= _loc5; _loc1 = _loc1 + 1)
		    {
		        _loc2 = time(_loc1);
		        if (_loc2 < _loc3)
		        {
		            _loc3 = _loc2;
		            X0 = _loc1;
		        } // end if
		    } // end of for
		    for (var _loc1 = X0 - 1; _loc1 <= X0 + 1; _loc1 = _loc1 + 0.100000)
		    {
		        _loc2 = time(_loc1);
		        if (_loc2 < _loc3)
		        {
		            _loc3 = _loc2;
		            X0 = _loc1;
		        } // end if
		    } // end of for
		    for (var _loc1 = X0 - 0.100000; _loc1 <= X0 + 0.100000; _loc1 = _loc1 + 0.010000)
		    {
		        _loc2 = time(_loc1);
		        if (_loc2 < _loc3)
		        {
		            _loc3 = _loc2;
		            X0 = _loc1;
		        } // end if
		    } // end of for
		    for (var _loc1 = X0 - 0.010000; _loc1 <= X0 + 0.010000; _loc1 = _loc1 + 0.001000)
		    {
		        _loc2 = time(_loc1);
		        if (_loc2 < _loc3)
		        {
		            _loc3 = _loc2;
		            X0 = _loc1;
		        } // end if
		    } // end of for
		
		    var _loc7 = Math.sqrt((X0 - X1) * (X0 - X1) + (Y0 - Y1) * (Y0 - Y1));
		    var _loc9 = Math.asin(Math.abs(X0 - X1) / _loc7);
		    _root.sin1_txt.text = "θ" + diktis1 + "=  " + sRound(_loc9 * 180 / 3.141593, 1) + moires;
		    var _loc6 = Math.sqrt((X0 - X2) * (X0 - X2) + (Y0 - Y2) * (Y0 - Y2));
		    var _loc8 = Math.asin(Math.abs(X0 - X2) / _loc6);
		    _root.sin2_txt.text = "θ" + diktis2 + "=  " + sRound(_loc8 * 180 / 3.141593, 1) + moires;
		    _root.test_txt.text = round(index1 * Math.abs(X0 - X1) / _loc7, 2) + " = " + round(index2 * Math.abs(X0 - X2) / _loc6, 2);
			
			proto_kommati1.graphics.beginStroke("grey", 100)
		    .moveTo(X0, 352)
		    .lineTo(X2, Y2)
			.endFill()
			stage.addChild(proto_kommati1);		
		} // End of the function
		
		function time(X)
		{
		    var _loc1 = index1 * Math.sqrt((X1 - X) * (X1 - X) + (Y1 - Y0) * (Y1 - Y0));
		    _loc1 = _loc1 + index2 * Math.sqrt((X2 - X) * (X2 - X) + (Y2 - Y0) * (Y2 - Y0));
		    return (_loc1);
		} // End of the function
		
		function onPressSlider()
		{
			this.yOffset = this.y;
		    this.onMouseMove = this.onMouseMoveSlider;
		} // End of the function
		
		function onMouseMoveFuncSlider()
		{
		    //var _loc2 = this._parent._ymouse - this.yOffset;
			var _loc2 = this.y;
		    if (_loc2 > 100)
		    {
		        _loc2 = 100;
		    } // end if
		    if (_loc2 < 0)
		    {
		        _loc2 = 0;
		    } // end if
		    this.y = _loc2;
		    drawBestPath();
		    drawClone();
		    stage.update();
		} // End of the function
		
		function onReleaseSlider()
		{
		    this.y = Math.round(this.y / 10) * 10;
		    drawBestPath();
		    drawClone();
		    stage.update();	
		    //delete this.onMouseMove;
		} // End of the function
		
		
		function round(x,n)
		{
		    return (Math.round(Math.pow(10, n) * x) / Math.pow(10, n));
		}
		
		function sRound(x,n)
		{
		    var _loc6;
		    var _loc1;
		    x = Math.round(Math.pow(10, n) * x) / Math.pow(10, n);
		    var _loc2 = x.toString();
		    var _loc7 = _loc2.indexOf(".");
		    if (_loc7 != -1)
		    {
		        var _loc4 = _loc2.substr(_loc7 + 1, n);
		        _loc6 = _loc2.substr(0, _loc7);
		        var _loc5 = n - _loc4.length;
		        for (var _loc1 = 1; _loc1 <= _loc5; ++_loc1)
		        {
		            _loc4 = _loc4 + "0";
		        } // end of for
		        _loc6 = _loc6 + ("." + _loc4);
		    }
		    else
		    {
		        if (n != 0)
		        {
		            _loc2 = _loc2 + ".";
		        } // end if
		        for (var _loc1 = 1; _loc1 <= n; ++_loc1)
		        {
		            _loc2 = _loc2 + "0";
		        } // end of for
		        _loc6 = _loc2;
		    } // end else if
		    if (x == 0)
		    {
		        _loc6 = "0";
		    } // end if
		    return (_loc6);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.help = new lib.Symbol10();
	this.help.name = "help";
	this.help.parent = this;
	this.help.setTransform(669.9,-348.9,1,1,0,0,0,491.1,282.9);

	this.timeline.addTween(cjs.Tween.get(this.help).wait(1));

	// heading
	this.heading = new lib.heading2();
	this.heading.name = "heading";
	this.heading.parent = this;
	this.heading.setTransform(639.9,23.2,1,1,0,0,0,640,23.2);

	this.timeline.addTween(cjs.Tween.get(this.heading).wait(1));

	// eyes
	this.point1_mc = new lib.Symbol1();
	this.point1_mc.name = "point1_mc";
	this.point1_mc.parent = this;
	this.point1_mc.setTransform(929.7,170.6,0.708,0.708,0,0,0,-0.6,0.1);

	this.timeline.addTween(cjs.Tween.get(this.point1_mc).wait(1));

	// moires
	this.test_txt = new cjs.Text("", "11px 'Roboto'");
	this.test_txt.name = "test_txt";
	this.test_txt.textAlign = "center";
	this.test_txt.lineHeight = 13;
	this.test_txt.lineWidth = 172;
	this.test_txt.parent = this;
	this.test_txt.setTransform(104,86.7);

	this.sin2_txt = new cjs.Text("", "12px 'Roboto'");
	this.sin2_txt.name = "sin2_txt";
	this.sin2_txt.textAlign = "center";
	this.sin2_txt.lineHeight = 14;
	this.sin2_txt.lineWidth = 84;
	this.sin2_txt.parent = this;
	this.sin2_txt.setTransform(140,63);

	this.sin1_txt = new cjs.Text("", "12px 'Roboto'");
	this.sin1_txt.name = "sin1_txt";
	this.sin1_txt.textAlign = "center";
	this.sin1_txt.lineHeight = 14;
	this.sin1_txt.lineWidth = 84;
	this.sin1_txt.parent = this;
	this.sin1_txt.setTransform(60,63);

	this.instance = new lib.Symbol8();
	this.instance.parent = this;
	this.instance.setTransform(104,80,1,1,0,0,0,94.5,31);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.sin1_txt},{t:this.sin2_txt},{t:this.test_txt}]}).wait(1));

	// slider2
	this.value2_slider = new lib.Symbol17copy4();
	this.value2_slider.name = "value2_slider";
	this.value2_slider.parent = this;
	this.value2_slider.setTransform(1102.6,668.3,1,1,0,0,0,1.6,0.1);

	this.timeline.addTween(cjs.Tween.get(this.value2_slider).wait(1));

	// slider1
	this.value1_slider = new lib.Symbol17copy();
	this.value1_slider.name = "value1_slider";
	this.value1_slider.parent = this;
	this.value1_slider.setTransform(1100.9,124.6,1,1,0,0,0,1.6,0.1);

	this.timeline.addTween(cjs.Tween.get(this.value1_slider).wait(1));

	// fish
	this.verticalLine_mc = new lib.sprite126();
	this.verticalLine_mc.name = "verticalLine_mc";
	this.verticalLine_mc.parent = this;
	this.verticalLine_mc.setTransform(446.3,535,1,1.869,0,0,0,0,0.1);

	this.point2Clone_mc = new lib.Symbol9copy3();
	this.point2Clone_mc.name = "point2Clone_mc";
	this.point2Clone_mc.parent = this;
	this.point2Clone_mc.setTransform(436.5,403.7,0.234,0.234,0,0,0,193.3,181.1);
	this.point2Clone_mc.alpha = 0.52;

	this.point2_mc = new lib.Symbol9copy2();
	this.point2_mc.name = "point2_mc";
	this.point2_mc.parent = this;
	this.point2_mc.setTransform(436.3,573.9,0.234,0.234,0,0,0,192.5,182);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.point2_mc},{t:this.point2Clone_mc},{t:this.verticalLine_mc}]}).wait(1));

	// back
	this.instance_1 = new lib.background3();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-12.4,-1.9,0.712,0.712);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(627.6,358.1,1719.3,730.8);
// library properties:
lib.properties = {
	id: '18E98CA226CEB54792488DE656B834A5',
	width: 1280,
	height: 720,
	fps: 60,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/index_atlas_.png?1600673276943", id:"index_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['18E98CA226CEB54792488DE656B834A5'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;
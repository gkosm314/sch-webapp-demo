﻿To πηγαίο αρχείο είναι το αρχείο "recycle-game.story" (ανοίγει με το Articulate 3 > Story Line 3).
Μετά την εξαγωγή θα πρέπει να μετονομαστεί η σελίδα story.html σε index.html

Αλλαγές στους συντελεστές γίνονται στο αρχείο dschInfo.html

Η αρχική έκδοση του ΜΑ (V 1.0) δημιουργήθηκε με Adobe Director (Shockwave).